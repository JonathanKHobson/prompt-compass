# Prompt Compass Claude Plugin

This plugin bundles:

- the Prompt Compass skill instructions
- a plugin-local Prompt Compass MCP server
- `.mcp.json` configuration for that MCP server

Use `prompt-compass-plugin.zip` when a Claude host asks for a custom
plugin package. Use `prompt-compass-0.1.0.mcpb` when Claude Desktop asks
for a Desktop Extension.

First smoke test after enabling the plugin:

```text
Use Prompt Compass and call get_started.
```

Expected warning: Claude may warn that this plugin includes local
software or MCP access. That is expected. Install only if you trust the
source.

Agent Mode remains explicit opt-in. The plugin does not silently spawn
agents or bypass host permissions.
