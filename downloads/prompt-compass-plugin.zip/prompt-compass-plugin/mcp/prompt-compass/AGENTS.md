# Prompt Compass Agent Guidance

This file is the shared operating guide for agents working on Prompt Compass.
Use it for Codex, Claude Code, future skill packaging, and plugin-side agents.
It is not a general agent manifesto; it exists to keep Prompt Compass shippable.

## Project Purpose

Prompt Compass is a local-first MCP for prompt diagnosis, improvement, prompt
building, preflight checks, model/surface targeting, personal overlay storage,
and approval-gated Agent Mode planning.

The product goal is practical prompt improvement for real users. Prefer stable
workflow behavior and clean packaging over new capability.

## Package Boundaries

- Shared core data is immutable and vendor-neutral.
- Personal overlay and prompt library data are user-owned runtime state.
- Packaged distributions must ship with a blank personal state.
- Do not hardcode private profile content, local vault paths, local sessions, or
  generated app-data into packaged artifacts.
- Do not mutate the core DB through personal overlay tools.

## Workflow Behavior

- Route first. If the user says "use Prompt Compass" without naming a tool, call
  `route_prompt_request` before browsing.
- Do not start rewrite/build jobs with `get_framework`, `list_frameworks`, or
  `search_prompt_patterns` unless the route explicitly permits browsing.
- Advanced flows have guided and direct lanes.
- User-facing gates should ask one question per turn unless a tool explicitly
  returns a different contract.
- If native question UI is available and Prompt Compass requires it, use native
  UI first. Prose questions are fallback only.
- If `must_pause=true`, stop and ask only the current returned question.
- Do not synthesize a final rewrite while `final_prompt_ready=false`.

## Agent Mode Boundaries

- Agent Mode is advanced-only and explicit opt-in.
- Valid trigger phrases include "Agent Mode," "multi-agent," "committee mode,"
  and "agent council."
- Do not trigger Agent Mode from generic words such as "council."
- V1 Agent Mode uses exactly three roles.
- Improve roles: `diagnostician`, `rewriter`, `judge_synthesizer`.
- Build roles: `intent_architect`, `drafter`, `judge_synthesizer`.
- Do not spawn recursive committees.
- Committee roles never ask the user questions directly.
- Use artifact-only handoff, not full transcript dumping.
- If native subagents are unavailable, disclose sequential fallback honestly.
- Committee approval does not bypass host sandboxing, MCP trust policy, or
  runtime permissions.

## Validation Commands

Run from the repo or clean release workspace:

```bash
.venv/bin/python scripts/build_prompt_compass_db.py
.venv/bin/python promotion_evals.py
.venv/bin/python preflight_surface_evals.py
.venv/bin/python preflight_efficiency_evals.py
.venv/bin/python smoke_suite.py
.venv/bin/python -m pytest
.venv/bin/python server.py --db-path db/prompt-compass.sqlite --boot-check
.venv/bin/python mcpb_launcher.py --boot-check
```

Packaging-specific checks:

```bash
.venv/bin/python scripts/check_release_clean.py dist/mcpb/prompt-compass
.venv/bin/python scripts/build_mcpb_bundle.py --pack
.venv/bin/python scripts/build_shareable_release.py
```

## File Exclusions

Never package:

- `.git/`
- `dist/`
- `.venv/`
- `.pytest_cache/`
- `__pycache__/`
- `node_modules/`
- `.env*`
- `.DS_Store`
- `._*` or `.__*`
- `*.pyc`
- `db/*.sqlite-wal`, `db/*.sqlite-shm`, or `db/*.sqlite-journal`
- personal overlay DBs
- prompt-library DBs or prompt-library private data
- private markdown mirrors
- local agent session output
- generated reports or private evaluation output

The canonical bundled DB is `db/prompt-compass.sqlite`. Treat other SQLite files
as suspect unless a release script explicitly allows them.

## MCPB Rules

- Stage the MCPB from a clean workspace, not from the active working tree.
- Use `packaging/mcpb/prompt-compass/` as the template source.
- Manifest fields must stay aligned with root `manifest.json`.
- Include only runtime-required files, core modules, selected docs/resources, and
  the canonical read-only DB.
- Inspect the `.mcpb` after packing and run the forbidden-path scanner.

## Source Zip Rules

- Build `prompt-compass-source.zip` from the same clean source used for MCPB.
- The source zip is a review/rebuild artifact, not a working-directory dump.
- Apply strict exclusions and generate SHA-256 checksums after validation.

## Skill Rules

- Shared skill package lives at `packaging/skills/prompt-compass/`.
- Skill entry file must be named `SKILL.md`.
- Reference paths must resolve exactly.
- Keep shared Prompt Compass philosophy.
- Do not ship private profile content or user-specific behavior fingerprints.
- Personal style and methodology notes belong in Prompt Compass personal overlay
  records or prompt-library items.

## Plugin Rules

- Plugin packaging is downstream of MCPB and skill validation.
- A plugin can bundle the MCP runtime, skill files, plugin metadata, install
  config, and optional agents under its own install protocol.
- Skill behavior guidance and plugin packaging instructions should not be
  conflated. Future skill and plugin contexts may each need their own
  AGENTS.md-equivalent surface.

## Release Signoff

Before public sharing:

- DB rebuild passes.
- Promotion evals pass.
- Preflight surface and efficiency evals pass.
- Smoke suite passes.
- Full pytest passes.
- Server boot check passes.
- Launcher boot check passes.
- MCPB packs and scans clean.
- Source zip validates with `unzip -t` and scans clean.
- Skill package validates and contains no private profile data.
- Plugin zip has one top-level folder and scans clean.
- Checksums match downloadable artifacts.
- Landing page contains no Critical Compass copy, fake example links, or
  unvalidated download claims.
