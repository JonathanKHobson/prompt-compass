# Prompt Compass

Prompt Compass is a local-first prompt engineering MCP that helps people diagnose, improve, build, compare, target, and reuse prompts with more structure and less guesswork.

Use Prompt Compass when the question is: **How do I turn this rough AI request into something clearer, safer, more reliable, and easier to run?**

It is built for AI users, educators, builders, researchers, and teams who need prompt help that is more practical than generic advice and more transparent than a hidden prompt rewrite.

## What The MCP Does

Prompt Compass gives a host AI a structured prompt-engineering layer. The host AI owns the conversation and final prose; Prompt Compass owns routing, prompt diagnosis, scoring, structured improvement plans, prompt-building scaffolds, model/surface targeting, catalog lookup, and the optional personal overlay.

The built-in core knowledge base is shared and protected. Personal methodology, saved prompts, preferences, and custom records belong in the writable personal overlay and should not ship in public packages.

## Tool Overview

Orientation and routing:

- `prompt_compass_overview`: product capabilities, modes, and routing rules.
- `get_started`: first-session paths for common jobs.
- `route_prompt_request`: hard-route broad requests before the host improvises.
- `list_tool_surface` and `list_catalog_categories`: browse the available surface.

Prompt workflows:

- `analyze_prompt`, `diagnose_prompt`, and `preflight_prompt`: inspect prompt quality, risks, and readiness.
- `improve_prompt`: revise an existing prompt through quick, advanced, guided, direct, or committee-style lanes.
- `build_prompt`: create a new prompt from intent.
- `compare_prompts`: compare alternatives before choosing.
- `target_prompt_to_model` and `target_prompt_to_surface`: adapt prompts for model families and product surfaces.

Knowledge and reuse:

- `search_prompt_patterns`, catalog lookup tools, and list tools expose frameworks, patterns, strategies, techniques, terms, templates, examples, and anti-patterns.
- `get_clarifying_questions`, `suggest_strategies`, and `get_model_profile` support better host questions and model-aware prompt choices.

Personal overlay:

- Personal record and prompt-library tools allow local customization without changing the shared core. Public packages should not include private overlay content.

## What To Download

- Claude Desktop Extension / MCPB: easiest local MCP install for Claude Desktop.
- Claude Code or Cowork Plugin: bundled MCP plus supporting agent/skill assets.
- Skill or Skill ZIP: lightweight prompt-only help when the MCP is unavailable.
- Source ZIP: inspect, audit, or rebuild from source.

If you only want prompt guidance, start with the skill. If you want structured local tools, use the MCPB or plugin.

## Dependencies And Optional Capabilities

- Python runtime and MCP host support are required for local MCP use.
- SQLite/FTS powers local retrieval.
- No external SaaS dependency is required for the shared core.
- Personal overlay features write local user-owned records and should be treated as private state.

## Files And Folders

- `server.py` and prompt modules: MCP tool implementation and contracts.
- `db/`, data, and support files: compiled prompt knowledge and retrieval records.
- `packaging/`: MCPB, plugin, and skill package inputs.
- `scripts/`: database builds, release packaging, validators, and public-page checks.
- `docs/`: specs, eval studio plans, examples, and release notes.
- `LOCAL_DEVELOPMENT.md`: local maintainer notes that may include machine-specific paths and should not be treated as public install instructions.

## Privacy And Safety Boundary

Prompt Compass is local-first. The shared core should remain vendor-neutral and public-safe. Saved prompts, personal records, private methodology, and user-specific profile data belong in the personal overlay and should not be included in public release assets.

## Compass Suite

Prompt Compass is part of the Compass Suite. Critical Compass focuses on reasoning and text trust. UX Heuristics Compass focuses on interface review. Research Compass, TTRPG Compass, and Job Application Compass cover adjacent specialized workflows.

Compass Suite home: https://jonathankhobson.github.io/compass-suite/

## Versioning

The package base version is `0.1.0`. Public beta tags identify release iterations. Rebuild release assets only after validators confirm manifests, Pages files, checksums, and package contents agree.

## About The Author

Jonathan Kyle Hobson is a UX researcher, product strategist, and AI tool builder with 10+ years of experience across design, storytelling, and emerging technology. He holds a master's degree in User Experience from Arizona State University.

LinkedIn: https://www.linkedin.com/in/jonathankylehobson/

Kyle created Prompt Compass to help people turn rough intent, messy drafts, and fragile AI instructions into prompts that are clearer, safer, and easier to use.

## License And Attribution

Created by Jonathan Kyle Hobson.

- Code license: AGPL-3.0-only. See `LICENSE`.
- Documentation, prompts, skills, rubrics, checklists, examples, and public methodology text: CC BY-SA 4.0. See `LICENSE-DOCS-CC-BY-SA-4.0.md`.
- Compass names, logos, author photo, and personal brand: reserved for attribution/reference use. See `BRAND-AND-ATTRIBUTION.md`.
- Redistribution notices: see `NOTICE` and `THIRD_PARTY_NOTICES.md`.

Modified versions are not official releases unless explicitly published by Jonathan Kyle Hobson.
