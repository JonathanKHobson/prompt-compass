"""Analysis helpers for Prompt Compass."""
