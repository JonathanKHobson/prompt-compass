from __future__ import annotations

import re
from typing import Any

from common import ensure_list, normalize_text


FORMAT_HINTS = ["table", "json", "yaml", "xml", "csv", "bullet", "bullets", "list", "email", "memo", "brief", "outline", "plan"]
SUCCESS_HINTS = ["usable", "ready", "first pass", "success", "what good looks like", "should include"]


def empty_prompt_contract(*, model_target: str | None = None) -> dict[str, Any]:
    return {
        "objective": "",
        "objective_source": "",
        "prompt_type": "",
        "subject_area": "general",
        "role": "",
        "audience": "",
        "context": [],
        "constraints": [],
        "steps": [],
        "output_contract": {
            "format": "",
            "success_test": "",
            "length": "",
            "sections": [],
        },
        "examples": [],
        "model_target": model_target or "",
        "assumptions": [],
    }


def _section_map(text: str) -> dict[str, str]:
    sections: dict[str, list[str]] = {}
    current = "body"
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        heading_match = re.match(r"^([A-Za-z][A-Za-z0-9 /_-]{1,40}):\s*(.*)$", line)
        if heading_match:
            current = normalize_text(heading_match.group(1)).lower()
            sections.setdefault(current, [])
            remainder = normalize_text(heading_match.group(2))
            if remainder:
                sections[current].append(remainder)
            continue
        sections.setdefault(current, []).append(line)
    return {key: normalize_text(" ".join(values)) for key, values in sections.items()}


def _extract_role(text: str) -> str:
    patterns = [
        r"\bact as (?:an?|the)\s+([^.,\n]+)",
        r"\byou are (?:an?|the)\s+([^.,\n]+)",
        r"\bas (?:an?|the)\s+([^.,\n]+),\s*(?:help|write|analyze|create|draft)",
    ]
    lowered = text.lower()
    for pattern in patterns:
        match = re.search(pattern, lowered, flags=re.IGNORECASE)
        if match:
            return normalize_text(match.group(1))
    return ""


def _extract_audience(text: str, sections: dict[str, str]) -> str:
    for key in ("audience", "for", "reader", "users"):
        if key in sections and sections[key]:
            return sections[key]
    patterns = [
        r"\baudience:\s*([A-Za-z0-9 ,/&-]{3,80})",
        r"\b(?:rewrite|write|create|draft|improve|fix|explain|summarize|prepare|tailor)\b.{0,24}\bfor ([A-Za-z0-9 ,/&-]{3,80})",
        r"\baudience is ([A-Za-z0-9 ,/&-]{3,80})",
        r"\bintended for ([A-Za-z0-9 ,/&-]{3,80})",
        r"\breader is ([A-Za-z0-9 ,/&-]{3,80})",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            value = normalize_text(match.group(1))
            lowered = value.lower()
            if (
                not lowered.startswith("example")
                and "targeting " not in lowered
                and not lowered.startswith("a saas product")
                and not lowered.startswith("saas product")
            ):
                return value
    return ""


def _extract_objective(text: str, sections: dict[str, str], user_goal: str | None = None) -> str:
    for key in ("objective", "task", "goal", "job", "request"):
        if sections.get(key):
            return sections[key]
    if user_goal:
        return normalize_text(user_goal)
    sentence_match = re.split(r"(?<=[.!?])\s+", normalize_text(text))
    for sentence in sentence_match:
        if _is_role_sentence(sentence):
            continue
        if any(token in sentence.lower() for token in ["write", "create", "build", "analyze", "summarize", "improve", "rewrite", "draft", "design"]):
            return normalize_text(sentence)
    for sentence in sentence_match:
        if not _is_role_sentence(sentence):
            return normalize_text(sentence)
    return ""


def _is_role_sentence(sentence: str) -> bool:
    lowered = normalize_text(sentence).lower()
    return bool(re.match(r"^(?:you are|act as|as an?|role:)", lowered))


def _objective_source(sections: dict[str, str], user_goal: str | None, objective: str) -> str:
    if any(sections.get(key) for key in ("objective", "task", "goal", "job", "request")):
        return "explicit"
    if user_goal and normalize_text(user_goal) == normalize_text(objective):
        return "user_goal"
    if objective:
        return "inferred"
    return ""


def _extract_context(sections: dict[str, str]) -> list[str]:
    values: list[str] = []
    for key in ("context", "background", "source", "materials", "situation"):
        if sections.get(key):
            values.append(sections[key])
    return values


def _extract_constraints(text: str, sections: dict[str, str]) -> list[str]:
    constraints: list[str] = []
    for key in ("constraints", "avoid", "rules", "must", "must not"):
        if sections.get(key):
            constraints.extend(_split_compound_items(sections[key]))
    for sentence in re.split(r"(?<=[.!?])\s+", normalize_text(text)):
        lowered = sentence.lower()
        if any(token in lowered for token in ["must ", "avoid ", "do not", "don't", "without ", "limit ", "under ", "no more than"]):
            constraints.append(sentence)
    return _dedupe(constraints)


def _extract_steps(text: str, sections: dict[str, str]) -> list[str]:
    if sections.get("steps"):
        return _split_compound_items(sections["steps"])
    steps: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if re.match(r"^\d+[.)]\s+", stripped):
            steps.append(re.sub(r"^\d+[.)]\s+", "", stripped))
    if steps:
        return _dedupe(steps)
    lowered = normalize_text(text)
    if "first" in lowered and "then" in lowered:
        return _dedupe(re.split(r"\b(?:first|then|finally|next)\b", lowered))
    return []


def _extract_examples(text: str, sections: dict[str, str]) -> list[str]:
    examples: list[str] = []
    for key in ("examples", "reference", "sample"):
        if sections.get(key):
            examples.extend(_split_compound_items(sections[key]))
    for sentence in re.split(r"(?<=[.!?])\s+", normalize_text(text)):
        if "example" in sentence.lower():
            examples.append(sentence)
    return _dedupe(examples)


def _extract_output_contract(text: str, sections: dict[str, str]) -> dict[str, Any]:
    output_contract = {"format": "", "success_test": "", "length": "", "sections": []}
    for key in ("format", "response", "output", "return"):
        if sections.get(key):
            output_contract["format"] = sections[key]
            break
    lowered = normalize_text(text).lower()
    if not output_contract["format"]:
        for hint in FORMAT_HINTS:
            if re.search(rf"\b(?:return|output|format)\b.{{0,40}}\b{re.escape(hint)}\b", lowered):
                output_contract["format"] = hint
                break
    if not output_contract["format"]:
        for hint in FORMAT_HINTS:
            if hint in lowered:
                output_contract["format"] = hint
                break
    length_match = re.search(r"\b(\d{2,4}\s*(?:words?|bullets?|sentences?|paragraphs?))\b", text, flags=re.IGNORECASE)
    if length_match:
        output_contract["length"] = normalize_text(length_match.group(1))
    for sentence in re.split(r"(?<=[.!?])\s+", normalize_text(text)):
        if any(hint in sentence.lower() for hint in SUCCESS_HINTS):
            output_contract["success_test"] = sentence
            break
    for key in ("include", "sections", "structure"):
        if sections.get(key):
            output_contract["sections"] = _split_compound_items(sections[key])
            break
    return output_contract


def _split_compound_items(text: str) -> list[str]:
    parts = re.split(r"(?:\s*[;•]\s*|\s+-\s+|\s*\|\s*|,\s+(?=[A-Za-z]))", normalize_text(text))
    return [normalize_text(part) for part in parts if normalize_text(part)]


def _dedupe(values: list[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        normalized = normalize_text(value)
        if not normalized:
            continue
        key = normalized.lower()
        if key in seen:
            continue
        seen.add(key)
        ordered.append(normalized)
    return ordered


def build_prompt_contract(
    text: str,
    *,
    user_goal: str | None = None,
    model_target: str | None = None,
    subject_area: str | None = None,
    prompt_type: str | None = None,
) -> dict[str, Any]:
    sections = _section_map(text)
    contract = empty_prompt_contract(model_target=model_target)
    contract["objective"] = _extract_objective(text, sections, user_goal=user_goal)
    contract["objective_source"] = _objective_source(sections, user_goal, contract["objective"])
    contract["role"] = _extract_role(text)
    contract["audience"] = _extract_audience(text, sections)
    contract["context"] = _extract_context(sections)
    contract["constraints"] = _extract_constraints(text, sections)
    contract["steps"] = _extract_steps(text, sections)
    contract["output_contract"] = _extract_output_contract(text, sections)
    contract["examples"] = _extract_examples(text, sections)
    contract["subject_area"] = subject_area or "general"
    contract["prompt_type"] = prompt_type or ""
    return contract


def merge_question_answers(contract: dict[str, Any], question_answers: dict[str, Any] | list[dict[str, Any]] | None) -> dict[str, Any]:
    updated = dict(contract)
    answer_map = question_answer_map(question_answers)
    if answer_map.get("objective"):
        updated["objective"] = answer_map["objective"]
    if answer_map.get("audience"):
        updated["audience"] = answer_map["audience"]
    if answer_map.get("context"):
        updated["context"] = ensure_list(answer_map["context"])
    if answer_map.get("constraints"):
        updated["constraints"] = ensure_list(answer_map["constraints"])
    if answer_map.get("examples"):
        updated["examples"] = ensure_list(answer_map["examples"])
    if answer_map.get("model_target"):
        updated["model_target"] = answer_map["model_target"]
    if answer_map.get("output_contract"):
        output_value = answer_map["output_contract"]
        if isinstance(output_value, dict):
            updated["output_contract"] = {
                **updated.get("output_contract", {}),
                **output_value,
            }
        else:
            updated["output_contract"] = {
                **updated.get("output_contract", {}),
                "format": normalize_text(output_value),
            }
    constraint_notes: list[str] = []
    context_notes: list[str] = []
    for slot, prefix in (
        ("runtime_layer", "Runtime layer"),
        ("parser_contract", "Parser contract"),
        ("evaluation", "Evaluation"),
        ("agent_control", "Agent control"),
        ("tool_use", "Tool use boundary"),
        ("source_priority", "Source priority"),
    ):
        if normalize_text(answer_map.get(slot)):
            constraint_notes.append(f"{prefix}: {normalize_text(answer_map[slot])}")
    if normalize_text(answer_map.get("grounding")):
        context_notes.append(f"Source-of-truth boundary: {normalize_text(answer_map['grounding'])}")
    if constraint_notes:
        updated["constraints"] = _dedupe([*ensure_list(updated.get("constraints")), *constraint_notes])
    if context_notes:
        updated["context"] = _dedupe([*ensure_list(updated.get("context")), *context_notes])
    return updated


def question_answer_map(question_answers: dict[str, Any] | list[dict[str, Any]] | None) -> dict[str, Any]:
    if isinstance(question_answers, dict):
        if "answers" in question_answers and isinstance(question_answers["answers"], dict):
            return {normalize_text(key).lower(): value for key, value in question_answers["answers"].items()}
        return {normalize_text(key).lower(): value for key, value in question_answers.items()}
    answer_map: dict[str, Any] = {}
    for item in ensure_list(question_answers):
        if not isinstance(item, dict):
            continue
        slot = normalize_text(item.get("slot")).lower()
        value = item.get("value", item.get("answer"))
        if slot:
            answer_map[slot] = value
    return answer_map


def contract_missing_blocks(contract: dict[str, Any]) -> list[str]:
    missing: list[str] = []
    if not normalize_text(contract.get("objective")):
        missing.append("objective")
    if not normalize_text(contract.get("audience")):
        missing.append("audience")
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    if not normalize_text(output_contract.get("format")):
        missing.append("output_contract")
    if not ensure_list(contract.get("context")):
        missing.append("context")
    if not ensure_list(contract.get("constraints")):
        missing.append("constraints")
    if not normalize_text(contract.get("role")):
        missing.append("role")
    return missing
