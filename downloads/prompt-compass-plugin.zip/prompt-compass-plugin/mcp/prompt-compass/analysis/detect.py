from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from typing import Any

from common import ensure_list, join_unique, normalize_text, tokenize
from analysis.contracts import contract_missing_blocks


ROOT = Path(__file__).resolve().parents[1]
TAXONOMY_DIR = ROOT / "support" / "taxonomy"

STYLE_WORDS = {
    "clear",
    "clearer",
    "concise",
    "strategic",
    "compelling",
    "smart",
    "wise",
    "nuanced",
    "warm",
    "bold",
    "deep",
    "empathetic",
    "emotionally",
    "structured",
    "sharper",
    "polished",
    "professional",
}


def _normalized_phrase_text(value: str) -> str:
    text = normalize_text(value).lower().replace("-", " ").replace("_", " ")
    return re.sub(r"[^a-z0-9 ]", " ", text)


def _contains_keyword(text: str, keyword: str) -> bool:
    normalized_text = f" {' '.join(_normalized_phrase_text(text).split())} "
    normalized_keyword = " ".join(_normalized_phrase_text(keyword).split())
    if not normalized_keyword:
        return False
    return f" {normalized_keyword} " in normalized_text


def _has_tool_invocation_cue(text: str) -> bool:
    lowered = normalize_text(text).lower()
    return bool(
        re.search(r"\buse\b.{0,30}\btools?\b", lowered)
        or re.search(r"\bcall\b.{0,20}\btools?\b", lowered)
        or re.search(r"\binvoke\b.{0,20}\btools?\b", lowered)
        or re.search(r"\bfunction\b.{0,20}\bcalls?\b", lowered)
        or re.search(r"\ballowed\b.{0,20}\btools?\b", lowered)
        or re.search(r"\btools?\b.{0,20}\bboundar(?:y|ies)\b", lowered)
        or re.search(r"\btool\b.{0,20}\bconfirmation\b", lowered)
        or re.search(r"\bask\b.{0,20}\bbefore\b.{0,20}\b(?:tool|action|patch|delete|write)\b", lowered)
    )


@lru_cache(maxsize=None)
def _load_taxonomy_entries(filename: str) -> list[dict[str, Any]]:
    path = TAXONOMY_DIR / filename
    payload = json.loads(path.read_text(encoding="utf-8"))
    entries: list[dict[str, Any]] = []
    for item in payload:
        if isinstance(item, str):
            entries.append({"name": item, "keywords": []})
            continue
        if isinstance(item, dict) and item.get("name"):
            entries.append(
                {
                    "name": normalize_text(item["name"]),
                    "keywords": [normalize_text(keyword) for keyword in item.get("keywords", []) if normalize_text(keyword)],
                    "description": normalize_text(item.get("description")),
                }
            )
    return entries


def _detect_taxonomy_value(text: str, filename: str, *, default: str) -> str:
    lowered = normalize_text(text).lower()
    best_name = default
    best_score = 0
    for entry in _load_taxonomy_entries(filename):
        keywords = entry.get("keywords", [])
        score = sum(2 for keyword in keywords if _contains_keyword(lowered, keyword))
        if score > best_score:
            best_name = entry["name"]
            best_score = score
    return best_name


def detect_subject_area(text: str) -> str:
    return _detect_taxonomy_value(text, "subject-areas.json", default="general")


def detect_prompt_type(text: str, user_goal: str | None = None) -> str:
    probe = normalize_text(f"{user_goal or ''} {text}").lower()
    if any(
        phrase in probe
        for phrase in (
            "rewrite this",
            "rewrite this prompt",
            "make this better",
            "improve this prompt",
            "improve this",
            "tighten this",
            "refine this",
        )
    ):
        return "transformative"
    if "prompt:" in probe and any(token in probe for token in ("rewrite", "better", "improve", "refine")):
        return "transformative"
    return _detect_taxonomy_value(probe, "prompt-types.json", default="generative")


def detect_interaction_mode(text: str, user_goal: str | None = None) -> str:
    probe = f"{user_goal or ''} {text}"
    if _has_tool_invocation_cue(probe):
        return "tool_calling"
    return _detect_taxonomy_value(probe, "interaction-modes.json", default="single_turn")


def detect_output_mode(text: str, contract: dict[str, Any] | None = None) -> str:
    output_contract = contract.get("output_contract") if isinstance(contract, dict) and isinstance(contract.get("output_contract"), dict) else {}
    probe = f"{text} {output_contract.get('format', '')} {output_contract.get('success_test', '')}"
    if any(_contains_keyword(probe, keyword) for keyword in ("json schema", "response schema", "valid json", "function schema", "schema bound", "schema-bound")):
        return "schema_bound"
    if any(
        _contains_keyword(probe, keyword)
        for keyword in ("structured issue list", "structured list", "issue list", "bug list", "checklist", "check list")
    ):
        return "structured"
    if any(_contains_keyword(probe, keyword) for keyword in ("yaml", "xml", "table", "csv", "columns", "fields", "sections")):
        return "structured"
    return _detect_taxonomy_value(probe, "output-modes.json", default="freeform")


def detect_grounding_mode(text: str, contract: dict[str, Any] | None = None) -> str:
    context = contract.get("context", []) if isinstance(contract, dict) else []
    probe = f"{text} {' '.join(str(item) for item in context)}"
    lowered = normalize_text(probe).lower()
    explicit_quote_first = (
        any(_contains_keyword(lowered, keyword) for keyword in ("quote first", "quote-first", "quotes first", "before synthesis"))
        or bool(re.search(r"\b(?:extract|pull|use)\b.{0,24}\bexact quotes?\b.{0,24}\bfirst\b", lowered))
        or bool(re.search(r"\bexact quotes?\b.{0,24}\bfirst\b", lowered))
        or bool(re.search(r"\bdo not paraphrase until after\b", lowered))
    )
    if explicit_quote_first:
        return "quote_first"
    if any(_contains_keyword(probe, keyword) for keyword in ("retrieved", "retrieved documents", "retrieved evidence", "retrieved answers", "retrieval")):
        return "retrieval"
    return _detect_taxonomy_value(probe, "grounding-modes.json", default="none")


def detect_evaluation_mode(text: str, contract: dict[str, Any] | None = None) -> str:
    output_contract = contract.get("output_contract") if isinstance(contract, dict) and isinstance(contract.get("output_contract"), dict) else {}
    probe = f"{text} {output_contract.get('success_test', '')}"
    return _detect_taxonomy_value(probe, "evaluation-modes.json", default="none")


def detect_capability_tags(text: str, contract: dict[str, Any] | None = None) -> list[str]:
    context = contract.get("context", []) if isinstance(contract, dict) else []
    output_contract = contract.get("output_contract") if isinstance(contract, dict) and isinstance(contract.get("output_contract"), dict) else {}
    probe = normalize_text(
        " ".join(
            [
                text,
                " ".join(str(item) for item in context),
                normalize_text(output_contract.get("format")),
                normalize_text(output_contract.get("success_test")),
            ]
        )
    )
    tags: list[str] = []
    for entry in _load_taxonomy_entries("capability-tags.json"):
        tag = normalize_text(entry.get("name"))
        keywords = entry.get("keywords", [])
        if any(_contains_keyword(probe, keyword) for keyword in keywords):
            tags.append(tag)
    lowered = probe.lower()
    if re.search(r"\b\d+\s+(?:documents?|transcripts?|files?|sources?)\b", lowered):
        tags.append("long_context")
    if any(phrase in lowered for phrase in ("interview packet", "large context", "large context of", "many documents", "many sources", "context window")):
        tags.append("long_context")
    if _has_tool_invocation_cue(probe):
        tags.extend(["tool_use", "function_calling"])
    if "agentic_tool_use" in tags and "tool_use" not in tags:
        tags.append("tool_use")
    return join_unique(tags)


def detect_intent(text: str, contract: dict[str, Any], user_goal: str | None = None) -> str:
    if user_goal:
        return normalize_text(user_goal)
    objective = normalize_text(contract.get("objective"))
    if objective:
        return objective
    return normalize_text(text.splitlines()[0] if text.splitlines() else text)


def build_output_contract_check(contract: dict[str, Any]) -> dict[str, Any]:
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    gaps: list[str] = []
    if not normalize_text(output_contract.get("format")):
        gaps.append("format")
    if not normalize_text(output_contract.get("success_test")):
        gaps.append("success_test")
    return {
        "has_output_contract": "format" not in gaps,
        "has_success_test": "success_test" not in gaps,
        "format": normalize_text(output_contract.get("format")),
        "length": normalize_text(output_contract.get("length")),
        "sections": output_contract.get("sections", []),
        "gaps": gaps,
    }


def detect_anti_patterns(prompt: str, contract: dict[str, Any]) -> list[dict[str, Any]]:
    lowered = normalize_text(prompt).lower()
    word_count = len(tokenize(prompt))
    missing = set(contract_missing_blocks(contract))
    anti_patterns: list[dict[str, Any]] = []

    role_hits = len(re.findall(r"\b(?:act as|you are|as a|as an)\b", lowered))
    persona_hits = len(
        re.findall(
            r"\b(?:architect|educator|collaborator|assistant|coach|implementer|reviewer|analyst|planner|teacher|mentor|writer)\b",
            lowered,
        )
    )
    task_verbs = len(re.findall(r"\b(?:write|create|build|analyze|compare|evaluate|plan|design|draft|rewrite|improve)\b", lowered))
    directive_verbs = len(re.findall(r"\b(?:must|should|need to|do not|don't|always|never|return|include|follow|ask|pause|continue|stop)\b", lowered))
    style_hits = sum(1 for word in STYLE_WORDS if re.search(rf"\b{re.escape(word)}\b", lowered))
    comparative_style_hits = len(
        re.findall(
            r"\bmore\s+(?:strategic|compelling|polished|professional|clear|clearer|sharp|sharper|concise|specific)\b",
            lowered,
        )
    )
    adjective_stack_hits = len(
        re.findall(
            r"\b(?:clear(?:er)?|concise|strategic|compelling|smart|wise|nuanced|warm|bold|deep|empathetic|structured|sharper|polished|professional)\b",
            lowered,
        )
    )
    has_persuasion = any(token in lowered for token in ["persuasive", "convincing", "engaging", "compelling", "sell"])
    asks_for_assumptions = any(token in lowered for token in ["fill in the gaps", "assume the rest", "be definitive", "make up"])
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    output_format = normalize_text(output_contract.get("format")).lower()
    success_test = normalize_text(output_contract.get("success_test"))
    format_probe = f"{output_format} {success_test}"
    strong_format = any(token in output_format for token in ["json", "csv", "table", "yaml", "xml"]) or bool(
        re.search(r"\breturn\b.{0,30}\b(json|csv|table|yaml|xml)\b", lowered)
    )
    schema_words = any(token in lowered for token in ["schema", "fields", "columns", "properties", "required", "parser", "machine-readable"])
    has_validation_language = any(token in lowered for token in ["valid json", "must match", "must conform", "schema", "required fields", "allowed values"])
    has_tool_language = _has_tool_invocation_cue(lowered) or any(token in lowered for token in ["tool", "tools", "function call", "function calling"])
    has_stop_condition = any(token in lowered for token in ["stop when", "once complete", "once done", "task is complete", "if still incomplete", "done when", "completion criteria"])
    has_demonstration_examples = bool(
        re.search(r"\b(?:example|examples)\s+below\b", lowered)
        or re.search(r"\b\d+\s+examples?\b", lowered)
        or any(
            phrase in lowered
            for phrase in (
                "demonstration",
                "demonstrations",
                "same structure",
                "same level of detail",
                "follow the demonstrated pattern",
                "infer the pattern",
            )
        )
    )
    has_source_pack = any(
        token in lowered
        for token in ["source pack", "sources", "transcript", "transcripts", "notes", "document", "documents", "attached", "below", "research", "retrieved", "retrieval", "knowledge base"]
    )
    has_visible_sections = sum(1 for line in prompt.splitlines() if re.match(r"^[A-Za-z][A-Za-z0-9 /_-]{1,40}:\s*", line.strip())) >= 2
    def add(name: str, slug: str, why: str, evidence: list[str], severity: str) -> None:
        anti_patterns.append(
            {
                "name": name,
                "slug": slug,
                "entry_id": f"pc:anti_pattern:{slug}",
                "why_detected": why,
                "evidence": evidence,
                "severity": severity,
            }
        )

    for conflict in detect_semantic_conflicts(prompt, contract):
        add(
            conflict["name"],
            conflict["slug"],
            conflict["why_detected"],
            ensure_list(conflict.get("evidence")),
            conflict.get("severity", "medium"),
        )

    if has_persuasion and "audience" in missing:
        add("Ghost Audience", "ghost-audience", "Tone or persuasion cues exist without a named audience.", ["missing audience", "persuasive or tone-heavy wording"], "medium")
    if asks_for_assumptions or ("context" in missing and any(re.search(rf"\b{re.escape(token)}\b", lowered) for token in ["definitive", "certain", "complete answer"])):
        add("Hallucination Bait", "hallucination-bait", "The prompt pressures certainty while leaving context or evidence implicit.", ["missing context", "certainty wording"], "high")
    if word_count >= 140 and (task_verbs + directive_verbs) >= 12 and not has_visible_sections:
        add(
            "Instruction Wall",
            "instruction-wall",
            "The prompt is long, directive-heavy, and under-structured.",
            [f"{word_count} words", f"{task_verbs} task verbs", f"{directive_verbs} directive cues"],
            "high",
        )
    if strong_format and ("objective" in missing or "audience" in missing):
        add("Premature Format Lock", "premature-format-lock", "The format is explicit before the real job is clear.", ["strong format constraint", "missing objective or audience"], "medium")
    if role_hits >= 2 or (role_hits >= 1 and persona_hits >= 3):
        add("Role Collapse", "role-collapse", "Multiple role frames compete inside the same prompt.", [f"{role_hits} role cues", f"{persona_hits} persona nouns"], "medium")
    if task_verbs >= 5:
        add("Scope Sprawl", "scope-sprawl", "The prompt appears to ask for multiple jobs at once.", [f"{task_verbs} task verbs"], "high")
    if style_hits + comparative_style_hits >= 4 or adjective_stack_hits >= 6:
        add("Stacked Adjectives", "stacked-adjectives", "Too many quality words appear without ranked priorities.", [f"{style_hits + comparative_style_hits} style cues", f"{adjective_stack_hits} adjective hits"], "medium")
    if any(token in lowered for token in ["make it better", "make this better", "tighten this", "improve this"]) and not contract.get("output_contract", {}).get("format"):
        add("Vague Compression", "vague-compression", "The prompt asks for improvement without a visible target artifact.", ["rewrite wording without criteria"], "medium")
    if has_source_pack and not has_demonstration_examples and any(
        phrase in lowered
        for phrase in ("help me with them", "help me with this", "help me with it", "make it good", "make this good", "help me with")
    ) and not contract.get("output_contract", {}).get("format"):
        add("Vague Compression", "vague-compression", "The prompt asks for help with source material but never names a specific target artifact.", ["source-heavy ask", "no target artifact"], "medium")
    if has_source_pack and not has_demonstration_examples and ("objective" in missing or "output_contract" in missing):
        add(
            "Source Pack with Vague Ask",
            "source-pack-with-vague-ask",
            "The prompt includes source material but never clearly states the job those sources should support.",
            ["source material present", "missing objective or output contract"],
            "high",
        )
    if (output_format or strong_format) and not success_test:
        add(
            "Missing Success Test",
            "missing-success-test",
            "The prompt names an output shape but not what would make that output usable.",
            ["output format present", "success test missing"],
            "high",
        )
    if (strong_format or schema_words) and not has_validation_language and any(token in format_probe for token in ["json", "csv", "yaml", "xml", "schema"]):
        add(
            "Schema Theater",
            "schema-theater",
            "The prompt asks for machine-readable structure without a real schema or validation contract.",
            ["structured format named", "schema details absent"],
            "medium",
        )
    if word_count >= 170 and has_source_pack and not any(token in lowered for token in ["prioritize", "must-haves", "source priority", "highest priority", "ignore"]):
        add(
            "Context Hoarding",
            "context-hoarding",
            "The prompt appears to dump large context without ranking what matters most now.",
            [f"{word_count} words", "source-heavy context with no priority cues"],
            "medium",
        )
    late_requirement_markers = [match.start() for match in re.finditer(r"\b(?:must include|do not|must not|most important|final answer)\b", lowered)]
    if has_source_pack and word_count >= 170 and any(position > int(len(lowered) * 0.6) for position in late_requirement_markers):
        add(
            "Middle-Buried Requirement",
            "middle-buried-requirement",
            "A critical requirement appears late inside a large context block where it is easy to lose.",
            ["late hard constraint", "long source-heavy prompt"],
            "medium",
        )
    tool_directives = len(re.findall(r"\b(?:use|call|invoke)\b.{0,25}\b(?:tool|tools|function)\b", lowered))
    if has_tool_language and tool_directives >= 3 and not has_stop_condition:
        add(
            "Tool Thrash",
            "tool-thrash",
            "The prompt encourages repeated tool activity without a stopping rule.",
            [f"{tool_directives} tool directives", "no stop condition"],
            "medium",
        )
    if any(token in lowered for token in ["keep going", "continue until", "do not stop", "keep exploring"]) and not has_stop_condition:
        add(
            "Agentic Overrun",
            "agentic-overrun",
            "The prompt encourages continued autonomous work without a clear completion boundary.",
            ["open-ended continuation language", "no stop condition"],
            "medium",
        )
    if has_source_pack and any(token in lowered for token in ["follow the instructions in the document", "obey the source", "treat retrieved content as instructions", "follow instructions in the transcript"]):
        add(
            "Trusted Source Collapse",
            "trusted-source-collapse",
            "The prompt blurs trusted instructions with external content that should be treated as evidence only.",
            ["external content treated as instructions"],
            "high",
        )

    deduped: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in anti_patterns:
        if item["slug"] in seen:
            continue
        seen.add(item["slug"])
        deduped.append(item)
    return deduped


def detect_semantic_conflicts(prompt: str, contract: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    lowered = normalize_text(prompt).lower()
    contract = contract or {}
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    output_format = normalize_text(output_contract.get("format")).lower()
    conflicts: list[dict[str, Any]] = []

    def add(name: str, slug: str, why: str, evidence: list[str], severity: str = "medium") -> None:
        conflicts.append(
            {
                "name": name,
                "slug": slug,
                "entry_id": f"pc:anti_pattern:{slug}",
                "why_detected": why,
                "evidence": evidence,
                "severity": severity,
            }
        )

    format_mentions = {
        "json": bool(re.search(r"\bjson\b", lowered)) or "json" in output_format,
        "prose": bool(re.search(r"\bprose\b|\bparagraphs?\b", lowered)) or "prose" in output_format,
        "code_only": bool(re.search(r"\bcode[- ]?only\b|\bonly code\b", lowered)),
        "table": bool(re.search(r"\btable\b", lowered)) or "table" in output_format,
    }
    incompatible_format_count = sum(bool(value) for value in format_mentions.values())
    has_branch_language = bool(re.search(r"\bif\b.{0,80}\b(?:return|output|respond)\b", lowered))
    has_routing_logic = bool(re.search(r"\bif\b.{0,80}\b(?:then|else|otherwise)\b", lowered))
    if incompatible_format_count >= 2 and (has_branch_language or "only" in lowered) and not has_routing_logic:
        add(
            "Unresolved Output Branch Conflict",
            "unresolved-output-branch-conflict",
            "The prompt names competing output shapes without clear routing logic for when each shape applies.",
            [name for name, present in format_mentions.items() if present],
            "high",
        )

    model_hits = {
        model
        for model in ("gpt", "gpt-4o", "gpt-5", "claude", "opus", "sonnet", "gemini")
        if re.search(rf"\b{re.escape(model)}\b", lowered)
    }
    if ("gpt" in model_hits or "gpt-4o" in model_hits or "gpt-5" in model_hits) and ("claude" in model_hits or "opus" in model_hits or "sonnet" in model_hits):
        add(
            "Dual-Model Targeting Conflict",
            "dual-model-targeting-conflict",
            "The prompt tries to target multiple model families equally even though model-specific prompt preferences can conflict.",
            sorted(model_hits),
            "medium",
        )

    has_retrieval = any(token in lowered for token in ("retrieved", "retrieval", "source documents", "knowledge base", "rag"))
    has_tool_fallback = bool(re.search(r"\b(tool|external_search|web search|function)\b", lowered))
    has_precedence = any(phrase in lowered for phrase in ("source priority", "retrieved context wins", "retrieval first", "tools only if", "fallback only if", "precedence"))
    if has_retrieval and has_tool_fallback and not has_precedence:
        add(
            "Missing Source Precedence",
            "missing-source-precedence",
            "The prompt combines retrieval and tool fallback without saying which source wins when they conflict.",
            ["retrieval/source language", "tool or fallback language", "no precedence rule"],
            "high",
        )

    if re.search(r"\bdo not hallucinate\b|\bdon't hallucinate\b|\bnever hallucinate\b", lowered):
        add(
            "Ineffective Negative Constraint",
            "ineffective-negative-constraint",
            "The prompt says not to hallucinate but does not provide an enforceable grounding behavior.",
            ["do not hallucinate"],
            "medium",
        )

    if re.search(r"\bbe creative\b|\bmake it creative\b|\bcreative\b", lowered) and not re.search(r"\bcreative (?:means|as in|by)\b", lowered):
        add(
            "Vague Style Directive",
            "vague-style-directive",
            "The prompt asks for creativity without defining what kind of creative output would count as successful.",
            ["creative"],
            "low",
        )

    trait_conflict_pairs = [
        (("concise", "brief", "short"), ("exhaustive", "comprehensive", "detailed", "thorough"), "brevity versus completeness"),
        (("creative", "inventive"), ("strictly literal", "literal", "exact"), "creative latitude versus literal fidelity"),
    ]
    for left_terms, right_terms, label in trait_conflict_pairs:
        if any(re.search(rf"\b{re.escape(term)}\b", lowered) for term in left_terms) and any(
            re.search(rf"\b{re.escape(term)}\b", lowered) for term in right_terms
        ):
            add(
                "Trait Priority Conflict",
                "trait-priority-conflict",
                "The prompt names quality traits that pull against each other without saying which should win.",
                [label],
                "medium",
            )
            break

    deduped: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in conflicts:
        if item["slug"] in seen:
            continue
        seen.add(item["slug"])
        deduped.append(item)
    return deduped


def detect_ai_data_risk_warnings(prompt: str, contract: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    lowered = normalize_text(prompt).lower()
    warnings: list[dict[str, Any]] = []

    def add(name: str, slug: str, why: str, evidence: list[str], severity: str = "medium", repair: str = "") -> None:
        warnings.append(
            {
                "name": name,
                "slug": slug,
                "why_detected": why,
                "evidence": evidence,
                "severity": severity,
                "repair_guidance": repair,
            }
        )

    confidence_cue = bool(
        re.search(r"\b(?:be|sound|make it)\b.{0,30}\b(?:confident|definitive|authoritative|certain)\b", lowered)
        or re.search(r"\b(?:confident|definitive|authoritative)\b.{0,30}\b(?:answer|summary|response)\b", lowered)
    )
    thin_evidence_cue = bool(
        re.search(r"\b(?:even if|if)\b.{0,40}\b(?:evidence|data|context|sources?)\b.{0,30}\b(?:incomplete|thin|missing|limited)\b", lowered)
        or "without evidence" in lowered
    )
    if confidence_cue and (thin_evidence_cue or any(token in lowered for token in ("unsupported", "make it sound", "sound definitive"))):
        add(
            "Hallucination Confidence Invitation",
            "hallucination-confidence-invitation",
            "The prompt rewards confident output even when evidence may be incomplete.",
            ["confidence cue", "thin or missing evidence cue"],
            "high",
            "Ask for evidence-backed claims, uncertainty labels, and a missing-information fallback.",
        )

    if re.search(r"\bprove\b.{0,40}\b(?:right|correct)\b", lowered) or re.search(r"\b(?:critics|opponents|skeptics)\b.{0,30}\bwrong\b", lowered):
        add(
            "Sycophancy Invitation",
            "sycophancy-invitation",
            "The prompt asks the model to validate a preferred belief instead of evaluating alternatives.",
            ["prove preferred view", "dismiss critics"],
            "medium",
            "Ask for strongest supporting evidence, strongest counterargument, and a balanced recommendation.",
        )

    if re.search(r"\bdo not mention\b.{0,50}\b(?:uncertainty|limitations|assumptions|missing evidence)\b", lowered) or re.search(
        r"\b(?:hide|omit|avoid)\b.{0,30}\b(?:uncertainty|limitations|assumptions)\b", lowered
    ):
        add(
            "Uncertainty Suppression",
            "uncertainty-suppression",
            "The prompt suppresses uncertainty handling, which can make weak evidence look stronger than it is.",
            ["uncertainty or limitation suppression"],
            "high",
            "Require the model to label assumptions, unknowns, and evidence gaps.",
        )

    verbosity_cue = bool(re.search(r"\b(?:long|detailed|comprehensive|impressive|authoritative)\b", lowered))
    quality_cue = bool(re.search(r"\b(?:success|quality|good|better)\b.{0,40}\b(?:long|detailed|comprehensive|impressive|authoritative)\b", lowered))
    if verbosity_cue and quality_cue and not any(token in lowered for token in ("evidence", "source", "verify", "ground", "citation")):
        add(
            "Verbosity As Quality",
            "verbosity-as-quality",
            "The prompt treats length or impressive detail as quality without requiring verification.",
            ["verbosity rewarded", "no evidence requirement"],
            "medium",
            "Define quality as useful, accurate, source-grounded, or decision-ready instead of merely long.",
        )

    if re.search(r"\b(?:optimi[sz]e|score)\b.{0,50}\bbenchmark\b", lowered) and re.search(
        r"\b(?:ignore|regardless of)\b.{0,50}\b(?:real user|usefulness|practical)\b", lowered
    ):
        add(
            "Benchmark Overfit Risk",
            "benchmark-overfit-risk",
            "The prompt treats benchmark score as the only success criterion, even when it conflicts with real use.",
            ["benchmark optimization", "real user usefulness deprioritized"],
            "medium",
            "Keep benchmark criteria, but add a real-user success test and failure examples.",
        )

    deduped: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in warnings:
        if item["slug"] in seen:
            continue
        seen.add(item["slug"])
        deduped.append(item)
    return deduped


def build_retrieval_keywords(
    detected_intent: str,
    subject_area: str,
    prompt_type: str,
    anti_patterns: list[dict[str, Any]],
    missing_building_blocks: list[str],
    *,
    model_target: str | None = None,
    interaction_mode: str | None = None,
    output_mode: str | None = None,
    grounding_mode: str | None = None,
    evaluation_mode: str | None = None,
    capability_tags: list[str] | None = None,
) -> list[str]:
    stop_tokens = {
        "general",
        "and",
        "for",
        "from",
        "the",
        "this",
        "please",
        "show",
        "single",
        "turn",
        "none",
        "tool",
        "prompt",
        "context",
        "constraints",
        "role",
        "audience",
    }
    prioritized_values = [
        *(capability_tags or []),
        output_mode if output_mode and output_mode != "freeform" else "",
        grounding_mode if grounding_mode and grounding_mode != "none" else "",
        evaluation_mode if evaluation_mode and evaluation_mode != "none" else "",
        interaction_mode if interaction_mode and interaction_mode != "single_turn" else "",
        subject_area if subject_area != "general" else "",
        prompt_type,
        model_target or "",
        *(item.get("slug", "") for item in anti_patterns),
        *missing_building_blocks,
        detected_intent,
    ]
    tokens = join_unique(
        [
            token
            for value in prioritized_values
            for token in tokenize(value)
            if len(token) > 2 and token not in stop_tokens
        ]
    )
    return tokens[:28]
