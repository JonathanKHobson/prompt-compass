from __future__ import annotations

from typing import Any

from common import normalize_text, text_blob, tokenize
from repository import PromptCompassRepository

SURFACE_SUPPORT_ALLOWLIST = {
    "parser_bound": {"parser-aware-prompting"},
    "retrieval_grounded": {"untrusted-context-boundary"},
    "tool_workflow": {"ask-vs-act-threshold", "stop-condition-contract", "tool-contract-prompting"},
    "multimodal": {"multimodal-prompting"},
}

DRIVER_ELIGIBLE_RECORD_TYPES = {"framework", "strategy", "pattern", "technique"}

SURFACE_PRIORITY_BONUSES = {
    "parser_bound": {
        "schema-first-output-contract": 26,
        "json-schema-outputs": 24,
        "structured-output-steering": 20,
        "parser-aware-prompting": 18,
    },
    "retrieval_grounded": {
        "retrieval-grounding": 22,
        "context-engineering": 18,
        "quote-first-evidence-extraction": 18,
        "untrusted-context-boundary": 16,
        "long-context-layout": 10,
    },
    "tool_workflow": {
        "tool-use-prompting": 24,
        "tool-contract-prompting": 20,
        "ask-vs-act-threshold": 18,
        "stop-condition-contract": 18,
    },
    "code_assistant": {
        "context-engineering": 14,
        "eval-first-prompting": 10,
        "evaluator-optimizer-loop": 8,
    },
    "multimodal": {
        "multimodal-prompting": 18,
    },
}


def suggest_strategy_records(
    repo: PromptCompassRepository,
    *,
    prompt_type: str,
    subject_area: str,
    model_target: str | None,
    interaction_mode: str | None = None,
    output_mode: str | None = None,
    grounding_mode: str | None = None,
    evaluation_mode: str | None = None,
    capability_tags: list[str] | None = None,
    anti_patterns: list[dict[str, Any]],
    missing_building_blocks: list[str],
    prompt_surface: str | None = None,
    surface_traits: list[str] | None = None,
    query_terms: list[str],
    limit: int = 5,
) -> list[dict[str, Any]]:
    records = repo.list_all()
    ranked: list[tuple[float, dict[str, Any], str]] = []
    anti_slugs = {item.get("slug") for item in anti_patterns}
    missing = set(missing_building_blocks)
    query_tokens = {token for term in query_terms for token in tokenize(term)}
    query_tokens.update(tokenize(prompt_surface or ""))
    query_tokens.update(token for term in (surface_traits or []) for token in tokenize(term))
    requested_capabilities = set(capability_tags or [])
    normalized_surface = normalize_text(prompt_surface) or None
    trait_set = {normalize_text(item) for item in surface_traits or [] if normalize_text(item)}
    support_allowlist = SURFACE_SUPPORT_ALLOWLIST.get(normalized_surface or "", set())
    surface_bonuses = SURFACE_PRIORITY_BONUSES.get(normalized_surface or "", {})
    rewrite_tokens = {"rewrite", "improve", "better", "refine", "revision", "clearer", "sharper"}
    trait_stack_tokens = {"clearer", "sharper", "strategic", "compelling", "polished", "professional", "traits", "priority"}
    long_context_tokens = {"long", "context", "documents", "document", "transcripts", "transcript", "packet", "sources"}
    few_shot_tokens = {"example", "examples", "demonstration", "demonstrations", "pattern", "structure", "detail"}

    for record in records:
        record_slug = normalize_text(record.get("slug"))
        record_status = normalize_text(record.get("curation_status"))
        record_layer = normalize_text(record.get("record_layer"))
        personal_driver = (
            record_layer == "personal"
            and bool(record.get("driver_eligible"))
            and record.get("record_type") in DRIVER_ELIGIBLE_RECORD_TYPES
        )
        if record_status != "core" and record_slug not in support_allowlist and not personal_driver:
            continue
        if record.get("record_type") not in {"strategy", "framework", "pattern", "technique"}:
            continue
        if record.get("record_type") == "pattern" and record.get("pattern_kind") == "anti":
            continue
        tool_fit = record.get("tool_fit", {}) if isinstance(record.get("tool_fit"), dict) else {}
        score = 0.0
        reasons: list[str] = []
        score += max(tool_fit.get("improve", 0), tool_fit.get("build", 0)) * 6
        score += float(record.get("search_weight", 0)) * 0.35
        score += float(record.get("source_priority", 0)) * 0.08
        prompt_types = set(record.get("prompt_types", []))
        if prompt_type in prompt_types:
            score += 25
            reasons.append("matches prompt type")
        if subject_area in set(record.get("subject_areas", [])) or "general" in set(record.get("subject_areas", [])):
            score += 12
            reasons.append("fits subject area")
        model_targets = {normalize_text(value) for value in record.get("model_targets", []) if normalize_text(value)}
        if model_target and repo.model_target_variants(model_target) & model_targets:
            score += 10
            reasons.append("supports target model")
        elif "generic" in model_targets:
            score += 4
        haystack = text_blob(
            record.get("name"),
            record.get("summary"),
            record.get("definition"),
            record.get("signals", []),
            record.get("fixes", []),
            record.get("tags", []),
            record.get("capability_tags", []),
        ).lower()
        if interaction_mode and normalize_text(record.get("interaction_mode")) == normalize_text(interaction_mode):
            score += 8
            reasons.append("fits interaction mode")
        elif interaction_mode == "tool_calling" and any(token in haystack for token in ["tool", "function", "sequence", "step", "workflow"]):
            score += 12
            reasons.append("fits tool-calling flow")
        elif interaction_mode == "multi_turn" and any(token in haystack for token in ["iterative", "refine", "follow up", "sequence"]):
            score += 10
            reasons.append("fits iterative prompting")
        if output_mode and normalize_text(record.get("output_mode")) == normalize_text(output_mode):
            score += 9
            reasons.append("fits output mode")
        elif output_mode == "schema_bound" and any(token in haystack for token in ["schema", "json", "valid", "structured output"]):
            score += 12
            reasons.append("fits schema-bound output control")
        elif output_mode == "structured" and any(token in haystack for token in ["structured", "format", "table", "xml", "delimiter"]):
            score += 8
            reasons.append("fits structured output control")
        if grounding_mode and normalize_text(record.get("grounding_mode")) == normalize_text(grounding_mode):
            score += 7
            reasons.append("fits grounding mode")
        elif grounding_mode == "retrieval" and any(token in haystack for token in ["retrieval", "ground", "context", "evidence", "source"]):
            score += 12
            reasons.append("fits retrieval grounding")
        elif grounding_mode == "quote_first" and any(token in haystack for token in ["quote", "evidence", "passage"]):
            score += 12
            reasons.append("fits quote-first grounding")
        if evaluation_mode and normalize_text(record.get("evaluation_mode")) == normalize_text(evaluation_mode):
            score += 7
            reasons.append("fits evaluation mode")
        elif evaluation_mode == "rubric" and any(token in haystack for token in ["rubric", "evaluate", "grade", "score", "criteria"]):
            score += 12
            reasons.append("fits rubric-led evaluation")
        overlap = len(query_tokens & set(tokenize(haystack)))
        if overlap:
            score += overlap * 2
        if query_tokens & set(tokenize(normalize_text(record.get("name")))):
            score += 8
            reasons.append("query overlaps record name")
        capability_overlap = len(requested_capabilities & set(record.get("capability_tags", [])))
        if capability_overlap:
            score += capability_overlap * 8
            reasons.append("matches capability tags")
        if "structured_output" in requested_capabilities and any(token in haystack for token in ["structured output", "output contract", "table", "fields", "sections"]):
            score += 10
            reasons.append("fits structured-output control")
        if "json_schema" in requested_capabilities and any(token in haystack for token in ["json schema", "valid json", "schema", "required"]):
            score += 16
            reasons.append("fits schema-first output control")
        if "parser_aware" in requested_capabilities and any(token in haystack for token in ["parser", "machine readable", "schema", "downstream"]):
            score += 12
            reasons.append("fits parser-aware output handling")
        if "few_shot_examples" in requested_capabilities and any(token in haystack for token in ["few shot", "few-shot", "example", "demonstration"]):
            score += 14
            reasons.append("fits few-shot prompting")
        if "long_context" in requested_capabilities and any(token in haystack for token in ["long context", "context window", "sequence", "organize", "section"]):
            score += 12
            reasons.append("fits long-context layout")
        if "retrieval_grounding" in requested_capabilities and any(token in haystack for token in ["retrieval", "ground", "evidence", "source"]):
            score += 10
            reasons.append("fits retrieval evidence handling")
        if "quote_first_evidence" in requested_capabilities and any(token in haystack for token in ["quote", "exact", "passage", "evidence"]):
            score += 10
            reasons.append("fits quote-first evidence extraction")
        if "context_engineering" in requested_capabilities and any(token in haystack for token in ["context engineering", "context selection", "context map", "source priority"]):
            score += 14
            reasons.append("fits context-engineering guidance")
        if "context_compaction" in requested_capabilities and any(token in haystack for token in ["compaction", "compress", "carry-forward", "trim context"]):
            score += 12
            reasons.append("fits context compaction")
        if "judge_evaluation" in requested_capabilities and any(token in haystack for token in ["judge", "grader", "evaluation loop", "rubric"]):
            score += 12
            reasons.append("fits evaluator loop guidance")
        if "agentic_tool_use" in requested_capabilities and any(token in haystack for token in ["tool contract", "ask vs act", "stop condition", "confirmation"]):
            score += 12
            reasons.append("fits tool boundary control")
        if "source_priority" in requested_capabilities and any(token in haystack for token in ["source priority", "source ranking", "authority"]):
            score += 12
            reasons.append("fits source-priority handling")
        if "untrusted_context" in requested_capabilities and any(token in haystack for token in ["untrusted context", "data not instructions", "external content"]):
            score += 12
            reasons.append("fits untrusted-context handling")
        if "stop_conditions" in requested_capabilities and any(token in haystack for token in ["stop condition", "done criteria", "completion boundary"]):
            score += 12
            reasons.append("fits stop-condition control")
        if any(slot in missing for slot in {"audience", "output_contract"}) and all(token in haystack for token in ["role", "audience", "task", "output"]):
            score += 14
            reasons.append("repairs role-audience-output scaffolding")
        if prompt_type == "transformative" and any(token in haystack for token in ["refine", "revise", "rewrite", "critique"]):
            score += 10
            reasons.append("fits prompt revision")
        if "output_contract" in missing and any(token in haystack for token in ["output", "format", "response"]):
            score += 10
            reasons.append("repairs output-contract gap")
        if "audience" in missing and "audience" in haystack:
            score += 8
            reasons.append("repairs audience gap")
        if "scope-sprawl" in anti_slugs and any(token in haystack for token in ["narrow", "scope", "one deliverable", "steps"]):
            score += 14
            reasons.append("helps reduce scope sprawl")
        if "intent-dump" in anti_slugs and any(token in haystack for token in ["objective", "must-haves", "exclusions", "context"]):
            score += 12
            reasons.append("helps sort an intent dump")
        if "stacked-adjectives" in anti_slugs and any(token in haystack for token in ["traits", "priority", "clear", "style"]):
            score += 10
            reasons.append("helps rank style traits")
        if "contextual-absences" in anti_slugs and any(token in haystack for token in ["context", "audience", "output"]):
            score += 10
            reasons.append("fills missing building blocks")
        if "ghost-audience" in anti_slugs and "audience" in haystack:
            score += 10
            reasons.append("repairs missing audience")
        if "missing-success-test" in anti_slugs and any(token in haystack for token in ["success", "usable", "output contract", "expectation"]):
            score += 11
            reasons.append("repairs missing success test")
        if "source-pack-with-vague-ask" in anti_slugs and any(token in haystack for token in ["source", "context", "ground", "evidence"]):
            score += 10
            reasons.append("clarifies grounded prompts")
        if "context-hoarding" in anti_slugs and any(token in haystack for token in ["context", "source priority", "must haves", "compaction"]):
            score += 12
            reasons.append("repairs context hoarding")
        if "schema-theater" in anti_slugs and any(token in haystack for token in ["schema", "json", "parser", "output contract"]):
            score += 14
            reasons.append("repairs schema theater")
        if "tool-thrash" in anti_slugs and any(token in haystack for token in ["tool", "stop condition", "ask vs act", "confirmation"]):
            score += 12
            reasons.append("reduces tool thrash")
        if "agentic-overrun" in anti_slugs and any(token in haystack for token in ["stop condition", "done criteria", "ask vs act"]):
            score += 12
            reasons.append("adds completion boundaries")
        if "trusted-source-collapse" in anti_slugs and any(token in haystack for token in ["untrusted context", "source", "evidence", "data not instructions"]):
            score += 12
            reasons.append("separates instructions from evidence")
        if "vague-compression" in anti_slugs and any(token in haystack for token in ["artifact", "deliverable", "format", "contract"]):
            score += 10
            reasons.append("clarifies the rewrite target")
        if evaluation_mode in {"rubric", "grader"} and record_slug == "prompt-based-evaluation":
            score += 22
            reasons.append("fits explicit prompt evaluation")
            if output_mode == "schema_bound":
                score += 10
                reasons.append("fits rubric plus schema review")
        if prompt_type == "transformative" and record_slug == "prompt-refinement-first":
            score += 18
            reasons.append("fits prompt-refinement workflow")
        if "vague-compression" in anti_slugs and record_slug in {"prompt-refinement-first", "one-primary-deliverable-narrowing"}:
            score += 16
            reasons.append("repairs vague compression")
        if "stacked-adjectives" in anti_slugs and record_slug in {"trait-stack-output-control", "top-three-traits-ranking"}:
            score += 18
            reasons.append("repairs adjective stacking")
        if query_tokens & rewrite_tokens and record_slug == "prompt-refinement-first":
            score += 16
            reasons.append("matches rewrite language")
        if query_tokens & trait_stack_tokens and record_slug in {"trait-stack-output-control", "top-three-traits-ranking"}:
            score += 14
            reasons.append("matches trait-stack language")
        if "few_shot_examples" in requested_capabilities and record_slug == "prompt-augmentation-demonstration-learning":
            score += 24
            reasons.append("fits demonstration-driven few-shot prompting")
        if "few_shot_examples" in requested_capabilities and record_slug == "few-shot-prompting":
            score += 12
            reasons.append("fits few-shot prompting")
        if query_tokens & few_shot_tokens and record_slug == "prompt-augmentation-demonstration-learning":
            score += 18
            reasons.append("matches example and demonstration language")
        if ("long_context" in requested_capabilities or query_tokens & long_context_tokens) and record_slug in {"long-context-layout", "context-injection-via-source-pack"}:
            score += 18
            reasons.append("fits long-context source handling")
        if ("long_context" in requested_capabilities or "source-pack-with-vague-ask" in anti_slugs) and record_slug == "one-primary-deliverable-narrowing":
            score += 18
            reasons.append("narrows a vague long-context brief")
        if grounding_mode == "retrieval" and record_slug in {"retrieval-grounding", "context-injection-via-source-pack", "source-priority"}:
            score += 12
            reasons.append("fits grounded synthesis")
        if grounding_mode == "retrieval" and record_slug == "retrieval-grounding":
            score += 18
            reasons.append("fits primary retrieval-grounding workflow")
        if grounding_mode == "quote_first" and record_slug == "quote-first-evidence-extraction":
            score += 16
            reasons.append("fits quote-first extraction")
        if "quote_first_evidence" in requested_capabilities and record_slug == "quote-first-evidence-extraction":
            score += 18
            reasons.append("fits explicit evidence-first guidance")
        if "retrieval_grounding" in requested_capabilities and record_slug == "retrieval-grounding":
            score += 16
            reasons.append("fits explicit retrieval-grounding guidance")
        if grounding_mode == "retrieval" and "quote_first_evidence" in requested_capabilities and record_slug == "quote-first-evidence-extraction":
            score += 12
            reasons.append("adds quote-first evidence support to retrieval")
        if grounding_mode == "quote_first" and "source-pack-with-vague-ask" in anti_slugs and record_slug == "quote-first-evidence-extraction":
            score += 12
            reasons.append("restores evidence-first ordering for source packs")
        if normalized_surface and record_slug in surface_bonuses:
            score += surface_bonuses[record_slug]
            reasons.append(f"fits {normalized_surface} surface")
        if "parser_aware" in trait_set and record_slug in {"parser-aware-prompting", "json-schema-outputs", "schema-first-output-contract"}:
            score += 10
            reasons.append("fits parser-aware surface trait")
        if "retrieval" in trait_set and record_slug in {"context-engineering", "quote-first-evidence-extraction", "retrieval-grounding"}:
            score += 10
            reasons.append("fits retrieval surface trait")
        if "tool_use" in trait_set and record_slug in {"ask-vs-act-threshold", "stop-condition-contract", "tool-contract-prompting", "tool-use-prompting"}:
            score += 10
            reasons.append("fits tool-use surface trait")
        if "multimodal" in trait_set and record_slug == "multimodal-prompting":
            score += 10
            reasons.append("fits multimodal surface trait")
        if record_slug in {"schema-first-output-contract", "eval-first-prompting", "evaluator-optimizer-loop", "context-engineering"}:
            score += 6
        if record.get("name") == "RACCCA":
            score += 4
        ranked.append((score, record, ", ".join(reasons) or "general fit"))

    ranked.sort(
        key=lambda item: (
            -item[0],
            item[1].get("apply_order", 50),
            item[1]["name"].lower(),
        )
    )
    results: list[dict[str, Any]] = []
    for score, record, reason in ranked[:limit]:
        results.append(
            {
                "entry_id": record["entry_id"],
                "name": record["name"],
                "record_type": record["record_type"],
                "fit_score": round(score, 2),
                "why": reason,
                "apply_order": record.get("apply_order", 50),
                "expected_effect": _expected_effect(record),
            }
        )
    return results


def match_frameworks(repo: PromptCompassRepository, strategy_records: list[dict[str, Any]], limit: int = 3) -> list[dict[str, Any]]:
    frameworks: list[dict[str, Any]] = []
    for item in strategy_records:
        if item.get("record_type") != "framework":
            continue
        record = repo.get_entry(item["entry_id"])
        if record.get("found"):
            frameworks.append(record)
        if len(frameworks) >= limit:
            break
    return frameworks


def match_patterns(repo: PromptCompassRepository, strategy_records: list[dict[str, Any]], limit: int = 4) -> list[dict[str, Any]]:
    patterns: list[dict[str, Any]] = []
    for item in strategy_records:
        if item.get("record_type") != "pattern":
            continue
        record = repo.get_entry(item["entry_id"])
        if record.get("found"):
            patterns.append(record)
        if len(patterns) >= limit:
            break
    return patterns


def _expected_effect(record: dict[str, Any]) -> str:
    fixes = record.get("fixes", [])
    if fixes:
        return normalize_text(fixes[0])
    summary = normalize_text(record.get("summary"))
    if summary:
        return summary
    return f"Improve the prompt with {record.get('name', 'this strategy')}."
