from __future__ import annotations

import re
from typing import Any

from common import ensure_list, normalize_text, tokenize


CONTRACT_SCHEMA_VERSION = "prompt_compass.output_contract.v1"

AGENTIC_DIMENSIONS = [
    "task_clarity",
    "context_sufficiency",
    "constraint_precision",
    "tool_policy",
    "output_schema",
    "interaction_policy",
    "evaluation_criteria",
    "fallback_behavior",
    "safety_privacy_constraints",
    "token_efficiency",
]

RETRIEVAL_BUDGETS: dict[str, dict[str, Any]] = {
    "analysis_only": {
        "workflow": "analysis_only",
        "max_strategies": 6,
        "max_frameworks": 0,
        "max_patterns": 0,
        "max_support_entries": 0,
        "max_prompt_library_items": 0,
        "max_search_results": 8,
        "max_tokens_retrieval": 1200,
        "include_full_definitions": False,
    },
    "quick_improve": {
        "workflow": "quick_improve",
        "max_strategies": 4,
        "max_frameworks": 2,
        "max_patterns": 3,
        "max_support_entries": 3,
        "max_prompt_library_items": 3,
        "max_search_results": 8,
        "max_tokens_retrieval": 1800,
        "include_full_definitions": False,
    },
    "advanced_guided": {
        "workflow": "advanced_guided",
        "max_strategies": 6,
        "max_frameworks": 3,
        "max_patterns": 4,
        "max_support_entries": 5,
        "max_prompt_library_items": 5,
        "max_search_results": 12,
        "max_tokens_retrieval": 3500,
        "include_full_definitions": False,
    },
    "agent_committee": {
        "workflow": "agent_committee",
        "max_strategies": 6,
        "max_frameworks": 3,
        "max_patterns": 4,
        "max_support_entries": 5,
        "max_prompt_library_items": 5,
        "max_search_results": 12,
        "max_tokens_retrieval": 3500,
        "include_full_definitions": False,
    },
    "debug": {
        "workflow": "debug",
        "max_strategies": 10,
        "max_frameworks": 5,
        "max_patterns": 6,
        "max_support_entries": 10,
        "max_prompt_library_items": 10,
        "max_search_results": 25,
        "max_tokens_retrieval": 8000,
        "include_full_definitions": True,
    },
}


def retrieval_budget_for(workflow: str | None) -> dict[str, Any]:
    normalized = normalize_text(workflow).lower() or "analysis_only"
    return dict(RETRIEVAL_BUDGETS.get(normalized, RETRIEVAL_BUDGETS["analysis_only"]))


def cap_items_by_budget(items: list[Any], budget: dict[str, Any], key: str) -> list[Any]:
    try:
        limit = int(budget.get(key))
    except (TypeError, ValueError):
        return items
    if limit < 0:
        return items
    return items[:limit]


def build_retrieval_trace(
    *,
    workflow: str,
    budget: dict[str, Any],
    query_terms: list[str] | None = None,
    selected: dict[str, list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    selected = selected or {}
    counts = {name: len(values) for name, values in selected.items()}
    return {
        "workflow": normalize_text(workflow) or budget.get("workflow") or "analysis_only",
        "budget_applied": True,
        "query_terms": [normalize_text(item) for item in ensure_list(query_terms) if normalize_text(item)][:12],
        "limits": {
            key: budget[key]
            for key in (
                "max_strategies",
                "max_frameworks",
                "max_patterns",
                "max_support_entries",
                "max_prompt_library_items",
                "max_search_results",
                "max_tokens_retrieval",
            )
            if key in budget
        },
        "selected_counts": counts,
        "selected_refs": {
            name: [_record_ref(item) for item in values[:8]]
            for name, values in selected.items()
        },
    }


def build_prompt_ir(
    prompt: str,
    analysis: dict[str, Any],
    *,
    runtime_payload: dict[str, Any] | None = None,
    behavior_inventory: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    runtime_payload = runtime_payload or {}
    contract = analysis.get("prompt_contract") if isinstance(analysis.get("prompt_contract"), dict) else {}
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    anti_patterns = ensure_list(analysis.get("anti_patterns"))
    semantic_conflicts = ensure_list(analysis.get("semantic_conflicts"))
    ai_data_risk_warnings = ensure_list(analysis.get("ai_data_risk_warnings"))
    questions = ensure_list(runtime_payload.get("questions_for_user"))
    interaction_contract = runtime_payload.get("interaction_contract") if isinstance(runtime_payload.get("interaction_contract"), dict) else {}
    return {
        "schema_version": "prompt_compass.prompt_ir.v1",
        "objective": normalize_text(contract.get("objective")),
        "objective_source": normalize_text(contract.get("objective_source")),
        "audience": normalize_text(contract.get("audience")),
        "role": normalize_text(contract.get("role")),
        "task_type": normalize_text(analysis.get("prompt_type")),
        "subject_area": normalize_text(analysis.get("subject_area")),
        "model_target": normalize_text(contract.get("model_target")),
        "prompt_surface": normalize_text(analysis.get("prompt_surface")),
        "inputs_required": _inputs_required(contract, analysis),
        "outputs_required": _outputs_required(output_contract),
        "tools": _detected_tools(prompt, analysis, contract),
        "success_criteria": _success_criteria(output_contract, contract),
        "constraints": ensure_list(contract.get("constraints")),
        "interaction_policy": {
            "ask_when": _ask_when(prompt, questions),
            "proceed_when": _proceed_when(prompt, runtime_payload),
            "question_widget_required": bool(
                interaction_contract.get("native_question_ui_required")
                or runtime_payload.get("native_ui_required")
                or _mentions_question_widget(prompt)
            ),
            "max_questions_per_turn": _max_questions_per_turn(runtime_payload),
        },
        "failure_modes": [
            *_risk_refs(anti_patterns),
            *_risk_refs(semantic_conflicts),
            *_risk_refs(ai_data_risk_warnings),
        ],
        "test_cases": _test_cases(prompt, output_contract, contract),
        "preservation_requirements": [
            {
                "kind": normalize_text(item.get("kind")),
                "label": normalize_text(item.get("label")),
                "critical": bool(item.get("critical")),
            }
            for item in ensure_list(behavior_inventory)
            if isinstance(item, dict)
        ],
    }


def agentic_prompt_score(
    prompt: str,
    analysis: dict[str, Any],
    *,
    runtime_payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    runtime_payload = runtime_payload or {}
    contract = analysis.get("prompt_contract") if isinstance(analysis.get("prompt_contract"), dict) else {}
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    anti_slugs = {normalize_text(item.get("slug")) for item in ensure_list(analysis.get("anti_patterns")) if isinstance(item, dict)}
    conflict_slugs = {normalize_text(item.get("slug")) for item in ensure_list(analysis.get("semantic_conflicts")) if isinstance(item, dict)}
    lowered = normalize_text(prompt).lower()
    output_mode = normalize_text(analysis.get("output_mode"))
    grounding_mode = normalize_text(analysis.get("grounding_mode"))
    interaction_mode = normalize_text(analysis.get("interaction_mode"))
    capability_tags = {normalize_text(item) for item in ensure_list(analysis.get("capability_tags"))}
    missing = set(ensure_list(analysis.get("missing_building_blocks")))
    dimensions = {
        "task_clarity": _dimension(
            _bounded_score(1 + bool_score(contract.get("objective")) * 2 + bool_score(contract.get("audience")) + bool_score(contract.get("role"))),
            evidence=[
                _present_or_missing("objective", contract.get("objective")),
                _present_or_missing("audience", contract.get("audience")),
                _present_or_missing("role", contract.get("role")),
            ],
            repair_hint="Name the task, output reader, and working role in the prompt contract.",
        ),
        "context_sufficiency": _dimension(
            _bounded_score(2 + bool_score(ensure_list(contract.get("context"))) + bool_score(grounding_mode in {"source_pack", "retrieval", "quote_first"}) + bool_score("context" not in missing)),
            evidence=[
                "context items: " + str(len(ensure_list(contract.get("context")))),
                f"grounding mode: {grounding_mode or 'none'}",
            ],
            repair_hint="Add the context the model must rely on, or state that context is intentionally minimal.",
        ),
        "constraint_precision": _dimension(
            _bounded_score(2 + bool_score(ensure_list(contract.get("constraints"))) + bool_score(not conflict_slugs) + bool_score("vague-style-directive" not in conflict_slugs) - bool_score("trait-priority-conflict" in conflict_slugs)),
            evidence=[
                "constraints present" if ensure_list(contract.get("constraints")) else "constraints are thin",
                "semantic conflicts: " + (", ".join(sorted(conflict_slugs)) if conflict_slugs else "none detected"),
            ],
            repair_hint="Convert vague or conflicting constraints into ranked, observable rules.",
        ),
        "tool_policy": _tool_policy_dimension(lowered, interaction_mode, capability_tags),
        "output_schema": _output_schema_dimension(lowered, output_mode, output_contract),
        "interaction_policy": _interaction_policy_dimension(lowered, runtime_payload),
        "evaluation_criteria": _dimension(
            _bounded_score(1 + bool_score(output_contract.get("success_test")) * 2 + bool_score(analysis.get("evaluation_mode") in {"rubric", "grader", "comparison"}) + bool_score(_has_failure_examples(lowered))),
            evidence=[
                _present_or_missing("success test", output_contract.get("success_test")),
                f"evaluation mode: {normalize_text(analysis.get('evaluation_mode')) or 'none'}",
            ],
            repair_hint="Add observable success criteria, failure examples, or a lightweight rubric.",
        ),
        "fallback_behavior": _dimension(
            _bounded_score(1 + bool_score(_has_fallback_language(lowered)) * 3 + bool_score(_has_uncertainty_language(lowered))),
            evidence=[
                "fallback language present" if _has_fallback_language(lowered) else "fallback behavior is not explicit",
                "uncertainty behavior present" if _has_uncertainty_language(lowered) else "uncertainty behavior is implicit",
            ],
            repair_hint="State what to do when tools, sources, schema fields, or required context are unavailable.",
        ),
        "safety_privacy_constraints": _safety_dimension(lowered, contract),
        "token_efficiency": _token_efficiency_dimension(prompt, anti_slugs),
    }
    total = sum(item["score"] for item in dimensions.values())
    return {
        "schema_version": "prompt_compass.agentic_prompt_score.v1",
        "dimensions": dimensions,
        "total": total,
        "max_total": 50,
        "label": _agentic_label(total),
        "confidence": _score_confidence(analysis),
        "score_note": "Agentic Prompt Score is separate from RACCCA and focuses on tool, schema, fallback, interaction, and validation readiness.",
    }


def schema_validation_for(payload: dict[str, Any], *, tool_name: str) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    if payload.get("contract_schema_version") != CONTRACT_SCHEMA_VERSION:
        errors.append("Missing or invalid contract_schema_version.")
    if not isinstance(payload.get("prompt_ir"), dict):
        errors.append("Missing prompt_ir object.")
    score = payload.get("agentic_prompt_score")
    score_valid = _compare_score_shape_valid(score) if tool_name == "compare_prompts" else _score_shape_valid(score)
    if not score_valid:
        errors.append("Invalid agentic_prompt_score shape.")
    if tool_name in {"analyze_prompt", "diagnose_prompt", "preflight_prompt", "improve_prompt"} and not isinstance(payload.get("prompt_contract"), dict):
        warnings.append("prompt_contract is absent; downstream clients may need to rely on prompt_ir only.")
    if tool_name == "compare_prompts" and not isinstance(payload.get("agentic_prompt_score"), dict):
        errors.append("compare_prompts must include before/after agentic scores.")
    return {
        "schema_version": "prompt_compass.schema_validation.v1",
        "tool": tool_name,
        "passed": not errors,
        "errors": errors,
        "warnings": warnings,
        "checked_fields": [
            "contract_schema_version",
            "prompt_ir",
            "agentic_prompt_score",
            "prompt_contract",
        ],
        "repair_recommendations": _repair_recommendations(errors, warnings),
    }


def postflight_validation_for(payload: dict[str, Any], *, tool_name: str) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    score = payload.get("agentic_prompt_score")
    score_shape_valid = _compare_score_shape_valid(score) if tool_name == "compare_prompts" else _score_shape_valid(score)
    score_dimensions = score.get("dimensions", {}) if isinstance(score, dict) else {}
    if tool_name == "compare_prompts" and isinstance(score, dict):
        score_dimensions = (score.get("after") or {}).get("dimensions", {}) if isinstance(score.get("after"), dict) else {}
    output_schema_score = _dimension_score(score_dimensions, "output_schema")
    tool_policy_score = _dimension_score(score_dimensions, "tool_policy")
    interaction_policy_score = _dimension_score(score_dimensions, "interaction_policy")
    prompt_ir = payload.get("prompt_ir") if isinstance(payload.get("prompt_ir"), dict) else {}
    if tool_name == "compare_prompts" and isinstance(prompt_ir.get("after"), dict):
        prompt_ir = prompt_ir["after"]
    has_questions = bool(payload.get("questions_for_user"))
    runtime_contract_present = bool(payload.get("interaction_contract")) if has_questions else True
    checks.append(_check("score_shape_valid", score_shape_valid, "Agentic Prompt Score includes all required dimensions."))
    checks.append(_check("runtime_contract_present_when_needed", runtime_contract_present, "Question gates include an interaction contract."))
    checks.append(_check("output_schema_ready", output_schema_score >= 3, "Schema or output-format prompts define enough structure.", warning_only=True))
    checks.append(_check("tool_policy_ready", tool_policy_score >= 3, "Tool-using prompts define tool triggers, fallback, or stop policy.", warning_only=True))
    checks.append(_check("interaction_policy_ready", interaction_policy_score >= 3, "Interactive prompts define ask/proceed behavior.", warning_only=True))
    checks.extend(_preservation_checks(payload))
    checks.append(_source_precedence_check(payload, prompt_ir))
    errors = [item["message"] for item in checks if not item["passed"] and item["severity"] == "error"]
    warnings = [item["message"] for item in checks if not item["passed"] and item["severity"] == "warning"]
    return {
        "schema_version": "prompt_compass.postflight_validation.v1",
        "tool": tool_name,
        "passed": not errors,
        "errors": errors,
        "warnings": warnings,
        "checks": checks,
        "repair_recommendations": _repair_recommendations(errors, warnings),
    }


def phase2s_fields(
    prompt: str,
    analysis: dict[str, Any],
    *,
    tool_name: str,
    workflow: str,
    runtime_payload: dict[str, Any] | None = None,
    behavior_inventory: list[dict[str, Any]] | None = None,
    selected: dict[str, list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    budget = retrieval_budget_for(workflow)
    base = {
        "contract_schema_version": CONTRACT_SCHEMA_VERSION,
        "retrieval_budget": budget,
        "retrieval_trace": build_retrieval_trace(
            workflow=workflow,
            budget=budget,
            query_terms=analysis.get("retrieval_keywords", []),
            selected=selected,
        ),
    }
    payload_for_ir = {**analysis, **(runtime_payload or {})}
    base["prompt_ir"] = build_prompt_ir(
        prompt,
        payload_for_ir,
        runtime_payload=runtime_payload,
        behavior_inventory=behavior_inventory,
    )
    base["agentic_prompt_score"] = agentic_prompt_score(prompt, payload_for_ir, runtime_payload=runtime_payload)
    validation_probe = {**(runtime_payload or {}), **base}
    if "prompt_contract" not in validation_probe and isinstance(analysis.get("prompt_contract"), dict):
        validation_probe["prompt_contract"] = analysis["prompt_contract"]
    base["schema_validation"] = schema_validation_for(validation_probe, tool_name=tool_name)
    validation_probe.update(base)
    base["postflight_validation"] = postflight_validation_for(validation_probe, tool_name=tool_name)
    return base


def bool_score(value: Any) -> int:
    return 1 if bool(value) else 0


def _bounded_score(value: int) -> int:
    return max(0, min(5, int(value)))


def _dimension(score: int, *, evidence: list[str], repair_hint: str) -> dict[str, Any]:
    return {
        "score": _bounded_score(score),
        "max": 5,
        "evidence": [normalize_text(item) for item in evidence if normalize_text(item)],
        "rationale": "; ".join(normalize_text(item) for item in evidence if normalize_text(item)) + ".",
        "repair_hint": repair_hint,
    }


def _record_ref(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "entry_id": record.get("entry_id") or record.get("item_id") or record.get("id"),
        "name": record.get("name") or record.get("title"),
        "record_type": record.get("record_type") or record.get("asset_kind"),
    }


def _inputs_required(contract: dict[str, Any], analysis: dict[str, Any]) -> list[str]:
    inputs = []
    if not ensure_list(contract.get("context")):
        inputs.append("context_or_assumptions")
    if normalize_text(analysis.get("grounding_mode")) in {"retrieval", "quote_first", "source_pack"}:
        inputs.append("authoritative_sources")
    if normalize_text(analysis.get("interaction_mode")) in {"tool_calling", "agentic"}:
        inputs.append("tool_environment")
    return inputs


def _outputs_required(output_contract: dict[str, Any]) -> list[str]:
    outputs = []
    if normalize_text(output_contract.get("format")):
        outputs.append(normalize_text(output_contract.get("format")))
    outputs.extend(normalize_text(item) for item in ensure_list(output_contract.get("sections")) if normalize_text(item))
    return outputs


def _detected_tools(prompt: str, analysis: dict[str, Any], contract: dict[str, Any]) -> list[str]:
    probe = normalize_text(" ".join([prompt, " ".join(ensure_list(contract.get("constraints")))]))
    tools = sorted(set(re.findall(r"\b[a-zA-Z][a-zA-Z0-9_]*(?:_tool|Tool|_api|_search|_lookup)\b", probe)))
    if normalize_text(analysis.get("interaction_mode")) in {"tool_calling", "agentic"} and not tools:
        tools.append("tool_policy_required")
    return tools


def _success_criteria(output_contract: dict[str, Any], contract: dict[str, Any]) -> list[str]:
    criteria = []
    if normalize_text(output_contract.get("success_test")):
        criteria.append(normalize_text(output_contract.get("success_test")))
    for constraint in ensure_list(contract.get("constraints")):
        if any(token in normalize_text(constraint).lower() for token in ("done", "success", "pass", "valid", "accepted")):
            criteria.append(normalize_text(constraint))
    return criteria


def _risk_refs(items: list[dict[str, Any]]) -> list[dict[str, str]]:
    refs = []
    for item in items:
        if not isinstance(item, dict):
            continue
        refs.append(
            {
                "slug": normalize_text(item.get("slug")),
                "name": normalize_text(item.get("name")),
                "severity": normalize_text(item.get("severity")),
            }
        )
    return refs


def _ask_when(prompt: str, questions: list[Any]) -> list[str]:
    if questions:
        return ["when returned questions_for_user is non-empty"]
    lowered = normalize_text(prompt).lower()
    if "ask" in lowered and any(token in lowered for token in ("clarify", "question", "before")):
        return ["when required information is missing"]
    return []


def _proceed_when(prompt: str, runtime_payload: dict[str, Any]) -> list[str]:
    host_action = runtime_payload.get("host_action") if isinstance(runtime_payload.get("host_action"), dict) else {}
    if host_action.get("must_pause"):
        return ["after the blocking gate clears"]
    lowered = normalize_text(prompt).lower()
    if "reasonable assumption" in lowered or "proceed" in lowered:
        return ["when a safe assumption is available"]
    return []


def _mentions_question_widget(prompt: str) -> bool:
    lowered = normalize_text(prompt).lower()
    return any(phrase in lowered for phrase in ("question widget", "native question ui", "ask_user", "questions_for_user"))


def _max_questions_per_turn(runtime_payload: dict[str, Any]) -> int | None:
    budget = runtime_payload.get("question_budget") if isinstance(runtime_payload.get("question_budget"), dict) else {}
    value = budget.get("max_questions_per_turn")
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _test_cases(prompt: str, output_contract: dict[str, Any], contract: dict[str, Any]) -> list[dict[str, str]]:
    cases = []
    if normalize_text(output_contract.get("success_test")):
        cases.append({"type": "success_test", "description": normalize_text(output_contract.get("success_test"))})
    if _has_failure_examples(normalize_text(prompt).lower()):
        cases.append({"type": "failure_examples", "description": "Prompt names examples of bad or unacceptable output."})
    if ensure_list(contract.get("examples")):
        cases.append({"type": "examples", "description": "Prompt includes examples or reference outputs."})
    return cases


def _present_or_missing(label: str, value: Any) -> str:
    return f"{label} present" if normalize_text(value) or ensure_list(value) else f"{label} missing"


def _tool_policy_dimension(lowered: str, interaction_mode: str, capability_tags: set[str]) -> dict[str, Any]:
    needs_tool_policy = (
        interaction_mode in {"tool_calling", "agentic"}
        or bool({"tool_use", "function_calling", "agentic_tool_use"} & capability_tags)
        or any(token in lowered for token in ("tool", "function call", "api", "browse", "search"))
    )
    if not needs_tool_policy:
        return _dimension(4, evidence=["tool policy not required by the detected prompt shape"], repair_hint="No repair needed unless tools are introduced.")
    trigger = bool(re.search(r"\b(?:when|if|only if|before|after)\b.{0,40}\b(?:tool|function|search|browse|api)\b", lowered))
    fallback = _has_fallback_language(lowered)
    stop = any(phrase in lowered for phrase in ("stop when", "once complete", "ask before", "confirmation", "tool budget", "max tool"))
    score = 1 + bool_score(trigger) * 2 + bool_score(fallback) + bool_score(stop)
    return _dimension(
        score,
        evidence=[
            "tool triggers present" if trigger else "tool triggers are implicit",
            "tool fallback present" if fallback else "tool fallback is implicit",
            "tool stop/confirmation policy present" if stop else "tool stop/confirmation policy is implicit",
        ],
        repair_hint="Define when tools are used, when they are not used, what to do if they fail, and when to stop.",
    )


def _output_schema_dimension(lowered: str, output_mode: str, output_contract: dict[str, Any]) -> dict[str, Any]:
    format_present = bool(normalize_text(output_contract.get("format")))
    success_present = bool(normalize_text(output_contract.get("success_test")))
    fields_present = bool(ensure_list(output_contract.get("sections"))) or bool(re.search(r"\bfields?\b.{0,80}\b[a-z][a-z0-9_]+", lowered))
    failure_behavior = _has_fallback_language(lowered) or any(token in lowered for token in ("null", "empty", "error", "invalid"))
    schema_needed = output_mode == "schema_bound" or any(token in lowered for token in ("json", "schema", "csv", "yaml", "parser"))
    score = 1 + bool_score(format_present) + bool_score(success_present) + bool_score(fields_present) + bool_score(failure_behavior)
    if not schema_needed and format_present:
        score = max(score, 4)
    if not schema_needed and not format_present:
        score = 3
    return _dimension(
        score,
        evidence=[
            "format present" if format_present else "format missing",
            "fields/sections present" if fields_present else "fields/sections missing",
            "success or failure behavior present" if success_present or failure_behavior else "success/failure behavior missing",
        ],
        repair_hint="For parser-bound prompts, name required fields, allowed values, missing-data behavior, and a validation success test.",
    )


def _interaction_policy_dimension(lowered: str, runtime_payload: dict[str, Any]) -> dict[str, Any]:
    contract = runtime_payload.get("interaction_contract") if isinstance(runtime_payload.get("interaction_contract"), dict) else {}
    host_validation = runtime_payload.get("host_validation") if isinstance(runtime_payload.get("host_validation"), dict) else {}
    questions_present = bool(runtime_payload.get("questions_for_user"))
    text_policy = any(phrase in lowered for phrase in ("ask when", "proceed when", "question widget", "native question ui", "ask before"))
    score = 2 + bool_score(text_policy) + bool_score(contract) + bool_score(host_validation)
    if not questions_present and not text_policy:
        score = 4
    return _dimension(
        score,
        evidence=[
            "interaction contract present" if contract else "interaction contract not present",
            "host validation present" if host_validation else "host validation not present",
            "text ask/proceed policy present" if text_policy else "text ask/proceed policy not explicit",
        ],
        repair_hint="State when to ask, when to proceed with assumptions, and whether native question UI is required.",
    )


def _safety_dimension(lowered: str, contract: dict[str, Any]) -> dict[str, Any]:
    constraints = " ".join(normalize_text(item).lower() for item in ensure_list(contract.get("constraints")))
    probe = f"{lowered} {constraints}"
    high_impact = any(token in probe for token in ("delete", "publish", "spend", "payment", "private", "sensitive", "secret", "credential", "write file", "modify"))
    has_boundary = any(token in probe for token in ("ask before", "confirm", "consent", "do not store", "privacy", "redact", "approval", "safe"))
    score = 4 if not high_impact else 1 + bool_score(has_boundary) * 3
    return _dimension(
        score,
        evidence=[
            "high-impact action detected" if high_impact else "no high-impact action detected",
            "confirmation/privacy boundary present" if has_boundary else "confirmation/privacy boundary not explicit",
        ],
        repair_hint="Add confirmation, privacy, redaction, or allowed-action boundaries for consequential operations.",
    )


def _token_efficiency_dimension(prompt: str, anti_slugs: set[str]) -> dict[str, Any]:
    words = len(tokenize(prompt))
    score = 5
    if words > 1200:
        score = 1
    elif words > 750:
        score = 2
    elif words > 450:
        score = 3
    elif words > 220:
        score = 4
    if "instruction-wall" in anti_slugs:
        score = max(1, score - 1)
    return _dimension(
        score,
        evidence=[f"word count: {words}", "instruction wall detected" if "instruction-wall" in anti_slugs else "no instruction wall anti-pattern detected"],
        repair_hint="Compress repeated instructions and move reusable scaffolding into references or selected lens cards.",
    )


def _has_failure_examples(lowered: str) -> bool:
    return any(phrase in lowered for phrase in ("bad output", "wrong output", "failure example", "unacceptable", "should fail"))


def _has_fallback_language(lowered: str) -> bool:
    return any(
        token in lowered
        for token in (
            "fallback",
            "unavailable",
            "if missing",
            "if insufficient",
            "if no",
            "cannot",
            "can't",
            "unable",
            "otherwise",
        )
    )


def _has_uncertainty_language(lowered: str) -> bool:
    return any(token in lowered for token in ("uncertain", "uncertainty", "confidence", "assumption", "unknown", "not enough evidence"))


def _agentic_label(total: int) -> str:
    if total >= 42:
        return "agent_ready"
    if total >= 34:
        return "operational"
    if total >= 24:
        return "needs_hardening"
    return "fragile"


def _score_confidence(analysis: dict[str, Any]) -> str:
    if ensure_list(analysis.get("semantic_conflicts")) or ensure_list(analysis.get("ai_data_risk_warnings")):
        return "medium"
    if len(ensure_list(analysis.get("missing_building_blocks"))) >= 3:
        return "medium"
    return "high"


def _score_shape_valid(score: Any) -> bool:
    if not isinstance(score, dict):
        return False
    dimensions = score.get("dimensions")
    if not isinstance(dimensions, dict):
        return False
    for name in AGENTIC_DIMENSIONS:
        item = dimensions.get(name)
        if not isinstance(item, dict):
            return False
        if not isinstance(item.get("score"), int) or not 0 <= item["score"] <= 5:
            return False
        if item.get("max") != 5:
            return False
    return True


def _compare_score_shape_valid(score: Any) -> bool:
    if not isinstance(score, dict):
        return False
    return _score_shape_valid(score.get("before")) and _score_shape_valid(score.get("after"))


def _dimension_score(dimensions: dict[str, Any], name: str) -> int:
    item = dimensions.get(name) if isinstance(dimensions, dict) else {}
    try:
        return int(item.get("score", 0))
    except (AttributeError, TypeError, ValueError):
        return 0


def _check(check_id: str, passed: bool, message: str, *, warning_only: bool = False) -> dict[str, Any]:
    return {
        "id": check_id,
        "passed": bool(passed),
        "severity": "warning" if warning_only else "error",
        "message": message,
    }


def _preservation_checks(payload: dict[str, Any]) -> list[dict[str, Any]]:
    stripped = [item for item in ensure_list(payload.get("stripped_behaviors")) if isinstance(item, dict)]
    critical = [item for item in stripped if item.get("critical")]
    warnings = ensure_list(payload.get("preservation_warnings"))
    return [
        _check(
            "rewrite_preservation_no_critical_strip",
            not critical,
            "Critical source behaviors must be preserved or visibly approved before shipping.",
            warning_only=True,
        ),
        _check(
            "rewrite_preservation_warnings_visible",
            not stripped or bool(warnings),
            "Stripped behaviors should have visible preservation warnings.",
            warning_only=True,
        ),
    ]


def _source_precedence_check(payload: dict[str, Any], prompt_ir: dict[str, Any]) -> dict[str, Any]:
    grounding = normalize_text(payload.get("grounding_mode")) or normalize_text(prompt_ir.get("prompt_surface"))
    constraints = " ".join(normalize_text(item).lower() for item in ensure_list(prompt_ir.get("constraints")))
    needs_precedence = grounding in {"retrieval", "quote_first", "retrieval_grounded"} or any(
        token in constraints for token in ("retrieval", "source", "document", "citation")
    )
    has_precedence = any(token in constraints for token in ("source priority", "source wins", "precedence", "authoritative", "conflict"))
    return _check(
        "source_retrieval_precedence",
        (not needs_precedence) or has_precedence,
        "Retrieval/source-pack prompts should say which source wins when sources conflict.",
        warning_only=True,
    )


def _repair_recommendations(errors: list[str], warnings: list[str]) -> list[str]:
    recommendations = []
    if errors:
        recommendations.append("Rebuild the payload through the Prompt Compass workflow before returning it to the host.")
    if warnings:
        recommendations.append("Show warnings in the host response or repair the prompt contract before execution.")
    if not recommendations:
        recommendations.append("No repair needed.")
    return recommendations
