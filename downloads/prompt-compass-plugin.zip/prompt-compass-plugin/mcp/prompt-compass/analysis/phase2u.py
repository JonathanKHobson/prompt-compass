from __future__ import annotations

import re
from typing import Any

from common import ensure_list, join_unique, normalize_text, tokenize
from rewrite.contract_builder import render_prompt_contract


GENERIC_ROLE_TERMS = {
    "best",
    "elite",
    "expert",
    "genius",
    "guru",
    "highly skilled",
    "master",
    "seasoned",
    "specialist",
    "top-tier",
    "world class",
    "world-class",
}

OPERATIONAL_ROLE_TERMS = {
    "analyst",
    "architect",
    "auditor",
    "coach",
    "copywriter",
    "critic",
    "developer",
    "editor",
    "facilitator",
    "implementer",
    "planner",
    "reviewer",
    "strategist",
    "teacher",
    "writer",
}

DOMAIN_ANCHOR_PATTERNS = {
    "code_workflow": {"api", "bug", "codex", "commit", "function", "github", "module", "pytest", "repo", "schema", "script", "sql", "test"},
    "retrieval_grounding": {"citation", "citations", "doc_id", "evidence", "grounded", "rag", "retrieval", "source", "sources"},
    "schema_output": {"csv", "field", "fields", "json", "parser", "schema", "xml", "yaml"},
    "tool_workflow": {"agent", "confirmation", "fallback", "host", "mcp", "tool", "tools", "workflow"},
    "audience_context": {"audience", "customer", "developer", "executive", "reader", "stakeholder", "user"},
}

SURFACE_PROFILES = {
    "direct_chat": {
        "surface_kind": "human_chat",
        "primary_risk": "The prompt may over-explain or drift into meta commentary.",
        "priority_controls": ["short task statement", "bounded output", "plain completion condition"],
        "verification_method": "Check that the answer responds directly to the user request without unnecessary scaffolding.",
        "failure_conditions": ["Answer is mostly meta commentary.", "The requested artifact is missing."],
    },
    "code_assistant": {
        "surface_kind": "coding_agent",
        "primary_risk": "The model may discuss code instead of making file-scoped, testable changes.",
        "priority_controls": ["file scope", "implementation boundary", "verification command"],
        "verification_method": "Verification confirms affected files, expected behavior, and test or smoke-check evidence are named.",
        "failure_conditions": ["No file or module scope is stated.", "No verification path is provided."],
    },
    "parser_bound": {
        "surface_kind": "structured_output",
        "primary_risk": "Parser-facing output can fail if fields, allowed values, or missing-data behavior are underspecified.",
        "priority_controls": ["required fields", "allowed values", "empty/error behavior"],
        "verification_method": "Validate that output conforms to the named schema without wrapper prose.",
        "failure_conditions": ["Required fields are missing.", "Wrapper prose breaks parser consumption."],
    },
    "retrieval_grounded": {
        "surface_kind": "grounded_generation",
        "primary_risk": "The model may synthesize beyond evidence or flatten source conflicts.",
        "priority_controls": ["source priority", "citation rule", "unknown fallback"],
        "verification_method": "Check every material claim against provided or retrieved evidence.",
        "failure_conditions": ["Unsupported claims are presented as facts.", "Source conflicts are hidden."],
    },
    "tool_workflow": {
        "surface_kind": "tool_using_agent",
        "primary_risk": "The model may call tools too freely or continue after the task is complete.",
        "priority_controls": ["tool trigger rules", "confirmation boundary", "stop condition"],
        "verification_method": "Confirm each tool call has a trigger and the workflow stops at the completion condition.",
        "failure_conditions": ["Tool calls happen without a trigger.", "High-impact actions occur without confirmation."],
    },
    "multimodal": {
        "surface_kind": "cross_modal_reasoning",
        "primary_risk": "The model may blur what came from text, images, audio, or video.",
        "priority_controls": ["modality roles", "quality fallback", "conflict reconciliation"],
        "verification_method": "Check that each modality contribution and any uncertainty are labeled.",
        "failure_conditions": ["A missing or low-quality modality is treated as complete.", "Cross-modal conflicts are hidden."],
    },
}


def apply_role_domain_calibration(
    contract: dict[str, Any],
    source_text: str,
    analysis: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    updated = dict(contract)
    assessment = role_prompt_assessment(source_text, updated, analysis)
    if assessment["decision"] == "demote_role":
        updated["role"] = ""
        constraints = list(ensure_list(updated.get("constraints")))
        constraints = _append_unique(
            constraints,
            "Use domain vocabulary and task constraints as the behavior anchor; do not rely on a generic expert persona.",
        )
        updated["constraints"] = constraints
    if assessment["domain_vocabulary_anchors"]:
        context = list(ensure_list(updated.get("context")))
        context = _append_unique(
            context,
            "Preserve domain vocabulary: " + ", ".join(assessment["domain_vocabulary_anchors"][:6]) + ".",
        )
        updated["context"] = context
    return updated, assessment


def role_prompt_assessment(
    source_text: str,
    contract: dict[str, Any],
    analysis: dict[str, Any] | None = None,
) -> dict[str, Any]:
    role = normalize_text(contract.get("role")) or _generic_role_from_source(source_text)
    anchors = domain_vocabulary_anchors(source_text, contract, analysis)
    generic_role = _is_generic_role_noise(role)
    operational_role = _is_operational_role(role)
    if role and generic_role and not operational_role:
        decision = "demote_role"
        preserve_role = False
        reason = "The role is mostly generic expertise framing and does not add concrete operating posture."
    elif role:
        decision = "preserve_role"
        preserve_role = True
        reason = "The role contributes concrete posture, audience framing, or task vocabulary."
    elif anchors:
        decision = "preserve_domain_vocabulary"
        preserve_role = False
        reason = "No role line is needed; domain vocabulary is the safer behavior anchor."
    else:
        decision = "no_role_needed"
        preserve_role = False
        reason = "No role line or domain anchor is necessary for this prompt shape."
    return {
        "schema_version": "prompt_compass.role_domain_assessment.v1",
        "decision": decision,
        "preserve_role": preserve_role,
        "role_value": role,
        "role_priority": "conditional",
        "generic_role_detected": generic_role,
        "operational_role_detected": operational_role,
        "domain_vocabulary_anchors": anchors,
        "reason": reason,
        "rewrite_priority_rule": "Role framing must not displace output contract, success criteria, grounding rules, or preservation warnings.",
    }


def success_criteria_contract(
    source_text: str,
    contract: dict[str, Any],
    analysis: dict[str, Any] | None = None,
) -> dict[str, Any]:
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    success_test = normalize_text(output_contract.get("success_test"))
    output_format = normalize_text(output_contract.get("format"))
    surface = _resolved_surface(analysis)
    source = "missing"
    if success_test:
        source = "explicit" if _source_mentions_success(source_text) else "inferred"
    verification_method = _verification_method(surface, success_test, output_format)
    failure_conditions = _failure_conditions(surface, contract)
    return {
        "schema_version": "prompt_compass.success_criteria_contract.v1",
        "status": "present" if success_test else "missing",
        "source": source,
        "success_test": success_test,
        "done_when": success_test or _fallback_done_when(output_format, surface),
        "verification_method": verification_method,
        "failure_conditions": failure_conditions,
        "priority": "first_class_rewrite_requirement",
    }


def compiled_prompt_artifact(
    source_text: str,
    payload: dict[str, Any],
    analysis: dict[str, Any] | None = None,
) -> dict[str, Any]:
    contract = payload.get("prompt_contract") if isinstance(payload.get("prompt_contract"), dict) else {}
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    prompt = (
        payload.get("rewritten_prompt")
        if isinstance(payload.get("rewritten_prompt"), str)
        else payload.get("scaffolded_prompt")
        if isinstance(payload.get("scaffolded_prompt"), str)
        else ""
    ) or render_prompt_contract(contract, include_assumptions=True)
    return {
        "schema_version": "prompt_compass.compiled_prompt_artifact.v1",
        "artifact_type": "rewritten_prompt" if payload.get("rewritten_prompt") else "scaffolded_prompt",
        "prompt": prompt,
        "source_summary": normalize_text(source_text)[:240],
        "sections": {
            "role": normalize_text(contract.get("role")),
            "objective": normalize_text(contract.get("objective")),
            "audience": normalize_text(contract.get("audience")),
            "constraints": ensure_list(contract.get("constraints")),
            "output_format": normalize_text(output_contract.get("format")),
            "success_test": normalize_text(output_contract.get("success_test")),
            "model_target": normalize_text(contract.get("model_target")),
        },
        "success_criteria_contract": success_criteria_contract(source_text, contract, analysis),
        "role_prompt_assessment": role_prompt_assessment(source_text, contract, analysis),
        "usage_note": "Use this artifact as the structured prompt handoff; standard rewritten_prompt/scaffolded_prompt remains unchanged.",
    }


def surface_targeting_profile(surface_name: str, contract: dict[str, Any] | None = None) -> dict[str, Any]:
    normalized = normalize_text(surface_name).lower() or "direct_chat"
    if normalized not in SURFACE_PROFILES:
        normalized = "direct_chat"
    profile = dict(SURFACE_PROFILES[normalized])
    profile["surface_name"] = normalized
    output_contract = contract.get("output_contract") if isinstance(contract, dict) and isinstance(contract.get("output_contract"), dict) else {}
    success_test = normalize_text(output_contract.get("success_test"))
    return {
        "surface_profile": profile,
        "surface_success_criteria": {
            "surface_name": normalized,
            "success_test": success_test or _fallback_done_when(normalize_text(output_contract.get("format")), normalized),
            "verification_method": profile["verification_method"],
            "failure_conditions": profile["failure_conditions"],
        },
    }


def domain_vocabulary_anchors(
    source_text: str,
    contract: dict[str, Any],
    analysis: dict[str, Any] | None = None,
) -> list[str]:
    tokens = set(tokenize(" ".join([source_text, normalize_text(contract.get("objective")), normalize_text(contract.get("audience"))])))
    anchors: list[str] = []
    for label, terms in DOMAIN_ANCHOR_PATTERNS.items():
        if terms & tokens:
            anchors.append(label)
    if isinstance(analysis, dict):
        for value in (
            analysis.get("prompt_surface"),
            analysis.get("subject_area"),
            analysis.get("interaction_mode"),
            analysis.get("output_mode"),
            analysis.get("grounding_mode"),
            analysis.get("evaluation_mode"),
        ):
            normalized = normalize_text(value)
            if normalized and normalized not in {"general", "none"}:
                anchors.append(normalized)
        anchors.extend(normalize_text(tag) for tag in ensure_list(analysis.get("capability_tags")) if normalize_text(tag))
    return join_unique(anchors)


def _append_unique(values: list[str], item: str) -> list[str]:
    normalized = normalize_text(item)
    existing = {normalize_text(value).lower() for value in values if normalize_text(value)}
    if normalized and normalized.lower() not in existing:
        values.append(normalized)
    return values


def _is_generic_role_noise(role: str) -> bool:
    lowered = normalize_text(role).lower()
    if not lowered:
        return False
    return bool(any(term in lowered for term in GENERIC_ROLE_TERMS)) and not _is_operational_role(role)


def _generic_role_from_source(source_text: str) -> str:
    lowered = normalize_text(source_text).lower()
    match = re.search(
        r"\b(?:you are|act as|as an?|as the)\s+(?:a|an|the)?\s*([^.,\n]{0,80}?(?:expert|guru|genius|master|specialist|world-class|world class)[^.,\n]{0,40})",
        lowered,
    )
    if not match:
        return ""
    return normalize_text(match.group(1))


def _is_operational_role(role: str) -> bool:
    lowered = normalize_text(role).lower()
    if not lowered:
        return False
    return any(re.search(rf"\b{re.escape(term)}\b", lowered) for term in OPERATIONAL_ROLE_TERMS)


def _source_mentions_success(text: str) -> bool:
    lowered = normalize_text(text).lower()
    return any(
        phrase in lowered
        for phrase in (
            "success:",
            "success criteria",
            "success test",
            "done when",
            "complete when",
            "acceptance criteria",
            "verify",
            "validated",
        )
    )


def _resolved_surface(analysis: dict[str, Any] | None) -> str:
    if isinstance(analysis, dict):
        surface = normalize_text(analysis.get("prompt_surface")).lower()
        if surface:
            return surface
    return "direct_chat"


def _verification_method(surface: str, success_test: str, output_format: str) -> str:
    profile = SURFACE_PROFILES.get(surface) or SURFACE_PROFILES["direct_chat"]
    if success_test and "parser" in success_test.lower():
        return "Validate with the parser or schema consumer named by the prompt."
    if output_format and any(token in output_format.lower() for token in ("json", "yaml", "xml", "csv", "schema")):
        return "Validate the output against the requested structured format before use."
    return profile["verification_method"]


def _failure_conditions(surface: str, contract: dict[str, Any]) -> list[str]:
    profile = SURFACE_PROFILES.get(surface) or SURFACE_PROFILES["direct_chat"]
    failures = list(profile["failure_conditions"])
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    if not normalize_text(output_contract.get("success_test")):
        failures.append("No observable completion condition is defined.")
    return join_unique(failures)


def _fallback_done_when(output_format: str, surface: str) -> str:
    if output_format:
        return f"The {output_format} is usable on the first pass and satisfies the named constraints."
    profile = SURFACE_PROFILES.get(surface) or SURFACE_PROFILES["direct_chat"]
    return profile["verification_method"]
