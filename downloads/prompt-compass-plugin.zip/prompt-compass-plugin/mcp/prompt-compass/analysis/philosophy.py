from __future__ import annotations

import re
from typing import Any

from common import ensure_list, normalize_text, tokenize


VOICE_MEMO_PHRASES = (
    "voice memo",
    "dictation",
    "stream of consciousness",
    "stream-of-consciousness",
    "brain dump",
    "raw brief",
    "thinking out loud",
)

VOICE_MEMO_FILLERS = (
    "um",
    "uh",
    "like",
    "right",
    "you know",
    "i think",
    "basically",
    "and also",
    "oh and",
    "i also want",
)

DRAFT_REFINEMENT_PHRASES = (
    "improve this prompt",
    "rewrite this prompt",
    "refine this prompt",
    "polish this prompt",
    "tighten this prompt",
    "make this better",
    "fix this prompt",
    "draft prompt",
    "prompt:",
)

SOURCE_PACK_PHRASES = (
    "source pack",
    "sources",
    "transcript",
    "transcripts",
    "notes",
    "document",
    "documents",
    "attached",
    "below",
    "research",
    "knowledge base",
    "retrieved",
    "retrieval",
)

PRESERVE_VOICE_PHRASES = (
    "keep the voice",
    "preserve the voice",
    "preserve tone",
    "preserve wording",
    "keep the tone",
    "without changing the meaning",
    "do not sterilize",
    "keep the style",
    "write this in my style",
)

TERMINOLOGY_PHRASES = (
    "terminology",
    "use this term",
    "must use the term",
    "exact wording",
    "call it",
    "do not call it",
    "canonical term",
    "vocabulary",
    "term table",
    "forbidden synonym",
)

LONG_OUTPUT_PHRASES = (
    "full audit",
    "full plan",
    "full analysis",
    "complete file",
    "all sections",
    "comprehensive analysis",
    "do not stop",
    "continue until",
    "keep going",
)

STYLE_TRAITS = {
    "clear",
    "clearer",
    "concise",
    "strategic",
    "compelling",
    "smart",
    "wise",
    "nuanced",
    "warm",
    "bold",
    "deep",
    "empathetic",
    "emotionally",
    "structured",
    "sharper",
    "polished",
    "professional",
    "comprehensive",
    "actionable",
}


def compress_role_line(value: Any) -> str:
    text = normalize_text(value)
    if not text:
        return ""
    collapsed = re.split(r"\s*(?:,| and | who | with | focused on | specializing in )\s*", text, maxsplit=1)[0]
    words = collapsed.split()
    if len(words) > 8:
        collapsed = " ".join(words[:8])
    return normalize_text(collapsed)


def guess_primary_deliverable(prompt: str, contract: dict[str, Any]) -> str:
    objective = normalize_text(contract.get("objective"))
    if not objective:
        sentences = [normalize_text(item) for item in re.split(r"(?<=[.!?])\s+", normalize_text(prompt)) if normalize_text(item)]
        objective = sentences[0] if sentences else ""
    lowered = objective.lower()
    for prefix in (
        "please ",
        "can you ",
        "help me ",
        "i need ",
        "i want ",
    ):
        if lowered.startswith(prefix):
            objective = objective[len(prefix) :]
            lowered = objective.lower()
            break
    for prefix in (
        "improve this prompt",
        "improve this",
        "make this better",
        "rewrite this prompt",
        "rewrite this",
        "refine this prompt",
        "refine this",
        "write a prompt",
        "build a prompt",
        "create a prompt",
    ):
        if lowered.startswith(prefix):
            objective = objective[len(prefix) :].strip(" .:-")
            lowered = objective.lower()
            break
    objective = re.split(r"\b(?:and then|and also|plus|while|then)\b", objective, maxsplit=1, flags=re.IGNORECASE)[0]
    objective = normalize_text(objective).rstrip(".")
    if objective:
        return objective + "."
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    output_format = normalize_text(output_contract.get("format"))
    if output_format:
        return f"Return a {output_format}."
    return ""


def build_prompt_fingerprint(prompt: str, contract: dict[str, Any]) -> dict[str, Any]:
    text = normalize_text(prompt)
    lowered = text.lower()
    tokens = tokenize(prompt)
    word_count = len(tokens)
    lines = [line for line in prompt.splitlines() if line.strip()]
    visible_sections = sum(1 for line in lines if ":" in line[:50])
    role_hits = len(re.findall(r"\b(?:act as|you are|as a|as an)\b", lowered))
    persona_hits = len(
        re.findall(
            r"\b(?:architect|educator|collaborator|assistant|coach|implementer|reviewer|analyst|planner|teacher|mentor|writer|expert|specialist)\b",
            lowered,
        )
    )
    style_hits = sum(1 for word in STYLE_TRAITS if re.search(rf"\b{re.escape(word)}\b", lowered))
    source_hits = sum(1 for phrase in SOURCE_PACK_PHRASES if phrase in lowered)
    filler_hits = sum(1 for phrase in VOICE_MEMO_FILLERS if phrase in lowered)
    explicit_voice_memo = any(phrase in lowered for phrase in VOICE_MEMO_PHRASES)
    draft_refinement = any(phrase in lowered for phrase in DRAFT_REFINEMENT_PHRASES)
    source_pack_heavy = source_hits >= 2 or len(ensure_list(contract.get("context"))) >= 2
    voice_memo_like = explicit_voice_memo or (
        word_count >= 80
        and filler_hits >= 2
        and lowered.count(" and ") >= 3
        and visible_sections < 2
    )
    role_heavy = role_hits >= 2 or (role_hits >= 1 and persona_hits >= 3)
    trait_stack_heavy = style_hits >= 4
    preserve_voice_requested = any(phrase in lowered for phrase in PRESERVE_VOICE_PHRASES)
    terminology_sensitive = any(phrase in lowered for phrase in TERMINOLOGY_PHRASES)
    negative_constraint_hits = len(re.findall(r"\b(?:do not|don't|never|avoid|without)\b", lowered))
    positive_target_hits = len(re.findall(r"\b(?:write|return|use|optimize for|prioritize|aim for|keep)\b", lowered))
    negative_avoidance_risk = negative_constraint_hits >= 2 and positive_target_hits <= negative_constraint_hits
    continuation_risk = any(phrase in lowered for phrase in LONG_OUTPUT_PHRASES) or (
        word_count >= 260 and (source_pack_heavy or "audit" in lowered or "analysis" in lowered or "plan" in lowered)
    )
    multi_deliverable_risk = _has_multi_deliverable_risk(contract.get("objective") or prompt)

    primary_shape = "direct_request"
    if voice_memo_like:
        primary_shape = "voice_memo_like"
    elif draft_refinement:
        primary_shape = "draft_refinement"
    elif source_pack_heavy:
        primary_shape = "source_pack_heavy"
    elif role_heavy:
        primary_shape = "role_heavy"
    elif trait_stack_heavy:
        primary_shape = "trait_stack_heavy"

    cues: list[str] = []
    if voice_memo_like:
        cues.append("raw or spoken-style brief")
    if draft_refinement:
        cues.append("prompt-improvement draft")
    if source_pack_heavy:
        cues.append("source-heavy brief")
    if role_heavy:
        cues.append("role-heavy framing")
    if trait_stack_heavy:
        cues.append("trait-stack pressure")
    if preserve_voice_requested:
        cues.append("voice preservation requested")
    if terminology_sensitive:
        cues.append("terminology-sensitive")
    if continuation_risk:
        cues.append("long-output continuation risk")
    if negative_avoidance_risk:
        cues.append("negative-only steering risk")
    if multi_deliverable_risk:
        cues.append("multi-deliverable drift")

    return {
        "primary_shape": primary_shape,
        "word_count": word_count,
        "prompt_length_band": _length_band(word_count),
        "voice_memo_like": voice_memo_like,
        "draft_refinement": draft_refinement,
        "source_pack_heavy": source_pack_heavy,
        "role_heavy": role_heavy,
        "trait_stack_heavy": trait_stack_heavy,
        "preserve_voice_requested": preserve_voice_requested,
        "terminology_sensitive": terminology_sensitive,
        "continuation_risk": continuation_risk,
        "negative_avoidance_risk": negative_avoidance_risk,
        "multi_deliverable_risk": multi_deliverable_risk,
        "visible_section_count": visible_sections,
        "cues": cues,
    }


def detect_primary_pattern(prompt: str, contract: dict[str, Any], anti_patterns: list[dict[str, Any]] | None = None) -> dict[str, Any] | None:
    fingerprint = build_prompt_fingerprint(prompt, contract)
    anti_slugs = {normalize_text(item.get("slug")) for item in anti_patterns or []}
    if fingerprint["voice_memo_like"]:
        return _pattern_card("voice-memo-dictation-intake", "Voice Memo / Dictation Intake", "pattern")
    if fingerprint["draft_refinement"]:
        return _pattern_card("prompt-refinement-first", "Prompt Refinement First", "pattern")
    if fingerprint["source_pack_heavy"] or "source-pack-with-vague-ask" in anti_slugs:
        return _pattern_card("context-injection-via-source-pack", "Context Injection via Source Pack", "pattern")
    if fingerprint["trait_stack_heavy"] or "stacked-adjectives" in anti_slugs:
        return _pattern_card("trait-stack-output-control", "Trait-Stack Output Control", "pattern")
    if fingerprint["role_heavy"] or "role-collapse" in anti_slugs:
        return _pattern_card("role-framing-as-shortcut", "Role Framing as Shortcut", "pattern")
    if fingerprint["multi_deliverable_risk"] or "scope-sprawl" in anti_slugs:
        return _pattern_card("one-primary-deliverable-narrowing", "One Primary Deliverable Narrowing", "strategy")
    return None


def core_principles_applied(
    prompt: str,
    contract: dict[str, Any],
    anti_patterns: list[dict[str, Any]] | None = None,
    *,
    workflow_kind: str,
) -> list[str]:
    fingerprint = build_prompt_fingerprint(prompt, contract)
    anti_slugs = {normalize_text(item.get("slug")) for item in anti_patterns or []}
    principles: list[str] = []
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}

    if workflow_kind == "improve":
        if fingerprint["draft_refinement"] or fingerprint["voice_memo_like"] or bool(anti_slugs):
            principles.append("Diagnosis before rewrite")
    else:
        if fingerprint["voice_memo_like"] or fingerprint["source_pack_heavy"] or fingerprint["multi_deliverable_risk"]:
            principles.append("Diagnosis before drafting")
    if fingerprint["voice_memo_like"]:
        principles.append("Context before compression")
    if fingerprint["multi_deliverable_risk"] or "scope-sprawl" in anti_slugs or fingerprint["voice_memo_like"]:
        principles.append("One primary deliverable")
    if fingerprint["role_heavy"] or "role-collapse" in anti_slugs:
        principles.append("Role is a shortcut, not a costume")
    if fingerprint["trait_stack_heavy"] or "stacked-adjectives" in anti_slugs:
        principles.append("Rank trait stacks")
    if fingerprint["source_pack_heavy"] or "source-pack-with-vague-ask" in anti_slugs:
        principles.append("Source packs need explicit extraction goals")
    if fingerprint["terminology_sensitive"]:
        principles.append("Terminology lockdown")
    if fingerprint["continuation_risk"]:
        principles.append("Continuation instructions for long outputs")
    if fingerprint["preserve_voice_requested"] or fingerprint["voice_memo_like"]:
        principles.append("Preserve useful voice while repairing structure")
    if normalize_text(output_contract.get("format")) or normalize_text(output_contract.get("success_test")):
        principles.append("Output contract always")
    return _dedupe(principles)


def _pattern_card(slug: str, name: str, record_type: str) -> dict[str, Any]:
    return {
        "slug": slug,
        "name": name,
        "record_type": record_type,
        "entry_id": f"pc:{record_type}:{slug}",
        "record_layer": "core",
    }


def _has_multi_deliverable_risk(value: Any) -> bool:
    text = normalize_text(value).lower()
    if not text:
        return False
    task_verbs = len(re.findall(r"\b(?:write|create|build|analyze|compare|evaluate|plan|design|draft|rewrite|improve|summarize)\b", text))
    return task_verbs >= 3 or " and " in text or " then " in text or " plus " in text


def _length_band(word_count: int) -> str:
    if word_count >= 220:
        return "long"
    if word_count >= 80:
        return "medium"
    return "short"


def _dedupe(values: list[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        normalized = normalize_text(value)
        if not normalized:
            continue
        key = normalized.lower()
        if key in seen:
            continue
        seen.add(key)
        ordered.append(normalized)
    return ordered
