from __future__ import annotations

import re
from typing import Any

from common import ensure_list, join_unique, normalize_text, tokenize


SUPPORTED_SURFACES = (
    "direct_chat",
    "code_assistant",
    "parser_bound",
    "retrieval_grounded",
    "tool_workflow",
    "multimodal",
)

_CODE_KEYWORDS = {
    "api",
    "bug",
    "code",
    "commit",
    "component",
    "css",
    "debug",
    "file",
    "function",
    "javascript",
    "js",
    "module",
    "patch",
    "pull request",
    "python",
    "refactor",
    "repo",
    "repository",
    "script",
    "sql",
    "test",
    "typescript",
}
_SCHEMA_KEYWORDS = {
    "allowed values",
    "empty value",
    "error behavior",
    "fields",
    "json",
    "json schema",
    "machine-readable",
    "parser",
    "properties",
    "required",
    "schema",
    "xml",
    "yaml",
}
_MODALITY_KEYWORDS = {
    "audio",
    "chart",
    "diagram",
    "image",
    "ocr",
    "photo",
    "screenshot",
    "table image",
    "video",
    "vision",
}

_FIX_ACTIONS = {
    "missing-objective": "State the one job this prompt should accomplish in one sentence.",
    "missing-output-contract": "Add an explicit output contract that names the artifact, format, and length.",
    "missing-success-test": "Define what makes the output usable on the first pass.",
    "schema-theater": "Replace format-only instructions with required fields, allowed values, and empty or error behavior.",
    "source-pack-with-vague-ask": "Name the decision, deliverable, or question the source pack should support.",
    "tool-thrash": "Add clear tool trigger rules so the model does not keep calling tools by reflex.",
    "agentic-overrun": "Define a stop condition so the model knows when to return control.",
    "weak-source-priority": "State which source wins when evidence conflicts or the context disagrees.",
    "missing-multimodal-fallback": "Add a fallback rule for missing, low-quality, or conflicting modalities.",
    "missing-confirmation-boundary": "State which actions require explicit confirmation before the model proceeds.",
    "instruction-wall": "Compress the prompt to the task, key constraints, and visible output contract.",
    "stacked-adjectives": "Rank the quality goals instead of stacking style adjectives with no priority order.",
    "context-hoarding": "Rank the source material by priority so the model knows what matters first.",
    "middle-buried-requirement": "Pull the hardest requirement up into a visible constraint near the top.",
    "trusted-source-collapse": "Separate trusted instructions from external content that should be treated as evidence only.",
}

_EFFICIENCY_RULES = {
    "instruction-wall": {
        "waste_type": "token_waste",
        "why_it_costs": "Dense instruction mass makes the model spend tokens re-parsing the prompt before it can act on the real job.",
    },
    "stacked-adjectives": {
        "waste_type": "token_waste",
        "why_it_costs": "Unranked quality words expand the prompt without telling the model which quality goal should win first.",
    },
    "context-hoarding": {
        "waste_type": "token_waste",
        "why_it_costs": "Large unranked context forces the model to sift through low-priority material before it can use the highest-value evidence.",
    },
    "missing-output-contract": {
        "waste_type": "iteration_waste",
        "why_it_costs": "Missing artifact rules usually creates one extra rewrite pass just to clarify what the answer should look like.",
    },
    "missing-success-test": {
        "waste_type": "iteration_waste",
        "why_it_costs": "Without a usable success test, the model can produce structurally correct output that still needs another corrective pass.",
    },
    "vague-compression": {
        "waste_type": "iteration_waste",
        "why_it_costs": "Vague improvement asks tend to produce generic rewrites that require another round to define the real deliverable.",
    },
    "weak-source-priority": {
        "waste_type": "retrieval_waste",
        "why_it_costs": "Grounded prompts waste effort when the model has to guess which source should win after it has already read the evidence.",
    },
    "source-pack-with-vague-ask": {
        "waste_type": "retrieval_waste",
        "why_it_costs": "A large source pack without a named job makes the model retrieve broadly and synthesize loosely before the real target is clear.",
    },
    "trusted-source-collapse": {
        "waste_type": "retrieval_waste",
        "why_it_costs": "Mixing evidence with instructions raises the odds of retrieval misuse and forces manual correction later.",
    },
    "schema-theater": {
        "waste_type": "parser_retry_risk",
        "why_it_costs": "Format-only structure tends to fail downstream parsing and forces retry cycles instead of one clean pass.",
    },
    "tool-thrash": {
        "waste_type": "tool_churn_risk",
        "why_it_costs": "Loose tool rules encourage repeated calls that spend time and tokens without moving the task to completion.",
    },
    "agentic-overrun": {
        "waste_type": "tool_churn_risk",
        "why_it_costs": "Open-ended autonomy increases the chance of extra tool calls and extra turns before the model hands control back.",
    },
    "missing-confirmation-boundary": {
        "waste_type": "tool_churn_risk",
        "why_it_costs": "Missing confirmation rules creates avoidable backtracking when the model reaches a risky action and has to recover or ask late.",
    },
}

_SURFACE_ALLOWLIST_SLOTS = {
    "direct_chat": ["evaluation"],
    "code_assistant": ["evaluation", "model_target"],
    "parser_bound": ["parser_contract", "evaluation", "model_target"],
    "retrieval_grounded": ["grounding", "evaluation", "model_target"],
    "tool_workflow": ["runtime_layer", "tool_use", "agent_control"],
    "multimodal": ["runtime_layer", "grounding", "model_target"],
}


def classify_prompt_surface(
    prompt: str,
    *,
    contract: dict[str, Any],
    subject_area: str,
    interaction_mode: str,
    output_mode: str,
    grounding_mode: str,
    evaluation_mode: str,
    capability_tags: list[str],
    anti_patterns: list[dict[str, Any]],
) -> dict[str, Any]:
    anti_slugs = {normalize_text(item.get("slug")) for item in anti_patterns}
    capability_set = {normalize_text(tag) for tag in capability_tags}
    probe = _analysis_probe(prompt, contract)
    probe_text = " ".join(probe)
    grounding_probe = " ".join([normalize_text(prompt).lower(), " ".join(normalize_text(item).lower() for item in ensure_list(contract.get("context")))])
    output_contract = contract.get("output_contract", {}) if isinstance(contract.get("output_contract"), dict) else {}
    parser_probe = " ".join(
        [
            normalize_text(output_contract.get("format")).lower(),
            normalize_text(output_contract.get("success_test")).lower(),
            " ".join(normalize_text(item).lower() for item in ensure_list(contract.get("constraints"))),
        ]
    )
    surface = "direct_chat"

    has_multimodal = interaction_mode == "multimodal" or "multimodal" in capability_set or any(
        keyword in probe_text for keyword in _MODALITY_KEYWORDS
    )
    has_tooling = interaction_mode == "tool_calling" or capability_set & {"tool_use", "function_calling", "agentic_tool_use"} or anti_slugs & {
        "agentic-overrun",
        "tool-thrash",
    }
    has_grounding = grounding_mode in {"retrieval", "quote_first"} or capability_set & {
        "context_engineering",
        "quote_first_evidence",
        "retrieval_grounding",
        "source_priority",
        "untrusted_context",
    } or anti_slugs & {"context-hoarding", "source-pack-with-vague-ask", "trusted-source-collapse"} or any(
        phrase in grounding_probe
        for phrase in ("ground each claim", "ground every claim", "quoted evidence", "docs below", "notes below", "sources below", "use the notes", "use the docs")
    )
    has_parser = output_mode == "schema_bound" or capability_set & {"json_schema", "parser_aware"} or any(
        keyword in parser_probe for keyword in _SCHEMA_KEYWORDS
    )
    has_code = normalize_text(subject_area) == "coding" or any(keyword in probe_text for keyword in _CODE_KEYWORDS)

    if has_multimodal:
        surface = "multimodal"
    elif has_tooling:
        surface = "tool_workflow"
    elif has_grounding:
        surface = "retrieval_grounded"
    elif has_parser:
        surface = "parser_bound"
    elif has_code:
        surface = "code_assistant"

    traits: list[str] = []
    if _looks_template_like(prompt, contract):
        traits.append("template_like")
    if surface == "parser_bound" or has_parser or "structured_output" in capability_set:
        traits.append("parser_aware")
    if surface == "retrieval_grounded" or has_grounding:
        traits.append("retrieval")
    if surface == "tool_workflow" or has_tooling:
        traits.append("tool_use")
    if surface == "multimodal" or has_multimodal:
        traits.append("multimodal")
    if traits or evaluation_mode not in {"", "none"} or capability_set & {"long_context", "stop_conditions"}:
        traits.append("runtime_aware")

    return {
        "prompt_surface": surface,
        "surface_traits": join_unique(traits),
    }


def build_preflight_fields(
    prompt: str,
    *,
    analysis: dict[str, Any],
) -> dict[str, Any]:
    prompt_surface = normalize_text(analysis.get("prompt_surface")) or "direct_chat"
    surface_traits = [normalize_text(tag) for tag in ensure_list(analysis.get("surface_traits")) if normalize_text(tag)]
    contract = analysis.get("prompt_contract", {}) if isinstance(analysis.get("prompt_contract"), dict) else {}
    output_contract_check = analysis.get("output_contract_check", {}) if isinstance(analysis.get("output_contract_check"), dict) else {}
    anti_patterns = ensure_list(analysis.get("anti_patterns"))
    anti_slugs = {normalize_text(item.get("slug")) for item in anti_patterns}
    missing = {normalize_text(item) for item in ensure_list(analysis.get("missing_building_blocks"))}

    blocking_issues = _build_blocking_issues(
        prompt_surface=prompt_surface,
        anti_patterns=anti_patterns,
        anti_slugs=anti_slugs,
        missing=missing,
        output_contract_check=output_contract_check,
    )
    warning_flags = _build_warning_flags(
        prompt,
        prompt_surface=prompt_surface,
        anti_patterns=anti_patterns,
        anti_slugs=anti_slugs,
        contract=contract,
        output_contract_check=output_contract_check,
    )
    efficiency_flags = _build_efficiency_flags(
        blocking_issues=blocking_issues,
        warning_flags=warning_flags,
    )
    scorecard = _build_preflight_scorecard(
        prompt_surface=prompt_surface,
        surface_traits=surface_traits,
        anti_slugs=anti_slugs,
        missing=missing,
        contract=contract,
        output_contract_check=output_contract_check,
    )
    total = scorecard["total"]
    if blocking_issues or total <= 9:
        status = "high_risk"
    elif warning_flags or total <= 15:
        status = "needs_clarification"
    else:
        status = "ready"

    fix_now = _rank_fix_now(
        prompt_surface=prompt_surface,
        blocking_issues=blocking_issues,
        warning_flags=warning_flags,
        efficiency_flags=efficiency_flags,
        status=status,
    )
    recommended_question_slots = _recommended_question_slots(
        prompt_surface=prompt_surface,
        status=status,
        output_contract_check=output_contract_check,
        model_target=normalize_text(contract.get("model_target")),
    )
    recommended_next_action = _recommended_next_action(
        prompt_surface=prompt_surface,
        status=status,
        blocking_issues=blocking_issues,
        recommended_question_slots=recommended_question_slots,
    )
    return {
        "preflight_scorecard": scorecard,
        "preflight_status": status,
        "blocking_issues": blocking_issues,
        "warning_flags": warning_flags,
        "efficiency_flags": efficiency_flags,
        "fix_now": fix_now,
        "recommended_question_slots": recommended_question_slots,
        "recommended_next_action": recommended_next_action,
    }


def _analysis_probe(prompt: str, contract: dict[str, Any]) -> list[str]:
    output_contract = contract.get("output_contract", {}) if isinstance(contract.get("output_contract"), dict) else {}
    return [
        normalize_text(prompt).lower(),
        normalize_text(contract.get("objective")).lower(),
        normalize_text(contract.get("audience")).lower(),
        " ".join(normalize_text(item).lower() for item in ensure_list(contract.get("context"))),
        " ".join(normalize_text(item).lower() for item in ensure_list(contract.get("constraints"))),
        normalize_text(output_contract.get("format")).lower(),
        normalize_text(output_contract.get("success_test")).lower(),
    ]


def _looks_template_like(prompt: str, contract: dict[str, Any]) -> bool:
    text = normalize_text(prompt)
    if any(marker in text for marker in ("{", "}", "[", "]", "<", ">")):
        return True
    if re.search(r"\b(template|placeholder|fill in|fill-in|variable|slot|reusable)\b", text, flags=re.IGNORECASE):
        return True
    steps = ensure_list(contract.get("steps"))
    return len(steps) >= 3 and any(re.search(r"\b(first|then|finally|next)\b", normalize_text(step), flags=re.IGNORECASE) for step in steps)


def _issue(slug: str, severity: str, message: str, why: str) -> dict[str, str]:
    return {
        "slug": slug,
        "severity": severity,
        "message": message,
        "why": why,
    }


def _build_blocking_issues(
    *,
    prompt_surface: str,
    anti_patterns: list[dict[str, Any]],
    anti_slugs: set[str],
    missing: set[str],
    output_contract_check: dict[str, Any],
) -> list[dict[str, str]]:
    issues: list[dict[str, str]] = []
    if "objective" in missing:
        issues.append(
            _issue(
                "missing-objective",
                "high",
                "The prompt does not state one clear objective.",
                "Preflight blocks direct execution when the core job is still implicit.",
            )
        )
    if "output_contract" in missing or not output_contract_check.get("has_output_contract"):
        issues.append(
            _issue(
                "missing-output-contract",
                "high",
                "The prompt does not define a visible output contract.",
                "Preflight blocks direct execution when the target artifact is still underspecified.",
            )
        )
    if prompt_surface == "parser_bound" and "schema-theater" in anti_slugs:
        issues.append(
            _issue(
                "schema-theater",
                "high",
                "The prompt names machine-readable output without a real parser contract.",
                "Parser-bound prompts need explicit fields, rules, and validation behavior.",
            )
        )
    if prompt_surface == "retrieval_grounded" and "source-pack-with-vague-ask" in anti_slugs:
        issues.append(
            _issue(
                "source-pack-with-vague-ask",
                "high",
                "The prompt includes source material but never states the concrete job it should support.",
                "Retrieved evidence should answer a named question or deliver a named artifact.",
            )
        )
    if prompt_surface == "tool_workflow" and "tool-thrash" in anti_slugs:
        issues.append(
            _issue(
                "tool-thrash",
                "high",
                "The prompt encourages tool use without a stable trigger or boundary.",
                "Tool-workflow prompts should define when tools are necessary, not just that tools exist.",
            )
        )
    if prompt_surface == "tool_workflow" and "agentic-overrun" in anti_slugs:
        issues.append(
            _issue(
                "agentic-overrun",
                "high",
                "The prompt encourages continued autonomous work without a clear stop condition.",
                "Tool-workflow prompts should know when to stop and hand control back.",
            )
        )
    if prompt_surface in {"parser_bound", "tool_workflow"} and not output_contract_check.get("has_success_test"):
        issues.append(
            _issue(
                "missing-success-test",
                "high",
                "The prompt names an operational surface but never defines what usable output looks like.",
                "Parser-bound and tool-workflow prompts need a success test before rewrite or execution.",
            )
        )

    deduped: list[dict[str, str]] = []
    seen: set[str] = set()
    for issue in issues:
        if issue["slug"] in seen:
            continue
        seen.add(issue["slug"])
        deduped.append(issue)
    return deduped


def _build_warning_flags(
    prompt: str,
    *,
    prompt_surface: str,
    anti_patterns: list[dict[str, Any]],
    anti_slugs: set[str],
    contract: dict[str, Any],
    output_contract_check: dict[str, Any],
) -> list[dict[str, str]]:
    blocking_slugs = {item["slug"] for item in _build_blocking_issues(
        prompt_surface=prompt_surface,
        anti_patterns=anti_patterns,
        anti_slugs=anti_slugs,
        missing=set(),
        output_contract_check=output_contract_check,
    )}
    warnings: list[dict[str, str]] = []
    for item in anti_patterns:
        slug = normalize_text(item.get("slug"))
        if not slug or slug in blocking_slugs:
            continue
        warnings.append(
            _issue(
                slug,
                normalize_text(item.get("severity")) or "medium",
                normalize_text(item.get("name")) or slug.replace("-", " "),
                normalize_text(item.get("why_detected")) or "The current prompt shape creates avoidable execution risk.",
            )
        )

    prompt_lower = normalize_text(prompt).lower()
    if prompt_surface == "retrieval_grounded" and not any(
        token in prompt_lower for token in ("priority", "authoritative", "highest priority", "if sources conflict", "prefer")
    ):
        warnings.append(
            _issue(
                "weak-source-priority",
                "medium",
                "The prompt asks for grounded work but does not rank which source should win when evidence conflicts.",
                "Retrieval-grounded prompts are stronger when source priority is explicit.",
            )
        )
    if prompt_surface == "tool_workflow" and not any(
        token in prompt_lower for token in ("confirm", "confirmation", "approve", "approval")
    ):
        warnings.append(
            _issue(
                "missing-confirmation-boundary",
                "medium",
                "The prompt allows tool activity without naming which actions need user confirmation.",
                "Tool-workflow prompts benefit from a visible confirmation boundary for high-impact actions.",
            )
        )
    if prompt_surface == "multimodal" and not any(
        token in prompt_lower for token in ("if the image is missing", "if the audio is missing", "fallback", "if one modality", "if the screenshot")
    ):
        warnings.append(
            _issue(
                "missing-multimodal-fallback",
                "medium",
                "The prompt uses multiple modalities but does not say what to do if one input is missing, weak, or conflicting.",
                "Multimodal prompts need a fallback or reconciliation rule for uneven inputs.",
            )
        )

    deduped: list[dict[str, str]] = []
    seen: set[str] = set()
    for warning in warnings:
        if warning["slug"] in seen:
            continue
        seen.add(warning["slug"])
        deduped.append(warning)
    return deduped


def _build_efficiency_flags(
    *,
    blocking_issues: list[dict[str, str]],
    warning_flags: list[dict[str, str]],
) -> list[dict[str, str]]:
    flags: list[dict[str, str]] = []
    seen: set[str] = set()
    for item in [*blocking_issues, *warning_flags]:
        slug = normalize_text(item.get("slug"))
        if not slug or slug in seen:
            continue
        rule = _EFFICIENCY_RULES.get(slug)
        if not rule:
            continue
        seen.add(slug)
        flags.append(
            {
                "slug": slug,
                "severity": normalize_text(item.get("severity")) or "medium",
                "waste_type": rule["waste_type"],
                "why_it_costs": rule["why_it_costs"],
                "suggested_fix": _FIX_ACTIONS.get(slug, "Tighten the prompt so the model can reach the target output in one pass."),
            }
        )
    return flags


def _build_preflight_scorecard(
    *,
    prompt_surface: str,
    surface_traits: list[str],
    anti_slugs: set[str],
    missing: set[str],
    contract: dict[str, Any],
    output_contract_check: dict[str, Any],
) -> dict[str, Any]:
    has_context = bool(ensure_list(contract.get("context")))
    has_constraints = bool(ensure_list(contract.get("constraints")))
    has_steps = bool(ensure_list(contract.get("steps")))
    has_objective = "objective" not in missing
    has_audience = "audience" not in missing
    has_output_contract = output_contract_check.get("has_output_contract", False)
    has_success_test = output_contract_check.get("has_success_test", False)

    contract_readiness = 0
    contract_readiness += 2 if has_objective else 0
    contract_readiness += 1 if has_audience else 0
    contract_readiness += 1 if has_output_contract else 0
    contract_readiness += 1 if has_success_test else 0

    if prompt_surface in {"retrieval_grounded", "multimodal"}:
        grounding_readiness = 1 + int(has_context)
        grounding_readiness += int("source-pack-with-vague-ask" not in anti_slugs)
        grounding_readiness += int("trusted-source-collapse" not in anti_slugs)
        grounding_readiness += int("weak-source-priority" not in anti_slugs)
    else:
        grounding_readiness = 3 + int("hallucination-bait" not in anti_slugs) + int("trusted-source-collapse" not in anti_slugs)

    runtime_readiness = 2 + int(has_constraints) + int(has_steps or prompt_surface != "tool_workflow")
    if prompt_surface == "parser_bound":
        runtime_readiness += int("schema-theater" not in anti_slugs)
    elif prompt_surface == "tool_workflow":
        runtime_readiness += int("tool-thrash" not in anti_slugs and "agentic-overrun" not in anti_slugs)
    elif prompt_surface == "retrieval_grounded":
        runtime_readiness += int("retrieval" in surface_traits)
    else:
        runtime_readiness += int("runtime_aware" not in surface_traits or has_output_contract)

    surface_fit = 2
    if prompt_surface == "direct_chat":
        surface_fit += int("instruction-wall" not in anti_slugs) + int("stacked-adjectives" not in anti_slugs) + int(has_output_contract)
    elif prompt_surface == "code_assistant":
        surface_fit += int(has_output_contract) + int(has_success_test) + int(has_constraints or has_steps)
    elif prompt_surface == "parser_bound":
        surface_fit += int(has_output_contract) + int(has_success_test) + int("parser_aware" in surface_traits) - int("schema-theater" in anti_slugs)
    elif prompt_surface == "retrieval_grounded":
        surface_fit += int(has_context) + int(has_success_test) + int("retrieval" in surface_traits) - int("source-pack-with-vague-ask" in anti_slugs)
    elif prompt_surface == "tool_workflow":
        surface_fit += int(has_constraints) + int(has_success_test) + int("tool_use" in surface_traits) - int(
            "tool-thrash" in anti_slugs or "agentic-overrun" in anti_slugs
        )
    else:
        surface_fit += int(has_context) + int(has_success_test) + int("multimodal" in surface_traits)

    dimensions = {
        "contract_readiness": {
            "score": _clamp(contract_readiness),
            "max": 5,
            "rationale": "Higher when the prompt states the job, artifact, and usable output test explicitly.",
        },
        "grounding_readiness": {
            "score": _clamp(grounding_readiness),
            "max": 5,
            "rationale": "Higher when the prompt handles source boundaries, evidence use, and conflict handling clearly enough for its surface.",
        },
        "runtime_readiness": {
            "score": _clamp(runtime_readiness),
            "max": 5,
            "rationale": "Higher when the prompt has the operational rules its runtime surface actually needs.",
        },
        "surface_fit": {
            "score": _clamp(surface_fit),
            "max": 5,
            "rationale": "Higher when the prompt shape matches the inferred execution surface instead of fighting it.",
        },
    }
    total = sum(item["score"] for item in dimensions.values())
    return {
        "dimensions": dimensions,
        "total": total,
        "max_total": 20,
        "label": _preflight_label(total),
    }


def _rank_fix_now(
    *,
    prompt_surface: str,
    blocking_issues: list[dict[str, str]],
    warning_flags: list[dict[str, str]],
    efficiency_flags: list[dict[str, str]],
    status: str,
) -> list[str]:
    ranked: list[str] = []
    for item in [*blocking_issues, *warning_flags]:
        action = _FIX_ACTIONS.get(item["slug"])
        if action and action not in ranked:
            ranked.append(action)
        if len(ranked) >= 3:
            return ranked

    for item in efficiency_flags:
        action = normalize_text(item.get("suggested_fix"))
        if action and action not in ranked:
            ranked.append(action)
        if len(ranked) >= 3:
            return ranked

    ready_actions = {
        "direct_chat": "Run direct-chat surface targeting so the prompt stays compact and task-first.",
        "code_assistant": "Run code-assistant surface targeting so files, tools, and test boundaries stay explicit.",
        "parser_bound": "Run parser-bound surface targeting so the schema contract stays visible and wrapper-free.",
        "retrieval_grounded": "Run retrieval-grounded surface targeting so the source-of-truth rule stays explicit.",
        "tool_workflow": "Run tool-workflow surface targeting so trigger rules, confirmation boundaries, and stop conditions stay visible.",
        "multimodal": "Run multimodal surface targeting so modality roles, fallback behavior, and reconciliation rules stay explicit.",
    }
    if status == "ready":
        ranked.append(ready_actions.get(prompt_surface, ready_actions["direct_chat"]))
    return ranked[:3]


def _recommended_question_slots(
    *,
    prompt_surface: str,
    status: str,
    output_contract_check: dict[str, Any],
    model_target: str,
) -> list[str]:
    if status == "ready":
        return []
    slots = list(_SURFACE_ALLOWLIST_SLOTS.get(prompt_surface, []))
    if not output_contract_check.get("has_success_test") and "evaluation" not in slots:
        slots.append("evaluation")
    if not model_target and prompt_surface in {"code_assistant", "parser_bound", "multimodal"} and "model_target" not in slots:
        slots.append("model_target")
    return join_unique(slots)[:3]


def _recommended_next_action(
    *,
    prompt_surface: str,
    status: str,
    blocking_issues: list[dict[str, str]],
    recommended_question_slots: list[str],
) -> str:
    if status == "high_risk":
        top_issue = blocking_issues[0]["slug"] if blocking_issues else "prompt-contract"
        return f"Resolve the top blocker (`{top_issue}`), then rerun preflight before rewrite or execution."
    if status == "needs_clarification":
        if recommended_question_slots:
            return f"Answer the runtime clarifiers for {prompt_surface} ({', '.join(recommended_question_slots)}), then rerun preflight or rewrite."
        return "Clarify the remaining weak spots, then rerun preflight before you rewrite."
    return f"Proceed to `{prompt_surface}` targeting, then apply model targeting only if you need model-specific adaptation."


def _clamp(value: int) -> int:
    return max(0, min(value, 5))


def _preflight_label(total: int) -> str:
    if total >= 17:
        return "ready"
    if total >= 11:
        return "needs_clarification"
    return "high_risk"
