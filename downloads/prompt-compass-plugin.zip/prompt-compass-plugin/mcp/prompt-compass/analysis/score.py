from __future__ import annotations

from typing import Any

from common import ensure_list, normalize_text


def _clamp(value: int) -> int:
    return max(0, min(value, 5))


def _has_anti(anti_patterns: list[dict[str, Any]], slug: str) -> bool:
    return any(item.get("slug") == slug for item in anti_patterns)


def raccca_score(
    prompt: str,
    contract: dict[str, Any],
    anti_patterns: list[dict[str, Any]],
    *,
    output_contract_check: dict[str, Any],
    semantic_conflicts: list[dict[str, Any]] | None = None,
    ai_data_risk_warnings: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    semantic_conflicts = ensure_list(semantic_conflicts)
    ai_data_risk_warnings = ensure_list(ai_data_risk_warnings)
    objective = bool(normalize_text(contract.get("objective")))
    audience = bool(normalize_text(contract.get("audience")))
    context = bool(ensure_list(contract.get("context")))
    constraints = bool(ensure_list(contract.get("constraints")))
    steps = bool(ensure_list(contract.get("steps")))
    role = bool(normalize_text(contract.get("role")))
    examples = bool(ensure_list(contract.get("examples")))

    relevance = 1 + int(objective) + int(context) + int(audience) + int(bool(contract.get("subject_area")))
    accuracy = 2 + int(constraints) + int(not _has_anti(anti_patterns, "hallucination-bait")) + int(not _has_anti(anti_patterns, "role-collapse"))
    completeness = int(objective) + int(audience) + int(context) + int(constraints) + int(output_contract_check.get("has_output_contract"))
    clarity = 2 + int(not _has_anti(anti_patterns, "instruction-wall")) + int(not _has_anti(anti_patterns, "stacked-adjectives")) + int(output_contract_check.get("has_output_contract"))
    coherence = 2 + int(steps) + int(role) + int(not _has_anti(anti_patterns, "scope-sprawl")) + int(not _has_anti(anti_patterns, "intent-dump"))
    appropriateness = 1 + int(audience) + int(output_contract_check.get("has_output_contract")) + int(examples) + int(not _has_anti(anti_patterns, "ghost-audience"))

    dimensions = {
        "relevance": {
            "score": _clamp(relevance),
            "max": 5,
            "rationale": _relevance_rationale(contract, objective=objective, context=context, audience=audience),
        },
        "accuracy": {
            "score": _clamp(accuracy),
            "max": 5,
            "rationale": _accuracy_rationale(contract, anti_patterns, constraints=constraints),
        },
        "completeness": {
            "score": _clamp(completeness),
            "max": 5,
            "rationale": _completeness_rationale(contract, output_contract_check=output_contract_check),
        },
        "clarity": {
            "score": _clamp(clarity),
            "max": 5,
            "rationale": _clarity_rationale(prompt, anti_patterns, output_contract_check=output_contract_check),
        },
        "coherence": {
            "score": _clamp(coherence),
            "max": 5,
            "rationale": _coherence_rationale(contract, anti_patterns, steps=steps, role=role),
        },
        "appropriateness": {
            "score": _clamp(appropriateness),
            "max": 5,
            "rationale": _appropriateness_rationale(contract, anti_patterns, examples=examples, output_contract_check=output_contract_check),
        },
    }
    if semantic_conflicts:
        conflict_names = ", ".join(normalize_text(item.get("name")) for item in semantic_conflicts[:3] if normalize_text(item.get("name")))
        accuracy_score = dimensions["accuracy"]["score"]
        coherence_score = dimensions["coherence"]["score"]
        dimensions["accuracy"]["score"] = min(accuracy_score, 3)
        dimensions["coherence"]["score"] = min(coherence_score, 3)
        dimensions["accuracy"]["rationale"] += f" Semantic conflicts cap accuracy: {conflict_names}."
        dimensions["coherence"]["rationale"] += f" Semantic conflicts cap coherence: {conflict_names}."
    if ai_data_risk_warnings:
        warning_names = ", ".join(normalize_text(item.get("name")) for item in ai_data_risk_warnings[:3] if normalize_text(item.get("name")))
        dimensions["accuracy"]["score"] = min(dimensions["accuracy"]["score"], 3)
        dimensions["appropriateness"]["score"] = min(dimensions["appropriateness"]["score"], 3)
        dimensions["accuracy"]["rationale"] += f" AI/data risk warning lowers accuracy readiness: {warning_names}."
        dimensions["appropriateness"]["rationale"] += f" AI/data risk warning lowers audience/readiness fit: {warning_names}."
    total = sum(item["score"] for item in dimensions.values())
    return {
        "dimensions": dimensions,
        "total": total,
        "max_total": 30,
        "label": _label(total),
        "semantic_conflict_count": len(semantic_conflicts),
        "semantic_conflict_cap_applied": bool(semantic_conflicts),
        "ai_data_risk_warning_count": len(ai_data_risk_warnings),
        "ai_data_risk_cap_applied": bool(ai_data_risk_warnings),
    }


def _label(total: int) -> str:
    if total >= 25:
        return "strong"
    if total >= 19:
        return "workable"
    if total >= 13:
        return "fragile"
    return "weak"


def _relevance_rationale(contract: dict[str, Any], *, objective: bool, context: bool, audience: bool) -> str:
    evidence: list[str] = []
    if objective:
        evidence.append(f"objective is explicit: {normalize_text(contract.get('objective'))[:80]}")
    else:
        evidence.append("objective is still implicit")
    if audience:
        evidence.append(f"audience is named: {normalize_text(contract.get('audience'))[:60]}")
    else:
        evidence.append("audience is not clearly named")
    if context:
        evidence.append("supporting context is present")
    else:
        evidence.append("supporting context is thin or absent")
    return "; ".join(evidence) + "."


def _accuracy_rationale(contract: dict[str, Any], anti_patterns: list[dict[str, Any]], *, constraints: bool) -> str:
    issues: list[str] = []
    if constraints:
        issues.append("explicit boundaries or constraints are present")
    else:
        issues.append("few explicit boundaries are present")
    if _has_anti(anti_patterns, "hallucination-bait"):
        issues.append("the prompt pressures certainty beyond its context")
    if _has_anti(anti_patterns, "role-collapse"):
        issues.append("multiple role frames compete")
    if not _has_anti(anti_patterns, "hallucination-bait") and not _has_anti(anti_patterns, "role-collapse"):
        issues.append("assumption risk looks moderate rather than acute")
    return "; ".join(issues) + "."


def _completeness_rationale(contract: dict[str, Any], *, output_contract_check: dict[str, Any]) -> str:
    missing: list[str] = []
    if not normalize_text(contract.get("objective")):
        missing.append("objective")
    if not normalize_text(contract.get("audience")):
        missing.append("audience")
    if not ensure_list(contract.get("context")):
        missing.append("context")
    if not ensure_list(contract.get("constraints")):
        missing.append("constraints")
    if not output_contract_check.get("has_output_contract"):
        missing.append("output contract")
    if not missing:
        return "The prompt includes the core building blocks: objective, audience, context, constraints, and a visible output contract."
    return "The prompt still leaves the model to infer: " + ", ".join(missing) + "."


def _clarity_rationale(prompt: str, anti_patterns: list[dict[str, Any]], *, output_contract_check: dict[str, Any]) -> str:
    notes: list[str] = []
    if output_contract_check.get("has_output_contract"):
        notes.append("the output shape is visible")
    else:
        notes.append("the output shape is still vague")
    if _has_anti(anti_patterns, "instruction-wall"):
        notes.append("instruction density is high")
    if _has_anti(anti_patterns, "stacked-adjectives"):
        notes.append("style pressure is overloaded")
    if len(normalize_text(prompt).splitlines()) > 1:
        notes.append("the prompt has some visible structure")
    if len(notes) == 1:
        notes.append("nothing else strongly improves readability yet")
    return "; ".join(notes) + "."


def _coherence_rationale(contract: dict[str, Any], anti_patterns: list[dict[str, Any]], *, steps: bool, role: bool) -> str:
    notes: list[str] = []
    if steps:
        notes.append("the task flow includes explicit steps")
    else:
        notes.append("the task flow is mostly implied")
    if role:
        notes.append(f"role is anchored as {normalize_text(contract.get('role'))[:50]}")
    if _has_anti(anti_patterns, "scope-sprawl"):
        notes.append("multiple deliverables still compete")
    if _has_anti(anti_patterns, "role-collapse"):
        notes.append("multiple role frames reduce coherence")
    return "; ".join(notes) + "."


def _appropriateness_rationale(
    contract: dict[str, Any],
    anti_patterns: list[dict[str, Any]],
    *,
    examples: bool,
    output_contract_check: dict[str, Any],
) -> str:
    notes: list[str] = []
    if normalize_text(contract.get("audience")):
        notes.append("the audience is named")
    else:
        notes.append("the audience fit is still inferred")
    if output_contract_check.get("has_output_contract"):
        notes.append(f"the output artifact is stated as {normalize_text(output_contract_check.get('format')) or 'a named format'}")
    if examples:
        notes.append("examples or references help calibrate the response")
    if _has_anti(anti_patterns, "ghost-audience"):
        notes.append("tone cues appear without a secure reader fit")
    return "; ".join(notes) + "."
