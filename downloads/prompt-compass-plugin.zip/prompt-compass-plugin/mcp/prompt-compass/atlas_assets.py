from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

from common import normalize_text, tokenize


ROOT = Path(__file__).resolve().parent
ATLAS_RESOURCES_DIR = ROOT / "support" / "resources" / "atlas"
TASK_TEMPLATE_EXAMPLES_PATH = ATLAS_RESOURCES_DIR / "task_template_examples.json"
AUDIENCE_TARGETING_SEEDS_PATH = ATLAS_RESOURCES_DIR / "audience_targeting_seeds.json"
PROMPT_LIBRARY_STARTERS_PATH = ATLAS_RESOURCES_DIR / "prompt_library_starter_examples.json"


@lru_cache(maxsize=None)
def load_task_template_examples() -> list[dict[str, Any]]:
    return _load_json_list(TASK_TEMPLATE_EXAMPLES_PATH)


@lru_cache(maxsize=None)
def load_audience_targeting_seeds() -> list[dict[str, Any]]:
    return _load_json_list(AUDIENCE_TARGETING_SEEDS_PATH)


@lru_cache(maxsize=None)
def load_prompt_library_starter_examples() -> list[dict[str, Any]]:
    return _load_json_list(PROMPT_LIBRARY_STARTERS_PATH)


def select_task_template_examples(text: str, *, limit: int = 3) -> list[dict[str, Any]]:
    return _rank_assets(text, load_task_template_examples(), limit=limit)


def select_audience_targeting_seeds(text: str, *, limit: int = 3) -> list[dict[str, Any]]:
    return _rank_assets(text, load_audience_targeting_seeds(), limit=limit)


def select_prompt_library_starter_examples(text: str, *, limit: int = 3) -> list[dict[str, Any]]:
    return _rank_assets(text, load_prompt_library_starter_examples(), limit=limit)


def _load_json_list(path: Path) -> list[dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, list):
        raise ValueError(f"{path} must contain a JSON list.")
    return [item for item in payload if isinstance(item, dict)]


def _rank_assets(text: str, assets: list[dict[str, Any]], *, limit: int) -> list[dict[str, Any]]:
    query_tokens = set(tokenize(text))
    scored: list[tuple[int, int, dict[str, Any]]] = []
    for index, asset in enumerate(assets):
        keywords = {normalize_text(item).lower() for item in asset.get("keywords", []) if normalize_text(item)}
        keyword_score = sum(3 for keyword in keywords if keyword and keyword in normalize_text(text).lower())
        token_score = len(query_tokens & set(tokenize(" ".join(asset.get("keywords", [])))))
        priority_score = int(asset.get("priority", 0))
        score = keyword_score + token_score + priority_score
        scored.append((score, -index, asset))
    ranked = [asset for score, _, asset in sorted(scored, reverse=True) if score > 0]
    if len(ranked) < limit:
        remaining = [asset for _, _, asset in sorted(scored, reverse=True) if asset not in ranked]
        ranked.extend(remaining)
    return [_compact_asset(asset) for asset in ranked[:limit]]


def _compact_asset(asset: dict[str, Any]) -> dict[str, Any]:
    keys = [
        "id",
        "title",
        "summary",
        "best_for",
        "audience_constraints",
        "starter_prompt",
        "template_preview",
        "source",
    ]
    return {key: asset[key] for key in keys if key in asset}
