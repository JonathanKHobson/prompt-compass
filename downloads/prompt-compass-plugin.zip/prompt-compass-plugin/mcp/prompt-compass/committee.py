from __future__ import annotations

import hashlib
import json
import time
import uuid
from typing import Any

from common import ensure_list, normalize_text, short_text


AGENT_MODE_SIGNALS = [
    "agent mode",
    "multi-agent",
    "multi agent",
    "multiple agents",
    "committee mode",
    "agent council",
    "subagent",
    "sub-agent",
    "engentic",
]

GUIDED_STYLE_SIGNALS = [
    "human in the loop",
    "ask me questions",
    "guided",
    "walk me through",
    "interactive",
]

DIRECT_STYLE_SIGNALS = [
    "direct",
    "no questions",
    "without questions",
    "without human in the loop",
    "no human in the loop",
]

ERROR_REGISTRY: dict[str, str] = {
    "TOKEN_MISMATCH": "Confirmation token does not match the current committee plan state.",
    "TOKEN_EXPIRED": "Confirmation token expired before committee execution could begin.",
    "QUICK_MODE_COMMITTEE_REJECTED": "Agent Mode is advanced-only and cannot run in quick mode.",
    "RECURSIVE_COMMITTEE_BLOCKED": "Nested committee execution is not allowed.",
    "COMMITTEE_UNAVAILABLE": "Agent Mode committee execution is not available for the declared host profile.",
    "HOST_CAPABILITY_MISMATCH": "The declared host capability profile does not match the requested Agent Mode execution path.",
    "TOOL_ALLOWLIST_VIOLATION": "A committee role attempted to use a tool outside its allowlist.",
    "REVISION_BUDGET_EXHAUSTED": "The judge requested more revisions than the committee budget allows.",
    "ARTIFACT_SCHEMA_VIOLATION": "A committee role returned an artifact that does not satisfy its required schema.",
    "HOST_CAPABILITY_INSUFFICIENT": "The declared host capability profile cannot satisfy this Agent Mode request.",
}

COMMITTEE_STOP_REASONS = [
    "awaiting_user_approval",
    "awaiting_host_execution",
    "completed_final_synthesis",
    "completed_after_revision_pass",
    "stopped_revision_budget_exhausted",
    "stopped_security_policy_block",
    "stopped_missing_host_capability",
    "stopped_tool_permission_denied",
    "stopped_invalid_confirmation_token",
    "stopped_artifact_schema_violation",
]

TOKEN_SCOPE = "session"
TOKEN_BOUND_TO = [
    "route_result",
    "repaired_context",
    "committee_plan",
    "role_contracts",
    "tool_allowlists",
    "fallback_strategy",
]
TOKEN_TTL_SECONDS = 30 * 60

DEFAULT_ARTIFACT_BUDGET = {
    "handoff_policy": "artifact_only",
    "max_artifact_chars_per_role": 4000,
    "max_total_turns": 7,
    "max_total_tool_calls": 9,
    "max_total_expanded_context_chars": 16000,
    "full_transcript_visibility": "audit_only",
}

ALLOWLIST_ENFORCEMENT_MODE = {
    "role_contracts": "schema_enforced",
    "sequential_fallback": "schema_enforced",
    "host_subagent_execution": "instruction_enforced",
    "mcp_trust_tiers": "instruction_enforced",
}


def has_agent_mode_signal(text: str) -> bool:
    lowered = normalize_text(text).lower()
    return any(signal in lowered for signal in AGENT_MODE_SIGNALS)


def prefers_guided_interaction(text: str) -> bool:
    lowered = normalize_text(text).lower()
    return any(signal in lowered for signal in GUIDED_STYLE_SIGNALS)


def prefers_direct_interaction(text: str) -> bool:
    lowered = normalize_text(text).lower()
    return any(signal in lowered for signal in DIRECT_STYLE_SIGNALS)


def normalize_host_capability_profile(profile: dict[str, Any] | None) -> dict[str, Any]:
    raw = dict(profile or {})
    host_family = normalize_text(raw.get("host_family") or raw.get("host") or raw.get("runtime")).lower()
    native_subagents = bool(raw.get("native_subagents") or raw.get("supports_native_subagents") or raw.get("supports_multi_role_execution"))
    allow_sequential_fallback = raw.get("allow_sequential_fallback")
    if allow_sequential_fallback is None:
        allow_sequential_fallback = True
    native_question_ui = raw.get("native_question_ui")
    if native_question_ui is None:
        native_question_ui = True

    if host_family in {"claude", "claude_code", "claude-desktop", "claude desktop"}:
        selected_adapter = "claude_native_subagents" if native_subagents or "code" in host_family else "sequential_labeled_fallback"
        delegation_style = "automatic" if selected_adapter == "claude_native_subagents" else "none"
    elif host_family in {"codex", "codex_app", "codex-cli", "codex_cli"}:
        selected_adapter = "codex_explicit_subagents" if native_subagents or host_family != "codex" else "sequential_labeled_fallback"
        delegation_style = "explicit" if selected_adapter == "codex_explicit_subagents" else "none"
    else:
        selected_adapter = "sequential_labeled_fallback"
        delegation_style = "none"

    return {
        "host_family": host_family or "generic_chat",
        "native_subagents": bool(native_subagents),
        "allow_sequential_fallback": bool(allow_sequential_fallback),
        "native_question_ui": bool(native_question_ui),
        "trusted_mcp_servers": [normalize_text(item) for item in ensure_list(raw.get("trusted_mcp_servers")) if normalize_text(item)],
        "selected_adapter": selected_adapter,
        "delegation_style": delegation_style,
    }


def committee_roles_for(workflow_kind: str) -> list[str]:
    if normalize_text(workflow_kind) == "build":
        return ["intent_architect", "drafter", "judge_synthesizer"]
    return ["diagnostician", "rewriter", "judge_synthesizer"]


def build_role_contracts(
    workflow_kind: str,
    *,
    source_text: str,
    prompt_contract: dict[str, Any],
) -> list[dict[str, Any]]:
    compact_context = {
        "objective": normalize_text(prompt_contract.get("objective")),
        "audience": normalize_text(prompt_contract.get("audience")),
        "model_target": normalize_text(prompt_contract.get("model_target")),
        "source_excerpt": short_text(source_text, 280),
    }
    if normalize_text(workflow_kind) == "build":
        return [
            {
                "role": "intent_architect",
                "purpose": "Lock the real job, audience, output contract, and hidden risks before the draft is written.",
                "inputs": ["user_intent", "analysis_summary", "prompt_contract"],
                "allowed_tools": ["analyze_prompt", "diagnose_prompt", "search_prompt_patterns", "get_record"],
                "forbidden_tools": ["build_prompt:committee", "improve_prompt:committee", "save_personal_record"],
                "expected_artifact_schema": {
                    "type": "object",
                    "required": ["intent_summary", "primary_deliverable", "audience", "output_contract", "risks"],
                },
                "stop_condition": "Stop after emitting one intent architecture artifact that narrows the job without drafting the final prompt.",
                "max_turns": 3,
                "max_tool_calls": 5,
                "permission_profile": "read_only",
                "handoff_target": "drafter",
                "asks_user_directly": False,
                "user_question_policy": "Never ask the user directly; surface needed questions only to the top-level Prompt Compass workflow.",
                "artifact_handoff_policy": "artifact_only",
                "preservation_checks": ["primary deliverable", "audience", "output contract", "runtime constraints"],
                "output_contract_discipline": "Do not hand off until format, length/bounds, and success test are explicit or marked as assumptions.",
                "compact_context": compact_context,
            },
            {
                "role": "drafter",
                "purpose": "Draft the strongest first-pass prompt from the approved intent architecture.",
                "inputs": ["intent_architecture_artifact", "prompt_contract", "selected_examples"],
                "allowed_tools": ["build_prompt:non_committee", "suggest_strategies", "target_prompt_to_model"],
                "forbidden_tools": ["build_prompt:committee", "improve_prompt:committee", "save_personal_record"],
                "expected_artifact_schema": {
                    "type": "object",
                    "required": ["scaffolded_prompt", "prompt_contract", "drafting_notes"],
                },
                "stop_condition": "Stop after producing one scaffolded prompt and its contract.",
                "max_turns": 3,
                "max_tool_calls": 4,
                "permission_profile": "bounded_transform",
                "handoff_target": "judge_synthesizer",
                "asks_user_directly": False,
                "user_question_policy": "Never ask the user directly; draft using approved intent artifacts and visible assumptions only.",
                "artifact_handoff_policy": "artifact_only",
                "preservation_checks": ["approved intent", "audience", "output contract", "constraints", "source priority"],
                "output_contract_discipline": "Keep the output contract copy-pasteable and task-specific, not generic.",
                "compact_context": compact_context,
            },
        ] + [build_judge_contract(compact_context, workflow_kind=workflow_kind)]
    return [
        {
            "role": "diagnostician",
            "purpose": "Name the real job, missing contract pieces, anti-patterns, and repair priorities before rewriting.",
            "inputs": ["original_prompt", "analysis_summary", "prompt_contract"],
            "allowed_tools": ["analyze_prompt", "diagnose_prompt", "search_prompt_patterns", "get_record", "preflight_prompt"],
            "forbidden_tools": ["improve_prompt:committee", "build_prompt:committee", "save_personal_record"],
            "expected_artifact_schema": {
                "type": "object",
                "required": ["diagnosis_summary", "anti_patterns", "missing_contract_slots", "repair_priorities"],
            },
            "stop_condition": "Stop after producing one diagnosis artifact that is precise enough for a rewrite pass.",
            "max_turns": 3,
            "max_tool_calls": 5,
            "permission_profile": "read_only",
            "handoff_target": "rewriter",
            "asks_user_directly": False,
            "user_question_policy": "Never ask the user directly; route question needs to the top-level workflow only.",
            "artifact_handoff_policy": "artifact_only",
            "preservation_checks": ["explicit constraints", "JSON/schema fields", "tool rules", "citation rules", "audience", "source priority"],
            "output_contract_discipline": "Name missing or weak contract slots before the rewrite role receives the artifact.",
            "compact_context": compact_context,
        },
        {
            "role": "rewriter",
            "purpose": "Rewrite the prompt from the diagnosis artifact without widening scope or losing the core job.",
            "inputs": ["original_prompt", "diagnosis_artifact", "prompt_contract", "selected_examples"],
            "allowed_tools": ["improve_prompt:non_committee", "suggest_strategies", "target_prompt_to_model"],
            "forbidden_tools": ["improve_prompt:committee", "build_prompt:committee", "save_personal_record"],
            "expected_artifact_schema": {
                "type": "object",
                "required": ["rewritten_prompt", "prompt_contract", "rewrite_rationale"],
            },
            "stop_condition": "Stop after producing one rewritten prompt plus the contract and rationale behind it.",
            "max_turns": 3,
            "max_tool_calls": 4,
            "permission_profile": "bounded_transform",
            "handoff_target": "judge_synthesizer",
            "asks_user_directly": False,
            "user_question_policy": "Never ask the user directly; rewrite from approved artifacts and visible assumptions only.",
            "artifact_handoff_policy": "artifact_only",
            "preservation_checks": ["explicit constraints", "JSON/schema fields", "tool rules", "citation rules", "audience", "source priority"],
            "output_contract_discipline": "Preserve or visibly report changes to format, length/bounds, and success test.",
            "compact_context": compact_context,
        },
    ] + [build_judge_contract(compact_context, workflow_kind=workflow_kind)]


def build_judge_contract(compact_context: dict[str, Any], *, workflow_kind: str) -> dict[str, Any]:
    is_improve = normalize_text(workflow_kind) == "improve"
    required = ["verdict", "final_prompt", "remaining_risks", "major_disagreements_resolved"]
    if is_improve:
        required.append("comparison_summary")
    return {
        "role": "judge_synthesizer",
        "purpose": (
            "Compare artifacts, run compare_prompts for improve workflows, decide whether one bounded revision is necessary, "
            "then finalize the best prompt and risk summary."
        ),
        "inputs": ["draft_artifact", "original_or_intent_artifact", "prompt_contract"],
        "allowed_tools": ["compare_prompts", "preflight_prompt", "diagnose_prompt"],
        "forbidden_tools": ["improve_prompt:committee", "build_prompt:committee", "save_personal_record"],
        "expected_artifact_schema": {
            "type": "object",
            "required": required,
        },
        "stop_condition": "Stop after final synthesis or after spending the single revision budget.",
        "max_turns": 2,
        "max_tool_calls": 3,
        "permission_profile": "review_only",
        "handoff_target": "",
        "asks_user_directly": False,
        "user_question_policy": "Never ask the user directly; report unresolved questions as remaining risks or top-level follow-up needs.",
        "artifact_handoff_policy": "artifact_only",
        "preservation_checks": ["behavior inventory", "stripped behavior", "semantic conflicts", "remaining gaps", "output contract"],
        "output_contract_discipline": "Reject generic or circular success tests when a task-specific contract is available.",
        "comparison_required": is_improve,
        "comparison_tool": "compare_prompts" if is_improve else "",
        "compact_context": compact_context,
    }


def build_committee_plan(
    workflow_kind: str,
    *,
    interaction_style: str,
    source_text: str,
    prompt_contract: dict[str, Any],
    role_contracts: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "workflow_kind": normalize_text(workflow_kind) or "improve",
        "interaction_style": normalize_text(interaction_style) or "guided",
        "label": "Agent Mode",
        "summary": (
            "Run a bounded three-role committee with artifact-only handoff, one judge revision budget, "
            "and explicit fallback to sequential labeled execution when native subagents are unavailable."
        ),
        "roles": committee_roles_for(workflow_kind),
        "revision_budget": 1,
        "handoff_policy": DEFAULT_ARTIFACT_BUDGET["handoff_policy"],
        "source_excerpt": short_text(source_text, 280),
        "prompt_contract_summary": {
            "objective": normalize_text(prompt_contract.get("objective")),
            "audience": normalize_text(prompt_contract.get("audience")),
            "model_target": normalize_text(prompt_contract.get("model_target")),
        },
        "tool_allowlists": {
            contract["role"]: list(contract.get("allowed_tools", []))
            for contract in role_contracts
        },
        "fallback_strategy": "sequential_labeled_fallback",
    }


def build_host_execution_instructions(
    host_capability_profile: dict[str, Any] | None,
    *,
    workflow_kind: str,
    role_contracts: list[dict[str, Any]],
) -> dict[str, Any]:
    profile = normalize_host_capability_profile(host_capability_profile)
    role_names = [contract["role"] for contract in role_contracts]
    disclosure_text = (
        "Note: Native subagents unavailable. Running committee roles sequentially in one thread."
    )
    return {
        "selected_adapter": profile["selected_adapter"],
        "recommended_host_prompt": "pc_agent_committee_flow",
        "execution_step_order": [
            "confirm_committee_plan_approval",
            *[f"run_role:{name}" for name in role_names],
            "judge_compare_and_synthesize" if normalize_text(workflow_kind) == "improve" else "judge_synthesize",
            "present_final_synthesis",
        ],
        "global_rules": [
            "Use the approved committee plan exactly; do not spawn recursive committees.",
            "Committee roles never ask the user questions directly.",
            "Committee roles pass artifacts only, not full transcripts.",
            "Each role must preserve explicit prompt behavior or report the exact behavior it cannot preserve.",
            "Every draft must keep a task-specific output contract visible.",
            "Respect each role's tool allowlist and artifact schema.",
            "Spend at most one judge-requested revision pass.",
            "Disclose sequential fallback when native subagents are unavailable.",
        ],
        "judge_comparison_required": normalize_text(workflow_kind) == "improve",
        "revision_budget": {"max_revision_passes": 1},
        "claude_native_subagents": {
            "spawn_method": "project_or_user_subagents",
            "role_label_format": "[ROLE_NAME]",
            "delegation": "automatic based on subagent description",
            "supported": profile["selected_adapter"] == "claude_native_subagents",
            "notes": "Parent Prompt Compass workflow must complete the approval gate before delegation.",
            "roles": role_names,
        },
        "codex_explicit_subagents": {
            "spawn_method": "explicit_subagent_spawn",
            "role_label_format": "[ROLE_NAME]",
            "delegation": "explicit only — do not rely on description-based auto-routing",
            "supported": profile["selected_adapter"] == "codex_explicit_subagents",
            "notes": "Subagents cost more than a single-agent pass. Confirm explicit user opt-in before delegation.",
            "roles": role_names,
        },
        "sequential_labeled_fallback": {
            "role_label_format": "## [ROLE NAME]",
            "disclosure_required": True,
            "disclosure_text": disclosure_text,
            "output_shape": sequential_output_skeleton(workflow_kind, role_names, disclosure_text),
            "supported": True,
        },
    }


def sequential_output_skeleton(workflow_kind: str, role_names: list[str], disclosure_text: str) -> dict[str, Any]:
    final_key = "rewritten_prompt" if normalize_text(workflow_kind) == "improve" else "scaffolded_prompt"
    return {
        "disclosure": disclosure_text,
        "sections": [f"## [{role.upper()}]" for role in role_names],
        "final_section": f"## [FINAL SYNTHESIS]\n- {final_key}\n- committee_rationale\n- remaining_risks\n- prompt_contract",
    }


def artifact_budget() -> dict[str, Any]:
    return dict(DEFAULT_ARTIFACT_BUDGET)


def allowlist_enforcement_mode() -> dict[str, Any]:
    return dict(ALLOWLIST_ENFORCEMENT_MODE)


def build_confirmation_bundle(plan_tuple: dict[str, Any]) -> dict[str, Any]:
    issued_at = int(time.time())
    return {
        "committee_run_id": str(uuid.uuid4()),
        "committee_confirmation_token": str(uuid.uuid4()),
        "committee_plan_hash": committee_plan_hash(plan_tuple),
        "token_scope": TOKEN_SCOPE,
        "token_bound_to": list(TOKEN_BOUND_TO),
        "issued_at": issued_at,
        "expires_at": issued_at + TOKEN_TTL_SECONDS,
    }


def committee_plan_hash(plan_tuple: dict[str, Any]) -> str:
    serialized = json.dumps(plan_tuple, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def confirmation_error(code: str, *, retry_allowed: bool = True) -> dict[str, Any]:
    return {
        "error": True,
        "error_code": code,
        "message": ERROR_REGISTRY.get(code, "Committee execution failed."),
        "retry_allowed": retry_allowed,
    }


def validate_confirmation(
    *,
    expected_token: str,
    provided_token: str | None,
    expected_hash: str,
    current_hash: str,
    issued_at: int | None,
) -> dict[str, Any] | None:
    if not provided_token or normalize_text(provided_token) != normalize_text(expected_token):
        return confirmation_error("TOKEN_MISMATCH")
    if issued_at and time.time() > issued_at + TOKEN_TTL_SECONDS:
        return confirmation_error("TOKEN_EXPIRED")
    if expected_hash != current_hash:
        return confirmation_error("TOKEN_MISMATCH")
    return None


def committee_stop_reason(reason: str | None) -> str:
    normalized = normalize_text(reason)
    if normalized in COMMITTEE_STOP_REASONS:
        return normalized
    return "completed_final_synthesis"
