from __future__ import annotations

import json
import re
import unicodedata
from typing import Any


PROMPT_TYPES = ["reductive", "transformative", "generative"]


def normalize_text(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    return re.sub(r"\s+", " ", value).strip()


def slugify(value: Any) -> str:
    text = normalize_text(value).lower()
    text = unicodedata.normalize("NFKD", text)
    text = text.replace("&", " and ")
    text = re.sub(r"[\s_/]+", "-", text)
    text = re.sub(r"[^a-z0-9-]", "", text)
    text = re.sub(r"-{2,}", "-", text)
    return text.strip("-")


def normalize_lookup_key(value: Any) -> str:
    text = normalize_text(value).lower()
    text = text.replace("_", " ").replace("-", " ")
    text = re.sub(r"[^a-z0-9 ]", "", text)
    return re.sub(r"\s+", " ", text).strip()


def to_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def from_json(value: str | None, default: Any) -> Any:
    if not value:
        return default
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return default


def ensure_list(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    if value is None:
        return []
    return [value]


def tokenize(value: str | None) -> list[str]:
    return [token for token in re.split(r"[^a-z0-9]+", (value or "").lower()) if token]


def build_fts_query(value: str | None) -> str:
    tokens: list[str] = []
    seen: set[str] = set()
    for token in tokenize(value):
        if len(token) < 3:
            continue
        if token in seen:
            continue
        seen.add(token)
        tokens.append(token)
    if not tokens:
        return ""
    if len(tokens) <= 3:
        return " AND ".join(f'{token}*' for token in tokens)
    return " OR ".join(f'{token}*' for token in tokens[:8])


def join_unique(values: list[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        normalized = normalize_text(value)
        if not normalized:
            continue
        if normalized.lower() in seen:
            continue
        seen.add(normalized.lower())
        ordered.append(normalized)
    return ordered


def text_blob(*values: Any) -> str:
    parts: list[str] = []
    for value in values:
        if isinstance(value, list):
            parts.append(" ".join(normalize_text(item) for item in value if normalize_text(item)))
        elif isinstance(value, dict):
            parts.append(text_blob(*value.values()))
        else:
            parts.append(normalize_text(value))
    return normalize_text(" ".join(part for part in parts if part))


def short_text(value: Any, limit: int = 180) -> str:
    text = normalize_text(value)
    if len(text) <= limit:
        return text
    return text[: max(limit - 1, 0)].rstrip() + "…"
