from __future__ import annotations

import json
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

from common import normalize_text
from repository import PromptCompassRepository


ROOT = Path(__file__).resolve().parent
DEFAULT_DB_PATH = ROOT / "db" / "prompt-compass.sqlite"
DECISIONS_PATH = ROOT / "support" / "library" / "normalized" / "aiglossary-decisions.jsonl"
COVERAGE_REPORT_PATH = ROOT / "docs" / "specs" / "coverage_report.md"
MANIFEST_PATH = ROOT / "support" / "library" / "curation_manifest.md"

TAXONOMY_DEFAULTS = {
    "interaction_mode": "single_turn",
    "output_mode": "freeform",
    "grounding_mode": "none",
    "evaluation_mode": "none",
}


def is_ignored_artifact_path(path: Path) -> bool:
    return path.name.startswith("._")


def load_jsonl_rows(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        rows.append(json.loads(line))
    return rows


def load_records(db_path: Path | str = DEFAULT_DB_PATH) -> list[dict[str, Any]]:
    repo = PromptCompassRepository(db_path)
    try:
        return repo.list_all()
    finally:
        repo.close()


def load_decisions(path: Path = DECISIONS_PATH) -> list[dict[str, Any]]:
    return load_jsonl_rows(path)


def build_coverage_payload(
    *,
    records: list[dict[str, Any]],
    decisions: list[dict[str, Any]],
    db_path: Path | str,
) -> dict[str, Any]:
    metrics = {
        "record_type": count_scalar(records, "record_type"),
        "curation_status": count_scalar(records, "curation_status"),
        "source_tier": count_scalar(records, "source_tier"),
        "interaction_mode": count_scalar(records, "interaction_mode"),
        "output_mode": count_scalar(records, "output_mode"),
        "grounding_mode": count_scalar(records, "grounding_mode"),
        "evaluation_mode": count_scalar(records, "evaluation_mode"),
        "capability_tags": count_list(records, "capability_tags"),
    }
    imported = [row for row in decisions if row.get("decision") in {"support_only", "promote_to_core", "graduated_core"}]
    excluded = [row for row in decisions if row.get("decision") == "excluded"]
    imported_metrics = {
        "family": Counter(normalize_text(row.get("family")) for row in imported if normalize_text(row.get("family"))),
        "origin_bucket": Counter(normalize_text(row.get("origin_bucket")) for row in imported if normalize_text(row.get("origin_bucket"))),
        "decision": Counter(normalize_text(row.get("decision")) for row in decisions if normalize_text(row.get("decision"))),
    }
    thin_spots: list[dict[str, Any]] = []
    for dimension, default_bucket in TAXONOMY_DEFAULTS.items():
        for bucket, count in metrics[dimension].items():
            if bucket == default_bucket:
                continue
            if count < 5:
                thin_spots.append(
                    {
                        "dimension": dimension,
                        "bucket": bucket,
                        "count": count,
                        "rule": "non-default taxonomy bucket has fewer than 5 records",
                    }
                )
    for tag, count in metrics["capability_tags"].items():
        if count < 3:
            thin_spots.append(
                {
                    "dimension": "capability_tags",
                    "bucket": tag,
                    "count": count,
                    "rule": "capability tag has fewer than 3 records",
                }
            )
    overrepresented: list[dict[str, Any]] = []
    total_records = len(records)
    for dimension in ("interaction_mode", "output_mode", "grounding_mode", "evaluation_mode"):
        for bucket, count in metrics[dimension].items():
            if total_records and (count / total_records) > 0.75:
                overrepresented.append(
                    {
                        "dimension": dimension,
                        "bucket": bucket,
                        "count": count,
                        "share": round(count / total_records, 4),
                    }
                )
    return {
        "generated_at": _generated_at_text(),
        "db_path": str(Path(db_path).resolve()),
        "total_records": total_records,
        "metrics": _serialize_counters(metrics),
        "imported_metrics": _serialize_counters(imported_metrics),
        "thin_spots": sorted(thin_spots, key=lambda item: (item["dimension"], item["count"], item["bucket"])),
        "overrepresented_areas": sorted(overrepresented, key=lambda item: (item["dimension"], -item["share"], item["bucket"])),
        "excluded_count": len(excluded),
    }


def build_manifest_payload(
    *,
    records: list[dict[str, Any]],
    decisions: list[dict[str, Any]],
    db_path: Path | str,
) -> dict[str, Any]:
    imported = [row for row in decisions if row.get("decision") in {"support_only", "promote_to_core", "graduated_core"}]
    excluded = [row for row in decisions if row.get("decision") == "excluded"]
    record_rows = []
    for record in sorted(
        records,
        key=lambda item: (
            0 if item.get("curation_status") == "core" else 1,
            item.get("record_type", ""),
            -int(item.get("search_weight", 0)),
            normalize_text(item.get("name")).lower(),
        ),
    ):
        record_rows.append(
            {
                "slug": record.get("slug"),
                "name": record.get("name"),
                "record_type": record.get("record_type"),
                "curation_status": record.get("curation_status"),
                "source_tier": record.get("source_tier"),
                "corpus_zone": record.get("corpus_zone"),
                "search_weight": int(record.get("search_weight", 0)),
                "decision": record.get("decision") or "curated",
                "driver_eligible": bool(record.get("driver_eligible")) if "driver_eligible" in record else (record.get("curation_status") == "core"),
                "capability_tags": list(record.get("capability_tags", [])),
                "curation_note": normalize_text(record.get("curation_note")),
            }
        )
    return {
        "generated_at": _generated_at_text(),
        "db_path": str(Path(db_path).resolve()),
        "compiled_totals": {
            "records": len(records),
            "record_type": _sorted_dict(count_scalar(records, "record_type")),
            "curation_status": _sorted_dict(count_scalar(records, "curation_status")),
            "source_tier": _sorted_dict(count_scalar(records, "source_tier")),
            "corpus_zone": _sorted_dict(count_scalar(records, "corpus_zone")),
        },
        "import_totals": {
            "approved": len(imported),
            "excluded": len(excluded),
            "decision": _sorted_dict(Counter(normalize_text(row.get("decision")) for row in decisions if normalize_text(row.get("decision")))),
            "family": _sorted_dict(Counter(normalize_text(row.get("family")) for row in imported if normalize_text(row.get("family")))),
            "origin_bucket": _sorted_dict(Counter(normalize_text(row.get("origin_bucket")) for row in imported if normalize_text(row.get("origin_bucket")))),
            "excluded_rule": _sorted_dict(Counter(normalize_text(row.get("rule_id")) for row in excluded if normalize_text(row.get("rule_id")))),
        },
        "record_rows": record_rows,
    }


def write_reports(
    *,
    db_path: Path | str = DEFAULT_DB_PATH,
    decisions_path: Path = DECISIONS_PATH,
    coverage_path: Path = COVERAGE_REPORT_PATH,
    manifest_path: Path = MANIFEST_PATH,
) -> dict[str, dict[str, Any]]:
    records = load_records(db_path)
    decisions = load_decisions(decisions_path)
    coverage_payload = build_coverage_payload(records=records, decisions=decisions, db_path=db_path)
    manifest_payload = build_manifest_payload(records=records, decisions=decisions, db_path=db_path)
    coverage_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    coverage_path.write_text(render_coverage_report(coverage_payload), encoding="utf-8")
    manifest_path.write_text(render_manifest(manifest_payload), encoding="utf-8")
    return {"coverage": coverage_payload, "manifest": manifest_payload}


def render_coverage_report(payload: dict[str, Any]) -> str:
    metrics = payload["metrics"]
    imported = payload["imported_metrics"]
    lines = [
        "# Prompt Compass Coverage Report",
        "",
        f"_Generated: {payload['generated_at']}_",
        "",
        f"_Compiled DB: `{payload['db_path']}`_",
        "",
        "## Snapshot",
        "",
        f"- Total compiled records: `{payload['total_records']}`",
        f"- Excluded AIGlossary candidates: `{payload['excluded_count']}`",
        "",
        "## Corpus Counts",
        "",
        "### By Record Type",
        "",
        _render_count_bullets(metrics["record_type"]),
        "",
        "### By Curation Status",
        "",
        _render_count_bullets(metrics["curation_status"]),
        "",
        "### By Source Tier",
        "",
        _render_count_bullets(metrics["source_tier"]),
        "",
        "## Taxonomy Coverage",
        "",
        "### Interaction Mode",
        "",
        _render_count_bullets(metrics["interaction_mode"]),
        "",
        "### Output Mode",
        "",
        _render_count_bullets(metrics["output_mode"]),
        "",
        "### Grounding Mode",
        "",
        _render_count_bullets(metrics["grounding_mode"]),
        "",
        "### Evaluation Mode",
        "",
        _render_count_bullets(metrics["evaluation_mode"]),
        "",
        "### Capability Tags",
        "",
        _render_count_bullets(metrics["capability_tags"]),
        "",
        "## Imported Support View",
        "",
        "### By Family",
        "",
        _render_count_bullets(imported["family"]),
        "",
        "### By Origin Bucket",
        "",
        _render_count_bullets(imported["origin_bucket"]),
        "",
        "### By Decision",
        "",
        _render_count_bullets(imported["decision"]),
        "",
        "## Thin Spots",
        "",
    ]
    if payload["thin_spots"]:
        for item in payload["thin_spots"]:
            lines.append(
                f"- `{item['dimension']}` -> `{item['bucket']}`: `{item['count']}` records. Rule: {item['rule']}."
            )
    else:
        lines.append("- None.")
    lines.extend(["", "## Overrepresented Areas", ""])
    if payload["overrepresented_areas"]:
        for item in payload["overrepresented_areas"]:
            share = round(item["share"] * 100, 1)
            lines.append(
                f"- `{item['dimension']}` -> `{item['bucket']}`: `{item['count']}` records (`{share}%` of the dimension)."
            )
    else:
        lines.append("- None.")
    lines.append("")
    return "\n".join(lines)


def render_manifest(payload: dict[str, Any]) -> str:
    compiled = payload["compiled_totals"]
    imported = payload["import_totals"]
    lines = [
        "# Prompt Compass Curation Manifest",
        "",
        f"_Generated: {payload['generated_at']}_",
        "",
        f"_Compiled DB: `{payload['db_path']}`_",
        "",
        "## Summary",
        "",
        f"- Total compiled records: `{compiled['records']}`",
        "",
        "### Compiled Counts By Record Type",
        "",
        _render_count_bullets(compiled["record_type"]),
        "",
        "### Compiled Counts By Curation Status",
        "",
        _render_count_bullets(compiled["curation_status"]),
        "",
        "### Compiled Counts By Source Tier",
        "",
        _render_count_bullets(compiled["source_tier"]),
        "",
        "### Compiled Counts By Corpus Zone",
        "",
        _render_count_bullets(compiled["corpus_zone"]),
        "",
        "## Import Decision Summary",
        "",
        f"- Approved imported records: `{imported['approved']}`",
        f"- Excluded imported candidates: `{imported['excluded']}`",
        "",
        "### Decisions",
        "",
        _render_count_bullets(imported["decision"]),
        "",
        "### Approved Families",
        "",
        _render_count_bullets(imported["family"]),
        "",
        "### Approved Origin Buckets",
        "",
        _render_count_bullets(imported["origin_bucket"]),
        "",
        "### Excluded Rule Counts",
        "",
        _render_count_bullets(imported["excluded_rule"]),
        "",
        "## Compiled Records",
        "",
        "| slug | name | record_type | curation_status | source_tier | corpus_zone | search_weight | decision | driver_eligible | capability_tags | curation_note |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for row in payload["record_rows"]:
        lines.append(
            "| {slug} | {name} | {record_type} | {curation_status} | {source_tier} | {corpus_zone} | {search_weight} | {decision} | {driver_eligible} | {capability_tags} | {curation_note} |".format(
                slug=_escape_pipe(row["slug"]),
                name=_escape_pipe(row["name"]),
                record_type=_escape_pipe(row["record_type"]),
                curation_status=_escape_pipe(row["curation_status"]),
                source_tier=_escape_pipe(row["source_tier"]),
                corpus_zone=_escape_pipe(row["corpus_zone"]),
                search_weight=row["search_weight"],
                decision=_escape_pipe(row["decision"]),
                driver_eligible="true" if row["driver_eligible"] else "false",
                capability_tags=_escape_pipe(", ".join(row["capability_tags"])),
                curation_note=_escape_pipe(row["curation_note"]),
            )
        )
    lines.append("")
    return "\n".join(lines)


def count_scalar(records: list[dict[str, Any]], key: str) -> Counter[str]:
    return Counter(normalize_text(record.get(key)) for record in records if normalize_text(record.get(key)))


def count_list(records: list[dict[str, Any]], key: str) -> Counter[str]:
    counter: Counter[str] = Counter()
    for record in records:
        for value in record.get(key, []) or []:
            normalized = normalize_text(value)
            if normalized:
                counter[normalized] += 1
    return counter


def _sorted_dict(counter: Counter[str]) -> dict[str, int]:
    return dict(sorted(counter.items(), key=lambda item: (-item[1], item[0])))


def _serialize_counters(metrics: dict[str, Counter[str]]) -> dict[str, dict[str, int]]:
    return {name: _sorted_dict(counter) for name, counter in metrics.items()}


def _render_count_bullets(counts: dict[str, int]) -> str:
    if not counts:
        return "- None."
    return "\n".join(f"- `{key}`: `{value}`" for key, value in counts.items())


def _escape_pipe(value: Any) -> str:
    return normalize_text(value).replace("|", "\\|")


def _generated_at_text() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")
