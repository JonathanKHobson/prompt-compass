# Agent Mode State Machine

```mermaid
stateDiagram-v2
    [*] --> route
    route --> quick: quick lane
    route --> advanced_guided: advanced + guided
    route --> advanced_direct: advanced + direct

    advanced_guided --> stage_1
    stage_1 --> stage_2
    stage_2 --> reflection: standard advanced
    stage_2 --> committee_plan_review: agent mode

    advanced_direct --> direct_pass
    direct_pass --> reflection: standard advanced
    direct_pass --> committee_plan_review: agent mode

    committee_plan_review --> approval_declined: decline
    committee_plan_review --> committee_execution: approval + valid token
    committee_plan_review --> invalid_token: token mismatch / expiry

    committee_execution --> final_synthesis: host executes contract
    committee_execution --> revision_budget_exhausted: judge exceeds budget
    committee_execution --> security_block: tool or trust policy block

    approval_declined --> reflection
    reflection --> [*]
    final_synthesis --> [*]
    invalid_token --> [*]
    revision_budget_exhausted --> [*]
    security_block --> [*]
```

## Notes

- Guided and direct are both advanced lanes.
- Agent Mode is entered only after explicit opt-in.
- Committee execution is host-guided.
- Sequential fallback must disclose itself.
