#!/usr/bin/env python3
"""Launcher used by the Prompt Compass MCPB package.

The installed bundle is treated as read-only. Writable personal overlay state
is redirected to per-user app data unless the host provides explicit override
paths through environment variables or command-line arguments.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


def _user_data_dir() -> Path:
    override = os.getenv("PROMPT_COMPASS_USER_DATA_DIR")
    if override:
        return Path(override).expanduser()
    if sys.platform == "win32":
        base = Path(os.getenv("APPDATA", str(Path.home() / "AppData" / "Roaming")))
        return base / "PromptCompass"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "Prompt Compass"
    return Path(os.getenv("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))) / "prompt-compass"


def main() -> None:
    bundle_root = Path(__file__).resolve().parent
    user_data = _user_data_dir()
    canonical_db = bundle_root / "db" / "prompt-compass.sqlite"
    personal_db = user_data / "prompt-compass-personal.sqlite"
    personal_vault = user_data / "personal-vault"
    passthrough_args = sys.argv[1:]

    user_data.mkdir(parents=True, exist_ok=True)
    personal_vault.mkdir(parents=True, exist_ok=True)

    os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
    os.environ.setdefault("PROMPT_COMPASS_PERSONAL_DB_PATH", str(personal_db))
    os.environ.setdefault("PROMPT_COMPASS_PERSONAL_VAULT_ROOT", str(personal_vault))

    if str(bundle_root) not in sys.path:
        sys.path.insert(0, str(bundle_root))

    sys.argv = [
        str(bundle_root / "server.py"),
        "--db-path",
        str(canonical_db),
        *passthrough_args,
    ]

    from server import main as server_main  # pylint: disable=import-outside-toplevel

    server_main()


if __name__ == "__main__":
    main()
