from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

from analysis.preflight import SUPPORTED_SURFACES
from common import ensure_list, normalize_text, short_text
from repository import PromptCompassRepository


ROOT = Path(__file__).resolve().parent
TAXONOMY_DIR = ROOT / "support" / "taxonomy"
DEFAULT_LIMIT = 10
MAX_LIMIT = 25
DEFAULT_CATALOG_SCOPE = "core_first"
CATALOG_SCOPES = ("core_only", "core_first", "merged")
LISTABLE_RECORD_TYPES = ("framework", "strategy", "pattern", "technique", "term", "anti_pattern")
TEMPLATE_RECORD_TYPES = ("strategy", "pattern", "technique", "term")

GROUP_LABELS = {
    "orientation": "Orientation Tools",
    "workflow": "Workflow Tools",
    "lookup_search": "Lookup & Search Tools",
    "guidance": "Guidance Tools",
    "targeting": "Model & Surface Targeting Tools",
    "write": "Write Tools",
    "personal_library": "Personal Library Tools",
}

GROUP_ORDER = [
    "orientation",
    "workflow",
    "lookup_search",
    "guidance",
    "targeting",
    "write",
    "personal_library",
]

OVERVIEW_TOPICS = (
    "overview",
    "quick_start",
    "diagnose",
    "improve",
    "build",
    "targeting",
    "knowledge_base",
    "personal_overlay",
    "prompt_library",
    "tool_surface",
)


def _prompt(
    name: str,
    *,
    description: str,
    when_to_use: str,
    arguments: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "prompt": name,
        "description": description,
        "when_to_use": when_to_use,
        "arguments": arguments or [],
    }


def _tool(
    name: str,
    *,
    group: str,
    description: str,
    when_to_use: str,
    inputs_summary: str,
    returns_summary: str,
    read_only: bool,
    destructive: bool = False,
    related_tools: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "tool": name,
        "group": group,
        "description": description,
        "when_to_use": when_to_use,
        "inputs_summary": inputs_summary,
        "returns_summary": returns_summary,
        "read_only": read_only,
        "destructive": destructive,
        "related_tools": related_tools or [],
    }


PUBLIC_TOOL_REGISTRY = [
    _tool(
        "prompt_compass_overview",
        group="orientation",
        description="Orient the host AI and end user to Prompt Compass workflows, capabilities, and routing.",
        when_to_use="Call first when the user or host AI needs a high-level map of Prompt Compass before choosing a tool.",
        inputs_summary="Optional topic and audience.",
        returns_summary="Overview text, workflow map, routing guidance, starter prompts, catalog snapshot, and markdown summary.",
        read_only=True,
        related_tools=["get_started", "list_tool_surface", "list_catalog_categories"],
    ),
    _tool(
        "get_started",
        group="orientation",
        description="Return the first-session path for the most common Prompt Compass jobs.",
        when_to_use="Use when the user is new, vague, or has not yet chosen between diagnose, improve, build, preflight, or browse.",
        inputs_summary="Optional topic and audience.",
        returns_summary="First five minutes plan, recommended first tools, routing rules, starter prompts, and markdown summary.",
        read_only=True,
        related_tools=["prompt_compass_overview", "analyze_prompt", "build_prompt", "preflight_prompt"],
    ),
    _tool(
        "list_tool_surface",
        group="orientation",
        description="List the live Prompt Compass tool surface grouped by role, with usage notes and safety boundaries.",
        when_to_use="Use when the host AI needs a complete inventory of available tools and how they fit together.",
        inputs_summary="Optional include_write_tools and audience.",
        returns_summary="Grouped tool cards, common sequences, write-safety notes, first-tool routing, and markdown summary.",
        read_only=True,
        related_tools=["prompt_compass_overview", "list_catalog_categories"],
    ),
    _tool(
        "list_catalog_categories",
        group="orientation",
        description="Show the main Prompt Compass browsing categories, taxonomies, model targets, and prompt surfaces.",
        when_to_use="Use before catalog browsing when the user needs to know what kinds of records or prompt slices exist.",
        inputs_summary="No required inputs.",
        returns_summary="Available record types, taxonomy values, supported models, prompt surfaces, and markdown summary.",
        read_only=True,
        related_tools=["search_prompt_patterns", "list_frameworks", "list_strategies", "list_terms"],
    ),
    _tool(
        "route_prompt_request",
        group="orientation",
        description="Hard-route a raw user request to the correct Prompt Compass workflow before Claude browses or improvises.",
        when_to_use="Use first when the user says 'use Prompt Compass' or asks for help without naming a specific workflow tool.",
        inputs_summary="Raw user request with optional model target.",
        returns_summary="Detected job, required next tool, required mode, required advanced lane, Agent Mode recommendation, blocked lookup tools, routing question if needed, and host instruction.",
        read_only=True,
        related_tools=["improve_prompt", "build_prompt", "analyze_prompt", "preflight_prompt"],
    ),
    _tool(
        "analyze_prompt",
        group="workflow",
        description="Diagnose a prompt and score it against the Prompt Compass prompt rubric.",
        when_to_use="Use first when the user already has a draft prompt and wants to know what is weak, missing, or risky.",
        inputs_summary="Prompt text with optional model target and user goal.",
        returns_summary="Intent, taxonomy, anti-patterns, missing blocks, RACCCA, preflight fields, and prompt contract.",
        read_only=True,
        related_tools=["diagnose_prompt", "search_prompt_patterns", "get_clarifying_questions", "improve_prompt"],
    ),
    _tool(
        "diagnose_prompt",
        group="workflow",
        description="Diagnose a prompt with detailed evidence, repair priority, and rewrite readiness without rewriting it.",
        when_to_use="Use when the user wants diagnosis before rewrite, or when Claude needs more evidence than analyze_prompt exposes.",
        inputs_summary="Prompt text with optional model target and user goal.",
        returns_summary="Prompt-specific evidence, structural measurements, anti-pattern explanations, RACCCA evidence, repair order, and rewrite readiness.",
        read_only=True,
        related_tools=["analyze_prompt", "compare_prompts", "improve_prompt"],
    ),
    _tool(
        "preflight_prompt",
        group="workflow",
        description="Run a visible preflight check that scores prompt readiness, identifies blockers, and recommends the next routing step.",
        when_to_use="Use before execution when the prompt must be ready for a parser, retrieval system, tool workflow, or other runtime surface.",
        inputs_summary="Prompt text with optional model target and user goal.",
        returns_summary="Prompt surface, readiness scorecard, blockers, warnings, efficiency flags, and next action.",
        read_only=True,
        related_tools=["analyze_prompt", "target_prompt_to_surface", "suggest_strategies"],
    ),
    _tool(
        "improve_prompt",
        group="workflow",
        description="improve_prompt / improve prompt / rewrite prompt: strengthen an existing prompt in quick improve, advanced improve, Auto Flow next-tool, or approval-gated Agent Mode committee planning.",
        when_to_use="Use when the user has an existing prompt and wants a fast one-pass rewrite, staged guided improvement, direct advanced pass, Auto Flow improve-then-execute, or Agent Mode committee plan.",
        inputs_summary="Prompt text with optional model target, analysis, question answers, question-loop state, selected prompt-library IDs, mode, interaction_style, interaction_pace, delivery_mode, agent_mode, host capability profile, committee depth, and optional confirmation token.",
        returns_summary="Rewritten prompt, staged question payload, or committee plan/execution contract with role schemas, host adapters, approval token, and artifact budget.",
        read_only=True,
        related_tools=["diagnose_prompt", "compare_prompts", "get_clarifying_questions", "search_prompt_patterns", "target_prompt_to_model"],
    ),
    _tool(
        "compare_prompts",
        group="workflow",
        description="Compare two prompt versions and report measurable improvements, regressions, and remaining risks.",
        when_to_use="Use after a rewrite, or when the user asks whether one prompt version is actually better than another.",
        inputs_summary="Before prompt, after prompt, and optional model target.",
        returns_summary="RACCCA deltas, anti-pattern deltas, missing-block deltas, prompt-contract diff, and verdict.",
        read_only=True,
        related_tools=["diagnose_prompt", "analyze_prompt", "improve_prompt"],
    ),
    _tool(
        "build_prompt",
        group="workflow",
        description="Scaffold a new prompt from user intent in quick mode, advanced guided/direct mode, or approval-gated Agent Mode committee planning.",
        when_to_use="Use when the user is starting from scratch and needs either a fast scaffold, a staged guided build, a direct advanced pass, or an Agent Mode committee plan.",
        inputs_summary="User intent with optional model target, question loop state, selected prompt-library IDs, mode, interaction_style, agent_mode, host capability profile, committee depth, and optional confirmation token.",
        returns_summary="Question batch, completed scaffolded prompt, or committee plan/execution contract with role schemas, host adapters, approval token, and artifact budget.",
        read_only=True,
        related_tools=["get_clarifying_questions", "suggest_strategies", "target_prompt_to_model"],
    ),
    _tool(
        "search_prompt_patterns",
        group="lookup_search",
        description="Search the local Prompt Compass KB across frameworks, strategies, patterns, anti-patterns, techniques, and terms.",
        when_to_use="Use for open-ended browsing or lookup after routing. Do not use this as the first step for rewrite/build jobs when a workflow tool should run instead.",
        inputs_summary="Query with optional record-type and taxonomy filters.",
        returns_summary="Ranked matching records with snippets, tags, layer metadata, and related IDs.",
        read_only=True,
        related_tools=["get_record", "list_frameworks", "list_patterns", "list_terms"],
    ),
    _tool(
        "get_framework",
        group="lookup_search",
        description="Resolve one named prompt framework with template, examples, and use notes.",
        when_to_use="Use when the user already knows the framework name and wants the exact record. Do not start here when the user really wants improve/build/preflight behavior.",
        inputs_summary="Framework name or alias.",
        returns_summary="Exact framework record or nearest matches.",
        read_only=True,
        related_tools=["search_prompt_patterns", "list_frameworks"],
    ),
    _tool(
        "get_pattern",
        group="lookup_search",
        description="Resolve one named prompt pattern or anti-pattern.",
        when_to_use="Use when the user already knows the pattern or anti-pattern name and wants the exact record, not when a rewrite or build workflow should run first.",
        inputs_summary="Pattern or anti-pattern name or alias.",
        returns_summary="Exact pattern or anti-pattern record or nearest matches.",
        read_only=True,
        related_tools=["search_prompt_patterns", "list_patterns", "list_anti_patterns"],
    ),
    _tool(
        "get_record",
        group="lookup_search",
        description="Resolve any named Prompt Compass record, optionally restricted to one or more record types.",
        when_to_use="Use when the host AI wants a generic named resolver across the KB after routing. Do not use this as the first workflow step for rewrite/build jobs.",
        inputs_summary="Record name with optional record types.",
        returns_summary="Exact resolved record or nearest matches.",
        read_only=True,
        related_tools=["search_prompt_patterns", "get_framework", "get_pattern", "get_term"],
    ),
    _tool(
        "get_technique",
        group="lookup_search",
        description="Resolve a named prompt-engineering technique.",
        when_to_use="Use when the user asks for a specific tactic like self-critique or role-playing prompting, not when the user is asking for a guided rewrite/build workflow.",
        inputs_summary="Technique name or alias.",
        returns_summary="Exact technique record or nearest matches.",
        read_only=True,
        related_tools=["search_prompt_patterns", "list_techniques"],
    ),
    _tool(
        "get_term",
        group="lookup_search",
        description="Resolve a named prompt-engineering term.",
        when_to_use="Use when the user asks for a specific term or concept definition after routing, not when they need a workflow tool first.",
        inputs_summary="Term name or alias.",
        returns_summary="Exact term record or nearest matches.",
        read_only=True,
        related_tools=["search_prompt_patterns", "list_terms"],
    ),
    _tool(
        "list_frameworks",
        group="lookup_search",
        description="Browse Prompt Compass frameworks with core-first or merged catalog views.",
        when_to_use="Use when the user wants a bounded snapshot of available frameworks after routing. Do not use this as the first step when the user already needs improve/build/preflight behavior.",
        inputs_summary="Optional query, limit, and catalog scope.",
        returns_summary="Browsable framework cards with layer labels, previews, starter prompts, and markdown summary.",
        read_only=True,
        related_tools=["get_framework", "search_prompt_patterns", "list_catalog_categories"],
    ),
    _tool(
        "list_strategies",
        group="lookup_search",
        description="Browse Prompt Compass strategies with core-first or merged catalog views.",
        when_to_use="Use when the user wants a bounded snapshot of available strategies after routing, not as the first step for rewrite/build jobs.",
        inputs_summary="Optional query, limit, and catalog scope.",
        returns_summary="Browsable strategy cards with layer labels, previews, starter prompts, and markdown summary.",
        read_only=True,
        related_tools=["suggest_strategies", "search_prompt_patterns", "get_record"],
    ),
    _tool(
        "list_patterns",
        group="lookup_search",
        description="Browse Prompt Compass patterns with core-first or merged catalog views.",
        when_to_use="Use when the user wants examples of structural prompt patterns after routing, not as the first step for rewrite/build jobs.",
        inputs_summary="Optional query, limit, and catalog scope.",
        returns_summary="Browsable pattern cards with layer labels, previews, starter prompts, and markdown summary.",
        read_only=True,
        related_tools=["get_pattern", "search_prompt_patterns", "list_anti_patterns"],
    ),
    _tool(
        "list_techniques",
        group="lookup_search",
        description="Browse Prompt Compass techniques with core-first or merged catalog views.",
        when_to_use="Use when the user wants single-move tactical prompt techniques after routing, not as the first step for rewrite/build jobs.",
        inputs_summary="Optional query, limit, and catalog scope.",
        returns_summary="Browsable technique cards with layer labels, previews, starter prompts, and markdown summary.",
        read_only=True,
        related_tools=["get_technique", "search_prompt_patterns", "list_terms"],
    ),
    _tool(
        "list_terms",
        group="lookup_search",
        description="Browse Prompt Compass terms with core-first or merged catalog views.",
        when_to_use="Use when the user wants concept definitions and vocabulary after routing rather than workflow-driving strategies.",
        inputs_summary="Optional query, limit, and catalog scope.",
        returns_summary="Browsable term cards with layer labels, previews, starter prompts, and markdown summary.",
        read_only=True,
        related_tools=["get_term", "search_prompt_patterns", "list_catalog_categories"],
    ),
    _tool(
        "list_prompt_templates",
        group="lookup_search",
        description="Browse built-in Prompt Compass template exemplars, with prompt-library templates optionally shown separately.",
        when_to_use="Use when the user asks for prompt templates or wants copyable scaffolds from the KB.",
        inputs_summary="Optional query, limit, catalog scope, and include_prompt_library flag.",
        returns_summary="KB template items plus optional separate prompt-library template items and markdown summary.",
        read_only=True,
        related_tools=["list_prompt_examples", "search_prompt_patterns", "search_prompt_library"],
    ),
    _tool(
        "list_prompt_examples",
        group="lookup_search",
        description="Browse built-in Prompt Compass example exemplars, with prompt-library examples optionally shown separately.",
        when_to_use="Use when the user asks for prompt examples or wants concrete before/after-style reference points.",
        inputs_summary="Optional query, limit, catalog scope, and include_prompt_library flag.",
        returns_summary="KB example items plus optional separate prompt-library example items and markdown summary.",
        read_only=True,
        related_tools=["list_prompt_templates", "search_prompt_patterns", "search_prompt_library"],
    ),
    _tool(
        "list_anti_patterns",
        group="lookup_search",
        description="List prompt anti-patterns with symptoms, severity, and fixes using the same catalog-card browsing surface as the new list tools.",
        when_to_use="Use when the user wants a bounded anti-pattern view instead of open-ended search.",
        inputs_summary="Optional limit, severity, prompt type, and catalog scope.",
        returns_summary="Browsable anti-pattern cards with severity, fix signals, layer labels, and markdown summary.",
        read_only=True,
        related_tools=["get_pattern", "search_prompt_patterns", "analyze_prompt"],
    ),
    _tool(
        "get_clarifying_questions",
        group="guidance",
        description="Return 3 to 5 targeted clarifying questions for prompt improvement or prompt building.",
        when_to_use="Use after analysis when Prompt Compass identifies missing slots that need user answers.",
        inputs_summary="Analysis payload with optional question-loop state and limit.",
        returns_summary="Question batch, coverage map, interaction batch, and updated question-loop state.",
        read_only=True,
        related_tools=["analyze_prompt", "build_prompt", "improve_prompt"],
    ),
    _tool(
        "suggest_strategies",
        group="guidance",
        description="Rank applicable prompt strategies for a prompt type, subject area, and model target.",
        when_to_use="Use when the host AI needs the best-fitting Prompt Compass strategies for a diagnosed prompt shape.",
        inputs_summary="Prompt type, subject area, and optional taxonomy signals, anti-patterns, and missing blocks.",
        returns_summary="Ranked strategy list with fit reasons and expected effects.",
        read_only=True,
        related_tools=["analyze_prompt", "search_prompt_patterns", "improve_prompt"],
    ),
    _tool(
        "target_prompt_to_model",
        group="targeting",
        description="Adapt an existing prompt to a supported model profile.",
        when_to_use="Use when the user already has a prompt and wants it tuned to a specific supported model.",
        inputs_summary="Prompt, model name, and optional prompt contract.",
        returns_summary="Adjusted prompt, adaptation notes, changed sections, and model summary.",
        read_only=True,
        related_tools=["get_model_profile", "improve_prompt", "build_prompt"],
    ),
    _tool(
        "target_prompt_to_surface",
        group="targeting",
        description="Adapt a prompt to a named execution surface such as parser-bound, retrieval-grounded, or tool-workflow, optionally followed by model targeting.",
        when_to_use="Use when the prompt must fit a parser, retrieval system, tool workflow, code assistant, or multimodal surface.",
        inputs_summary="Prompt, surface name, optional model target, and optional prompt contract.",
        returns_summary="Adjusted prompt, surface-specific notes, changed sections, and optional model-targeting output.",
        read_only=True,
        related_tools=["preflight_prompt", "target_prompt_to_model"],
    ),
    _tool(
        "get_model_profile",
        group="targeting",
        description="Return a supported model profile with prompting preferences and warnings.",
        when_to_use="Use when the user wants to understand how a target model behaves before rewriting or targeting a prompt.",
        inputs_summary="Model name or alias.",
        returns_summary="Model profile or nearest matches.",
        read_only=True,
        related_tools=["target_prompt_to_model", "suggest_strategies"],
    ),
    _tool(
        "save_personal_record",
        group="write",
        description="Create or update a personal Prompt Compass record in the writable overlay and Markdown mirror.",
        when_to_use="Use when the user wants to add a custom framework, strategy, pattern, technique, term, or anti-pattern note.",
        inputs_summary="Personal record payload with optional confirmation token for updates.",
        returns_summary="Saved record or confirmation-preview payload.",
        read_only=False,
        related_tools=["seed_personal_overlay", "delete_personal_record", "sync_personal_overlay_from_markdown", "flag_core_record"],
    ),
    _tool(
        "seed_personal_overlay",
        group="write",
        description="Guide and confirm first personal-overlay seed records without mutating the built-in Prompt Compass KB.",
        when_to_use="Use when the user wants Prompt Compass to learn their domains, models, prompt styles, or named methods through the personal layer.",
        inputs_summary="Optional seed answers, confirm flag, and confirmation token.",
        returns_summary="Onboarding questions, proposed personal records, or confirmed saved personal records.",
        read_only=False,
        related_tools=["save_personal_record", "search_prompt_patterns", "sync_personal_overlay_from_markdown"],
    ),
    _tool(
        "manage_preferences",
        group="write",
        description="Read, preview, confirm, or reset Prompt Compass Auto Flow preferences in the personal overlay.",
        when_to_use="Use when the user wants Auto Flow on/off by default, silent or brief summaries, clarification behavior, or ask-before-running behavior.",
        inputs_summary="Optional preferences payload, reset flag, confirm flag, and confirmation token.",
        returns_summary="Current preferences, setup questions, confirmation preview, confirmed saved preferences, or reset result.",
        read_only=False,
        related_tools=["route_prompt_request", "improve_prompt", "seed_personal_overlay"],
    ),
    _tool(
        "delete_personal_record",
        group="write",
        description="Delete a personal Prompt Compass record from the writable overlay and Markdown mirror.",
        when_to_use="Use when the user wants to remove only personal overlay content; core records are refused here.",
        inputs_summary="Personal record ID/name with optional confirmation token.",
        returns_summary="Delete confirmation preview or delete result.",
        read_only=False,
        destructive=True,
        related_tools=["save_personal_record", "flag_core_record"],
    ),
    _tool(
        "flag_core_record",
        group="write",
        description="Flag a built-in Prompt Compass record for later review without mutating the core corpus.",
        when_to_use="Use when the user or host AI wants to mark core content for later human review instead of editing it directly.",
        inputs_summary="Core entry ID, reason, suggested action, and optional notes.",
        returns_summary="Created review flag with status and markdown path.",
        read_only=False,
        related_tools=["list_core_review_flags", "save_personal_record", "delete_personal_record"],
    ),
    _tool(
        "list_core_review_flags",
        group="write",
        description="List review flags created for immutable core Prompt Compass records.",
        when_to_use="Use after flag_core_record when the user wants to see open, reviewed, or dismissed core-review notes.",
        inputs_summary="Optional status, target entry ID, and limit.",
        returns_summary="Review flag cards with target entry IDs, reasons, suggested actions, status, and markdown paths.",
        read_only=True,
        related_tools=["flag_core_record", "get_record"],
    ),
    _tool(
        "sync_personal_overlay_from_markdown",
        group="write",
        description="Scan the personal Prompt Compass vault and upsert personal records and saved prompts into the writable overlay DB.",
        when_to_use="Use after manual Obsidian or Markdown edits when the runtime overlay needs to be updated from disk.",
        inputs_summary="No required inputs.",
        returns_summary="Sync status and per-surface upsert counts.",
        read_only=False,
        related_tools=["save_personal_record", "save_prompt_library_item"],
    ),
    _tool(
        "search_prompt_library",
        group="personal_library",
        description="Search saved prompts, templates, and examples in the personal prompt library.",
        when_to_use="Use when the user wants reusable saved prompt assets rather than shipped Prompt Compass KB records.",
        inputs_summary="Query with optional asset kind, model target, target surface, tags, and limit.",
        returns_summary="Ranked prompt-library items.",
        read_only=True,
        related_tools=["get_prompt_library_item", "save_prompt_library_item", "list_prompt_templates"],
    ),
    _tool(
        "get_prompt_library_item",
        group="personal_library",
        description="Get one saved prompt, template, or example from the personal prompt library.",
        when_to_use="Use when the user knows the saved item they want and needs the exact asset.",
        inputs_summary="Prompt-library item ID, slug, or title.",
        returns_summary="Exact prompt-library item or nearest matches.",
        read_only=True,
        related_tools=["search_prompt_library", "save_prompt_library_item"],
    ),
    _tool(
        "save_prompt_library_item",
        group="personal_library",
        description="Create or update a saved prompt, template, or example in the personal prompt library.",
        when_to_use="Use when the user wants to save a useful prompt asset for later reuse.",
        inputs_summary="Prompt-library item payload with optional confirmation token for updates.",
        returns_summary="Saved item or confirmation-preview payload.",
        read_only=False,
        related_tools=["search_prompt_library", "get_prompt_library_item", "delete_prompt_library_item"],
    ),
    _tool(
        "delete_prompt_library_item",
        group="personal_library",
        description="Delete a saved prompt, template, or example from the personal prompt library.",
        when_to_use="Use when the user wants to remove a personal prompt asset from the overlay and markdown mirror.",
        inputs_summary="Prompt-library item ID/name with optional confirmation token.",
        returns_summary="Delete confirmation preview or delete result.",
        read_only=False,
        destructive=True,
        related_tools=["save_prompt_library_item", "search_prompt_library"],
    ),
]

PUBLIC_PROMPT_REGISTRY = [
    _prompt(
        "pc_route_request",
        description="Route a user request to the right Prompt Compass workflow before any deep tool use begins.",
        when_to_use="Use first when Claude needs help deciding between diagnose, improve, build, preflight, browse, or write-layer flows.",
        arguments=["user_request"],
    ),
    _prompt(
        "pc_quick_improve_flow",
        description="Guide Claude through the one-pass quick improve workflow.",
        when_to_use="Use when the user wants a fast improvement pass and a staged audit is unnecessary.",
        arguments=["prompt_text"],
    ),
    _prompt(
        "pc_advanced_improve_flow",
        description="Guide Claude through the advanced improve workflow across guided, direct, and Agent Mode lanes.",
        when_to_use="Use when the prompt needs stronger diagnosis, a guided or direct advanced pass, or an approval-gated Agent Mode committee plan.",
        arguments=["prompt_text"],
    ),
    _prompt(
        "pc_autopilot_flow",
        description="Guide Claude through Auto Flow delivery: improve first, respect preference gates, then execute when allowed.",
        when_to_use="Use when the user wants Prompt Compass to improve the request and immediately run the improved prompt without showing the full rewrite.",
        arguments=["user_request"],
    ),
    _prompt(
        "pc_quick_build_flow",
        description="Guide Claude through the one-pass quick build workflow.",
        when_to_use="Use when the user wants a prompt scaffold quickly and the request is detailed enough to infer the rest safely.",
        arguments=["user_intent"],
    ),
    _prompt(
        "pc_advanced_build_flow",
        description="Guide Claude through the advanced build workflow across guided, direct, and Agent Mode lanes.",
        when_to_use="Use when the user is starting from scratch and needs staged clarification, a direct advanced scaffold, or an approval-gated Agent Mode committee plan.",
        arguments=["user_intent"],
    ),
    _prompt(
        "pc_agent_committee_flow",
        description="Guide Claude through the approval-gated Agent Mode committee workflow.",
        when_to_use="Use after route_prompt_request or an advanced workflow selects agent_mode=committee.",
        arguments=["user_request"],
    ),
    _prompt(
        "pc_browse_resolve_flow",
        description="Guide Claude through knowledge browsing without drifting into rewrite/build work too early.",
        when_to_use="Use when the user wants to browse frameworks, strategies, patterns, terms, templates, or examples.",
        arguments=["query"],
    ),
    _prompt(
        "pc_personalize_reuse_flow",
        description="Guide Claude through personal overlay onboarding and prompt-library reuse.",
        when_to_use="Use when the user wants Prompt Compass to learn personal methods, save reusable prompt assets, or reuse saved prompts.",
        arguments=["user_goal"],
    ),
]


@lru_cache(maxsize=1)
def _taxonomy_catalog() -> dict[str, list[dict[str, Any]]]:
    values: dict[str, list[dict[str, Any]]] = {}
    for path in TAXONOMY_DIR.glob("*.json"):
        if path.name.startswith("._"):
            continue
        values[path.stem] = json.loads(path.read_text(encoding="utf-8"))
    return values


def tool_registry() -> list[dict[str, Any]]:
    return [dict(item) for item in PUBLIC_TOOL_REGISTRY]


def prompt_registry() -> list[dict[str, Any]]:
    return [dict(item) for item in PUBLIC_PROMPT_REGISTRY]


def tool_description(name: str) -> str:
    for item in PUBLIC_TOOL_REGISTRY:
        if item["tool"] == name:
            return item["description"]
    raise KeyError(f"Unknown tool: {name}")


def prompt_description(name: str) -> str:
    for item in PUBLIC_PROMPT_REGISTRY:
        if item["prompt"] == name:
            return item["description"]
    raise KeyError(f"Unknown prompt: {name}")


def runtime_policy_prompt_text() -> str:
    return (
        "Runtime contract reminder:\n"
        "- Treat Prompt Compass payload fields as the contract for this turn, not optional advice.\n"
        "- If questions_for_user is present and native_ui_required=true, use native Claude/Codex question UI; do not ask the question in prose.\n"
        "- If native UI is unavailable, show the fallback disclosure and render exactly one compact question block.\n"
        "- Follow runtime_policy_card, interaction_contract, host_validation, and required_tool_sequence when they are returned.\n"
        "- If you violate the contract, repair before showing the response to the user.\n\n"
    )


def route_request_prompt_text(user_request: str) -> str:
    request = normalize_text(user_request)
    return (
        "You are routing a Prompt Compass request.\n"
        "Prompt Compass owns the knowledge base, structured diagnosis, staged question payloads, and prompt contracts.\n"
        "Claude owns the conversation, asks the current question in native chat UI, and presents the final synthesis.\n\n"
        f"{runtime_policy_prompt_text()}"
        f"User request:\n{request}\n\n"
        "Routing rules:\n"
        "- Call route_prompt_request first when the user did not already name a specific Prompt Compass workflow tool.\n"
        "- If route_prompt_request returns interaction_pace_required, ask only the pace question first and resume routing with the answer.\n"
        "- If route_prompt_request requires a workflow tool, honor that route before calling browse or lookup tools.\n"
        "- If the user already has a draft and wants to know what is weak, start with analyze_prompt.\n"
        "- If the prompt must be runtime-safe, parser-safe, retrieval-safe, or tool-safe, use preflight_prompt.\n"
        "- If the user wants a rewrite, use improve_prompt.\n"
        "- If the user is starting from intent rather than a draft, use build_prompt.\n"
        "- If quick versus advanced is ambiguous after pace is known, ask one routing question before continuing.\n"
        "- In advanced mode, honor the routed interaction_style (`guided` vs `direct`).\n"
        "- Agent Mode is advanced-only and explicit opt-in. If the route enables it, keep it on the committee lane and do not silently downgrade it.\n"
        "- Ask at most one user-facing question per turn. Do not preview later stages.\n"
        "- Do not browse frameworks first when Prompt Compass has already routed the request to improve/build/analyze/preflight.\n"
    )


def quick_improve_flow_prompt_text(prompt_text: str) -> str:
    prompt = normalize_text(prompt_text)
    return (
        "Run the Prompt Compass quick improve flow.\n"
        "Goal: deliver a stronger rewritten prompt in one pass with bounded assumptions.\n"
        f"{runtime_policy_prompt_text()}"
        "If the request has not already been routed, call route_prompt_request first and honor the route.\n"
        "Call improve_prompt with mode=quick.\n"
        "Do not browse frameworks or patterns first unless the route explicitly allowed browse-first behavior.\n"
        "Do not stage a full audit unless Prompt Compass returns a blocking clarification question.\n"
        "Present the result as:\n"
        "1. short change summary\n"
        "2. rewritten prompt\n"
        "3. assumptions made\n"
        "4. optional short follow-up recommendations\n\n"
        f"Prompt draft:\n{prompt}\n"
    )


def advanced_improve_flow_prompt_text(prompt_text: str) -> str:
    prompt = normalize_text(prompt_text)
    return (
        "Run the Prompt Compass advanced improve flow.\n"
        "Goal: diagnose first, then move through either the guided lane, the direct lane, or the approval-gated Agent Mode committee lane.\n"
        f"{runtime_policy_prompt_text()}"
        "If the request has not already been routed, call route_prompt_request first and honor the route.\n"
        "Use improve_prompt with mode=advanced.\n"
        "Behavior rules:\n"
        "- Ask only the current stage question in the guided lane.\n"
        "- Ask at most one user-facing question per turn.\n"
        "- In the direct lane, make bounded assumptions first and avoid the staged loop unless one clarification is truly necessary.\n"
        "- In Agent Mode, stop at committee plan review, get approval, then follow the returned host execution contract.\n"
        "- If must_pause=true, stop and use Claude Desktop/Codex native question UI first when available.\n"
        "- Do not paraphrase stage questions into inline prose unless native UI is unavailable or the user explicitly waives it.\n"
        "- Pause after each question and pass question_loop_state back on resume.\n"
        "- Do not browse frameworks or patterns first once Prompt Compass has routed this as an improve workflow.\n"
        "- After stage 2, deliver the improved prompt before any optional reflection prompts.\n\n"
        f"Prompt draft:\n{prompt}\n"
    )


def autopilot_flow_prompt_text(user_request: str) -> str:
    request = normalize_text(user_request)
    return (
        "Run the Prompt Compass Auto Flow.\n"
        "Goal: improve the user's request with Prompt Compass, then execute the improved prompt in the same turn without showing the full rewrite.\n"
        f"{runtime_policy_prompt_text()}"
        "If the request has not already been routed, call route_prompt_request first and honor the returned route.\n"
        "Call improve_prompt with delivery_mode='autopilot'. Use mode='quick' unless route_prompt_request requires advanced mode.\n"
        "Behavior rules:\n"
        "- Silence means Auto Flow ran; it must never mean Auto Flow was skipped.\n"
        "- If route_prompt_request returns autoflow_disclosure, show it to the user before doing anything else.\n"
        "- If route_prompt_request returns route_status='meta_task_bypassed' or autoflow_suppressed=true, do not call improve_prompt for Auto Flow.\n"
        "- If improve_prompt is unavailable in the host tool surface, say 'Auto Flow skipped: improve_prompt is unavailable in this host session.'\n"
        "- Do not browse frameworks or patterns first once the route selects improve_prompt.\n"
        "- If improve_prompt returns must_pause=true or questions_for_user, stop and clear that gate before executing.\n"
        "- If autoflow_execution_decision=execute_now, follow host_action: show the brief delta when provided, or run silently only when saved preferences allow it.\n"
        "- If autoflow_execution_decision=approval_required, show rewritten_prompt and ask exactly the returned execute-approval question before running it.\n"
        "- If autoflow_post_execution_onboarding is returned, execute the current task first, then surface the setup questions via native question UI when available.\n"
        "- Do not surface rewritten_prompt in execute_now cases unless the user explicitly asks to see it.\n"
        "- Execute rewritten_prompt only when host_action permits execution.\n\n"
        f"User request:\n{request}\n"
    )


def quick_build_flow_prompt_text(user_intent: str) -> str:
    intent = normalize_text(user_intent)
    return (
        "Run the Prompt Compass quick build flow.\n"
        "Goal: scaffold a usable prompt in one pass when the request is detailed enough.\n"
        f"{runtime_policy_prompt_text()}"
        "If the request has not already been routed, call route_prompt_request first and honor the route.\n"
        "Use build_prompt with mode=quick.\n"
        "Do not browse frameworks or patterns first unless the route explicitly allowed browse-first behavior.\n"
        "Only ask a single clarification question if the request is too vague for a useful scaffold.\n\n"
        f"User intent:\n{intent}\n"
    )


def advanced_build_flow_prompt_text(user_intent: str) -> str:
    intent = normalize_text(user_intent)
    return (
        "Run the Prompt Compass advanced build flow.\n"
        "Goal: scaffold a prompt through either the guided lane, the direct lane, or the approval-gated Agent Mode committee lane.\n"
        f"{runtime_policy_prompt_text()}"
        "If the request has not already been routed, call route_prompt_request first and honor the route.\n"
        "Use build_prompt with mode=advanced.\n"
        "Behavior rules:\n"
        "- Ask at most one user-facing question per turn.\n"
        "- Stage 1 locks objective, audience, and output contract.\n"
        "- Stage 2 gathers context, constraints, and runtime boundaries.\n"
        "- The direct lane should make bounded assumptions first and only ask a clarification question when the build would otherwise be unsafe or too underspecified.\n"
        "- In Agent Mode, stop at committee plan review, get approval, then follow the returned host execution contract.\n"
        "- Stage 3 reflection is optional and must not block delivery of the scaffolded prompt.\n"
        "- If must_pause=true, stop and use Claude Desktop/Codex native question UI first when available.\n"
        "- Do not paraphrase stage questions into inline prose unless native UI is unavailable or the user explicitly waives it.\n"
        "- Ask only the current stage question and pause after each answer.\n"
        "- Do not browse frameworks or patterns first once Prompt Compass has routed this as a build workflow.\n\n"
        f"User intent:\n{intent}\n"
    )


def agent_committee_flow_prompt_text(user_request: str) -> str:
    request = normalize_text(user_request)
    return (
        "Run the Prompt Compass Agent Mode committee flow.\n"
        "Goal: keep Agent Mode approval-gated, bounded, and host-guided.\n"
        f"{runtime_policy_prompt_text()}"
        "Call route_prompt_request first if the request has not already been routed.\n"
        "Use improve_prompt or build_prompt with mode=advanced and agent_mode=committee.\n"
        "Behavior rules:\n"
        "- Stop at committee plan review and ask for approval before execution.\n"
        "- Use native question UI for the approval question when available.\n"
        "- After approval, follow host_execution_instructions exactly.\n"
        "- Use native subagents only when the host supports them; otherwise disclose and run the sequential labeled fallback.\n"
        "- Committee roles must not ask the user questions directly.\n"
        "- Do not spawn recursive committees or exceed the single judge revision budget.\n"
        "- For improve committees, the judge must run compare_prompts before final synthesis.\n\n"
        f"User request:\n{request}\n"
    )


def browse_resolve_flow_prompt_text(query: str) -> str:
    request = normalize_text(query)
    return (
        "Run the Prompt Compass browse and resolve flow.\n"
        "Goal: help the user explore the KB, resolve exact records, and only route into workflow tools when the user chooses a job.\n"
        f"{runtime_policy_prompt_text()}"
        "Use list_catalog_categories first when the user needs the map of available record types.\n"
        "Use list_frameworks/list_strategies/list_patterns/list_techniques/list_terms for broad browsing.\n"
        "Use search_prompt_patterns for open-ended lookup, then get_record/get_framework/get_pattern/get_technique/get_term to resolve the chosen record.\n"
        "If the user switches from browsing to improve/build/diagnose/preflight, call route_prompt_request before workflow execution.\n\n"
        f"Browse query:\n{request}\n"
    )


def personalize_reuse_flow_prompt_text(user_goal: str) -> str:
    goal = normalize_text(user_goal)
    return (
        "Run the Prompt Compass personalize and reuse flow.\n"
        "Goal: use the personal overlay and prompt library without mutating the shared core.\n"
        f"{runtime_policy_prompt_text()}"
        "Start with seed_personal_overlay when the user wants guided personalization or profile bootstrap.\n"
        "Use manage_preferences when the user wants Auto Flow defaults, summary visibility, clarifying-question behavior, or ask-before-running behavior.\n"
        "Use save_personal_record for a specific personal framework, strategy, pattern, technique, term, or anti-pattern.\n"
        "Use save_prompt_library_item for reusable prompts, templates, and examples.\n"
        "Use search_prompt_library and get_prompt_library_item before passing selected prompt-library IDs into improve_prompt or build_prompt.\n"
        "Personal overlay and prompt library can be empty and still enabled; empty means ready for first records, not unavailable.\n"
        "Respect confirmation tokens for writes and deletes.\n\n"
        f"User goal:\n{goal}\n"
    )


def normalize_overview_topic(topic: str | None) -> str:
    value = normalize_text(topic).lower().replace(" ", "_")
    return value if value in OVERVIEW_TOPICS else "overview"


def normalize_audience(audience: str | None) -> str:
    value = normalize_text(audience).lower().replace("-", "_")
    if value in {"end_user", "nontechnical", "non_technical"}:
        return "user"
    if value in {"host", "developer", "host_ai"}:
        return "host_ai"
    return value if value in {"both", "user", "host_ai"} else "both"


def normalize_catalog_scope(catalog_scope: str | None) -> str:
    value = normalize_text(catalog_scope).lower()
    return value if value in CATALOG_SCOPES else DEFAULT_CATALOG_SCOPE


def prompt_compass_overview_payload(
    repo: PromptCompassRepository,
    *,
    topic: str | None = None,
    audience: str | None = "both",
) -> dict[str, Any]:
    resolved_topic = normalize_overview_topic(topic)
    resolved_audience = normalize_audience(audience)
    topic_overviews = {
        "overview": "Prompt Compass helps users diagnose, improve, scaffold, target, and now personalize prompts without collapsing into a generic prompt glossary.",
        "quick_start": "Start with the user job, not the tool name: do they already have a draft, are they starting from scratch, do they need runtime preflight, or are they browsing the KB before choosing a workflow?",
        "diagnose": "Diagnosis is the fastest way to understand what a prompt is missing. Use it when the user already has a draft and wants weakness, anti-pattern, and missing-block visibility before rewriting.",
        "improve": "Improve is the rewrite lane: route first, then choose quick, advanced guided/direct, or the approval-gated Agent Mode committee lane before returning a stronger prompt.",
        "build": "Build is the scaffold lane: if the user has intent but no prompt yet, Prompt Compass can ask bounded questions, run a direct advanced pass, or stage an approval-gated Agent Mode committee plan.",
        "targeting": "Targeting helps an already-usable prompt fit a specific model or execution surface such as parser-bound, retrieval-grounded, or tool-workflow use.",
        "knowledge_base": "The knowledge base is tiered: the immutable shared core carries vendor-neutral workflow philosophy and deterministic drivers, while support and personal records broaden search and exact lookup without hijacking core authority.",
        "personal_overlay": "The personal overlay lets the user add custom prompt-engineering records, private methodology notes, profile preferences, and review flags without mutating the shipped Prompt Compass corpus.",
        "prompt_library": "The prompt library stores reusable prompts, templates, and examples as explicit assets. They can enrich rewrite and build flows only when selected.",
        "tool_surface": "Prompt Compass now has an orientation layer, a deterministic workflow layer, a KB lookup layer, and a separate personal overlay plus prompt-library layer.",
    }
    user_overview = topic_overviews[resolved_topic]
    host_ai_overview = (
        "Route by job shape first: call `route_prompt_request` when the user did not already name the workflow tool, then use `analyze_prompt` or `preflight_prompt` for existing drafts, `improve_prompt` for rewrites, "
        "`build_prompt` for prompts from scratch, `target_prompt_to_model` or `target_prompt_to_surface` for adaptation, "
        "and the list/search tools for browsing after routing. Use the host prompts when Claude needs explicit workflow guidance about quick versus advanced modes. "
        "In advanced mode, honor the routed `interaction_style` and treat Agent Mode as an approval-gated host execution contract rather than something Prompt Compass should silently improvise. "
        "Use compare_prompts as the advanced-improve quality check. Preserve core authority while surfacing personal records as labeled additions; an empty personal overlay is enabled and ready for first records."
    )
    tool_map = [_tool_card(item) for item in _featured_tools_for_topic(resolved_topic)]
    core_workflows = _core_workflows()
    catalog_snapshot = _catalog_snapshot(repo)
    write_surface_summary = {
        "core_is_immutable": True,
        "personal_overlay_writable": True,
        "personal_overlay_enabled": catalog_snapshot["personal_overlay_enabled"],
        "personal_overlay_state": catalog_snapshot["personal_overlay_state"],
        "prompt_library_writable": True,
        "prompt_library_enabled": catalog_snapshot["prompt_library_enabled"],
        "prompt_library_state": catalog_snapshot["prompt_library_state"],
        "update_delete_confirmation_required": True,
        "core_delete_supported": False,
        "first_write_tools": [
            "manage_preferences",
            "save_personal_record",
            "save_prompt_library_item",
            "flag_core_record",
        ],
    }
    starter_prompts = _starter_prompts_for_topic(resolved_topic)
    next_steps = _next_steps_for_topic(resolved_topic)
    routing_rule = {
        "use_prompt_compass_overview_when": [
            "Call prompt_compass_overview when the user or host AI needs a high-level map of Prompt Compass capabilities and workflows.",
            "Use it when the user is not sure whether they should diagnose, improve, build, target, browse, or use the personal layer.",
        ],
        "use_get_started_when": [
            "Call get_started when the user is new, vague, or asking what to do first.",
            "Use get_started when the user has a prompt job but has not yet chosen the first tool.",
        ],
        "default_first_tool_candidates": [
            "route_prompt_request",
            "analyze_prompt",
            "preflight_prompt",
            "build_prompt",
        ],
    }
    markdown = _overview_markdown(
        resolved_topic,
        user_overview=user_overview,
        host_ai_overview=host_ai_overview,
        tool_map=tool_map,
        core_workflows=core_workflows,
        starter_prompts=starter_prompts,
        next_steps=next_steps,
        write_surface_summary=write_surface_summary,
    )
    return {
        "status": "overview_ready",
        "tool": "prompt_compass_overview",
        "topic": resolved_topic,
        "available_topics": list(OVERVIEW_TOPICS),
        "audience": resolved_audience,
        "user_overview": user_overview,
        "host_ai_overview": host_ai_overview,
        "core_workflows": core_workflows,
        "tool_map": tool_map,
        "catalog_snapshot": catalog_snapshot,
        "write_surface_summary": write_surface_summary,
        "starter_prompts": starter_prompts,
        "host_prompts": prompt_registry(),
        "next_steps": next_steps,
        "routing_rule": routing_rule,
        "markdown": markdown,
    }


def get_started_payload(
    repo: PromptCompassRepository,
    *,
    topic: str | None = None,
    audience: str | None = "both",
) -> dict[str, Any]:
    resolved_topic = normalize_overview_topic(topic or "quick_start")
    resolved_audience = normalize_audience(audience)
    if resolved_audience == "user":
        markdown = (
            "# Prompt Compass Get Started\n\n"
            "I help you write clearer AI requests. Tell me what you want the AI to help with, "
            "or paste something you already wrote and I will guide you from there.\n\n"
            "Good starts:\n"
            "- Make this prompt better: [paste it]\n"
            "- Help me write a prompt for [thing]\n"
            "- Tell me what is confusing about this prompt: [paste it]\n\n"
            "Next step: answer the pace question, then Prompt Compass will ask at most one question at a time."
        )
        return {
            "status": "get_started_ready",
            "tool": "get_started",
            "topic": resolved_topic,
            "audience": resolved_audience,
            "plain_language_summary": "Tell me what you want the AI to help with, or paste what you already wrote.",
            "first_step": "Start with the pace question: Quick fix, Guided, or Deep dive.",
            "starter_prompts": [
                "Make this prompt better: [paste it]",
                "Help me write a prompt for [thing]",
                "Tell me what is confusing about this prompt: [paste it]",
            ],
            "next_step": "route_prompt_request",
            "markdown": markdown,
        }
    first_five_minutes = [
        {
            "minute": "0-1",
            "action": "If the user did not already name a workflow tool, call route_prompt_request and let Prompt Compass choose the lane before browsing or improvising.",
            "best_tool": "route_prompt_request",
        },
        {
            "minute": "1-2",
            "action": "Decide whether the user already has a draft prompt, needs one from scratch, or needs a runtime preflight before using the prompt.",
            "branching_note": "If draft: analyze_prompt or improve_prompt. If from scratch: build_prompt. If runtime readiness matters: preflight_prompt.",
            "branching_tools": ["analyze_prompt", "build_prompt", "preflight_prompt"],
        },
        {
            "minute": "2-3",
            "action": "If there is already a draft, call analyze_prompt first; switch to preflight_prompt instead when runtime or execution-surface readiness matters.",
            "best_tool": "analyze_prompt",
        },
        {
            "minute": "3-4",
            "action": "If there is no draft yet, call build_prompt and let Prompt Compass drive the bounded question loop.",
            "best_tool": "build_prompt",
        },
        {
            "minute": "4-5",
            "action": "Use improve_prompt for rewrites, or target_prompt_to_model / target_prompt_to_surface if the prompt must fit a particular model or runtime.",
            "best_tool": "improve_prompt",
        },
        {
            "minute": "5+",
            "action": "If the user wants examples, frameworks, strategies, reusable assets, or personalization, use the browse or personalize host prompts instead of forcing a rewrite workflow. Empty personal layers are still enabled and ready for first records.",
            "best_tool": "prompt_compass_overview",
        },
    ]
    recommended_first_tools = _recommended_first_tools(resolved_topic)
    starter_prompts = _starter_prompts_for_topic(resolved_topic)
    routing_rule = {
        "use_get_started_when": [
            "The user is new to Prompt Compass.",
            "The user asks what to do first or how to use the MCP.",
            "The user has not yet chosen between diagnose, improve, build, preflight, target, browse, or personalize.",
        ],
        "use_prompt_compass_overview_when": [
            "The user wants a broader map of capabilities, tool inventory, or workflow differences.",
            "The host AI already knows the user's job but needs orientation to the full surface.",
        ],
    }
    next_step = recommended_first_tools[0]["tool"] if recommended_first_tools else "prompt_compass_overview"
    markdown = _get_started_markdown(
        resolved_topic,
        first_five_minutes=first_five_minutes,
        recommended_first_tools=recommended_first_tools,
        starter_prompts=starter_prompts,
        next_step=next_step,
    )
    return {
        "status": "get_started_ready",
        "tool": "get_started",
        "topic": resolved_topic,
        "audience": resolved_audience,
        "routing_rule": routing_rule,
        "first_five_minutes": first_five_minutes,
        "recommended_first_tools": recommended_first_tools,
        "starter_prompts": starter_prompts,
        "next_step": next_step,
        "markdown": markdown,
    }


def list_tool_surface_payload(*, include_write_tools: bool = True, audience: str | None = "both") -> dict[str, Any]:
    resolved_audience = normalize_audience(audience)
    tools = [
        dict(item)
        for item in PUBLIC_TOOL_REGISTRY
        if include_write_tools or item["read_only"]
    ]
    grouped = []
    for group in GROUP_ORDER:
        group_tools = [_tool_card(item) for item in tools if item["group"] == group]
        if not group_tools:
            continue
        grouped.append(
            {
                "group": group,
                "label": GROUP_LABELS.get(group, group.replace("_", " ").title()),
                "tools": group_tools,
            }
        )
    common_sequences = [
        {
            "name": "Diagnose then advanced improve then compare",
            "sequence": ["route_prompt_request", "analyze_prompt/diagnose_prompt", "get_clarifying_questions", "improve_prompt(mode=advanced)", "compare_prompts"],
        },
        {
            "name": "Route then quick improve",
            "sequence": ["route_prompt_request", "pc_quick_improve_flow", "improve_prompt"],
        },
        {
            "name": "Route then advanced build",
            "sequence": ["route_prompt_request", "pc_advanced_build_flow", "build_prompt"],
        },
        {
            "name": "Route then advanced improve",
            "sequence": ["route_prompt_request", "pc_advanced_improve_flow", "improve_prompt"],
        },
        {
            "name": "Route then direct advanced improve",
            "sequence": ["route_prompt_request", "pc_advanced_improve_flow", "improve_prompt(interaction_style=direct)"],
        },
        {
            "name": "Route then Agent Mode committee",
            "sequence": ["route_prompt_request", "pc_agent_committee_flow", "improve_prompt/build_prompt(agent_mode=committee)", "committee_plan_review", "host_execution", "compare_prompts", "final_synthesis"],
        },
        {
            "name": "Build then target",
            "sequence": ["build_prompt", "target_prompt_to_model", "target_prompt_to_surface"],
        },
        {
            "name": "Browse then resolve",
            "sequence": ["pc_browse_resolve_flow", "list_catalog_categories", "search_prompt_patterns", "get_record"],
        },
        {
            "name": "Personalize then reuse",
            "sequence": ["pc_personalize_reuse_flow", "seed_personal_overlay", "save_personal_record/save_prompt_library_item", "search_prompt_library", "improve_prompt/build_prompt"],
        },
    ]
    write_safety_notes = [
        "Core Prompt Compass records are immutable and cannot be deleted or overwritten.",
        "An empty personal overlay is enabled and ready for first records; empty does not mean unavailable.",
        "Auto Flow preferences live in the personal overlay and use confirmation tokens before saving or resetting.",
        "Personal overlay updates and deletes require explicit confirmation tokens.",
        "An empty prompt library is enabled and ready for saved prompts, templates, and examples.",
        "Prompt-library assets only influence improve_prompt or build_prompt when explicitly selected.",
        "Use flag_core_record instead of trying to edit or delete built-in Prompt Compass records.",
    ]
    first_tools_for_common_jobs = [
        {"job": "I said use Prompt Compass but did not name the exact workflow.", "tool": "route_prompt_request"},
        {"job": "I already have a prompt and want to know what is wrong.", "tool": "analyze_prompt"},
        {"job": "I need to make this prompt usable before I run it.", "tool": "preflight_prompt"},
        {"job": "I want a better rewritten version of my prompt.", "tool": "improve_prompt"},
        {"job": "I need a prompt from scratch.", "tool": "build_prompt"},
        {"job": "Show me frameworks, strategies, or examples first.", "tool": "prompt_compass_overview"},
        {"job": "Save this useful pattern or prompt for later.", "tool": "save_personal_record"},
    ]
    markdown = _tool_surface_markdown(grouped, common_sequences, write_safety_notes)
    return {
        "status": "tool_surface_ready",
        "tool": "list_tool_surface",
        "audience": resolved_audience,
        "include_write_tools": bool(include_write_tools),
        "tool_count": len(tools),
        "host_prompt_count": len(PUBLIC_PROMPT_REGISTRY),
        "host_prompts": prompt_registry(),
        "groups": grouped,
        "common_sequences": common_sequences,
        "write_safety_notes": write_safety_notes,
        "first_tools_for_common_jobs": first_tools_for_common_jobs,
        "markdown": markdown,
    }


def list_catalog_categories_payload(repo: PromptCompassRepository) -> dict[str, Any]:
    taxonomy = _taxonomy_catalog()
    record_types = [
        {
            "name": record_type,
            "count": len(repo.list_records(record_type)),
        }
        for record_type in LISTABLE_RECORD_TYPES + ("question", "model_profile")
    ]
    payload = {
        "status": "catalog_categories_ready",
        "tool": "list_catalog_categories",
        "catalog_scopes": list(CATALOG_SCOPES),
        "record_types": record_types,
        "prompt_types": taxonomy.get("prompt-types", []),
        "subject_areas": taxonomy.get("subject-areas", []),
        "interaction_modes": taxonomy.get("interaction-modes", []),
        "output_modes": taxonomy.get("output-modes", []),
        "grounding_modes": taxonomy.get("grounding-modes", []),
        "evaluation_modes": taxonomy.get("evaluation-modes", []),
        "capability_tags": taxonomy.get("capability-tags", []),
        "supported_model_targets": repo.supported_model_ids(),
        "supported_prompt_surfaces": list(SUPPORTED_SURFACES),
    }
    payload["markdown"] = _catalog_categories_markdown(payload)
    return payload


def list_frameworks_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = DEFAULT_LIMIT,
    catalog_scope: str = DEFAULT_CATALOG_SCOPE,
) -> dict[str, Any]:
    return _list_record_family_payload(repo, tool_name="list_frameworks", record_type="framework", query=query, limit=limit, catalog_scope=catalog_scope)


def list_strategies_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = DEFAULT_LIMIT,
    catalog_scope: str = DEFAULT_CATALOG_SCOPE,
) -> dict[str, Any]:
    return _list_record_family_payload(repo, tool_name="list_strategies", record_type="strategy", query=query, limit=limit, catalog_scope=catalog_scope)


def list_patterns_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = DEFAULT_LIMIT,
    catalog_scope: str = DEFAULT_CATALOG_SCOPE,
) -> dict[str, Any]:
    return _list_record_family_payload(repo, tool_name="list_patterns", record_type="pattern", query=query, limit=limit, catalog_scope=catalog_scope)


def list_techniques_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = DEFAULT_LIMIT,
    catalog_scope: str = DEFAULT_CATALOG_SCOPE,
) -> dict[str, Any]:
    return _list_record_family_payload(repo, tool_name="list_techniques", record_type="technique", query=query, limit=limit, catalog_scope=catalog_scope)


def list_terms_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = DEFAULT_LIMIT,
    catalog_scope: str = DEFAULT_CATALOG_SCOPE,
) -> dict[str, Any]:
    return _list_record_family_payload(repo, tool_name="list_terms", record_type="term", query=query, limit=limit, catalog_scope=catalog_scope)


def list_anti_patterns_payload(
    repo: PromptCompassRepository,
    *,
    limit: int = 25,
    severity: str | None = None,
    prompt_type: str | None = None,
    catalog_scope: str = DEFAULT_CATALOG_SCOPE,
) -> dict[str, Any]:
    safe_limit = _safe_limit(limit, default=25)
    scope = normalize_catalog_scope(catalog_scope)
    records = []
    for record in repo.list_records("anti_pattern", catalog_scope=scope):
        if severity and normalize_text(record.get("severity_default")).lower() != normalize_text(severity).lower():
            continue
        if prompt_type and prompt_type not in ensure_list(record.get("prompt_types")):
            continue
        records.append(record)
        if len(records) >= safe_limit:
            break
    results = [_catalog_card(record) for record in records]
    for card, record in zip(results, records):
        card.update(
            {
                "severity_default": record.get("severity_default"),
                "fix": _fix_preview(record),
                "detection_signal": _signal_preview(record),
                "what_it_looks_like": _example_preview(record),
            }
        )
    markdown = _family_markdown("Anti-Patterns", results)
    return {
        "status": "catalog_ready",
        "tool": "list_anti_patterns",
        "record_type": "anti_pattern",
        "severity": severity,
        "prompt_type": prompt_type,
        "catalog_scope": scope,
        "count": len(results),
        "counts_by_layer": _counts_by_layer(results),
        "results": results,
        "starter_prompts": [
            "Show me the anti-patterns most likely to affect a vague rewrite request.",
            "Which anti-pattern best matches my current prompt?",
            "Show me anti-patterns for parser-bound prompts.",
        ],
        "next_tools": ["analyze_prompt", "get_pattern", "search_prompt_patterns"],
        "markdown": markdown,
    }


def list_prompt_templates_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = DEFAULT_LIMIT,
    catalog_scope: str = DEFAULT_CATALOG_SCOPE,
    include_prompt_library: bool = False,
) -> dict[str, Any]:
    return _list_exemplars_payload(
        repo,
        tool_name="list_prompt_templates",
        exemplar_kind="template",
        query=query,
        limit=limit,
        catalog_scope=catalog_scope,
        include_prompt_library=include_prompt_library,
    )


def list_prompt_examples_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = DEFAULT_LIMIT,
    catalog_scope: str = DEFAULT_CATALOG_SCOPE,
    include_prompt_library: bool = False,
) -> dict[str, Any]:
    return _list_exemplars_payload(
        repo,
        tool_name="list_prompt_examples",
        exemplar_kind="example",
        query=query,
        limit=limit,
        catalog_scope=catalog_scope,
        include_prompt_library=include_prompt_library,
    )


def _featured_tools_for_topic(topic: str) -> list[dict[str, Any]]:
    featured_map = {
        "overview": [
            "prompt_compass_overview",
            "get_started",
            "route_prompt_request",
            "analyze_prompt",
            "diagnose_prompt",
            "preflight_prompt",
            "improve_prompt",
            "compare_prompts",
            "build_prompt",
            "target_prompt_to_model",
            "target_prompt_to_surface",
            "suggest_strategies",
            "manage_preferences",
            "seed_personal_overlay",
            "save_personal_record",
            "save_prompt_library_item",
            "list_tool_surface",
        ],
        "quick_start": ["get_started", "route_prompt_request", "analyze_prompt", "build_prompt", "preflight_prompt"],
        "diagnose": ["diagnose_prompt", "analyze_prompt", "preflight_prompt", "search_prompt_patterns", "get_clarifying_questions"],
        "improve": ["route_prompt_request", "diagnose_prompt", "analyze_prompt", "improve_prompt", "compare_prompts", "suggest_strategies"],
        "build": ["route_prompt_request", "build_prompt", "get_clarifying_questions", "list_prompt_examples"],
        "targeting": ["target_prompt_to_model", "target_prompt_to_surface", "get_model_profile", "preflight_prompt"],
        "knowledge_base": ["search_prompt_patterns", "get_record", "list_catalog_categories", "list_frameworks", "list_terms"],
        "personal_overlay": ["seed_personal_overlay", "manage_preferences", "save_personal_record", "delete_personal_record", "flag_core_record", "list_core_review_flags", "sync_personal_overlay_from_markdown"],
        "prompt_library": ["save_prompt_library_item", "search_prompt_library", "get_prompt_library_item", "list_prompt_templates"],
        "tool_surface": ["list_tool_surface", "route_prompt_request", "prompt_compass_overview", "list_catalog_categories"],
    }
    names = featured_map.get(topic, featured_map["overview"])
    return [item for name in names for item in PUBLIC_TOOL_REGISTRY if item["tool"] == name]


def _core_workflows() -> list[dict[str, Any]]:
    return [
        {
            "name": "Route first",
            "user_job": "I said use Prompt Compass, but I did not name the exact workflow.",
            "sequence": ["route_prompt_request", "improve_prompt/build_prompt/analyze_prompt/preflight_prompt"],
            "best_for": ["broad requests", "hard routing", "preventing lookup-first drift"],
        },
        {
            "name": "Diagnose then improve",
            "user_job": "I already have a prompt and want a stronger version.",
            "sequence": ["route_prompt_request", "analyze_prompt/diagnose_prompt", "get_clarifying_questions", "improve_prompt", "compare_prompts"],
            "best_for": ["draft prompts", "rewrite requests", "anti-pattern repair"],
        },
        {
            "name": "Agent Mode committee",
            "user_job": "I want multiple bounded roles to improve or build the prompt.",
            "sequence": ["route_prompt_request", "pc_agent_committee_flow", "improve_prompt/build_prompt(agent_mode=committee)", "compare_prompts", "final_synthesis"],
            "best_for": ["explicit agent mode", "committee review", "host-guided subagents"],
        },
        {
            "name": "Build from scratch",
            "user_job": "I know what I want, but I do not have a prompt yet.",
            "sequence": ["route_prompt_request", "build_prompt", "target_prompt_to_model"],
            "best_for": ["new prompts", "scaffold-first workflows"],
        },
        {
            "name": "Preflight before use",
            "user_job": "I need to know whether this prompt is safe to run in a specific runtime context.",
            "sequence": ["route_prompt_request", "preflight_prompt", "suggest_strategies", "target_prompt_to_surface"],
            "best_for": ["parser-bound", "retrieval-grounded", "tool-workflow", "multimodal"],
        },
        {
            "name": "Browse the KB",
            "user_job": "Show me the kinds of frameworks, strategies, patterns, or examples you have.",
            "sequence": ["pc_browse_resolve_flow", "list_catalog_categories", "search_prompt_patterns", "get_record"],
            "best_for": ["orientation", "teaching", "knowledge browsing"],
        },
        {
            "name": "Personalize Prompt Compass",
            "user_job": "I want to save my own records or reusable prompts without mutating the shipped KB.",
            "sequence": ["pc_personalize_reuse_flow", "seed_personal_overlay", "save_prompt_library_item", "search_prompt_library"],
            "best_for": ["custom overlays", "prompt libraries", "personal workflows"],
        },
    ]


def _catalog_snapshot(repo: PromptCompassRepository) -> dict[str, Any]:
    all_records = repo.list_records()
    counts_by_type: dict[str, int] = {}
    counts_by_layer: dict[str, int] = {}
    for record in all_records:
        counts_by_type[record["record_type"]] = counts_by_type.get(record["record_type"], 0) + 1
        layer = normalize_text(record.get("record_layer")) or "core"
        counts_by_layer[layer] = counts_by_layer.get(layer, 0) + 1
    personal_record_count = len(repo.personal.list_records())
    prompt_library_item_count = repo.prompt_library_item_count()
    personal_available = personal_record_count > 0
    prompt_library_available = prompt_library_item_count > 0
    return {
        "record_counts": counts_by_type,
        "counts_by_layer": counts_by_layer,
        "supported_model_targets": repo.supported_model_ids(),
        "supported_prompt_surfaces": list(SUPPORTED_SURFACES),
        "personal_overlay_enabled": True,
        "personal_overlay_enabled_meaning": "The writable personal overlay surface exists and can store user records.",
        "personal_overlay_state": "populated" if personal_available else "empty",
        "personal_record_count": personal_record_count,
        "prompt_library_enabled": True,
        "prompt_library_enabled_meaning": "The writable personal prompt-library surface exists and can store reusable prompts.",
        "prompt_library_state": "populated" if prompt_library_available else "empty",
        "prompt_library_item_count": prompt_library_item_count,
        "personal_overlay_available": personal_available,
        "personal_overlay_available_meaning": "True only when the personal overlay currently contains at least one user record.",
        "prompt_library_available": prompt_library_available,
        "prompt_library_available_meaning": "True only when the personal prompt library currently contains at least one saved item.",
    }


def _starter_prompts_for_topic(topic: str) -> list[str]:
    prompt_map = {
        "overview": [
            "Show me what Prompt Compass can do and which tool I should call first.",
            "Route this Prompt Compass request before doing anything else.",
            "What is the difference between analyze_prompt, preflight_prompt, improve_prompt, and build_prompt?",
            "Show me the main Prompt Compass workflows.",
        ],
        "quick_start": [
            "Use route_prompt_request on this request first.",
            "I already have a prompt. What should I call first?",
            "I need a prompt from scratch for Claude Sonnet 4. What tool do I use?",
            "Show me the first five-minute path for Prompt Compass.",
        ],
        "diagnose": [
            "Analyze this prompt and tell me what is weak or missing.",
            "Which anti-patterns are likely in this prompt?",
            "Show me the strategies that match this broken prompt.",
        ],
        "improve": [
            "Improve this prompt for a hiring manager memo.",
            "Rewrite this prompt and show me what changed.",
            "Show me a few prompt templates I can borrow before rewriting.",
        ],
        "build": [
            "Help me build a prompt from scratch for a research brief.",
            "Show me a few frameworks I could use before I build the prompt.",
            "What questions should Prompt Compass ask me first?",
        ],
        "targeting": [
            "Target this prompt to GPT-5.4.",
            "Make this prompt parser-bound before I run it.",
            "Which model profile should I check before retargeting this prompt?",
        ],
        "knowledge_base": [
            "Show me 10 frameworks.",
            "Show me strategies for retrieval-grounded prompts.",
            "List some prompt examples I can learn from.",
        ],
        "personal_overlay": [
            "Save this as a personal strategy.",
            "Flag this built-in record for later review.",
            "How do I sync my Prompt Compass personal vault?",
        ],
        "prompt_library": [
            "Save this rewritten prompt as a template.",
            "Search my saved prompt library for parser-bound templates.",
            "Show me prompt examples from the KB and my library separately.",
        ],
        "tool_surface": [
            "List the full Prompt Compass tool surface.",
            "Show me the route-first workflow entry tools.",
            "Which tools are writable versus read-only?",
            "Show me the common tool sequences for Prompt Compass.",
        ],
    }
    return prompt_map.get(topic, prompt_map["overview"])


def _next_steps_for_topic(topic: str) -> list[str]:
    next_steps = {
        "overview": [
            "If the user did not name a specific workflow tool, start with route_prompt_request.",
            "If there is already a draft prompt, start with analyze_prompt.",
            "If the prompt must be runtime-safe, start with preflight_prompt.",
            "If there is no draft yet, start with build_prompt.",
        ],
        "quick_start": [
            "If the user says 'use Prompt Compass' without naming a workflow tool, call route_prompt_request first.",
            "Pick the first tool based on job shape, not based on the user's mention of a framework name.",
            "Use the list tools when the user is browsing or learning, not when they are already in a rewrite workflow.",
        ],
        "diagnose": [
            "After analyze_prompt, ask only the clarifying questions that actually change the rewrite.",
            "Then move to improve_prompt instead of staying in analysis mode too long.",
        ],
        "improve": [
            "In advanced mode, treat must_pause=true as a blocking gate and use native question UI first when available.",
            "Use selected prompt-library items only when the user explicitly wants them to steer the rewrite.",
            "Target the improved prompt to a model or surface only after the prompt itself is structurally sound.",
        ],
    }
    return next_steps.get(topic, next_steps.get("overview", []))


def _recommended_first_tools(topic: str) -> list[dict[str, Any]]:
    mappings = {
        "quick_start": [
            ("route_prompt_request", "For any broad 'use Prompt Compass' request where the workflow tool has not been named yet."),
            ("analyze_prompt", "For an existing draft prompt that needs diagnosis before rewrite."),
            ("build_prompt", "For a prompt that does not exist yet."),
            ("preflight_prompt", "For prompts that must be checked against a runtime or execution surface."),
        ],
        "personal_overlay": [
            ("save_personal_record", "To add a custom framework, strategy, pattern, technique, term, or anti-pattern note."),
            ("save_prompt_library_item", "To save a reusable prompt, template, or example."),
            ("flag_core_record", "To mark built-in content for later review without mutating it."),
        ],
        "prompt_library": [
            ("search_prompt_library", "To browse previously saved prompt assets."),
            ("save_prompt_library_item", "To save a new prompt, template, or example."),
            ("build_prompt", "To reuse selected prompt-library items explicitly in a new scaffold."),
        ],
        "knowledge_base": [
            ("list_catalog_categories", "To see the main browsing slices before narrowing."),
            ("list_frameworks", "To get a bounded overview of frameworks."),
            ("search_prompt_patterns", "To do open-ended retrieval across the KB."),
        ],
    }
    chosen = mappings.get(topic, mappings["quick_start"])
    return [
        {
            "tool": tool_name,
            "when_to_use": why,
        }
        for tool_name, why in chosen
    ]


def _list_record_family_payload(
    repo: PromptCompassRepository,
    *,
    tool_name: str,
    record_type: str,
    query: str | None,
    limit: int,
    catalog_scope: str,
) -> dict[str, Any]:
    safe_limit = _safe_limit(limit)
    scope = normalize_catalog_scope(catalog_scope)
    results = [_catalog_card(record) for record in _search_or_browse_records(repo, record_type=record_type, query=query, limit=safe_limit, catalog_scope=scope)]
    return {
        "status": "catalog_ready",
        "tool": tool_name,
        "record_type": record_type,
        "query": normalize_text(query),
        "limit": safe_limit,
        "catalog_scope": scope,
        "count": len(results),
        "counts_by_layer": _counts_by_layer(results),
        "results": results,
        "starter_prompts": _family_starter_prompts(record_type),
        "next_tools": _family_next_tools(record_type),
        "markdown": _family_markdown(record_type.replace("_", " ").title() + "s", results),
    }


def _list_exemplars_payload(
    repo: PromptCompassRepository,
    *,
    tool_name: str,
    exemplar_kind: str,
    query: str | None,
    limit: int,
    catalog_scope: str,
    include_prompt_library: bool,
) -> dict[str, Any]:
    safe_limit = _safe_limit(limit)
    scope = normalize_catalog_scope(catalog_scope)
    records = _search_or_browse_exemplars(repo, exemplar_kind=exemplar_kind, query=query, limit=safe_limit, catalog_scope=scope)
    kb_items = [_catalog_card(record) for record in records]
    prompt_library_items = []
    if include_prompt_library:
        asset_kind = "template" if exemplar_kind == "template" else "example"
        prompt_library_items = repo.search_prompt_library(normalize_text(query), asset_kind=asset_kind, limit=safe_limit).get("results", [])
    markdown = _exemplar_markdown(exemplar_kind, kb_items, prompt_library_items)
    return {
        "status": "catalog_ready",
        "tool": tool_name,
        "query": normalize_text(query),
        "limit": safe_limit,
        "catalog_scope": scope,
        "include_prompt_library": bool(include_prompt_library),
        "counts_by_layer": _counts_by_layer(kb_items),
        "kb_items": kb_items,
        "prompt_library_items": prompt_library_items,
        "starter_prompts": [
            f"Show me {safe_limit} prompt {exemplar_kind.replace('_', ' ')}s for parser-bound prompts.",
            f"Show me a few prompt {exemplar_kind.replace('_', ' ')}s before we rewrite this prompt.",
            "Include my prompt library too, but keep it separate from the built-in KB.",
        ],
        "next_tools": ["search_prompt_patterns", "search_prompt_library", "build_prompt", "improve_prompt"],
        "markdown": markdown,
    }


def _search_or_browse_records(
    repo: PromptCompassRepository,
    *,
    record_type: str,
    query: str | None,
    limit: int,
    catalog_scope: str,
) -> list[dict[str, Any]]:
    normalized_query = normalize_text(query)
    if normalized_query:
        search = repo.search_prompt_patterns(normalized_query, record_types=[record_type], limit=max(limit, 25))
        indexed_records: list[tuple[int, str, dict[str, Any]]] = []
        seen_entry_ids: set[str] = set()
        for position, item in enumerate(search.get("results", [])):
            entry_id = item.get("entry_id")
            if not entry_id or entry_id in seen_entry_ids:
                continue
            record = repo.get_entry(entry_id)
            if not record.get("found"):
                continue
            if catalog_scope == "core_only" and normalize_text(record.get("record_layer")) != "core":
                continue
            seen_entry_ids.add(entry_id)
            indexed_records.append((position, normalize_text(item.get("match_type")), record))
        if catalog_scope == "core_first":
            indexed_records.sort(
                key=lambda item: (
                    0 if item[1].startswith("exact") else 1,
                    0 if normalize_text(item[2].get("record_layer")) == "core" else 1,
                    item[0],
                )
            )
        return [record for _, _, record in indexed_records[:limit]]
    records = repo.list_records(record_type, catalog_scope=catalog_scope)
    return records[:limit]


def _search_or_browse_exemplars(
    repo: PromptCompassRepository,
    *,
    exemplar_kind: str,
    query: str | None,
    limit: int,
    catalog_scope: str,
) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    if normalize_text(query):
        search = repo.search_prompt_patterns(normalize_text(query), record_types=list(TEMPLATE_RECORD_TYPES), limit=25)
        indexed_records: list[tuple[int, str, dict[str, Any]]] = []
        for position, item in enumerate(search.get("results", [])):
            record = repo.get_entry(item.get("entry_id", ""))
            if not record.get("found"):
                continue
            if record.get("record_type") not in TEMPLATE_RECORD_TYPES:
                continue
            if catalog_scope == "core_only" and normalize_text(record.get("record_layer")) != "core":
                continue
            if exemplar_kind == "template" and not _has_template(record):
                continue
            if exemplar_kind == "example" and not _has_examples(record):
                continue
            indexed_records.append((position, normalize_text(item.get("match_type")), record))
        if catalog_scope == "core_first":
            indexed_records.sort(
                key=lambda item: (
                    0 if item[1].startswith("exact") else 1,
                    0 if normalize_text(item[2].get("record_layer")) == "core" else 1,
                    item[0],
                )
            )
        deduped: list[dict[str, Any]] = []
        seen: set[str] = set()
        for _, _, record in indexed_records:
            if record["entry_id"] in seen:
                continue
            seen.add(record["entry_id"])
            deduped.append(record)
        return deduped[:limit]
    for record_type in TEMPLATE_RECORD_TYPES:
        for record in repo.list_records(record_type, catalog_scope=catalog_scope):
            if exemplar_kind == "template" and _has_template(record):
                records.append(record)
            elif exemplar_kind == "example" and _has_examples(record):
                records.append(record)
    return records[:limit]


def _catalog_card(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "entry_id": record.get("entry_id"),
        "name": record.get("name"),
        "record_type": record.get("record_type"),
        "summary": normalize_text(record.get("summary")) or short_text(record.get("definition"), 180),
        "when_to_use": _when_to_use(record),
        "template_preview": _template_preview(record),
        "example_preview": _example_preview(record),
        "tags": ensure_list(record.get("tags"))[:6],
        "record_layer": normalize_text(record.get("record_layer")) or "core",
        "mutable": bool(record.get("mutable", False)),
        "driver_eligible": bool(record.get("driver_eligible", False)),
    }


def _when_to_use(record: dict[str, Any]) -> str:
    explicit = record.get("when_to_use")
    if isinstance(explicit, list) and explicit:
        return normalize_text(explicit[0])
    if isinstance(explicit, str) and normalize_text(explicit):
        return normalize_text(explicit)
    summary = normalize_text(record.get("summary"))
    if summary:
        return summary
    return short_text(record.get("definition"), 160)


def _template_preview(record: dict[str, Any]) -> str:
    template = record.get("template")
    if isinstance(template, str):
        return short_text(template, 140)
    if template:
        return short_text(json.dumps(template, ensure_ascii=False), 140)
    return ""


def _example_preview(record: dict[str, Any]) -> str:
    examples = ensure_list(record.get("examples"))
    if not examples:
        return ""
    first = examples[0]
    if isinstance(first, dict):
        return short_text(json.dumps(first, ensure_ascii=False), 140)
    return short_text(first, 140)


def _fix_preview(record: dict[str, Any]) -> str:
    fixes = ensure_list(record.get("recommended_fixes")) or ensure_list(record.get("fixes"))
    if fixes:
        return short_text(fixes[0], 140)
    return ""


def _signal_preview(record: dict[str, Any]) -> str:
    signals = ensure_list(record.get("detection_signal")) or ensure_list(record.get("signals"))
    if signals:
        return short_text(signals[0], 140)
    return ""


def _counts_by_layer(items: list[dict[str, Any]]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for item in items:
        layer = normalize_text(item.get("record_layer")) or "core"
        counts[layer] = counts.get(layer, 0) + 1
    return counts


def _family_starter_prompts(record_type: str) -> list[str]:
    label = record_type.replace("_", " ")
    return [
        f"Show me 10 {label}s.",
        f"Show me {label}s for parser-bound prompts.",
        f"Which {label} should I use before I rewrite this prompt?",
    ]


def _family_next_tools(record_type: str) -> list[str]:
    mapping = {
        "framework": ["get_framework", "search_prompt_patterns", "build_prompt"],
        "strategy": ["suggest_strategies", "get_record", "improve_prompt"],
        "pattern": ["get_pattern", "search_prompt_patterns", "improve_prompt"],
        "technique": ["get_technique", "search_prompt_patterns", "improve_prompt"],
        "term": ["get_term", "search_prompt_patterns", "prompt_compass_overview"],
    }
    return mapping.get(record_type, ["search_prompt_patterns", "get_record"])


def _overview_markdown(
    topic: str,
    *,
    user_overview: str,
    host_ai_overview: str,
    tool_map: list[dict[str, Any]],
    core_workflows: list[dict[str, Any]],
    starter_prompts: list[str],
    next_steps: list[str],
    write_surface_summary: dict[str, Any],
) -> str:
    tool_lines = "\n".join(f"- `{item['tool']}`: {item['when_to_use']}" for item in tool_map)
    workflow_lines = "\n".join(f"- **{item['name']}**: {' -> '.join(item['sequence'])}" for item in core_workflows)
    starter_lines = "\n".join(f"- {item}" for item in starter_prompts)
    next_step_lines = "\n".join(f"- {item}" for item in next_steps)
    return (
        f"# Prompt Compass Overview: {topic.replace('_', ' ').title()}\n\n"
        f"## User Overview\n{user_overview}\n\n"
        f"## Host AI Overview\n{host_ai_overview}\n\n"
        f"## Featured Tools\n{tool_lines}\n\n"
        f"## Core Workflows\n{workflow_lines}\n\n"
        f"## Write Safety\n"
        f"- Core immutable: `{write_surface_summary['core_is_immutable']}`\n"
        f"- Personal overlay writable: `{write_surface_summary['personal_overlay_writable']}`\n"
        f"- Personal overlay state: `{write_surface_summary['personal_overlay_state']}` (enabled: `{write_surface_summary['personal_overlay_enabled']}`)\n"
        f"- Prompt library writable: `{write_surface_summary['prompt_library_writable']}`\n"
        f"- Prompt library state: `{write_surface_summary['prompt_library_state']}` (enabled: `{write_surface_summary['prompt_library_enabled']}`)\n"
        f"- Confirmation required for updates/deletes: `{write_surface_summary['update_delete_confirmation_required']}`\n\n"
        f"## Starter Prompts\n{starter_lines}\n\n"
        f"## Next Steps\n{next_step_lines}"
    )


def _get_started_markdown(
    topic: str,
    *,
    first_five_minutes: list[dict[str, Any]],
    recommended_first_tools: list[dict[str, Any]],
    starter_prompts: list[str],
    next_step: str,
) -> str:
    minute_lines = "\n".join(_minute_step_markdown(item) for item in first_five_minutes)
    tool_lines = "\n".join(f"- `{item['tool']}`: {item['when_to_use']}" for item in recommended_first_tools)
    starter_lines = "\n".join(f"- {item}" for item in starter_prompts)
    return (
        f"# Prompt Compass Get Started: {topic.replace('_', ' ').title()}\n\n"
        f"## First Five Minutes\n{minute_lines}\n\n"
        f"## Recommended First Tools\n{tool_lines}\n\n"
        f"## Starter Prompts\n{starter_lines}\n\n"
        f"## Next Step\nStart with `{next_step}`."
    )


def _minute_step_markdown(item: dict[str, Any]) -> str:
    if item.get("best_tool"):
        return f"- {item['minute']}: {item['action']} (`{item['best_tool']}`)"
    branching_tools = [normalize_text(tool) for tool in item.get("branching_tools", []) if normalize_text(tool)]
    if branching_tools:
        tools = ", ".join(f"`{tool}`" for tool in branching_tools)
        note = normalize_text(item.get("branching_note"))
        suffix = f" {note}" if note else ""
        return f"- {item['minute']}: {item['action']} ({tools}){suffix}"
    return f"- {item['minute']}: {item['action']}"


def _tool_surface_markdown(grouped: list[dict[str, Any]], common_sequences: list[dict[str, Any]], write_safety_notes: list[str]) -> str:
    group_sections = []
    for group in grouped:
        tool_lines = "\n".join(f"- `{item['tool']}`: {item['when_to_use']}" for item in group["tools"])
        group_sections.append(f"## {group['label']}\n{tool_lines}")
    sequence_lines = "\n".join(f"- **{item['name']}**: {' -> '.join(item['sequence'])}" for item in common_sequences)
    safety_lines = "\n".join(f"- {item}" for item in write_safety_notes)
    return (
        "# Prompt Compass Tool Surface\n\n"
        + "\n\n".join(group_sections)
        + "\n\n## Common Sequences\n"
        + sequence_lines
        + "\n\n## Write Safety Notes\n"
        + safety_lines
    )


def _catalog_categories_markdown(payload: dict[str, Any]) -> str:
    record_lines = "\n".join(f"- `{item['name']}`: {item['count']}" for item in payload["record_types"])
    model_lines = "\n".join(f"- `{item}`" for item in payload["supported_model_targets"])
    surface_lines = "\n".join(f"- `{item}`" for item in payload["supported_prompt_surfaces"])
    return (
        "# Prompt Compass Catalog Categories\n\n"
        "## Record Types\n"
        f"{record_lines}\n\n"
        "## Supported Model Targets\n"
        f"{model_lines}\n\n"
        "## Supported Prompt Surfaces\n"
        f"{surface_lines}"
    )


def _family_markdown(title: str, results: list[dict[str, Any]]) -> str:
    if not results:
        return f"# {title}\n\nNo matching records found."
    lines = []
    for item in results:
        layer = item.get("record_layer", "core")
        lines.append(f"- `{item['name']}` ({item['record_type']}, {layer}): {item['summary']}")
    return f"# {title}\n\n" + "\n".join(lines)


def _exemplar_markdown(exemplar_kind: str, kb_items: list[dict[str, Any]], prompt_library_items: list[dict[str, Any]]) -> str:
    kb_lines = "\n".join(f"- `{item['name']}` ({item['record_type']}, {item['record_layer']}): {item['summary']}" for item in kb_items) or "- No KB items found."
    library_lines = "\n".join(f"- `{item['title']}` ({item['asset_kind']}): {short_text(item.get('prompt_text'), 120)}" for item in prompt_library_items) or "- No prompt-library items included."
    return (
        f"# Prompt {exemplar_kind.replace('_', ' ').title()}s\n\n"
        f"## KB Items\n{kb_lines}\n\n"
        f"## Prompt Library Items\n{library_lines}"
    )


def _tool_card(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "tool": item["tool"],
        "group": item["group"],
        "label": GROUP_LABELS.get(item["group"], item["group"].replace("_", " ").title()),
        "description": item["description"],
        "when_to_use": item["when_to_use"],
        "inputs_summary": item["inputs_summary"],
        "returns_summary": item["returns_summary"],
        "read_only": item["read_only"],
        "destructive": item["destructive"],
        "related_tools": item["related_tools"],
    }


def _safe_limit(limit: int | None, *, default: int = DEFAULT_LIMIT) -> int:
    return max(1, min(int(limit or default), MAX_LIMIT))


def _has_template(record: dict[str, Any]) -> bool:
    template = record.get("template")
    if isinstance(template, str):
        text = normalize_text(template)
        return len(text) >= 24 and ("[" in text or ":" in text or "\n" in template)
    if isinstance(template, dict):
        return bool(template)
    return False


def _has_examples(record: dict[str, Any]) -> bool:
    return bool(ensure_list(record.get("examples")))
