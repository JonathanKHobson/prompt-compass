from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from common import ensure_list, join_unique, normalize_text, slugify


RECORD_FOLDER_MAP = {
    "framework": Path("Custom Records/frameworks"),
    "strategy": Path("Custom Records/strategies"),
    "pattern": Path("Custom Records/patterns"),
    "technique": Path("Custom Records/techniques"),
    "term": Path("Custom Records/terms"),
    "anti_pattern": Path("Custom Records/anti_patterns"),
}

ASSET_FOLDER_MAP = {
    "prompt": Path("Prompt Library/prompts"),
    "template": Path("Prompt Library/templates"),
    "example": Path("Prompt Library/examples"),
}

CORE_REVIEW_FLAGS_DIR = Path("Core Review Flags")


def ensure_vault_layout(vault_root: Path) -> None:
    vault_root.mkdir(parents=True, exist_ok=True)
    for folder in (*RECORD_FOLDER_MAP.values(), *ASSET_FOLDER_MAP.values(), CORE_REVIEW_FLAGS_DIR):
        (vault_root / folder).mkdir(parents=True, exist_ok=True)


def record_markdown_path(vault_root: Path, record_type: str, slug: str) -> Path:
    folder = RECORD_FOLDER_MAP[record_type]
    return (vault_root / folder / f"{slugify(slug)}.md").resolve()


def asset_markdown_path(vault_root: Path, asset_kind: str, slug: str) -> Path:
    folder = ASSET_FOLDER_MAP[asset_kind]
    return (vault_root / folder / f"{slugify(slug)}.md").resolve()


def review_flag_markdown_path(vault_root: Path, flag_id: str) -> Path:
    return (vault_root / CORE_REVIEW_FLAGS_DIR / f"{slugify(flag_id)}.md").resolve()


def _yaml_scalar(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return str(value)
    return normalize_text(value)


def _dump_yaml_value(value: Any, *, indent: int = 0) -> list[str]:
    prefix = " " * indent
    if isinstance(value, dict):
        lines: list[str] = []
        for key, inner in value.items():
            if isinstance(inner, (dict, list)):
                lines.append(f"{prefix}{key}:")
                lines.extend(_dump_yaml_value(inner, indent=indent + 2))
            else:
                scalar = _yaml_scalar(inner)
                if "\n" in scalar:
                    lines.append(f"{prefix}{key}: |")
                    lines.extend(f"{' ' * (indent + 2)}{line}" for line in scalar.splitlines())
                else:
                    lines.append(f"{prefix}{key}: {scalar}")
        return lines
    if isinstance(value, list):
        lines = []
        for item in value:
            if isinstance(item, (dict, list)):
                lines.append(f"{prefix}-")
                lines.extend(_dump_yaml_value(item, indent=indent + 2))
            else:
                scalar = _yaml_scalar(item)
                if "\n" in scalar:
                    lines.append(f"{prefix}- |")
                    lines.extend(f"{' ' * (indent + 2)}{line}" for line in scalar.splitlines())
                else:
                    lines.append(f"{prefix}- {scalar}")
        return lines
    return [f"{prefix}{_yaml_scalar(value)}"]


def dump_frontmatter(data: dict[str, Any]) -> str:
    body = "\n".join(_dump_yaml_value(data))
    return f"---\n{body}\n---\n"


def line_indent(line: str) -> int:
    return len(line) - len(line.lstrip(" "))


def parse_scalar(value: str) -> Any:
    text = value.strip()
    if text == "":
        return ""
    if text.lower() in {"true", "false"}:
        return text.lower() == "true"
    if re.fullmatch(r"-?\d+", text):
        return int(text)
    if re.fullmatch(r"-?\d+\.\d+", text):
        return float(text)
    return text


def parse_mapping(lines: list[str], index: int, indent: int) -> tuple[dict[str, Any], int]:
    result: dict[str, Any] = {}
    while index < len(lines):
        line = lines[index]
        if not line.strip():
            index += 1
            continue
        current_indent = line_indent(line)
        if current_indent < indent:
            break
        if current_indent != indent:
            raise ValueError(f"Unexpected indentation in frontmatter: {line!r}")
        stripped = line.strip()
        if stripped.startswith("- "):
            break
        if ":" not in stripped:
            raise ValueError(f"Expected key/value pair in frontmatter: {line!r}")
        key, raw_value = stripped.split(":", 1)
        key = normalize_text(key)
        raw_value = raw_value.lstrip()
        index += 1
        if raw_value == "|":
            block_lines: list[str] = []
            while index < len(lines):
                next_line = lines[index]
                if not next_line.strip():
                    block_lines.append("")
                    index += 1
                    continue
                next_indent = line_indent(next_line)
                if next_indent <= current_indent:
                    break
                block_lines.append(next_line[current_indent + 2 :])
                index += 1
            result[key] = "\n".join(block_lines).rstrip("\n")
            continue
        if raw_value:
            result[key] = parse_scalar(raw_value)
            continue
        nested, index = parse_block(lines, index, indent + 2)
        result[key] = nested
    return result, index


def parse_list(lines: list[str], index: int, indent: int) -> tuple[list[Any], int]:
    result: list[Any] = []
    while index < len(lines):
        line = lines[index]
        if not line.strip():
            index += 1
            continue
        current_indent = line_indent(line)
        if current_indent < indent:
            break
        if current_indent != indent or not line.strip().startswith("-"):
            break
        stripped = line.strip()
        if stripped == "-":
            index += 1
            nested, index = parse_block(lines, index, indent + 2)
            result.append(nested)
            continue
        item_text = stripped[1:].lstrip()
        index += 1
        if item_text == "|":
            block_lines: list[str] = []
            while index < len(lines):
                next_line = lines[index]
                if not next_line.strip():
                    block_lines.append("")
                    index += 1
                    continue
                next_indent = line_indent(next_line)
                if next_indent <= current_indent:
                    break
                block_lines.append(next_line[current_indent + 2 :])
                index += 1
            result.append("\n".join(block_lines).rstrip("\n"))
            continue
        result.append(parse_scalar(item_text))
    return result, index


def parse_block(lines: list[str], index: int, indent: int) -> tuple[Any, int]:
    while index < len(lines) and not lines[index].strip():
        index += 1
    if index >= len(lines):
        return {}, index
    stripped = lines[index].strip()
    if stripped.startswith("-"):
        return parse_list(lines, index, indent)
    return parse_mapping(lines, index, indent)


def parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    if not text.startswith("---\n"):
        return {}, text
    end_marker = text.find("\n---\n", 4)
    if end_marker == -1:
        raise ValueError("Missing closing frontmatter delimiter.")
    raw_frontmatter = text[4:end_marker]
    body = text[end_marker + 5 :]
    lines = raw_frontmatter.splitlines()
    parsed, _ = parse_block(lines, 0, 0)
    if not isinstance(parsed, dict):
        raise ValueError("Frontmatter must parse into a mapping.")
    return parsed, body.lstrip("\n")


def _render_section(title: str, content: Any) -> str:
    if isinstance(content, list):
        body = "\n".join(f"- {normalize_text(item)}" for item in content if normalize_text(item))
    else:
        body = str(content).strip()
    if not body:
        return ""
    return f"## {title}\n\n{body}\n"


def render_personal_record_markdown(record: dict[str, Any]) -> str:
    frontmatter = {
        "id": record["id"],
        "title": record["title"],
        "record_type": record["record_type"],
        "aliases": join_unique(ensure_list(record.get("aliases"))),
        "tags": join_unique(ensure_list(record.get("tags"))),
        "prompt_types": join_unique(ensure_list(record.get("prompt_types"))),
        "subject_areas": join_unique(ensure_list(record.get("subject_areas"))),
        "model_targets": join_unique(ensure_list(record.get("model_targets"))),
        "driver_eligible": bool(record.get("driver_eligible")),
        "capability_tags": join_unique(ensure_list(record.get("capability_tags"))),
        "related_entry_ids": join_unique(ensure_list(record.get("related_entry_ids"))),
        "signals": join_unique(ensure_list(record.get("signals"))),
        "created_at": normalize_text(record.get("created_at")),
        "updated_at": normalize_text(record.get("updated_at")),
    }
    parts = [
        dump_frontmatter(frontmatter),
        _render_section("Description", normalize_text(record.get("description"))),
        _render_section("Template", record.get("template") or ""),
        _render_section("Examples", ensure_list(record.get("examples"))),
        _render_section("Notes", normalize_text(record.get("notes"))),
    ]
    return "\n".join(part.rstrip() for part in parts if part).strip() + "\n"


def render_prompt_library_markdown(item: dict[str, Any]) -> str:
    frontmatter = {
        "id": item["id"],
        "title": item["title"],
        "asset_kind": item["asset_kind"],
        "tags": join_unique(ensure_list(item.get("tags"))),
        "model_target": normalize_text(item.get("model_target")),
        "target_surface": normalize_text(item.get("target_surface")),
        "linked_record_ids": join_unique(ensure_list(item.get("linked_record_ids"))),
        "favorite": bool(item.get("favorite")),
        "prompt_contract": item.get("prompt_contract") or {},
        "rationale_table": item.get("rationale_table") or [],
        "created_at": normalize_text(item.get("created_at")),
        "updated_at": normalize_text(item.get("updated_at")),
    }
    parts = [
        dump_frontmatter(frontmatter),
        _render_section("Prompt Text", item.get("prompt_text") or ""),
        _render_section("Notes", normalize_text(item.get("notes"))),
        _render_section("Success Notes", normalize_text(item.get("success_notes"))),
    ]
    return "\n".join(part.rstrip() for part in parts if part).strip() + "\n"


def render_review_flag_markdown(flag: dict[str, Any]) -> str:
    frontmatter = {
        "id": flag["id"],
        "target_entry_id": flag["target_entry_id"],
        "reason": flag["reason"],
        "suggested_action": flag["suggested_action"],
        "status": flag["status"],
        "created_at": normalize_text(flag.get("created_at")),
        "updated_at": normalize_text(flag.get("updated_at")),
    }
    parts = [
        dump_frontmatter(frontmatter),
        _render_section("Notes", normalize_text(flag.get("notes"))),
    ]
    return "\n".join(part.rstrip() for part in parts if part).strip() + "\n"


def _section_map(body: str) -> dict[str, str]:
    pattern = re.compile(r"^##\s+(.+?)\n(.*?)(?=^##\s+|\Z)", re.MULTILINE | re.DOTALL)
    sections: dict[str, str] = {}
    for match in pattern.finditer(body):
        title = normalize_text(match.group(1)).lower()
        sections[title] = match.group(2).strip()
    return sections


def _parse_bullet_list(value: str) -> list[str]:
    results: list[str] = []
    for line in value.splitlines():
        stripped = line.strip()
        if stripped.startswith("- "):
            results.append(normalize_text(stripped[2:]))
        elif stripped:
            results.append(normalize_text(stripped))
    return join_unique(results)


def parse_personal_record_markdown(path: Path) -> dict[str, Any]:
    frontmatter, body = parse_frontmatter(path.read_text(encoding="utf-8"))
    sections = _section_map(body)
    record_type = normalize_text(frontmatter.get("record_type"))
    return {
        "id": normalize_text(frontmatter.get("id")) or slugify(frontmatter.get("title") or path.stem),
        "title": normalize_text(frontmatter.get("title")) or normalize_text(path.stem.replace("-", " ")),
        "record_type": record_type,
        "description": normalize_text(sections.get("description")),
        "template": sections.get("template", "").strip(),
        "examples": _parse_bullet_list(sections.get("examples", "")),
        "notes": sections.get("notes", "").strip(),
        "aliases": join_unique(ensure_list(frontmatter.get("aliases"))),
        "tags": join_unique(ensure_list(frontmatter.get("tags"))),
        "prompt_types": join_unique(ensure_list(frontmatter.get("prompt_types"))),
        "subject_areas": join_unique(ensure_list(frontmatter.get("subject_areas"))),
        "model_targets": join_unique(ensure_list(frontmatter.get("model_targets"))),
        "driver_eligible": bool(frontmatter.get("driver_eligible")),
        "capability_tags": join_unique(ensure_list(frontmatter.get("capability_tags"))),
        "related_entry_ids": join_unique(ensure_list(frontmatter.get("related_entry_ids"))),
        "signals": join_unique(ensure_list(frontmatter.get("signals"))),
        "created_at": normalize_text(frontmatter.get("created_at")),
        "updated_at": normalize_text(frontmatter.get("updated_at")),
        "markdown_path": str(path.resolve()),
    }


def parse_prompt_library_markdown(path: Path) -> dict[str, Any]:
    frontmatter, body = parse_frontmatter(path.read_text(encoding="utf-8"))
    sections = _section_map(body)
    asset_kind = normalize_text(frontmatter.get("asset_kind")) or infer_asset_kind_from_path(path)
    return {
        "id": normalize_text(frontmatter.get("id")) or slugify(frontmatter.get("title") or path.stem),
        "title": normalize_text(frontmatter.get("title")) or normalize_text(path.stem.replace("-", " ")),
        "asset_kind": asset_kind,
        "prompt_text": sections.get("prompt text", "").strip(),
        "tags": join_unique(ensure_list(frontmatter.get("tags"))),
        "model_target": normalize_text(frontmatter.get("model_target")),
        "target_surface": normalize_text(frontmatter.get("target_surface")),
        "prompt_contract": frontmatter.get("prompt_contract") or {},
        "rationale_table": ensure_list(frontmatter.get("rationale_table")),
        "linked_record_ids": join_unique(ensure_list(frontmatter.get("linked_record_ids"))),
        "notes": sections.get("notes", "").strip(),
        "success_notes": sections.get("success notes", "").strip(),
        "favorite": bool(frontmatter.get("favorite")),
        "created_at": normalize_text(frontmatter.get("created_at")),
        "updated_at": normalize_text(frontmatter.get("updated_at")),
        "markdown_path": str(path.resolve()),
    }


def parse_review_flag_markdown(path: Path) -> dict[str, Any]:
    frontmatter, body = parse_frontmatter(path.read_text(encoding="utf-8"))
    sections = _section_map(body)
    return {
        "id": normalize_text(frontmatter.get("id")) or slugify(path.stem),
        "target_entry_id": normalize_text(frontmatter.get("target_entry_id")),
        "reason": normalize_text(frontmatter.get("reason")),
        "suggested_action": normalize_text(frontmatter.get("suggested_action")),
        "status": normalize_text(frontmatter.get("status")) or "open",
        "notes": sections.get("notes", "").strip(),
        "created_at": normalize_text(frontmatter.get("created_at")),
        "updated_at": normalize_text(frontmatter.get("updated_at")),
        "markdown_path": str(path.resolve()),
    }


def infer_asset_kind_from_path(path: Path) -> str:
    lower_parts = [part.lower() for part in path.parts]
    for kind in ASSET_FOLDER_MAP:
        if f"{kind}s" in lower_parts:
            return kind
    return "prompt"

