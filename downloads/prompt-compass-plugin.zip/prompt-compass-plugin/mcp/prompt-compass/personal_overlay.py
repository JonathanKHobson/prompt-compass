from __future__ import annotations

import re
import sqlite3
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from common import (
    build_fts_query,
    ensure_list,
    from_json,
    join_unique,
    normalize_lookup_key,
    normalize_text,
    short_text,
    slugify,
    text_blob,
    to_json,
)
from personal_markdown import (
    CORE_REVIEW_FLAGS_DIR,
    RECORD_FOLDER_MAP,
    ASSET_FOLDER_MAP,
    asset_markdown_path,
    ensure_vault_layout,
    parse_personal_record_markdown,
    parse_prompt_library_markdown,
    parse_review_flag_markdown,
    record_markdown_path,
    render_personal_record_markdown,
    render_prompt_library_markdown,
    render_review_flag_markdown,
    review_flag_markdown_path,
)


def _default_user_data_dir() -> Path:
    """Return a per-user data directory that is safe for packaged installs."""

    override = os.getenv("PROMPT_COMPASS_USER_DATA_DIR")
    if override:
        return Path(override).expanduser()
    if sys.platform == "win32":
        base = Path(os.getenv("APPDATA", str(Path.home() / "AppData" / "Roaming")))
        return base / "PromptCompass"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "Prompt Compass"
    return Path(os.getenv("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))) / "prompt-compass"


DEFAULT_PERSONAL_DATA_DIR = _default_user_data_dir()
DEFAULT_PERSONAL_DB_PATH = DEFAULT_PERSONAL_DATA_DIR / "prompt-compass-personal.sqlite"
DEFAULT_PERSONAL_VAULT_ROOT = DEFAULT_PERSONAL_DATA_DIR / "personal-vault"

PERSONAL_RECORD_TYPES = {"framework", "strategy", "pattern", "technique", "term", "anti_pattern"}
PROMPT_LIBRARY_ASSET_KINDS = {"prompt", "template", "example"}
DRIVER_ELIGIBLE_RECORD_TYPES = {"framework", "strategy", "pattern", "technique"}
REVIEW_FLAG_STATUSES = {"open", "reviewed", "dismissed"}
PREFERENCES_NAMESPACE = "prompt_compass"
PREFERENCES_SCHEMA_VERSION = 1
SUMMARY_VISIBILITY_VALUES = {"brief", "silent"}
CLARIFYING_QUESTION_VALUES = {"allow_when_uncertain", "never"}
HITL_LEVEL_VALUES = {"none", "soft_gate", "always"}

DEFAULT_TOOL_FIT = {
    "framework": {"analyze": 3, "improve": 4, "build": 4, "target": 1, "search": 4},
    "strategy": {"analyze": 3, "improve": 4, "build": 4, "target": 1, "search": 4},
    "pattern": {"analyze": 4, "improve": 4, "build": 2, "target": 0, "search": 4},
    "technique": {"analyze": 1, "improve": 4, "build": 2, "target": 1, "search": 4},
    "term": {"analyze": 0, "improve": 1, "build": 0, "target": 0, "search": 5},
    "anti_pattern": {"analyze": 5, "improve": 2, "build": 0, "target": 0, "search": 4},
}


def default_preferences_payload() -> dict[str, Any]:
    return {
        "schema_version": PREFERENCES_SCHEMA_VERSION,
        "onboarding_completed": False,
        "additional_preferences_acknowledged": False,
        "additional_preferences_choice": "",
        "autoflow": {
            "enabled_by_default": False,
            "summary_visibility": "brief",
            "clarifying_questions": "allow_when_uncertain",
            "hitl_level": "soft_gate",
        },
    }


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _record_from_row(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    record = {
        "entry_id": row["entry_id"],
        "record_type": row["record_type"],
        "name": row["name"],
        "slug": row["slug"],
        "summary": row["summary"],
        "definition": row["definition"],
        "prompt_types": from_json(row["prompt_types_json"], []),
        "subject_areas": from_json(row["subject_areas_json"], []),
        "model_targets": from_json(row["model_targets_json"], []),
        "signals": from_json(row["signals_json"], []),
        "contraindications": from_json(row["contraindications_json"], []),
        "template": from_json(row["template_json"], None),
        "examples": from_json(row["examples_json"], []),
        "fixes": from_json(row["fixes_json"], []),
        "related_entry_ids": from_json(row["related_entry_ids_json"], []),
        "tags": from_json(row["tags_json"], []),
        "source_refs": from_json(row["source_refs_json"], []),
        "quality_flags": from_json(row["quality_flags_json"], []),
        "source_priority": row["source_priority"],
    }
    extra = from_json(row["extra_json"], {})
    if isinstance(extra, dict):
        record.update(extra)
    return record


def _item_from_row(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    return {
        "item_id": row["item_id"],
        "id": row["slug"],
        "title": row["title"],
        "asset_kind": row["asset_kind"],
        "prompt_text": row["prompt_text"],
        "tags": from_json(row["tags_json"], []),
        "model_target": row["model_target"],
        "target_surface": row["target_surface"],
        "prompt_contract": from_json(row["prompt_contract_json"], {}),
        "rationale_table": from_json(row["rationale_table_json"], []),
        "linked_record_ids": from_json(row["linked_record_ids_json"], []),
        "notes": row["notes"],
        "success_notes": row["success_notes"],
        "favorite": bool(row["favorite"]),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
        "markdown_path": row["markdown_path"],
        "record_layer": "personal",
        "mutable": True,
    }


def _flag_from_row(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    return {
        "id": row["flag_id"],
        "flag_id": row["flag_id"],
        "target_entry_id": row["target_entry_id"],
        "reason": row["reason"],
        "suggested_action": row["suggested_action"],
        "notes": row["notes"],
        "status": row["status"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
        "markdown_path": row["markdown_path"],
        "record_layer": "personal",
        "mutable": True,
    }


class PersonalOverlayStore:
    def __init__(self, db_path: str | Path | None = None, vault_root: str | Path | None = None) -> None:
        self.db_path = Path(db_path or DEFAULT_PERSONAL_DB_PATH).expanduser().resolve()
        self.vault_root = Path(vault_root or DEFAULT_PERSONAL_VAULT_ROOT).expanduser().resolve()
        self._connection: sqlite3.Connection | None = None

    def close(self) -> None:
        if self._connection is not None:
            self._connection.close()
            self._connection = None

    def exists(self) -> bool:
        return self.db_path.exists()

    def ensure_initialized(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        ensure_vault_layout(self.vault_root)
        connection = self._open(create_if_missing=True)
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS records (
                entry_id TEXT PRIMARY KEY,
                record_type TEXT NOT NULL,
                name TEXT NOT NULL,
                slug TEXT NOT NULL UNIQUE,
                summary TEXT,
                definition TEXT,
                prompt_types_json TEXT NOT NULL,
                subject_areas_json TEXT NOT NULL,
                model_targets_json TEXT NOT NULL,
                signals_json TEXT NOT NULL,
                contraindications_json TEXT NOT NULL,
                template_json TEXT NOT NULL,
                examples_json TEXT NOT NULL,
                fixes_json TEXT NOT NULL,
                related_entry_ids_json TEXT NOT NULL,
                tags_json TEXT NOT NULL,
                source_refs_json TEXT NOT NULL,
                quality_flags_json TEXT NOT NULL,
                source_priority INTEGER NOT NULL,
                extra_json TEXT NOT NULL,
                search_text TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_records_record_type ON records(record_type);
            CREATE INDEX IF NOT EXISTS idx_records_name ON records(name);
            CREATE TABLE IF NOT EXISTS aliases (
                alias_norm TEXT NOT NULL,
                entry_id TEXT NOT NULL,
                PRIMARY KEY(alias_norm, entry_id)
            );
            CREATE VIRTUAL TABLE IF NOT EXISTS records_fts USING fts5(entry_id UNINDEXED, search_text);
            CREATE TABLE IF NOT EXISTS prompt_library_items (
                item_id TEXT PRIMARY KEY,
                slug TEXT NOT NULL UNIQUE,
                title TEXT NOT NULL,
                asset_kind TEXT NOT NULL,
                prompt_text TEXT NOT NULL,
                tags_json TEXT NOT NULL,
                model_target TEXT NOT NULL,
                target_surface TEXT NOT NULL,
                prompt_contract_json TEXT NOT NULL,
                rationale_table_json TEXT NOT NULL,
                linked_record_ids_json TEXT NOT NULL,
                notes TEXT NOT NULL,
                success_notes TEXT NOT NULL,
                favorite INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                markdown_path TEXT NOT NULL,
                search_text TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_prompt_library_slug ON prompt_library_items(slug);
            CREATE INDEX IF NOT EXISTS idx_prompt_library_asset_kind ON prompt_library_items(asset_kind);
            CREATE VIRTUAL TABLE IF NOT EXISTS prompt_library_fts USING fts5(item_id UNINDEXED, search_text);
            CREATE TABLE IF NOT EXISTS core_review_flags (
                flag_id TEXT PRIMARY KEY,
                target_entry_id TEXT NOT NULL,
                reason TEXT NOT NULL,
                suggested_action TEXT NOT NULL,
                notes TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                markdown_path TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS pending_confirmations (
                token TEXT PRIMARY KEY,
                action_kind TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS preferences (
                namespace TEXT PRIMARY KEY,
                schema_version INTEGER NOT NULL,
                preferences_json TEXT NOT NULL,
                onboarding_completed INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            """
        )
        connection.commit()

    def list_records(self, record_type: str | None = None) -> list[dict[str, Any]]:
        connection = self._open()
        if connection is None:
            return []
        if record_type:
            rows = connection.execute(
                "SELECT * FROM records WHERE record_type = ? ORDER BY source_priority DESC, name COLLATE NOCASE",
                (record_type,),
            ).fetchall()
        else:
            rows = connection.execute(
                "SELECT * FROM records ORDER BY source_priority DESC, name COLLATE NOCASE"
            ).fetchall()
        return [record for row in rows if (record := _record_from_row(row))]

    def get_record(self, entry_id: str) -> dict[str, Any] | None:
        connection = self._open()
        if connection is None:
            return None
        row = connection.execute("SELECT * FROM records WHERE entry_id = ?", (entry_id,)).fetchone()
        return _record_from_row(row)

    def resolve_record(self, value: str, record_types: list[str] | None = None) -> dict[str, Any]:
        connection = self._open()
        if connection is None:
            return {"found": False, "query": value, "nearest_matches": []}
        if value.startswith("pp:"):
            record = self.get_record(value)
            if record and self._record_type_allowed(record, record_types):
                return {"found": True, **record}
        lookup = normalize_lookup_key(value)
        if not lookup:
            return {"found": False, "query": value, "nearest_matches": []}
        row = connection.execute(
            """
            SELECT r.*
            FROM aliases a
            JOIN records r ON r.entry_id = a.entry_id
            WHERE a.alias_norm = ?
            ORDER BY r.source_priority DESC
            LIMIT 1
            """,
            (lookup,),
        ).fetchone()
        record = _record_from_row(row)
        if record and self._record_type_allowed(record, record_types):
            return {"found": True, **record}
        return {
            "found": False,
            "query": value,
            "nearest_matches": self.nearest_record_matches(value, record_types=record_types),
        }

    def nearest_record_matches(self, value: str, record_types: list[str] | None = None, limit: int = 5) -> list[dict[str, Any]]:
        lookup = normalize_lookup_key(value)
        candidates = self.list_records()
        scored: list[tuple[float, dict[str, Any]]] = []
        for record in candidates:
            if not self._record_type_allowed(record, record_types):
                continue
            haystack = " ".join(
                [
                    normalize_text(record.get("name")),
                    normalize_text(record.get("slug")),
                    " ".join(normalize_text(alias) for alias in record.get("aliases", [])),
                ]
            ).lower()
            hay_norm = normalize_lookup_key(haystack)
            score = 0.0
            if lookup and lookup in hay_norm:
                score += 10
            if normalize_lookup_key(record.get("name")) == lookup:
                score += 25
            if normalize_lookup_key(record.get("slug")) == lookup:
                score += 20
            if score > 0:
                scored.append((score, record))
        scored.sort(key=lambda item: (-item[0], item[1]["name"].lower()))
        return [
            {
                "entry_id": record["entry_id"],
                "record_type": record["record_type"],
                "name": record["name"],
                "summary": record.get("summary"),
                "record_layer": record.get("record_layer", "personal"),
            }
            for _, record in scored[:limit]
        ]

    def get_preferences(self, namespace: str = PREFERENCES_NAMESPACE) -> dict[str, Any]:
        namespace_value = normalize_text(namespace) or PREFERENCES_NAMESPACE
        defaults = default_preferences_payload()
        if self._open() is None:
            return self._preferences_response(
                namespace_value,
                defaults,
                configured=False,
                preference_state="missing_blank_overlay",
            )
        self.ensure_initialized()
        connection = self._open()
        assert connection is not None
        row = connection.execute(
            "SELECT * FROM preferences WHERE namespace = ?",
            (namespace_value,),
        ).fetchone()
        if row is None:
            content_counts = self._personal_content_counts(connection)
            preference_state = "missing_existing_overlay" if any(content_counts.values()) else "missing_blank_overlay"
            return self._preferences_response(
                namespace_value,
                defaults,
                configured=False,
                preference_state=preference_state,
                content_counts=content_counts,
            )
        stored = from_json(row["preferences_json"], {})
        preferences = self._normalize_preferences(stored, default_onboarding=bool(row["onboarding_completed"]))
        return self._preferences_response(
            namespace_value,
            preferences,
            configured=True,
            preference_state="configured",
            content_counts=self._personal_content_counts(connection),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def manage_preferences(
        self,
        preferences: dict[str, Any] | None = None,
        *,
        reset: bool = False,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict[str, Any]:
        if confirm:
            pending = self._consume_confirmation_token(confirmation_token, expected_action="manage_preferences")
            if pending.get("reset"):
                namespace = normalize_text(pending.get("namespace")) or PREFERENCES_NAMESPACE
                self._delete_preferences(namespace)
                current = self.get_preferences(namespace)
                current.update(
                    {
                        "status": "preferences_reset",
                        "saved": True,
                        "reset": True,
                        "user_message": "Auto Flow preferences were reset to defaults.",
                    }
                )
                return current
            namespace = normalize_text(pending.get("namespace")) or PREFERENCES_NAMESPACE
            saved = self._upsert_preferences(namespace, pending["preferences"])
            saved.update(
                {
                    "status": "preferences_saved",
                    "saved": True,
                    "user_message": "Auto Flow preferences were saved.",
                }
            )
            return saved

        if preferences is None and not reset:
            current = self.get_preferences()
            current.update(
                {
                    "status": "preferences_ready",
                    "saved": False,
                    "confirmation_required": False,
                    "setup_questions": self._preference_setup_questions(),
                }
            )
            return current

        current = self.get_preferences()
        if reset:
            proposed = default_preferences_payload()
            token = self._store_confirmation(
                "manage_preferences",
                {"namespace": PREFERENCES_NAMESPACE, "reset": True},
            )
            return {
                "status": "preferences_reset_preview",
                "saved": False,
                "reset": True,
                "confirmation_required": True,
                "confirmation_token": token,
                "namespace": PREFERENCES_NAMESPACE,
                "schema_version": PREFERENCES_SCHEMA_VERSION,
                "current_preferences": current["preferences"],
                "proposed_preferences": proposed,
                "diff_preview": self._preference_diff(current["preferences"], proposed),
                "record_layer": "personal",
                "mutable": True,
                "additional_preferences_available": True,
                "additional_preferences_gate": self._additional_preferences_gate(),
                "setup_questions": self._preference_setup_questions(),
            }

        proposed = self._normalize_preferences(preferences or {}, base=current["preferences"], default_onboarding=False)
        token = self._store_confirmation(
            "manage_preferences",
            {"namespace": PREFERENCES_NAMESPACE, "preferences": proposed},
        )
        return {
            "status": "preferences_update_preview",
            "saved": False,
            "confirmation_required": True,
            "confirmation_token": token,
            "namespace": PREFERENCES_NAMESPACE,
            "schema_version": PREFERENCES_SCHEMA_VERSION,
            "current_preferences": current["preferences"],
            "proposed_preferences": proposed,
            "diff_preview": self._preference_diff(current["preferences"], proposed),
            "record_layer": "personal",
            "mutable": True,
            "additional_preferences_available": True,
            "additional_preferences_gate": self._additional_preferences_gate(),
            "setup_questions": self._preference_setup_questions(),
            "plain_language_summary": "Review these Auto Flow preference changes, then confirm to save them.",
        }

    def save_personal_record(
        self,
        payload: dict[str, Any],
        *,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict[str, Any]:
        normalized = self._normalize_personal_record(payload)
        existing = self.resolve_record(normalized["id"])
        if existing.get("found") and normalize_text(existing.get("record_type")) != normalized["record_type"]:
            raise ValueError(
                f"Personal record id `{normalized['id']}` already exists as `{existing.get('record_type')}`. "
                "Delete it first or choose a different id."
            )
        if not existing.get("found"):
            record = self._upsert_record(normalized)
            return {
                "saved": True,
                "created": True,
                "record": record,
                "record_layer": "personal",
                "mutable": True,
            }
        if confirm:
            pending = self._consume_confirmation_token(confirmation_token, expected_action="update_personal_record")
            record = self._upsert_record(pending["record"])
            return {
                "saved": True,
                "created": False,
                "record": record,
                "record_layer": "personal",
                "mutable": True,
            }
        token = self._store_confirmation(
            "update_personal_record",
            {"record": normalized},
        )
        return {
            "saved": False,
            "confirmation_required": True,
            "confirmation_token": token,
            "diff_preview": self._record_diff(existing, normalized),
            "existing_record": self._compact_record(existing),
            "proposed_record": self._compact_record(normalized),
        }

    def seed_personal_overlay(
        self,
        seed_answers: dict[str, Any] | None = None,
        *,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict[str, Any]:
        if confirm:
            pending = self._consume_confirmation_token(confirmation_token, expected_action="seed_personal_overlay")
            saved: list[dict[str, Any]] = []
            skipped: list[dict[str, Any]] = []
            for record in pending.get("records", []):
                existing = self.resolve_record(record.get("id", ""))
                if existing.get("found"):
                    skipped.append(
                        {
                            "id": record.get("id"),
                            "reason": "A personal record with this id already exists.",
                            "existing_entry_id": existing.get("entry_id"),
                        }
                    )
                    continue
                saved.append(self._upsert_record(record))
            return {
                "seeded": True,
                "saved_count": len(saved),
                "skipped_count": len(skipped),
                "records": saved,
                "skipped": skipped,
                "record_layer": "personal",
            }
        if not seed_answers:
            return {
                "seeded": False,
                "confirmation_required": False,
                "workflow_stage": "seed_questions",
                "host_action": {
                    "must_pause": True,
                    "prompt_style": "Ask these onboarding questions in native chat UI, then call seed_personal_overlay again with seed_answers.",
                },
                "questions_for_user": [
                    {
                        "id": "prompt_domains",
                        "slot": "domains",
                        "question": "What domains or recurring prompt jobs should Prompt Compass personalize first?",
                        "answer_type": "list",
                        "why_i_am_asking": "Domains shape the first personal strategy and examples.",
                        "what_this_can_change": "Creates domain-specific output-contract and success-test guidance.",
                        "on_skip": "Use general prompt-workflow defaults.",
                    },
                    {
                        "id": "target_models",
                        "slot": "model_targets",
                        "question": "Which models or AI products do you most often write prompts for?",
                        "answer_type": "list",
                        "why_i_am_asking": "Model targets shape personal targeting notes.",
                        "what_this_can_change": "Creates lightweight model-specific reminder records in the personal layer.",
                        "on_skip": "Use generic model targets.",
                    },
                    {
                        "id": "personal_methods",
                        "slot": "custom_concepts",
                        "question": "What named methods, phrases, or prompt rules do you already use that should become searchable?",
                        "answer_type": "list",
                        "why_i_am_asking": "This is how Prompt Compass learns personal prompting vocabulary without changing the core KB.",
                        "what_this_can_change": "Creates personal term records for the user's own methods.",
                        "on_skip": "No custom method records are created.",
                    },
                ],
                "resume_payload_template": {
                    "tool": "seed_personal_overlay",
                    "seed_answers": {
                        "domains": ["example domain"],
                        "model_targets": ["example model"],
                        "preferred_prompt_styles": ["example style"],
                        "custom_concepts": ["example method"],
                        "profile_bootstrap": {
                            "profile_name": "Personal Prompting Profile",
                            "working_style": "Context rich before concise.",
                            "default_posture": "Collaborative but directive.",
                            "output_priorities": ["clarity", "visible structure", "actionable depth"],
                            "failure_modes": ["scope sprawl", "stacked adjectives"],
                            "editing_rules": ["Keep the real job in the first two lines."],
                            "anti_profile": ["generic helpfulness", "compliance without judgment"],
                            "prompt_defaults": ["Add an explicit output contract."],
                        },
                    },
                },
            }
        proposed = [self._normalize_personal_record(record) for record in self._seed_records_from_answers(seed_answers)]
        token = self._store_confirmation("seed_personal_overlay", {"records": proposed})
        return {
            "seeded": False,
            "confirmation_required": True,
            "confirmation_token": token,
            "record_layer": "personal",
            "proposed_record_count": len(proposed),
            "proposed_records": [self._compact_record(record) for record in proposed],
            "diff_preview": {
                "action": "create_personal_overlay_seed_records",
                "records": [{"id": record["id"], "title": record["title"], "record_type": record["record_type"]} for record in proposed],
            },
        }

    def _seed_records_from_answers(self, seed_answers: dict[str, Any]) -> list[dict[str, Any]]:
        domains = [normalize_text(item) for item in ensure_list(seed_answers.get("domains")) if normalize_text(item)]
        model_targets = [normalize_text(item) for item in ensure_list(seed_answers.get("model_targets")) if normalize_text(item)]
        styles = [normalize_text(item) for item in ensure_list(seed_answers.get("preferred_prompt_styles")) if normalize_text(item)]
        custom_concepts = [normalize_text(item) for item in ensure_list(seed_answers.get("custom_concepts")) if normalize_text(item)]
        profile_bootstrap = seed_answers.get("profile_bootstrap") if isinstance(seed_answers.get("profile_bootstrap"), dict) else None
        records: list[dict[str, Any]] = []
        if profile_bootstrap:
            records.extend(self._seed_profile_bootstrap_records(profile_bootstrap, model_targets or ["generic"]))
        for domain in (domains or ["general prompt work"])[:3]:
            slug = slugify(domain)
            records.append(
                {
                    "id": f"personal-{slug}-output-contract",
                    "title": f"Personal {domain.title()} Output Contract",
                    "record_type": "strategy",
                    "description": f"Personal strategy for {domain}: name the deliverable, audience, format, length, and success test before asking for a rewrite or build. Use this when Prompt Compass is helping with recurring {domain} prompts.",
                    "aliases": [f"{domain} output contract", f"{domain} prompt standard"],
                    "tags": ["personal-seed", "output-contract", slug],
                    "prompt_types": ["reductive", "transformative", "generative"],
                    "subject_areas": [slug or "general"],
                    "model_targets": model_targets or ["generic"],
                    "driver_eligible": True,
                    "template": "Objective: [job]\nAudience: [reader]\nOutput: [format and length]\nSuccess test: [what makes this usable]\nConstraints: [must-haves and exclusions]",
                    "signals": [domain, "recurring prompt job", "personal standard"],
                    "capability_tags": ["structured_output"],
                }
            )
        for style in styles[:2]:
            slug = slugify(style)
            records.append(
                {
                    "id": f"personal-{slug}-style-guardrail",
                    "title": f"Personal {style.title()} Style Guardrail",
                    "record_type": "pattern",
                    "description": f"Personal pattern for keeping outputs aligned with the user's preferred {style} style without relying on vague adjective stacks. Rank the top traits, define what they mean, and state what to avoid.",
                    "aliases": [f"{style} style guardrail"],
                    "tags": ["personal-seed", "style", slug],
                    "prompt_types": ["transformative", "generative"],
                    "subject_areas": ["general"],
                    "model_targets": model_targets or ["generic"],
                    "driver_eligible": True,
                    "template": "Style priority:\n1. [top trait and meaning]\n2. [second trait and meaning]\n3. [third trait and meaning]\nAvoid: [style drift or overreach]",
                    "signals": [style, "style preference", "trait ranking"],
                }
            )
        for model in model_targets[:2]:
            slug = slugify(model)
            records.append(
                {
                    "id": f"personal-{slug}-targeting-note",
                    "title": f"Personal {model} Targeting Note",
                    "record_type": "technique",
                    "description": f"Personal targeting reminder for prompts intended for {model}. Keep model-specific preferences visible, but do not let them override the task, audience, output contract, or safety boundary.",
                    "aliases": [f"{model} prompt notes"],
                    "tags": ["personal-seed", "model-targeting", slug],
                    "prompt_types": ["reductive", "transformative", "generative"],
                    "subject_areas": ["general"],
                    "model_targets": [model],
                    "driver_eligible": True,
                    "template": f"Target model: {model}\nPrompt adaptation notes:\n- [preferred structure]\n- [format expectations]\n- [avoid-list]",
                    "signals": [model, "model target", "prompt adaptation"],
                }
            )
        for concept in custom_concepts[:5]:
            slug = slugify(concept)
            records.append(
                {
                    "id": f"personal-{slug}",
                    "title": concept.title(),
                    "record_type": "term",
                    "description": f"Personal Prompt Compass concept supplied during onboarding: {concept}. Refine this definition in the Markdown vault as the method becomes clearer.",
                    "aliases": [concept],
                    "tags": ["personal-seed", "personal-method", slug],
                    "prompt_types": ["reductive", "transformative", "generative"],
                    "subject_areas": ["general"],
                    "model_targets": model_targets or ["generic"],
                    "driver_eligible": False,
                    "signals": [concept],
                }
            )
        return records[:16]

    def _seed_profile_bootstrap_records(self, bootstrap: dict[str, Any], model_targets: list[str]) -> list[dict[str, Any]]:
        profile_name = normalize_text(bootstrap.get("profile_name")) or "Personal Prompting Profile"
        profile_slug = slugify(profile_name)
        profile_prefix = re.sub(r"\bprompting profile\b", "", profile_name, flags=re.IGNORECASE).strip() or profile_name
        working_style = normalize_text(bootstrap.get("working_style"))
        default_posture = normalize_text(bootstrap.get("default_posture"))
        output_priorities = [normalize_text(item) for item in ensure_list(bootstrap.get("output_priorities")) if normalize_text(item)]
        failure_modes = [normalize_text(item) for item in ensure_list(bootstrap.get("failure_modes")) if normalize_text(item)]
        editing_rules = [normalize_text(item) for item in ensure_list(bootstrap.get("editing_rules")) if normalize_text(item)]
        anti_profile = [normalize_text(item) for item in ensure_list(bootstrap.get("anti_profile")) if normalize_text(item)]
        prompt_defaults = [normalize_text(item) for item in ensure_list(bootstrap.get("prompt_defaults")) if normalize_text(item)]
        voice_memo_defaults = [normalize_text(item) for item in ensure_list(bootstrap.get("voice_memo_cleanup_defaults")) if normalize_text(item)]

        shared_tags = ["personal-seed", "profile-bootstrap", profile_slug]
        profile_description_parts = [part for part in [working_style, default_posture] if part]
        profile_description = (
            " ".join(profile_description_parts)
            or f"{profile_name} captures the user's default prompting posture, output preferences, and editing behavior."
        )
        records: list[dict[str, Any]] = [
            {
                "id": profile_slug,
                "title": profile_name,
                "record_type": "term",
                "description": profile_description,
                "aliases": [profile_name.lower(), f"{profile_prefix.lower()} profile"],
                "tags": shared_tags + ["personal-profile"],
                "prompt_types": ["reductive", "transformative", "generative"],
                "subject_areas": ["general"],
                "model_targets": model_targets,
                "driver_eligible": False,
                "signals": output_priorities[:3] + failure_modes[:2],
            },
            {
                "id": f"{profile_slug}-working-style",
                "title": f"{profile_prefix} Working Style",
                "record_type": "term",
                "description": working_style or f"Working-style notes for {profile_prefix}.",
                "aliases": [f"{profile_prefix.lower()} working style"],
                "tags": shared_tags + ["working-style"],
                "prompt_types": ["reductive", "transformative", "generative"],
                "subject_areas": ["general"],
                "model_targets": model_targets,
                "driver_eligible": False,
                "signals": [working_style] if working_style else [],
            },
            {
                "id": f"{profile_slug}-anti-profile",
                "title": f"{profile_prefix} Anti-Profile",
                "record_type": "term",
                "description": (
                    "Do not optimize toward: " + "; ".join(anti_profile)
                    if anti_profile
                    else f"Things {profile_prefix} does not want the model to optimize toward."
                ),
                "aliases": [f"{profile_prefix.lower()} anti profile", f"{profile_prefix.lower()} anti-profile"],
                "tags": shared_tags + ["anti-profile"],
                "prompt_types": ["reductive", "transformative", "generative"],
                "subject_areas": ["general"],
                "model_targets": model_targets,
                "driver_eligible": False,
                "signals": anti_profile[:4],
            },
            {
                "id": f"{profile_slug}-failure-modes",
                "title": f"{profile_prefix} Failure Modes",
                "record_type": "term",
                "description": (
                    "Known failure modes: " + "; ".join(failure_modes)
                    if failure_modes
                    else f"Known failure modes and drift patterns for {profile_prefix}."
                ),
                "aliases": [f"{profile_prefix.lower()} failure modes"],
                "tags": shared_tags + ["failure-modes"],
                "prompt_types": ["reductive", "transformative", "generative"],
                "subject_areas": ["general"],
                "model_targets": model_targets,
                "driver_eligible": False,
                "signals": failure_modes[:5],
            },
            {
                "id": f"{profile_slug}-editing-rules",
                "title": f"{profile_prefix} Editing Rules",
                "record_type": "strategy",
                "description": (
                    "Apply these editing rules when tightening prompts: " + "; ".join(editing_rules)
                    if editing_rules
                    else f"Operational editing rules for tightening prompts in a way that fits {profile_prefix}."
                ),
                "aliases": [f"{profile_prefix.lower()} editing rules"],
                "tags": shared_tags + ["editing-rules"],
                "prompt_types": ["transformative", "generative"],
                "subject_areas": ["general"],
                "model_targets": model_targets,
                "driver_eligible": True,
                "signals": editing_rules[:5],
                "template": "\n".join(f"- {rule}" for rule in editing_rules[:6]) if editing_rules else "",
            },
            {
                "id": f"{profile_slug}-prompt-defaults",
                "title": f"{profile_prefix} Prompt Defaults",
                "record_type": "strategy",
                "description": (
                    "Default prompt upgrades to apply automatically: " + "; ".join(prompt_defaults)
                    if prompt_defaults
                    else f"Default prompt upgrades that should be applied for {profile_prefix}."
                ),
                "aliases": [f"{profile_prefix.lower()} prompt defaults"],
                "tags": shared_tags + ["prompt-defaults"],
                "prompt_types": ["transformative", "generative"],
                "subject_areas": ["general"],
                "model_targets": model_targets,
                "driver_eligible": True,
                "signals": prompt_defaults[:5],
                "template": "\n".join(f"- {rule}" for rule in prompt_defaults[:6]) if prompt_defaults else "",
            },
            {
                "id": f"{profile_slug}-trait-priority-stack",
                "title": f"{profile_prefix} Trait Priority Stack",
                "record_type": "strategy",
                "description": (
                    "Rank output qualities in this order: " + ", ".join(output_priorities)
                    if output_priorities
                    else f"Priority stack for output qualities that should dominate when tradeoffs appear for {profile_prefix}."
                ),
                "aliases": [f"{profile_prefix.lower()} output priorities", f"{profile_prefix.lower()} trait priority stack"],
                "tags": shared_tags + ["trait-priority"],
                "prompt_types": ["transformative", "generative"],
                "subject_areas": ["general"],
                "model_targets": model_targets,
                "driver_eligible": True,
                "signals": output_priorities[:5],
                "template": "\n".join(f"{idx + 1}. {trait}" for idx, trait in enumerate(output_priorities[:5])) if output_priorities else "",
            },
            {
                "id": f"{profile_slug}-voice-memo-cleanup-defaults",
                "title": f"{profile_prefix} Voice Memo Cleanup Defaults",
                "record_type": "strategy",
                "description": (
                    "Default cleanup behavior for raw briefs and voice memos: " + "; ".join(voice_memo_defaults)
                    if voice_memo_defaults
                    else f"Default cleanup behavior for turning raw briefs into usable prompts for {profile_prefix}."
                ),
                "aliases": [f"{profile_prefix.lower()} voice memo cleanup defaults"],
                "tags": shared_tags + ["voice-memo-cleanup"],
                "prompt_types": ["transformative", "generative"],
                "subject_areas": ["general"],
                "model_targets": model_targets,
                "driver_eligible": True,
                "signals": voice_memo_defaults[:5] or ["voice memo cleanup", "must-haves", "exclusions"],
                "template": "\n".join(f"- {rule}" for rule in voice_memo_defaults[:6]) if voice_memo_defaults else "",
            },
        ]
        return records

    def prompt_library_item_count(self) -> int:
        connection = self._open()
        if connection is None:
            return 0
        row = connection.execute("SELECT COUNT(*) AS count FROM prompt_library_items").fetchone()
        return int(row["count"] if row else 0)

    def delete_personal_record(
        self,
        value: str,
        *,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict[str, Any]:
        record = self.resolve_record(value)
        if not record.get("found"):
            return {"deleted": False, "found": False, "query": value}
        if confirm:
            pending = self._consume_confirmation_token(confirmation_token, expected_action="delete_personal_record")
            record = pending["record"]
            self._delete_record(record)
            return {
                "deleted": True,
                "record": self._compact_record(record),
            }
        token = self._store_confirmation(
            "delete_personal_record",
            {"record": self._compact_record(record)},
        )
        return {
            "deleted": False,
            "confirmation_required": True,
            "confirmation_token": token,
            "diff_preview": {
                "action": "delete",
                "entry_id": record["entry_id"],
                "name": record["name"],
                "record_type": record["record_type"],
                "markdown_path": record.get("markdown_path"),
            },
        }

    def get_prompt_library_item(self, value: str) -> dict[str, Any]:
        connection = self._open()
        if connection is None:
            return {"found": False, "query": value, "nearest_matches": []}
        row: sqlite3.Row | None
        if value.startswith("pl:"):
            row = connection.execute("SELECT * FROM prompt_library_items WHERE item_id = ?", (value,)).fetchone()
        else:
            slug = slugify(value)
            row = connection.execute(
                """
                SELECT * FROM prompt_library_items
                WHERE slug = ? OR lower(title) = lower(?)
                ORDER BY updated_at DESC
                LIMIT 1
                """,
                (slug, value),
            ).fetchone()
        item = _item_from_row(row)
        if item:
            return {"found": True, **item}
        return {"found": False, "query": value, "nearest_matches": self._nearest_item_matches(value)}

    def search_prompt_library(
        self,
        query: str,
        *,
        asset_kind: str | None = None,
        model_target: str | None = None,
        target_surface: str | None = None,
        tags: list[str] | None = None,
        limit: int = 10,
    ) -> dict[str, Any]:
        connection = self._open()
        if connection is None:
            return {
                "query": query,
                "filters": {
                    "asset_kind": asset_kind,
                    "model_target": model_target,
                    "target_surface": target_surface,
                    "tags": tags or [],
                    "limit": max(1, min(limit, 25)),
                },
                "results": [],
            }
        safe_limit = max(1, min(limit, 25))
        fts_query = build_fts_query(query)
        if fts_query:
            rows = connection.execute(
                """
                SELECT p.*, bm25(prompt_library_fts) AS rank
                FROM prompt_library_fts
                JOIN prompt_library_items p ON p.item_id = prompt_library_fts.item_id
                WHERE prompt_library_fts MATCH ?
                ORDER BY rank
                LIMIT 200
                """,
                (fts_query,),
            ).fetchall()
        else:
            rows = connection.execute(
                "SELECT *, 999.0 AS rank FROM prompt_library_items ORDER BY updated_at DESC LIMIT 200"
            ).fetchall()
        query_norm = normalize_lookup_key(query)
        tag_filters = {normalize_text(item).lower() for item in tags or [] if normalize_text(item)}
        results: list[tuple[float, dict[str, Any], str]] = []
        for position, row in enumerate(rows):
            item = _item_from_row(row)
            if not item:
                continue
            if asset_kind and item["asset_kind"] != asset_kind:
                continue
            if model_target and normalize_text(item.get("model_target")) != normalize_text(model_target):
                continue
            if target_surface and normalize_text(item.get("target_surface")) != normalize_text(target_surface):
                continue
            item_tags = {normalize_text(tag).lower() for tag in item.get("tags", [])}
            if tag_filters and not tag_filters.issubset(item_tags):
                continue
            score = 50.0
            if query_norm and normalize_lookup_key(item["title"]) == query_norm:
                score += 40
            if query_norm and normalize_lookup_key(item["id"]) == query_norm:
                score += 35
            score += max(25 - position, 0)
            if tag_filters:
                score += len(tag_filters & item_tags) * 10
            if item.get("favorite"):
                score += 4
            results.append((score, item, "fts" if fts_query else "scan"))
        results.sort(key=lambda item: (-item[0], item[1]["title"].lower()))
        return {
            "query": query,
            "filters": {
                "asset_kind": asset_kind,
                "model_target": model_target,
                "target_surface": target_surface,
                "tags": tags or [],
                "limit": safe_limit,
            },
            "results": [
                {
                    "item_id": item["item_id"],
                    "id": item["id"],
                    "title": item["title"],
                    "asset_kind": item["asset_kind"],
                    "tags": item.get("tags", []),
                    "model_target": item.get("model_target"),
                    "target_surface": item.get("target_surface"),
                    "favorite": item.get("favorite", False),
                    "markdown_path": item.get("markdown_path"),
                    "snippet": short_text(item.get("prompt_text"), 180),
                    "score": round(score, 2),
                    "match_type": match_type,
                }
                for score, item, match_type in results[:safe_limit]
            ],
        }

    def save_prompt_library_item(
        self,
        payload: dict[str, Any],
        *,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict[str, Any]:
        normalized = self._normalize_prompt_library_item(payload)
        existing = self.get_prompt_library_item(normalized["id"])
        if existing.get("found") and normalize_text(existing.get("asset_kind")) != normalized["asset_kind"]:
            raise ValueError(
                f"Prompt library id `{normalized['id']}` already exists as `{existing.get('asset_kind')}`. "
                "Delete it first or choose a different id."
            )
        if not existing.get("found"):
            item = self._upsert_prompt_library_item(normalized)
            return {
                "saved": True,
                "created": True,
                "item": item,
                "mutable": True,
            }
        if confirm:
            pending = self._consume_confirmation_token(confirmation_token, expected_action="update_prompt_library_item")
            item = self._upsert_prompt_library_item(pending["item"])
            return {
                "saved": True,
                "created": False,
                "item": item,
                "mutable": True,
            }
        token = self._store_confirmation(
            "update_prompt_library_item",
            {"item": normalized},
        )
        return {
            "saved": False,
            "confirmation_required": True,
            "confirmation_token": token,
            "diff_preview": self._prompt_item_diff(existing, normalized),
            "existing_item": self._compact_item(existing),
            "proposed_item": self._compact_item(normalized),
        }

    def delete_prompt_library_item(
        self,
        value: str,
        *,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict[str, Any]:
        item = self.get_prompt_library_item(value)
        if not item.get("found"):
            return {"deleted": False, "found": False, "query": value}
        if confirm:
            pending = self._consume_confirmation_token(confirmation_token, expected_action="delete_prompt_library_item")
            item = pending["item"]
            self._delete_prompt_library_item(item)
            return {
                "deleted": True,
                "item": self._compact_item(item),
            }
        token = self._store_confirmation(
            "delete_prompt_library_item",
            {"item": self._compact_item(item)},
        )
        return {
            "deleted": False,
            "confirmation_required": True,
            "confirmation_token": token,
            "diff_preview": {
                "action": "delete",
                "item_id": item["item_id"],
                "title": item["title"],
                "asset_kind": item["asset_kind"],
                "markdown_path": item.get("markdown_path"),
            },
        }

    def flag_core_record(
        self,
        target_entry_id: str,
        reason: str,
        suggested_action: str,
        notes: str | None = None,
    ) -> dict[str, Any]:
        self.ensure_initialized()
        now = utc_now_iso()
        flag = {
            "id": f"flag-{uuid.uuid4().hex[:12]}",
            "target_entry_id": normalize_text(target_entry_id),
            "reason": normalize_text(reason),
            "suggested_action": normalize_text(suggested_action),
            "notes": normalize_text(notes),
            "status": "open",
            "created_at": now,
            "updated_at": now,
        }
        flag_path = review_flag_markdown_path(self.vault_root, flag["id"])
        flag["markdown_path"] = str(flag_path)
        connection = self._open(create_if_missing=True)
        connection.execute(
            """
            INSERT INTO core_review_flags (
                flag_id, target_entry_id, reason, suggested_action, notes, status, created_at, updated_at, markdown_path
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                flag["id"],
                flag["target_entry_id"],
                flag["reason"],
                flag["suggested_action"],
                flag["notes"],
                flag["status"],
                flag["created_at"],
                flag["updated_at"],
                flag["markdown_path"],
            ),
        )
        connection.commit()
        flag_path.write_text(render_review_flag_markdown(flag), encoding="utf-8")
        return {"flagged": True, "flag": flag}

    def list_core_review_flags(
        self,
        *,
        status: str | None = None,
        target_entry_id: str | None = None,
        limit: int = 25,
    ) -> dict[str, Any]:
        connection = self._open()
        safe_limit = max(1, min(int(limit or 25), 100))
        status_value = normalize_text(status)
        target_value = normalize_text(target_entry_id)
        if connection is None:
            return {
                "status": "review_flags_ready",
                "count": 0,
                "filters": {"status": status_value or None, "target_entry_id": target_value or None, "limit": safe_limit},
                "flags": [],
            }
        clauses: list[str] = []
        params: list[Any] = []
        if status_value:
            clauses.append("status = ?")
            params.append(status_value)
        if target_value:
            clauses.append("target_entry_id = ?")
            params.append(target_value)
        where_clause = " WHERE " + " AND ".join(clauses) if clauses else ""
        rows = connection.execute(
            f"""
            SELECT *
            FROM core_review_flags
            {where_clause}
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (*params, safe_limit),
        ).fetchall()
        flags = [flag for row in rows if (flag := _flag_from_row(row))]
        return {
            "status": "review_flags_ready",
            "count": len(flags),
            "filters": {"status": status_value or None, "target_entry_id": target_value or None, "limit": safe_limit},
            "flags": flags,
        }

    def sync_from_markdown(self) -> dict[str, Any]:
        self.ensure_initialized()
        counts = {"records": 0, "prompt_library_items": 0, "review_flags": 0}
        errors: list[dict[str, Any]] = []
        for path in sorted(self.vault_root.rglob("*.md")):
            if self._ignored_path(path):
                continue
            try:
                relative = path.resolve().relative_to(self.vault_root)
                if relative.parts[:2] == ("Custom Records", "frameworks") or relative.parts[:2] == ("Custom Records", "strategies") or relative.parts[:2] == ("Custom Records", "patterns") or relative.parts[:2] == ("Custom Records", "techniques") or relative.parts[:2] == ("Custom Records", "terms") or relative.parts[:2] == ("Custom Records", "anti_patterns"):
                    record = self._normalize_personal_record(parse_personal_record_markdown(path))
                    self._upsert_record(record, write_markdown=False)
                    counts["records"] += 1
                elif relative.parts and relative.parts[0] == "Prompt Library":
                    item = self._normalize_prompt_library_item(parse_prompt_library_markdown(path))
                    self._upsert_prompt_library_item(item, write_markdown=False)
                    counts["prompt_library_items"] += 1
                elif relative.parts and relative.parts[0] == CORE_REVIEW_FLAGS_DIR.name:
                    flag = parse_review_flag_markdown(path)
                    self._upsert_review_flag(flag, write_markdown=False)
                    counts["review_flags"] += 1
            except Exception as exc:  # pragma: no cover - surfaced to caller
                errors.append({"path": str(path), "error": str(exc)})
        return {"synced": True, "counts": counts, "errors": errors}

    def _open(self, create_if_missing: bool = False) -> sqlite3.Connection | None:
        if self._connection is not None:
            return self._connection
        if not self.db_path.exists() and not create_if_missing:
            return None
        if create_if_missing:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._connection = sqlite3.connect(str(self.db_path))
        self._connection.row_factory = sqlite3.Row
        return self._connection

    def _normalize_personal_record(self, payload: dict[str, Any]) -> dict[str, Any]:
        title = normalize_text(payload.get("title")) or normalize_text(payload.get("name"))
        record_id = slugify(payload.get("id") or title)
        record_type = normalize_text(payload.get("record_type"))
        if record_type not in PERSONAL_RECORD_TYPES:
            raise ValueError(f"Unsupported personal record_type: {record_type}")
        if not record_id:
            raise ValueError("Personal record requires id or title.")
        if not title:
            raise ValueError("Personal record requires title.")
        description = normalize_text(payload.get("description"))
        if not description:
            raise ValueError("Personal record requires description.")
        driver_eligible = bool(payload.get("driver_eligible")) and record_type in DRIVER_ELIGIBLE_RECORD_TYPES
        now = utc_now_iso()
        markdown_path = normalize_text(payload.get("markdown_path")) or str(record_markdown_path(self.vault_root, record_type, record_id))
        return {
            "entry_id": f"pp:{record_type}:{record_id}",
            "id": record_id,
            "title": title,
            "name": title,
            "slug": record_id,
            "record_type": record_type,
            "description": description,
            "summary": short_text(description, 180),
            "aliases": join_unique(ensure_list(payload.get("aliases"))),
            "tags": join_unique(ensure_list(payload.get("tags"))),
            "prompt_types": join_unique(ensure_list(payload.get("prompt_types")) or ["reductive", "transformative", "generative"]),
            "subject_areas": join_unique(ensure_list(payload.get("subject_areas")) or ["general"]),
            "model_targets": join_unique(ensure_list(payload.get("model_targets")) or ["generic"]),
            "driver_eligible": driver_eligible,
            "template": payload.get("template", ""),
            "examples": join_unique(ensure_list(payload.get("examples"))),
            "signals": join_unique(ensure_list(payload.get("signals"))),
            "related_entry_ids": join_unique(ensure_list(payload.get("related_entry_ids"))),
            "capability_tags": join_unique(ensure_list(payload.get("capability_tags"))),
            "notes": normalize_text(payload.get("notes")),
            "tool_fit": payload.get("tool_fit") or DEFAULT_TOOL_FIT[record_type],
            "source_refs": [{"source_name": "personal_overlay", "source_type": "markdown", "source_path_or_id": markdown_path, "confidence": "user"}],
            "quality_flags": [],
            "source_priority": 82 if driver_eligible else 74,
            "source_tier": "personal_overlay",
            "search_weight": 18 if driver_eligible else 15,
            "curation_status": "supporting",
            "curation_note": "User-authored personal overlay record.",
            "corpus_zone": record_type,
            "family": "personal_overlay",
            "origin_bucket": "personal_overlay",
            "ambiguity_status": "clear",
            "weight_reason": "User-authored personal overlay guidance.",
            "decision": "personal_added",
            "phase": 2,
            "record_layer": "personal",
            "mutable": True,
            "source_of_truth": "sqlite_overlay",
            "markdown_path": markdown_path,
            "interaction_mode": normalize_text(payload.get("interaction_mode")) or "single_turn",
            "output_mode": normalize_text(payload.get("output_mode")) or "freeform",
            "grounding_mode": normalize_text(payload.get("grounding_mode")) or "none",
            "evaluation_mode": normalize_text(payload.get("evaluation_mode")) or "none",
            "contraindications": join_unique(ensure_list(payload.get("contraindications"))),
            "fixes": join_unique(ensure_list(payload.get("fixes"))),
            "created_at": normalize_text(payload.get("created_at")) or now,
            "updated_at": now,
        }

    def _normalize_prompt_library_item(self, payload: dict[str, Any]) -> dict[str, Any]:
        title = normalize_text(payload.get("title"))
        item_id = slugify(payload.get("id") or title)
        asset_kind = normalize_text(payload.get("asset_kind")) or "prompt"
        if asset_kind not in PROMPT_LIBRARY_ASSET_KINDS:
            raise ValueError(f"Unsupported prompt library asset_kind: {asset_kind}")
        if not item_id:
            raise ValueError("Prompt library item requires id or title.")
        if not title:
            raise ValueError("Prompt library item requires title.")
        prompt_text = str(payload.get("prompt_text", "")).strip()
        if not prompt_text:
            raise ValueError("Prompt library item requires prompt_text.")
        now = utc_now_iso()
        markdown_path = normalize_text(payload.get("markdown_path")) or str(asset_markdown_path(self.vault_root, asset_kind, item_id))
        return {
            "item_id": f"pl:{asset_kind}:{item_id}",
            "id": item_id,
            "slug": item_id,
            "title": title,
            "asset_kind": asset_kind,
            "prompt_text": prompt_text,
            "tags": join_unique(ensure_list(payload.get("tags"))),
            "model_target": normalize_text(payload.get("model_target")),
            "target_surface": normalize_text(payload.get("target_surface")),
            "prompt_contract": payload.get("prompt_contract") or {},
            "rationale_table": ensure_list(payload.get("rationale_table")),
            "linked_record_ids": join_unique(ensure_list(payload.get("linked_record_ids"))),
            "notes": normalize_text(payload.get("notes")),
            "success_notes": normalize_text(payload.get("success_notes")),
            "favorite": bool(payload.get("favorite")),
            "created_at": normalize_text(payload.get("created_at")) or now,
            "updated_at": now,
            "markdown_path": markdown_path,
        }

    def _upsert_record(self, record: dict[str, Any], *, write_markdown: bool = True) -> dict[str, Any]:
        self.ensure_initialized()
        existing = self.get_record(record["entry_id"])
        created_at = normalize_text(record.get("created_at")) or (existing or {}).get("created_at") or utc_now_iso()
        updated = {
            **record,
            "created_at": created_at,
            "updated_at": normalize_text(record.get("updated_at")) or utc_now_iso(),
        }
        search_text = text_blob(
            updated["title"],
            updated["slug"],
            updated["description"],
            updated.get("aliases", []),
            updated.get("tags", []),
            updated.get("signals", []),
            updated.get("capability_tags", []),
            updated.get("examples", []),
        )
        extra = {
            "aliases": updated.get("aliases", []),
            "tool_fit": updated.get("tool_fit", DEFAULT_TOOL_FIT[updated["record_type"]]),
            "source_tier": updated.get("source_tier"),
            "search_weight": updated.get("search_weight"),
            "curation_status": updated.get("curation_status"),
            "curation_note": updated.get("curation_note"),
            "corpus_zone": updated.get("corpus_zone"),
            "phase": updated.get("phase"),
            "id": updated["id"],
            "title": updated["title"],
            "description": updated["description"],
            "family": updated.get("family"),
            "origin_bucket": updated.get("origin_bucket"),
            "driver_eligible": updated.get("driver_eligible", False),
            "ambiguity_status": updated.get("ambiguity_status"),
            "weight_reason": updated.get("weight_reason"),
            "decision": updated.get("decision"),
            "record_layer": "personal",
            "mutable": True,
            "source_of_truth": "sqlite_overlay",
            "markdown_path": updated["markdown_path"],
            "interaction_mode": updated.get("interaction_mode", "single_turn"),
            "output_mode": updated.get("output_mode", "freeform"),
            "grounding_mode": updated.get("grounding_mode", "none"),
            "evaluation_mode": updated.get("evaluation_mode", "none"),
            "capability_tags": updated.get("capability_tags", []),
            "notes": updated.get("notes", ""),
            "created_at": created_at,
            "updated_at": updated["updated_at"],
        }
        connection = self._open(create_if_missing=True)
        assert connection is not None
        connection.execute("DELETE FROM aliases WHERE entry_id = ?", (updated["entry_id"],))
        connection.execute("DELETE FROM records_fts WHERE entry_id = ?", (updated["entry_id"],))
        connection.execute(
            """
            INSERT OR REPLACE INTO records (
                entry_id, record_type, name, slug, summary, definition,
                prompt_types_json, subject_areas_json, model_targets_json,
                signals_json, contraindications_json, template_json, examples_json,
                fixes_json, related_entry_ids_json, tags_json, source_refs_json,
                quality_flags_json, source_priority, extra_json, search_text
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                updated["entry_id"],
                updated["record_type"],
                updated["title"],
                updated["slug"],
                updated["summary"],
                updated["description"],
                to_json(updated["prompt_types"]),
                to_json(updated["subject_areas"]),
                to_json(updated["model_targets"]),
                to_json(updated["signals"]),
                to_json(updated.get("contraindications", [])),
                to_json(updated.get("template", "")),
                to_json(updated.get("examples", [])),
                to_json(updated.get("fixes", [])),
                to_json(updated.get("related_entry_ids", [])),
                to_json(updated.get("tags", [])),
                to_json(updated.get("source_refs", [])),
                to_json(updated.get("quality_flags", [])),
                int(updated.get("source_priority", 74)),
                to_json(extra),
                search_text,
            ),
        )
        aliases = {updated["title"], updated["slug"], *updated.get("aliases", [])}
        for alias in aliases:
            alias_norm = normalize_lookup_key(alias)
            if not alias_norm:
                continue
            connection.execute(
                "INSERT OR IGNORE INTO aliases(alias_norm, entry_id) VALUES (?, ?)",
                (alias_norm, updated["entry_id"]),
            )
        connection.execute(
            "INSERT INTO records_fts(entry_id, search_text) VALUES (?, ?)",
            (updated["entry_id"], search_text),
        )
        connection.commit()
        if write_markdown:
            path = Path(updated["markdown_path"])
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(render_personal_record_markdown(updated), encoding="utf-8")
        saved = self.get_record(updated["entry_id"])
        assert saved is not None
        return saved

    def _upsert_prompt_library_item(self, item: dict[str, Any], *, write_markdown: bool = True) -> dict[str, Any]:
        self.ensure_initialized()
        existing = self.get_prompt_library_item(item["item_id"])
        created_at = normalize_text(item.get("created_at")) or (existing or {}).get("created_at") or utc_now_iso()
        updated = {
            **item,
            "created_at": created_at,
            "updated_at": normalize_text(item.get("updated_at")) or utc_now_iso(),
        }
        search_text = text_blob(
            updated["title"],
            updated["id"],
            updated["prompt_text"],
            updated.get("tags", []),
            updated.get("model_target"),
            updated.get("target_surface"),
            updated.get("notes"),
            updated.get("success_notes"),
        )
        connection = self._open(create_if_missing=True)
        assert connection is not None
        connection.execute("DELETE FROM prompt_library_fts WHERE item_id = ?", (updated["item_id"],))
        connection.execute(
            """
            INSERT OR REPLACE INTO prompt_library_items (
                item_id, slug, title, asset_kind, prompt_text, tags_json,
                model_target, target_surface, prompt_contract_json, rationale_table_json,
                linked_record_ids_json, notes, success_notes, favorite, created_at,
                updated_at, markdown_path, search_text
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                updated["item_id"],
                updated["id"],
                updated["title"],
                updated["asset_kind"],
                updated["prompt_text"],
                to_json(updated.get("tags", [])),
                updated.get("model_target", ""),
                updated.get("target_surface", ""),
                to_json(updated.get("prompt_contract", {})),
                to_json(updated.get("rationale_table", [])),
                to_json(updated.get("linked_record_ids", [])),
                updated.get("notes", ""),
                updated.get("success_notes", ""),
                int(bool(updated.get("favorite"))),
                created_at,
                updated["updated_at"],
                updated["markdown_path"],
                search_text,
            ),
        )
        connection.execute(
            "INSERT INTO prompt_library_fts(item_id, search_text) VALUES (?, ?)",
            (updated["item_id"], search_text),
        )
        connection.commit()
        if write_markdown:
            path = Path(updated["markdown_path"])
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(render_prompt_library_markdown(updated), encoding="utf-8")
        saved = self.get_prompt_library_item(updated["item_id"])
        assert saved.get("found")
        return saved

    def _upsert_review_flag(self, flag: dict[str, Any], *, write_markdown: bool = True) -> dict[str, Any]:
        self.ensure_initialized()
        updated = {
            **flag,
            "status": normalize_text(flag.get("status")) if normalize_text(flag.get("status")) in REVIEW_FLAG_STATUSES else "open",
            "created_at": normalize_text(flag.get("created_at")) or utc_now_iso(),
            "updated_at": normalize_text(flag.get("updated_at")) or utc_now_iso(),
            "markdown_path": normalize_text(flag.get("markdown_path")) or str(review_flag_markdown_path(self.vault_root, flag["id"])),
        }
        connection = self._open(create_if_missing=True)
        assert connection is not None
        connection.execute(
            """
            INSERT OR REPLACE INTO core_review_flags (
                flag_id, target_entry_id, reason, suggested_action, notes, status, created_at, updated_at, markdown_path
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                updated["id"],
                updated["target_entry_id"],
                updated["reason"],
                updated["suggested_action"],
                updated.get("notes", ""),
                updated["status"],
                updated["created_at"],
                updated["updated_at"],
                updated["markdown_path"],
            ),
        )
        connection.commit()
        if write_markdown:
            path = Path(updated["markdown_path"])
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(render_review_flag_markdown(updated), encoding="utf-8")
        return updated

    def _delete_record(self, record: dict[str, Any]) -> None:
        connection = self._open()
        if connection is None:
            return
        connection.execute("DELETE FROM aliases WHERE entry_id = ?", (record["entry_id"],))
        connection.execute("DELETE FROM records_fts WHERE entry_id = ?", (record["entry_id"],))
        connection.execute("DELETE FROM records WHERE entry_id = ?", (record["entry_id"],))
        connection.commit()
        markdown_path = normalize_text(record.get("markdown_path"))
        if markdown_path:
            Path(markdown_path).unlink(missing_ok=True)

    def _delete_prompt_library_item(self, item: dict[str, Any]) -> None:
        connection = self._open()
        if connection is None:
            return
        connection.execute("DELETE FROM prompt_library_fts WHERE item_id = ?", (item["item_id"],))
        connection.execute("DELETE FROM prompt_library_items WHERE item_id = ?", (item["item_id"],))
        connection.commit()
        markdown_path = normalize_text(item.get("markdown_path"))
        if markdown_path:
            Path(markdown_path).unlink(missing_ok=True)

    def _normalize_preferences(
        self,
        payload: dict[str, Any],
        *,
        base: dict[str, Any] | None = None,
        default_onboarding: bool = False,
    ) -> dict[str, Any]:
        current = base if isinstance(base, dict) else default_preferences_payload()
        current_autoflow = current.get("autoflow") if isinstance(current.get("autoflow"), dict) else {}
        incoming_autoflow = payload.get("autoflow") if isinstance(payload.get("autoflow"), dict) else {}
        autoflow = {
            "enabled_by_default": bool(incoming_autoflow.get("enabled_by_default", current_autoflow.get("enabled_by_default", False))),
            "summary_visibility": normalize_text(
                incoming_autoflow.get("summary_visibility", current_autoflow.get("summary_visibility", "brief"))
            ).lower(),
            "clarifying_questions": normalize_text(
                incoming_autoflow.get("clarifying_questions", current_autoflow.get("clarifying_questions", "allow_when_uncertain"))
            ).lower(),
            "hitl_level": normalize_text(incoming_autoflow.get("hitl_level", current_autoflow.get("hitl_level", "soft_gate"))).lower(),
        }
        if autoflow["summary_visibility"] not in SUMMARY_VISIBILITY_VALUES:
            raise ValueError("summary_visibility must be one of: brief, silent.")
        if autoflow["clarifying_questions"] not in CLARIFYING_QUESTION_VALUES:
            raise ValueError("clarifying_questions must be one of: allow_when_uncertain, never.")
        if autoflow["hitl_level"] not in HITL_LEVEL_VALUES:
            raise ValueError("hitl_level must be one of: none, soft_gate, always.")
        incoming_choice = normalize_text(payload.get("additional_preferences_choice")).lower().replace("-", "_").replace(" ", "_")
        current_choice = normalize_text(current.get("additional_preferences_choice")).lower().replace("-", "_").replace(" ", "_")
        additional_choice = incoming_choice or current_choice
        additional_acknowledged = bool(
            payload.get("additional_preferences_acknowledged", current.get("additional_preferences_acknowledged", False))
            or additional_choice in {"configure_now", "come_back_later", "skip_for_now", "skip"}
        )
        if "onboarding_completed" in payload:
            onboarding_completed = bool(payload.get("onboarding_completed"))
        else:
            current_onboarding = bool(current.get("onboarding_completed")) or bool(default_onboarding)
            onboarding_completed = bool(
                current_onboarding
                or (additional_acknowledged and bool(incoming_choice or payload.get("additional_preferences_acknowledged")))
            )
        return {
            "schema_version": PREFERENCES_SCHEMA_VERSION,
            "onboarding_completed": onboarding_completed,
            "additional_preferences_acknowledged": additional_acknowledged,
            "additional_preferences_choice": additional_choice,
            "autoflow": autoflow,
        }

    def _preferences_response(
        self,
        namespace: str,
        preferences: dict[str, Any],
        *,
        configured: bool,
        preference_state: str,
        content_counts: dict[str, int] | None = None,
        created_at: str | None = None,
        updated_at: str | None = None,
    ) -> dict[str, Any]:
        return {
            "status": "preferences_ready",
            "tool": "manage_preferences",
            "namespace": namespace,
            "schema_version": PREFERENCES_SCHEMA_VERSION,
            "preferences": preferences,
            "defaults": default_preferences_payload(),
            "onboarding_completed": bool(preferences.get("onboarding_completed")),
            "additional_preferences_available": True,
            "additional_preferences_gate": self._additional_preferences_gate(),
            "setup_questions": self._preference_setup_questions(),
            "configured": configured,
            "autoflow_preference_state": preference_state,
            "personal_content_counts": content_counts or {"records": 0, "prompt_library_items": 0, "core_review_flags": 0},
            "created_at": created_at,
            "updated_at": updated_at,
            "record_layer": "personal",
            "mutable": True,
        }

    def _upsert_preferences(self, namespace: str, preferences: dict[str, Any]) -> dict[str, Any]:
        self.ensure_initialized()
        normalized = self._normalize_preferences(preferences, default_onboarding=True)
        connection = self._open(create_if_missing=True)
        assert connection is not None
        existing = connection.execute(
            "SELECT created_at FROM preferences WHERE namespace = ?",
            (namespace,),
        ).fetchone()
        created_at = existing["created_at"] if existing else utc_now_iso()
        updated_at = utc_now_iso()
        connection.execute(
            """
            INSERT OR REPLACE INTO preferences (
                namespace, schema_version, preferences_json, onboarding_completed, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                namespace,
                PREFERENCES_SCHEMA_VERSION,
                to_json(normalized),
                1 if normalized.get("onboarding_completed") else 0,
                created_at,
                updated_at,
            ),
        )
        connection.commit()
        return self._preferences_response(
            namespace,
            normalized,
            configured=True,
            preference_state="configured",
            content_counts=self._personal_content_counts(connection),
            created_at=created_at,
            updated_at=updated_at,
        )

    def _delete_preferences(self, namespace: str) -> None:
        connection = self._open()
        if connection is None:
            return
        self.ensure_initialized()
        connection = self._open()
        assert connection is not None
        connection.execute("DELETE FROM preferences WHERE namespace = ?", (namespace,))
        connection.commit()

    def _personal_content_counts(self, connection: sqlite3.Connection) -> dict[str, int]:
        return {
            "records": int(connection.execute("SELECT COUNT(*) FROM records").fetchone()[0]),
            "prompt_library_items": int(connection.execute("SELECT COUNT(*) FROM prompt_library_items").fetchone()[0]),
            "core_review_flags": int(connection.execute("SELECT COUNT(*) FROM core_review_flags").fetchone()[0]),
        }

    def _preference_diff(self, current: dict[str, Any], proposed: dict[str, Any]) -> list[dict[str, Any]]:
        diffs: list[dict[str, Any]] = []
        fields = [
            ("onboarding_completed", current.get("onboarding_completed"), proposed.get("onboarding_completed")),
            (
                "additional_preferences_acknowledged",
                current.get("additional_preferences_acknowledged"),
                proposed.get("additional_preferences_acknowledged"),
            ),
            (
                "additional_preferences_choice",
                current.get("additional_preferences_choice"),
                proposed.get("additional_preferences_choice"),
            ),
            (
                "autoflow.enabled_by_default",
                (current.get("autoflow") or {}).get("enabled_by_default"),
                (proposed.get("autoflow") or {}).get("enabled_by_default"),
            ),
            (
                "autoflow.summary_visibility",
                (current.get("autoflow") or {}).get("summary_visibility"),
                (proposed.get("autoflow") or {}).get("summary_visibility"),
            ),
            (
                "autoflow.clarifying_questions",
                (current.get("autoflow") or {}).get("clarifying_questions"),
                (proposed.get("autoflow") or {}).get("clarifying_questions"),
            ),
            (
                "autoflow.hitl_level",
                (current.get("autoflow") or {}).get("hitl_level"),
                (proposed.get("autoflow") or {}).get("hitl_level"),
            ),
        ]
        for field, before, after in fields:
            if before != after:
                diffs.append({"field": field, "before": before, "after": after})
        return diffs

    def _preference_setup_questions(self) -> list[dict[str, Any]]:
        return [
            {
                "id": "pc:prefs:autoflow-default",
                "slot": "autoflow.enabled_by_default",
                "question": "Should Auto Flow run by default when you ask an AI for help?",
                "display_label": "Auto Flow default",
                "plain_question": "Should Auto Flow run by default when you ask an AI for help?",
                "answer_type": "single_choice",
                "choices": [
                    {"label": "No, only when I ask", "value": False},
                    {"label": "Yes, improve and run automatically", "value": True},
                ],
                "assumption_if_skipped": "Auto Flow stays off unless you ask for it.",
            },
            {
                "id": "pc:prefs:autoflow-summary",
                "slot": "autoflow.summary_visibility",
                "question": "When Auto Flow runs, should it show a brief note before executing?",
                "display_label": "Change note",
                "plain_question": "When Auto Flow runs, should it show a brief note before executing?",
                "answer_type": "single_choice",
                "choices": [
                    {"label": "Show a brief note", "value": "brief"},
                    {"label": "Run silently when safe", "value": "silent"},
                ],
                "assumption_if_skipped": "Auto Flow shows a brief note.",
            },
            {
                "id": "pc:prefs:autoflow-clarifying",
                "slot": "autoflow.clarifying_questions",
                "question": "When Auto Flow is unsure, may it ask one quick question before running?",
                "display_label": "Ask if unsure",
                "plain_question": "When Auto Flow is unsure, may it ask one quick question before running?",
                "answer_type": "single_choice",
                "choices": [
                    {"label": "Yes, ask one quick question", "value": "allow_when_uncertain"},
                    {"label": "No, make safe assumptions", "value": "never"},
                ],
                "assumption_if_skipped": "Auto Flow may ask one quick question when it is genuinely uncertain.",
            },
            {
                "id": "pc:prefs:autoflow-approval",
                "slot": "autoflow.hitl_level",
                "question": "When should Auto Flow ask before running the improved version?",
                "display_label": "Ask before running",
                "plain_question": "When should Auto Flow ask before running the improved version?",
                "answer_type": "single_choice",
                "choices": [
                    {"label": "Only for bigger changes", "value": "soft_gate"},
                    {"label": "Always ask first", "value": "always"},
                    {"label": "Do not ask unless blocked", "value": "none"},
                ],
                "assumption_if_skipped": "Auto Flow asks before bigger changes.",
            },
        ]

    def _additional_preferences_gate(self) -> dict[str, Any]:
        return {
            "id": "pc:prefs:additional-awareness",
            "slot": "additional_preferences_choice",
            "question": "More preferences are available for quick mode, advanced mode, Agent Mode, and interaction style. Configure them now or come back later?",
            "display_label": "More settings",
            "plain_question": "More preferences are available for quick mode, advanced mode, Agent Mode, and interaction style. Configure them now or come back later?",
            "answer_type": "single_choice",
            "choices": [
                {"label": "Come back later", "value": "come_back_later"},
                {"label": "Configure now", "value": "configure_now"},
            ],
            "assumption_if_skipped": "Prompt Compass keeps the current defaults and marks Auto Flow onboarding as acknowledged once you skip this gate.",
            "available_preference_domains": ["quick_mode", "advanced_mode", "agent_mode", "interaction_style"],
        }

    def _store_confirmation(self, action_kind: str, payload: dict[str, Any]) -> str:
        self.ensure_initialized()
        token = f"pc-token-{uuid.uuid4().hex}"
        connection = self._open(create_if_missing=True)
        assert connection is not None
        connection.execute(
            "INSERT INTO pending_confirmations(token, action_kind, payload_json, created_at) VALUES (?, ?, ?, ?)",
            (token, action_kind, to_json(payload), utc_now_iso()),
        )
        connection.commit()
        return token

    def _consume_confirmation_token(self, token: str | None, *, expected_action: str) -> dict[str, Any]:
        if not token:
            raise ValueError("confirmation_token is required when confirm=true.")
        connection = self._open()
        if connection is None:
            raise ValueError("No pending confirmations are available.")
        row = connection.execute(
            "SELECT action_kind, payload_json FROM pending_confirmations WHERE token = ?",
            (token,),
        ).fetchone()
        if row is None:
            raise ValueError("Unknown confirmation_token.")
        if row["action_kind"] != expected_action:
            raise ValueError(f"confirmation_token does not match expected action `{expected_action}`.")
        connection.execute("DELETE FROM pending_confirmations WHERE token = ?", (token,))
        connection.commit()
        payload = from_json(row["payload_json"], {})
        if not isinstance(payload, dict):
            raise ValueError("Stored confirmation payload is invalid.")
        return payload

    def _record_type_allowed(self, record: dict[str, Any], record_types: list[str] | None) -> bool:
        if not record_types:
            return True
        return record.get("record_type") in set(record_types)

    def _record_diff(self, existing: dict[str, Any], proposed: dict[str, Any]) -> list[dict[str, Any]]:
        diffs: list[dict[str, Any]] = []
        for field in (
            "title",
            "description",
            "aliases",
            "tags",
            "prompt_types",
            "subject_areas",
            "model_targets",
            "driver_eligible",
            "template",
            "examples",
            "signals",
            "related_entry_ids",
            "capability_tags",
            "notes",
        ):
            before = existing.get(field)
            after = proposed.get(field)
            if before == after:
                continue
            diffs.append(
                {
                    "field": field,
                    "before": short_text(before if not isinstance(before, list) else ", ".join(before), 120),
                    "after": short_text(after if not isinstance(after, list) else ", ".join(after), 120),
                }
            )
        return diffs

    def _prompt_item_diff(self, existing: dict[str, Any], proposed: dict[str, Any]) -> list[dict[str, Any]]:
        diffs: list[dict[str, Any]] = []
        for field in (
            "title",
            "asset_kind",
            "prompt_text",
            "tags",
            "model_target",
            "target_surface",
            "linked_record_ids",
            "notes",
            "success_notes",
            "favorite",
        ):
            before = existing.get(field)
            after = proposed.get(field)
            if before == after:
                continue
            diffs.append(
                {
                    "field": field,
                    "before": short_text(before if not isinstance(before, list) else ", ".join(before), 120),
                    "after": short_text(after if not isinstance(after, list) else ", ".join(after), 120),
                }
            )
        return diffs

    def _compact_record(self, record: dict[str, Any]) -> dict[str, Any]:
        return {
            "entry_id": record.get("entry_id"),
            "id": record.get("id") or record.get("slug"),
            "name": record.get("name") or record.get("title"),
            "record_type": record.get("record_type"),
            "driver_eligible": bool(record.get("driver_eligible")),
            "record_layer": record.get("record_layer", "personal"),
            "markdown_path": record.get("markdown_path"),
        }

    def _compact_item(self, item: dict[str, Any]) -> dict[str, Any]:
        return {
            "item_id": item.get("item_id"),
            "id": item.get("id"),
            "title": item.get("title"),
            "asset_kind": item.get("asset_kind"),
            "markdown_path": item.get("markdown_path"),
        }

    def _nearest_item_matches(self, value: str, limit: int = 5) -> list[dict[str, Any]]:
        connection = self._open()
        if connection is None:
            return []
        lookup = normalize_lookup_key(value)
        if not lookup:
            return []
        rows = connection.execute("SELECT * FROM prompt_library_items ORDER BY updated_at DESC").fetchall()
        scored: list[tuple[float, dict[str, Any]]] = []
        for row in rows:
            item = _item_from_row(row)
            if not item:
                continue
            score = 0.0
            if normalize_lookup_key(item["title"]) == lookup:
                score += 25
            if normalize_lookup_key(item["id"]) == lookup:
                score += 20
            if lookup in normalize_lookup_key(item["prompt_text"]):
                score += 10
            if score:
                scored.append((score, item))
        scored.sort(key=lambda item: (-item[0], item[1]["title"].lower()))
        return [
            {
                "item_id": item["item_id"],
                "title": item["title"],
                "asset_kind": item["asset_kind"],
                "markdown_path": item["markdown_path"],
            }
            for _, item in scored[:limit]
        ]

    def _ignored_path(self, path: Path) -> bool:
        return path.name.startswith("._") or any(part.startswith("._") for part in path.parts)
