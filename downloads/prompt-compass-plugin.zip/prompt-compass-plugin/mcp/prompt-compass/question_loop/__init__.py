"""Question loop helpers for Prompt Compass."""
