from __future__ import annotations

import json
from typing import Any

from analysis.contracts import contract_missing_blocks
from common import ensure_list, normalize_text
from question_loop.state import _has_answer_value, normalize_question_loop_state, register_pending_questions
from repository import PromptCompassRepository


def get_clarifying_questions_payload(
    repo: PromptCompassRepository,
    analysis: dict[str, Any],
    question_loop_state: dict[str, Any] | None = None,
    limit: int | None = None,
    *,
    preferred_slots: list[str] | None = None,
    allowed_categories: list[str] | None = None,
    workflow_stage: str | None = None,
    stage_goal: str | None = None,
    stage_exit_criteria: list[str] | None = None,
    prelude_summary: str | None = None,
    prompt_style: str = "ask_only_this_stage",
) -> dict[str, Any]:
    safe_limit = max(1, min(limit or 5, 5))
    state = normalize_question_loop_state(question_loop_state)
    safe_limit = 1
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    resolved_slots = {
        normalize_text(slot).lower()
        for slot in ensure_list(state.get("answered_slots"))
        if normalize_text(slot)
    }
    missing = set(analysis.get("missing_building_blocks", []))
    anti_slugs = {item.get("slug") for item in analysis.get("anti_patterns", [])}
    prompt_type = normalize_text(analysis.get("prompt_type"))
    preferred_slot_set = {normalize_text(item) for item in preferred_slots or [] if normalize_text(item)}
    allowed_category_set = {normalize_text(item) for item in allowed_categories or [] if normalize_text(item)}

    scored: list[tuple[float, dict[str, Any]]] = []
    for record in repo.list_all(record_type="question"):
        slot = normalize_text(record.get("slot"))
        category = normalize_text(record.get("question_category"))
        slot_key = slot.lower()
        if slot_key in resolved_slots:
            continue
        if slot in answers and _has_answer_value(answers.get(slot)):
            continue
        if preferred_slot_set and slot not in preferred_slot_set:
            continue
        if allowed_category_set and category not in allowed_category_set:
            continue
        tool_fit = record.get("tool_fit", {}) if isinstance(record.get("tool_fit"), dict) else {}
        sequence_priority = int(record.get("sequence_priority", 5) or 5)
        score = float(tool_fit.get("build", 0)) * 8 + float(tool_fit.get("improve", 0)) * 4
        score += max(20 - sequence_priority * 2, 0)
        if preferred_slot_set and slot in preferred_slot_set:
            score += 18
        for rule in record.get("triggers_when", []) or record.get("applies_when", []):
            if rule.startswith("missing:") and rule.split(":", 1)[1] in missing:
                score += 25
            if rule.startswith("anti_pattern:") and rule.split(":", 1)[1] in anti_slugs:
                score += 20
            if rule.startswith("prompt_type:") and rule.split(":", 1)[1] == prompt_type:
                score += 8
            if rule.startswith("output_contract:") and rule.endswith("missing") and "output_contract" in missing:
                score += 12
            if rule.startswith("trait_stack:") and "stacked-adjectives" in anti_slugs:
                score += 8
        if slot in {"objective", "audience", "output_contract"}:
            score += 10
        scored.append((score, record))

    scored.sort(
        key=lambda item: (
            -item[0],
            int(item[1].get("sequence_priority", 5) or 5),
            item[1]["name"].lower(),
        )
    )
    selected: list[dict[str, Any]] = []
    seen_slots: set[str] = set()
    for _, record in scored:
        slot = normalize_text(record.get("slot")).lower()
        if slot in seen_slots:
            continue
        selected.append(record)
        seen_slots.add(slot)
        if len(selected) >= safe_limit:
            break
    if limit is None and len(selected) < 3:
        for fallback_slot in ("objective", "audience", "output_contract"):
            fallback = next(
                (
                    record
                    for record in repo.list_all(record_type="question")
                    if normalize_text(record.get("slot")) == fallback_slot
                    and fallback_slot not in resolved_slots
                    and normalize_text(record.get("slot")).lower() not in seen_slots
                    and record["entry_id"] not in {item["entry_id"] for item in selected}
                ),
                None,
            )
            if fallback:
                selected.append(fallback)
                seen_slots.add(normalize_text(fallback.get("slot")).lower())
            if len(selected) >= 3:
                break

    questions_for_user = [_host_question(record, analysis) for record in selected[:safe_limit]]
    updated_state = register_pending_questions(state, questions_for_user)
    if workflow_stage:
        updated_state["workflow_stage"] = workflow_stage
    if stage_goal:
        updated_state["stage_status"] = "awaiting_user_answers"
    gate_name = (normalize_text(workflow_stage) or "clarifying_questions") + "_pending"
    native_ui_directive = (
        "Use Claude Desktop/Codex native question UI first when available. "
        "Do not paraphrase these questions into inline chat unless native UI is unavailable or the user explicitly waives it."
    )
    fallback_directive = (
        "If native UI is unavailable, render one compact inline question block using only `questions_for_user`, "
        "keep the same wording and choices, and do not preview future stages."
    )
    directive = (
        "PAUSE before continuing. Ask only the current question, capture the answer or skip, "
        "then call the workflow tool again with the returned `question_loop_state` plus the new answers."
    )
    return {
        "workflow_stage": workflow_stage,
        "current_stage": workflow_stage,
        "stage_goal": stage_goal,
        "stage_status": "awaiting_user_answers" if workflow_stage else None,
        "stage_exit_criteria": stage_exit_criteria or [],
        "prelude_summary": normalize_text(prelude_summary) or None,
        "questions_for_user": questions_for_user,
        "interaction_batch": {
            "stage": "clarifying_questions",
            "ask_together": True,
            "max_questions_this_turn": len(questions_for_user),
            "do_not_prefetch_future_questions": True,
            "next_stage": "rewrite_or_build",
        },
        "coverage_map": {
            "missing_building_blocks": sorted(missing),
            "anti_pattern_slugs": sorted(anti_slugs),
            "answered_slots": sorted(answers.keys()),
        },
        "question_loop_state": updated_state,
        "host_action": {
            "must_pause": True,
            "blocking_gate": gate_name,
            "directive": directive,
            "preferred_interaction_surface": "native_host_question_ui",
            "fallback_interaction_surface": "compact_inline_question_block",
            "native_ui_directive": native_ui_directive,
            "fallback_rendering_directive": fallback_directive,
            "prompt_style": prompt_style,
            "do_not_preview_future_stages": True,
            "disallowed_actions_until_resume": [
                "do_not_ask_future_stage_questions",
                "do_not_synthesize_final_prompt",
                "do_not_browse_for_frameworks_instead_of_asking_this_question",
            ],
            "required_next_step": "Ask this question, then resume the workflow tool with updated answers.",
            "route_violation_if_ignored": "If the host skips this gate and keeps going, it is leaving the guided Prompt Compass workflow.",
        },
        "awaiting_question_ids": ensure_list(updated_state.get("awaiting_question_ids")),
        "answered_question_ids": ensure_list(updated_state.get("answered_question_ids")),
        "answered_slots": ensure_list(updated_state.get("answered_slots")),
        "stage_completion": {
            "question_count": len(questions_for_user),
            "awaiting_question_ids": ensure_list(updated_state.get("awaiting_question_ids")),
            "answered_slots": ensure_list(updated_state.get("answered_slots")),
            "exit_ready": False,
        },
        "resume_allowed": False,
    }


def _host_question(record: dict[str, Any], analysis: dict[str, Any]) -> dict[str, Any]:
    slot = normalize_text(record.get("slot"))
    reason = f"Fills the `{slot}` slot so the prompt can move from diagnosis to a usable prompt contract."
    plain = _plain_question_fields(slot, normalize_text(record.get("question_text")))
    return {
        "id": record["entry_id"],
        "slot": slot,
        "question": record.get("question_text"),
        "display_label": plain["display_label"],
        "plain_question": plain["plain_question"],
        "example_answers": plain["example_answers"],
        "assumption_if_skipped": plain["assumption_if_skipped"],
        "answer_type": record.get("answer_type"),
        "choices": _normalize_choices(record.get("choices", [])),
        "why_i_am_asking": reason,
        "what_this_can_change": record.get("what_changes", []),
        "on_skip": {
            "action": "use_inferred_or_empty_value",
            "value": record.get("on_skip", record.get("skip_behavior")),
        },
    }


def _normalize_choices(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped or stripped == "[]":
            return []
        try:
            parsed = json.loads(stripped)
        except json.JSONDecodeError:
            return []
        return parsed if isinstance(parsed, list) else []
    return []


def _plain_question_fields(slot: str, fallback_question: str) -> dict[str, Any]:
    fields: dict[str, dict[str, Any]] = {
        "objective": {
            "display_label": "What should the AI do?",
            "plain_question": "What are you trying to get the AI to do?",
            "example_answers": ["Write a clearer email", "Make a lesson plan", "Summarize my notes"],
            "assumption_if_skipped": "I will infer the main task from what you already wrote.",
        },
        "audience": {
            "display_label": "Who is this for?",
            "plain_question": "Who will read or use the AI's answer?",
            "example_answers": ["My boss", "Customers", "Students", "Just me"],
            "assumption_if_skipped": "I will assume the answer is for a general reader.",
        },
        "output_contract": {
            "display_label": "What should come back?",
            "plain_question": "What should the AI give you back, and how will you know it worked?",
            "example_answers": ["A short email", "A table", "A checklist", "A JSON object"],
            "assumption_if_skipped": "I will choose a simple structured format and a practical success test.",
        },
        "constraints": {
            "display_label": "Any must-haves?",
            "plain_question": "Is there anything the answer must include, avoid, or respect?",
            "example_answers": ["Keep it under 200 words", "Use a warm tone", "Do not invent facts"],
            "assumption_if_skipped": "I will only use the constraints already visible in your request.",
        },
        "context": {
            "display_label": "What context matters?",
            "plain_question": "What background should the AI know before answering?",
            "example_answers": ["This is for a client", "The reader is new to the topic", "Use the notes I pasted"],
            "assumption_if_skipped": "I will keep the background minimal and avoid adding facts you did not provide.",
        },
        "source_priority": {
            "display_label": "Which source wins?",
            "plain_question": "If your sources disagree, which one should the AI trust first?",
            "example_answers": ["My pasted notes", "The latest retrieved source", "Official documentation"],
            "assumption_if_skipped": "I will prioritize user-provided material first.",
        },
        "agent_mode": {
            "display_label": "Use Agent Mode?",
            "plain_question": "Do you want the standard advanced path, or Agent Mode with a small review committee?",
            "example_answers": ["Standard advanced", "Agent Mode"],
            "assumption_if_skipped": "I will stay in standard advanced mode.",
        },
    }
    default = {
        "display_label": slot.replace("_", " ").title() if slot else "Clarifying question",
        "plain_question": fallback_question,
        "example_answers": [],
        "assumption_if_skipped": "I will make a conservative assumption and keep going.",
    }
    return fields.get(normalize_text(slot).lower(), default)
