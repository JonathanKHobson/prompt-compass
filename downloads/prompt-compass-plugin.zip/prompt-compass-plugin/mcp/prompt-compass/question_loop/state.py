from __future__ import annotations

from typing import Any

from common import ensure_list, normalize_text


def _has_answer_value(value: Any) -> bool:
    if isinstance(value, dict):
        return any(_has_answer_value(item) for item in value.values())
    if isinstance(value, list):
        return any(_has_answer_value(item) for item in value)
    return bool(normalize_text(value))


def normalize_question_loop_state(question_loop_state: dict[str, Any] | None) -> dict[str, Any]:
    state = dict(question_loop_state or {})
    state.setdefault("answers", {})
    state.setdefault("asked_question_ids", [])
    state.setdefault("pending_question_ids", [])
    state.setdefault("awaiting_question_ids", ensure_list(state.get("pending_question_ids")))
    state.setdefault("answered_question_ids", [])
    state.setdefault("skipped_question_ids", [])
    state.setdefault("answered_slots", [])
    state.setdefault("question_slot_map", {})
    state.setdefault("round", 0)
    state.setdefault("question_count", len(state.get("asked_question_ids", [])))
    state.setdefault("mode", "")
    state.setdefault("current_stage", normalize_text(state.get("workflow_stage")))
    state.setdefault("workflow_stage", "")
    state.setdefault("stage_history", [])
    state.setdefault("stage_status", "")
    state.setdefault("stage_completion", {})
    state.setdefault("resume_allowed", False)
    state.setdefault("final_prompt_ready", False)
    state.setdefault("interaction_style", "")
    state.setdefault("interaction_pace", "")
    state.setdefault("agent_mode", "off")
    state.setdefault("host_capability_profile", {})
    state.setdefault("committee_depth", 0)
    state.setdefault("committee_run_id", "")
    state.setdefault("committee_plan_hash", "")
    state.setdefault("committee_confirmation_token", "")
    state.setdefault("committee_confirmation_issued_at", 0)
    state.setdefault("committee_confirmation_expires_at", 0)
    state.setdefault("committee_plan", {})
    state.setdefault("role_contracts", [])
    state.setdefault("judge_revision_state", {})
    state.setdefault("committee_stop_reason", "")
    state.setdefault("offer_agent_mode_prompt", False)
    state.setdefault("agent_mode_prompted", False)
    if not state["workflow_stage"] and state["current_stage"]:
        state["workflow_stage"] = state["current_stage"]
    if not state["current_stage"] and state["workflow_stage"]:
        state["current_stage"] = state["workflow_stage"]
    return state


def merge_question_loop_answers(
    question_loop_state: dict[str, Any] | None,
    question_answers: dict[str, Any] | list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    state = normalize_question_loop_state(question_loop_state)
    normalized_answers: dict[str, Any] = {}
    answered_ids = {normalize_text(item) for item in ensure_list(state.get("answered_question_ids")) if normalize_text(item)}
    skipped_ids = {normalize_text(item) for item in ensure_list(state.get("skipped_question_ids")) if normalize_text(item)}
    answered_slots = {normalize_text(item).lower() for item in ensure_list(state.get("answered_slots")) if normalize_text(item)}
    question_slot_map = {
        normalize_text(key): normalize_text(value).lower()
        for key, value in (state.get("question_slot_map") or {}).items()
        if normalize_text(key) and normalize_text(value)
    }
    awaiting_ids = [normalize_text(item) for item in ensure_list(state.get("awaiting_question_ids") or state.get("pending_question_ids")) if normalize_text(item)]

    for source in (state.get("answers"), question_answers):
        for slot, value, question_id, skipped in _normalized_answer_entries(source, question_slot_map):
            if not slot:
                continue
            if skipped:
                answered_slots.add(slot)
                if question_id:
                    skipped_ids.add(question_id)
                continue
            if _has_answer_value(value):
                normalized_answers[slot] = value
                answered_slots.add(slot)
                if question_id:
                    answered_ids.add(question_id)

    for question_id in awaiting_ids:
        slot = question_slot_map.get(question_id)
        if slot and slot in answered_slots:
            answered_ids.add(question_id)

    active_awaiting = [question_id for question_id in awaiting_ids if question_id not in answered_ids and question_id not in skipped_ids]
    state["answers"] = normalized_answers
    state["question_slot_map"] = question_slot_map
    state["answered_question_ids"] = sorted(answered_ids)
    state["skipped_question_ids"] = sorted(skipped_ids)
    state["answered_slots"] = sorted(answered_slots)
    state["awaiting_question_ids"] = active_awaiting
    state["pending_question_ids"] = active_awaiting
    state["resume_allowed"] = bool(answered_ids or skipped_ids or not active_awaiting)
    if active_awaiting:
        state["stage_status"] = "awaiting_user_answers"
    elif answered_ids or skipped_ids:
        state["stage_status"] = "answers_recorded"
    return state


def answered_slots(state: dict[str, Any]) -> list[str]:
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    return [normalize_text(key).lower() for key, value in answers.items() if _has_answer_value(value)]


def answered_count(state: dict[str, Any]) -> int:
    return len(answered_slots(state))


def register_pending_questions(state: dict[str, Any], questions: list[dict[str, Any]]) -> dict[str, Any]:
    updated = normalize_question_loop_state(state)
    ids = [question["id"] for question in questions]
    updated["pending_question_ids"] = ids
    updated["awaiting_question_ids"] = ids
    slot_map = dict(updated.get("question_slot_map") or {})
    for question in questions:
        question_id = normalize_text(question.get("id"))
        slot = normalize_text(question.get("slot")).lower()
        if question_id and slot:
            slot_map[question_id] = slot
    updated["question_slot_map"] = slot_map
    updated["asked_question_ids"] = ensure_list(updated.get("asked_question_ids")) + [item for item in ids if item not in ensure_list(updated.get("asked_question_ids"))]
    updated["question_count"] = len(ensure_list(updated.get("asked_question_ids")))
    updated["round"] = int(updated.get("round") or 0) + 1
    updated["resume_allowed"] = False
    return updated


def _normalized_answer_entries(
    source: dict[str, Any] | list[dict[str, Any]] | None,
    question_slot_map: dict[str, str],
) -> list[tuple[str, Any, str, bool]]:
    entries: list[tuple[str, Any, str, bool]] = []
    if isinstance(source, dict) and "answers" in source and isinstance(source["answers"], (dict, list)):
        source = source["answers"]
    if isinstance(source, dict):
        for raw_key, raw_value in source.items():
            slot, question_id = _resolve_slot_and_question_id(raw_key, raw_value, question_slot_map)
            if not slot:
                continue
            value, skipped = _extract_value_and_skip(raw_value)
            entries.append((slot, value, question_id, skipped))
        return entries
    for item in ensure_list(source):
        if not isinstance(item, dict):
            continue
        slot, question_id = _resolve_slot_and_question_id("", item, question_slot_map)
        if not slot:
            continue
        value, skipped = _extract_value_and_skip(item)
        entries.append((slot, value, question_id, skipped))
    return entries


def _resolve_slot_and_question_id(raw_key: str, raw_value: Any, question_slot_map: dict[str, str]) -> tuple[str, str]:
    question_id = ""
    slot = ""
    if isinstance(raw_value, dict):
        slot = normalize_text(raw_value.get("slot")).lower()
        question_id = normalize_text(raw_value.get("question_id") or raw_value.get("id"))
    raw_key_normalized = normalize_text(raw_key)
    if not slot and raw_key_normalized and not raw_key_normalized.startswith("pc:"):
        slot = raw_key_normalized.lower()
    if not question_id and raw_key_normalized.startswith("pc:"):
        question_id = raw_key_normalized
    if not slot and question_id:
        slot = question_slot_map.get(question_id, "")
    return slot, question_id


def _extract_value_and_skip(raw_value: Any) -> tuple[Any, bool]:
    if isinstance(raw_value, dict):
        if raw_value.get("skipped") is True:
            return "", True
        action = normalize_text(raw_value.get("action")).lower()
        if action in {"skip", "skipped"}:
            return "", True
        if any(key in raw_value for key in ("format", "success_test", "length", "sections")):
            value = {
                "format": normalize_text(raw_value.get("format")),
                "success_test": normalize_text(raw_value.get("success_test")),
                "length": normalize_text(raw_value.get("length")),
                "sections": ensure_list(raw_value.get("sections")),
            }
            return value, False
        for key in ("value", "answer", "response"):
            if key in raw_value:
                return _extract_value_and_skip(raw_value[key])
        for key in ("selected_options", "selected_option", "choice", "choices"):
            if key in raw_value:
                value = _extract_choice_value(raw_value[key])
                if _has_answer_value(value):
                    return value, False
        for key in ("free_text", "text", "note"):
            if key in raw_value and _has_answer_value(raw_value[key]):
                return normalize_text(raw_value[key]), False
        return "", False
    if isinstance(raw_value, list):
        value = _extract_choice_value(raw_value)
        return value, not _has_answer_value(value)
    value = normalize_text(raw_value)
    if value.lower() in {"skip", "skipped"}:
        return "", True
    return raw_value, False


def _extract_choice_value(raw_value: Any) -> Any:
    if isinstance(raw_value, list):
        values: list[Any] = []
        for item in raw_value:
            if isinstance(item, dict):
                candidate = item.get("value", item.get("label", item.get("text", "")))
            else:
                candidate = item
            if _has_answer_value(candidate):
                values.append(candidate)
        if len(values) == 1:
            return values[0]
        return values
    if isinstance(raw_value, dict):
        return raw_value.get("value", raw_value.get("label", raw_value.get("text", "")))
    return raw_value
