# Prompt Compass Anti-Pattern Library

- Ghost Audience
- Hallucination Bait
- Instruction Wall
- Premature Format Lock
- Role Collapse
- Scope Sprawl
- Stacked Adjectives
- Vague Compression
- Intent Dump
- Contextual Absences
