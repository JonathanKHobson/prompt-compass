# Prompt Compass Frameworks

- Golden Circle
- RACCCA
- COSTAR
- RISEN
- RTF
- CLEAR Prompting
- Chain-of-Thought
- SELF-DISCOVER
- Tree of Thoughts
- Least-to-Most
