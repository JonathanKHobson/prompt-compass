# Prompt Compass Model Profiles

Phase 1 supported models:

- Claude Sonnet
- Claude Opus
- GPT-4o
- GPT-4 Turbo
