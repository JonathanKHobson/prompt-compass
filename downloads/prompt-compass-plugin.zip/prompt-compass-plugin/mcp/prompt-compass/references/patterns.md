# Prompt Compass Patterns

Positive patterns:

- Context Ladder
- Output Contract First

Anti-patterns live in `references/anti-pattern-library.md`.
