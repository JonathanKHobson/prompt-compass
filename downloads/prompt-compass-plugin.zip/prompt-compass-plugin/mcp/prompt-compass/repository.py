from __future__ import annotations

import re
import sqlite3
from pathlib import Path
from typing import Any

from common import from_json, normalize_lookup_key, normalize_text, short_text, tokenize
from personal_overlay import PersonalOverlayStore

TAXONOMY_DEFAULTS = {
    "interaction_mode": "single_turn",
    "output_mode": "freeform",
    "grounding_mode": "none",
    "evaluation_mode": "none",
}

SEARCH_STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "for",
    "from",
    "how",
    "i",
    "in",
    "into",
    "is",
    "it",
    "me",
    "my",
    "of",
    "on",
    "or",
    "prompt",
    "prompting",
    "that",
    "the",
    "this",
    "to",
    "with",
    "you",
}

SEARCH_SYNONYM_GROUPS = [
    {"voice", "memo", "dictation", "spoken", "stream", "consciousness", "rambling", "cleanup", "clean", "transcript"},
    {"schema", "json", "structured", "parser", "machine", "readable", "fields", "contract"},
    {"tool", "tools", "function", "calling", "arguments", "contract", "boundary"},
    {"examples", "example", "few", "shot", "demonstration", "demonstrations", "pattern"},
    {"retrieval", "rag", "source", "sources", "grounding", "quote", "evidence", "passage"},
    {"rewrite", "improve", "refine", "cleanup", "tighten", "polish"},
]

class PromptCompassRepository:
    def __init__(
        self,
        db_path: str | Path,
        *,
        personal_db_path: str | Path | None = None,
        personal_vault_root: str | Path | None = None,
    ) -> None:
        self.db_path = Path(db_path).expanduser().resolve()
        if not self.db_path.exists():
            raise FileNotFoundError(
                f"Prompt Compass DB not found at {self.db_path}. Run python3 scripts/build_prompt_compass_db.py first."
            )
        self._connection = sqlite3.connect(str(self.db_path))
        self._connection.row_factory = sqlite3.Row
        self._validate_core_db()
        self.personal = PersonalOverlayStore(db_path=personal_db_path, vault_root=personal_vault_root)

    def close(self) -> None:
        self._connection.close()
        self.personal.close()

    def _fetch_all(self, query: str, params: tuple[Any, ...] | list[Any] = ()) -> list[sqlite3.Row]:
        cursor = self._connection.execute(query, params)
        rows = cursor.fetchall()
        cursor.close()
        return rows

    def _fetch_one(self, query: str, params: tuple[Any, ...] | list[Any] = ()) -> sqlite3.Row | None:
        cursor = self._connection.execute(query, params)
        row = cursor.fetchone()
        cursor.close()
        return row

    def _validate_core_db(self) -> None:
        try:
            table_rows = self._fetch_all(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name IN ('records', 'aliases', 'records_fts')"
            )
        except sqlite3.DatabaseError as exc:
            raise RuntimeError(
                f"Prompt Compass DB at {self.db_path} could not be opened cleanly. "
                "Rebuild it with `.venv/bin/python scripts/build_prompt_compass_db.py`."
            ) from exc
        table_names = {row["name"] for row in table_rows}
        expected = {"records", "aliases", "records_fts"}
        if table_names != expected:
            raise RuntimeError(
                f"Prompt Compass DB at {self.db_path} is missing the expected compiled schema. "
                "Rebuild it with `.venv/bin/python scripts/build_prompt_compass_db.py`."
            )
        row = self._fetch_one("SELECT COUNT(*) AS count FROM records")
        record_count = int(row["count"]) if row else 0
        if record_count <= 0:
            raise RuntimeError(
                f"Prompt Compass DB at {self.db_path} is blank and cannot serve the MCP. "
                "Rebuild it with `.venv/bin/python scripts/build_prompt_compass_db.py`."
            )

    def _record_from_row(self, row: sqlite3.Row | None) -> dict[str, Any] | None:
        if row is None:
            return None
        record = {
            "entry_id": row["entry_id"],
            "record_type": row["record_type"],
            "name": row["name"],
            "slug": row["slug"],
            "summary": row["summary"],
            "definition": row["definition"],
            "prompt_types": from_json(row["prompt_types_json"], []),
            "subject_areas": from_json(row["subject_areas_json"], []),
            "model_targets": from_json(row["model_targets_json"], []),
            "signals": from_json(row["signals_json"], []),
            "contraindications": from_json(row["contraindications_json"], []),
            "template": from_json(row["template_json"], None),
            "examples": from_json(row["examples_json"], []),
            "fixes": from_json(row["fixes_json"], []),
            "related_entry_ids": from_json(row["related_entry_ids_json"], []),
            "tags": from_json(row["tags_json"], []),
            "source_refs": from_json(row["source_refs_json"], []),
            "quality_flags": from_json(row["quality_flags_json"], []),
            "source_priority": row["source_priority"],
        }
        extra = from_json(row["extra_json"], {})
        if isinstance(extra, dict):
            record.update(extra)
        record.setdefault("record_layer", "core")
        record.setdefault("mutable", False)
        record.setdefault("source_of_truth", "compiled_core")
        record.setdefault("driver_eligible", record.get("curation_status") == "core")
        record.setdefault("markdown_path", None)
        return record

    def _core_list_all(self, record_type: str | None = None) -> list[dict[str, Any]]:
        if record_type:
            rows = self._fetch_all(
                "SELECT * FROM records WHERE record_type = ? ORDER BY source_priority DESC, name COLLATE NOCASE",
                (record_type,),
            )
        else:
            rows = self._fetch_all("SELECT * FROM records ORDER BY source_priority DESC, name COLLATE NOCASE")
        return [record for row in rows if (record := self._record_from_row(row))]

    def list_all(self, record_type: str | None = None) -> list[dict[str, Any]]:
        records = [*self._core_list_all(record_type=record_type), *self.personal.list_records(record_type=record_type)]
        records.sort(
            key=lambda item: (
                -int(item.get("source_priority", 0)),
                0 if normalize_text(item.get("record_layer")) == "core" else 1,
                normalize_text(item.get("name")).lower(),
            )
        )
        return records

    def list_records(self, record_type: str | None = None, *, catalog_scope: str = "core_first") -> list[dict[str, Any]]:
        scope = normalize_text(catalog_scope) or "core_first"
        if scope == "core_only":
            return self._core_list_all(record_type=record_type)
        if scope == "merged":
            records = [*self._core_list_all(record_type=record_type), *self.personal.list_records(record_type=record_type)]
            records.sort(
                key=lambda item: (
                    -int(item.get("source_priority", 0)),
                    normalize_text(item.get("name")).lower(),
                )
            )
            return records
        return self.list_all(record_type=record_type)

    def get_entry(self, entry_id: str) -> dict[str, Any]:
        record = self._record_from_row(self._fetch_one("SELECT * FROM records WHERE entry_id = ?", (entry_id,)))
        if not record:
            record = self.personal.get_record(entry_id)
        if not record:
            return {"found": False, "entry_id": entry_id}
        return {"found": True, **record}

    def resolve_entry(self, value: str, record_types: list[str] | None = None) -> dict[str, Any]:
        lookup = normalize_lookup_key(value)
        if not lookup:
            return {"found": False, "query": value, "nearest_matches": []}
        row = self._fetch_one(
            """
            SELECT r.*
            FROM aliases a
            JOIN records r ON r.entry_id = a.entry_id
            WHERE a.alias_norm = ?
            ORDER BY r.source_priority DESC
            LIMIT 1
            """,
            (lookup,),
        )
        record = self._record_from_row(row)
        if record and self._record_type_allowed(record, record_types):
            return {"found": True, **record}
        personal = self.personal.resolve_record(value, record_types=record_types)
        if personal.get("found"):
            return personal
        nearest_matches = self.nearest_matches(value, record_types=record_types, limit=5)
        return {"found": False, "query": value, "nearest_matches": nearest_matches}

    def nearest_matches(self, value: str, record_types: list[str] | None = None, limit: int = 5) -> list[dict[str, Any]]:
        tokens = set(tokenize(value))
        candidates = self.list_all()
        scored: list[tuple[float, dict[str, Any]]] = []
        for record in candidates:
            if not self._record_type_allowed(record, record_types):
                continue
            haystack = " ".join(
                [
                    normalize_text(record.get("name")),
                    normalize_text(record.get("slug")),
                    " ".join(normalize_text(alias) for alias in record.get("aliases", [])),
                ]
            ).lower()
            hay_tokens = set(tokenize(haystack))
            overlap = len(tokens & hay_tokens)
            if not overlap and normalize_lookup_key(value) not in normalize_lookup_key(haystack):
                continue
            score = overlap * 10
            if normalize_lookup_key(value) == normalize_lookup_key(record.get("name")):
                score += 100
            if normalize_lookup_key(value) == normalize_lookup_key(record.get("slug")):
                score += 80
            scored.append((score, record))
        scored.sort(key=lambda item: (-item[0], item[1]["name"].lower()))
        return [
            {
                "entry_id": record["entry_id"],
                "record_type": record["record_type"],
                "name": record["name"],
                "summary": record.get("summary"),
            }
            for _, record in scored[:limit]
        ]

    def search_prompt_patterns(
        self,
        query: str,
        record_types: list[str] | None = None,
        prompt_type: str | None = None,
        subject_area: str | None = None,
        model_target: str | None = None,
        interaction_mode: str | None = None,
        output_mode: str | None = None,
        grounding_mode: str | None = None,
        evaluation_mode: str | None = None,
        limit: int = 10,
    ) -> dict[str, Any]:
        safe_limit = max(1, min(limit, 25))
        query_norm = normalize_lookup_key(query)
        exact_results: list[tuple[int, dict[str, Any]]] = []
        seen_entry_ids: set[str] = set()
        records = self.list_all()

        if query_norm:
            for record in records:
                if not self._record_matches_filters(
                    record,
                    record_types,
                    prompt_type,
                    subject_area,
                    model_target,
                    interaction_mode,
                    output_mode,
                    grounding_mode,
                    evaluation_mode,
                ):
                    continue
                match_class = self._exact_match_class(record, query_norm)
                if match_class is None:
                    continue
                exact_results.append((match_class, record))
            exact_results.sort(
                key=lambda item: (
                    item[0],
                    0 if normalize_text(item[1].get("record_layer")) == "core" else 1,
                    -int(item[1].get("source_priority", 0)),
                    -int(item[1].get("search_weight", 0)),
                    item[1]["name"].lower(),
                )
            )

        results: list[dict[str, Any]] = []
        for match_class, record in exact_results:
            seen_entry_ids.add(record["entry_id"])
            results.append(
                self._search_result_card(
                    record,
                    score=self._exact_match_score(match_class),
                    match_type=self._match_type_name(match_class),
                    query=query,
                )
            )
            if len(results) >= safe_limit:
                break
        reranked: list[tuple[float, dict[str, Any], str]] = []
        for position, record in enumerate(records):
            if record["entry_id"] in seen_entry_ids:
                continue
            if not self._record_matches_filters(
                record,
                record_types,
                prompt_type,
                subject_area,
                model_target,
                interaction_mode,
                output_mode,
                grounding_mode,
                evaluation_mode,
            ):
                continue
            relevance = self._search_relevance_details(record, query)
            if self._skip_irrelevant_search_result(
                query,
                relevance,
                prompt_type=prompt_type,
                subject_area=subject_area,
                interaction_mode=interaction_mode,
                output_mode=output_mode,
                grounding_mode=grounding_mode,
                evaluation_mode=evaluation_mode,
            ):
                continue
            reranked.append(
                (
                    self._search_rerank_score(
                        record,
                        position=position,
                        query=query,
                        prompt_type=prompt_type,
                        subject_area=subject_area,
                        model_target=model_target,
                        interaction_mode=interaction_mode,
                        output_mode=output_mode,
                        grounding_mode=grounding_mode,
                        evaluation_mode=evaluation_mode,
                        relevance_details=relevance,
                    ),
                    record,
                    "hybrid_relevance",
                )
            )
        reranked.sort(key=lambda item: (-item[0], item[1]["name"].lower()))
        for score, record, match_type in reranked:
            results.append(self._search_result_card(record, score=score, match_type=match_type, query=query))
            if len(results) >= safe_limit:
                break
        return {
            "query": query,
            "filters": {
                "record_types": record_types or [],
                "prompt_type": prompt_type,
                "subject_area": subject_area,
                "model_target": model_target,
                "interaction_mode": interaction_mode,
                "output_mode": output_mode,
                "grounding_mode": grounding_mode,
                "evaluation_mode": evaluation_mode,
                "limit": safe_limit,
            },
            "results": results,
        }

    def _search_result_card(self, record: dict[str, Any], *, score: float, match_type: str, query: str = "") -> dict[str, Any]:
        relevance = self._search_relevance_details(record, query)
        return {
            "entry_id": record["entry_id"],
            "record_type": record["record_type"],
            "name": record["name"],
            "summary": record.get("summary"),
            "tags": record.get("tags", []),
            "related_entry_ids": record.get("related_entry_ids", []),
            "template_preview": short_text(record.get("template"), 140),
            "snippet": short_text(record.get("definition") or record.get("summary"), 180),
            "score": round(float(score), 2),
            "match_type": match_type,
            "matched_terms": relevance["matched_terms"],
            "matched_phrases": relevance["matched_phrases"],
            "relevance_reason": relevance["relevance_reason"],
            "curation_status": record.get("curation_status"),
            "corpus_zone": record.get("corpus_zone"),
            "family": record.get("family"),
            "origin_bucket": record.get("origin_bucket"),
            "driver_eligible": record.get("driver_eligible"),
            "ambiguity_status": record.get("ambiguity_status"),
            "weight_reason": record.get("weight_reason"),
            "decision": record.get("decision"),
            "record_layer": record.get("record_layer", "core"),
            "mutable": bool(record.get("mutable", False)),
            "markdown_path": record.get("markdown_path"),
            "interaction_mode": record.get("interaction_mode"),
            "output_mode": record.get("output_mode"),
            "grounding_mode": record.get("grounding_mode"),
            "evaluation_mode": record.get("evaluation_mode"),
            "capability_tags": record.get("capability_tags", []),
        }

    def _exact_match_class(self, record: dict[str, Any], query_norm: str) -> int | None:
        slug_norm = normalize_lookup_key(record.get("slug"))
        name_norm = normalize_lookup_key(record.get("name"))
        alias_norms = [
            normalize_lookup_key(alias)
            for alias in record.get("aliases", [])
            if normalize_lookup_key(alias) not in {slug_norm, name_norm}
        ]
        if query_norm in alias_norms:
            return 0
        if query_norm == slug_norm:
            return 1
        if query_norm == name_norm:
            return 2
        return None

    def _exact_match_score(self, match_class: int) -> float:
        if match_class == 0:
            return 1000.0
        if match_class == 1:
            return 950.0
        return 900.0

    def _match_type_name(self, match_class: int) -> str:
        return {0: "exact_alias", 1: "exact_slug", 2: "exact_title"}.get(match_class, "exact")

    def _search_rerank_score(
        self,
        record: dict[str, Any],
        *,
        position: int,
        query: str,
        prompt_type: str | None,
        subject_area: str | None,
        model_target: str | None,
        interaction_mode: str | None = None,
        output_mode: str | None = None,
        grounding_mode: str | None = None,
        evaluation_mode: str | None = None,
        relevance_details: dict[str, Any] | None = None,
    ) -> float:
        tool_fit = record.get("tool_fit", {}) if isinstance(record.get("tool_fit"), dict) else {}
        relevance = relevance_details or self._search_relevance_details(record, query)
        query_tokens = set(self._search_query_terms(query))
        query_text = normalize_text(query).lower()
        related_tokens = set(tokenize(" ".join(record.get("related_entry_ids", []))))
        tag_tokens = set(tokenize(" ".join(record.get("tags", []))))
        capability_tokens = set(tokenize(" ".join(record.get("capability_tags", []))))
        name_tokens = set(tokenize(record.get("name")))
        slug_tokens = set(tokenize(record.get("slug")))
        summary_tokens = set(tokenize(record.get("summary")))
        family = normalize_text(record.get("family")).lower()
        origin_bucket = normalize_text(record.get("origin_bucket")).lower()
        ambiguity_status = normalize_text(record.get("ambiguity_status")).lower()
        record_type = normalize_text(record.get("record_type"))
        record_name = normalize_text(record.get("name")).lower()
        record_slug = normalize_text(record.get("slug")).lower()
        family_tokens_map = {
            "role_goal_output_control": {"role", "audience", "task", "instruction", "output", "format", "constraint"},
            "decomposition_sequencing": {"step", "sequence", "decompose", "reasoning", "scratchpad", "parallel"},
            "context_grounding": {"context", "source", "grounding", "audience", "history", "culture"},
            "evaluation_reflection": {"evaluate", "evaluation", "review", "rubric", "confidence", "critique", "bias"},
            "task_shape": {"extract", "transform", "generate", "rewrite", "reduce", "expand"},
            "systems_architecture": {"system", "architecture", "composition", "conversation", "layered", "master"},
            "support_terms": {"term", "concept", "prompt"},
        }
        record_type_bonus = {
            "strategy": 16,
            "pattern": 16,
            "technique": 16,
            "framework": 15,
            "anti_pattern": 14,
            "term": 12,
            "question": 4,
            "model_profile": 2,
        }
        origin_bucket_bonus = {
            "methodology_audit": 5,
            "methodology_preflight": 4,
            "other_adjacent": 3,
            "reasoning_frameworks": 2,
            "thinking_lenses": 1,
            "biases_ai": 1,
            "heuristics": 0,
        }
        ambiguity_penalty = {
            "normalized_unknown": 4,
            "alias_guarded": 2,
            "overlap_guarded": 1,
            "clear": 0,
        }
        has_query = bool(query_tokens)
        score = float(relevance["score"])
        authority_factor = 0.25 if has_query else 1.0
        score += float(record.get("source_priority", 0)) * authority_factor
        score += float(record_type_bonus.get(record_type, 0))
        score += float(record.get("search_weight", 0))
        score += float(tool_fit.get("search", 0)) * 5
        score += float(origin_bucket_bonus.get(origin_bucket, 0))
        score -= float(ambiguity_penalty.get(ambiguity_status, 0))
        if record.get("decision") == "promote_to_core":
            score += 3
        if record_type == "model_profile" and not (query_tokens & {"model", "gpt", "claude", "gemini", "sonnet", "opus", "flash", "turbo"}):
            score -= 40
        if record_type == "question" and not (query_tokens & {"question", "questions", "ask", "clarify", "clarifying", "success", "format", "audience"}):
            score -= 12
        if prompt_type and prompt_type in record.get("prompt_types", []):
            score += 8
        if subject_area:
            subjects = set(record.get("subject_areas", []))
            if subject_area in subjects:
                score += 6
            elif "general" in subjects:
                score += 3
        if model_target:
            targets = set(normalize_text(value) for value in record.get("model_targets", []) if normalize_text(value))
            variants = self.model_target_variants(model_target)
            if variants & targets:
                score += 6
            elif "generic" in targets:
                score += 2
        if interaction_mode:
            record_mode = normalize_text(record.get("interaction_mode"))
            if record_mode == normalize_text(interaction_mode):
                score += 14
            elif record_mode == TAXONOMY_DEFAULTS["interaction_mode"]:
                score += 2
        if output_mode:
            record_mode = normalize_text(record.get("output_mode"))
            if record_mode == normalize_text(output_mode):
                score += 18 if normalize_text(output_mode) == "schema_bound" else 14
            elif record_mode == TAXONOMY_DEFAULTS["output_mode"]:
                score += 2
        if grounding_mode:
            record_mode = normalize_text(record.get("grounding_mode"))
            if record_mode == normalize_text(grounding_mode):
                score += 16 if normalize_text(grounding_mode) in {"retrieval", "quote_first"} else 12
            elif record_mode == TAXONOMY_DEFAULTS["grounding_mode"]:
                score += 2
        if evaluation_mode:
            record_mode = normalize_text(record.get("evaluation_mode"))
            if record_mode == normalize_text(evaluation_mode):
                score += 16 if normalize_text(evaluation_mode) in {"rubric", "grader"} else 12
            elif record_mode == TAXONOMY_DEFAULTS["evaluation_mode"]:
                score += 2
        name_overlap = len(query_tokens & name_tokens)
        if name_overlap:
            score += name_overlap * 10
        slug_overlap = len(query_tokens & slug_tokens)
        if slug_overlap:
            score += slug_overlap * 8
        summary_overlap = len(query_tokens & summary_tokens)
        if summary_overlap:
            score += summary_overlap * 3
        if record_name and record_name in query_text:
            score += 20
        if record_slug and record_slug.replace("-", " ") in query_text:
            score += 18
        capability_overlap = len(query_tokens & capability_tokens)
        if capability_overlap:
            score += capability_overlap * 8
        if query_tokens & related_tokens:
            score += 3
        if query_tokens & tag_tokens:
            score += 4
        family_tokens = family_tokens_map.get(family, set())
        if query_tokens & family_tokens:
            score += 4
        if output_mode == "schema_bound" and (
            {"schema", "json"} & name_tokens
            or {"schema", "json", "parser", "structured"} & tag_tokens
            or {"structured_output", "json_schema", "parser_aware"} & set(record.get("capability_tags", []))
        ):
            score += 18
        if output_mode == "structured" and (
            {"structured", "yaml", "xml", "delimiter", "output"} & name_tokens
            or {"structured_output", "xml_structure"} & set(record.get("capability_tags", []))
        ):
            score += 12
        if interaction_mode == "multimodal" and output_mode == "structured" and record_slug == "structured-output-steering":
            score += 18
        if {"issue", "issues", "checklist", "list"} & query_tokens and record_slug == "structured-output-steering":
            score += 10
        if evaluation_mode in {"rubric", "grader"} and (
            {"eval", "evaluation", "judge", "grader", "rubric"} & name_tokens
            or {"judge_evaluation"} & set(record.get("capability_tags", []))
        ):
            score += 16
        if interaction_mode in {"tool_calling", "agentic"} and (
            {"tool", "function", "agent", "stop", "boundary"} & (name_tokens | tag_tokens)
            or {"tool_use", "function_calling", "agentic_tool_use", "stop_conditions"} & set(record.get("capability_tags", []))
        ):
            score += 16
        if grounding_mode in {"retrieval", "quote_first"} and (
            {"retrieval", "quote", "evidence", "source"} & (name_tokens | tag_tokens)
            or {"retrieval_grounding", "quote_first_evidence", "source_priority", "untrusted_context"} & set(record.get("capability_tags", []))
        ):
            score += 16
        if {"context", "carry", "compaction", "priority", "source"} & query_tokens and (
            {"context", "source", "carry", "priority"} & (name_tokens | tag_tokens)
            or {"context_engineering", "context_compaction", "source_priority"} & set(record.get("capability_tags", []))
        ):
            score += 12
        if {"rewrite", "improve", "better", "refine"} & query_tokens and record_slug == "prompt-refinement-first":
            score += 24
        if {"clearer", "sharper", "strategic", "compelling", "polished", "professional"} & query_tokens and record_slug in {
            "trait-stack-output-control",
            "top-three-traits-ranking",
        }:
            score += 20
        if {"stacked", "adjectives"} <= query_tokens and record_slug in {
            "trait-stack-output-control",
            "top-three-traits-ranking",
        }:
            score += 24
        if {"long", "context", "documents", "transcripts", "packet", "sources"} & query_tokens and record_slug in {
            "long-context-layout",
            "context-injection-via-source-pack",
            "one-primary-deliverable-narrowing",
        }:
            score += 18
        if {"quote", "quotes", "first", "evidence", "passages"} & query_tokens and record_slug == "quote-first-evidence-extraction":
            score += 22
        if grounding_mode == "quote_first" and record_slug == "quote-first-evidence-extraction":
            score += 20
        if grounding_mode == "retrieval" and {"quote", "quotes", "passages", "evidence"} & query_tokens and record_slug == "quote-first-evidence-extraction":
            score += 12
        if {"transcript", "packet"} & query_tokens and record_slug == "quote-first-evidence-extraction":
            score += 10
        if {"rubric", "score", "weaknesses", "strengths", "rewrite", "recommendation"} & query_tokens and record_slug == "prompt-based-evaluation":
            score += 20
        if output_mode == "schema_bound" and evaluation_mode in {"rubric", "grader"} and record_slug == "prompt-based-evaluation":
            score += 16
        if has_query and record.get("curation_status") == "core" and relevance["coverage"] < 0.25:
            score -= 35
        score += max(12 - position, 0) if has_query else max(20 - position, 0)
        return score

    def _search_query_terms(self, query: str) -> list[str]:
        terms: list[str] = []
        seen: set[str] = set()
        for token in tokenize(query):
            if len(token) < 2 or token in SEARCH_STOPWORDS:
                continue
            if token in seen:
                continue
            seen.add(token)
            terms.append(token)
        return terms

    def _expanded_search_terms(self, query: str) -> set[str]:
        terms = set(self._search_query_terms(query))
        expanded = set(terms)
        for group in SEARCH_SYNONYM_GROUPS:
            if terms & group:
                expanded |= group
        return expanded

    def _search_relevance_details(self, record: dict[str, Any], query: str) -> dict[str, Any]:
        original_terms = set(self._search_query_terms(query))
        expanded_terms = self._expanded_search_terms(query)
        if not original_terms:
            return {
                "score": 0.0,
                "matched_terms": [],
                "matched_phrases": [],
                "coverage": 0.0,
                "relevance_reason": "Browse result; no query terms were supplied.",
            }
        name_text = " ".join(
            [
                normalize_text(record.get("name")),
                normalize_text(record.get("slug")),
                " ".join(normalize_text(alias) for alias in record.get("aliases", [])),
            ]
        ).lower()
        tag_text = " ".join(
            [
                " ".join(normalize_text(tag) for tag in record.get("tags", [])),
                " ".join(normalize_text(tag) for tag in record.get("capability_tags", [])),
                " ".join(normalize_text(signal) for signal in record.get("signals", [])),
            ]
        ).lower()
        body_text = " ".join(
            [
                normalize_text(record.get("summary")),
                normalize_text(record.get("definition")),
                normalize_text(record.get("curation_note")),
                normalize_text(record.get("template")),
            ]
        ).lower()
        combined_text = f"{name_text} {tag_text} {body_text}"
        name_tokens = set(tokenize(name_text))
        tag_tokens = set(tokenize(tag_text))
        body_tokens = set(tokenize(body_text))
        score = 0.0
        matched_terms: set[str] = set()
        for term in expanded_terms:
            if term in name_tokens:
                score += 28
                matched_terms.add(term)
            elif term in tag_tokens:
                score += 18
                matched_terms.add(term)
            elif term in body_tokens:
                score += 8
                matched_terms.add(term)
        matched_original = sorted(term for term in original_terms if term in matched_terms or re.search(rf"\b{re.escape(term)}\b", combined_text))
        phrase_candidates = self._query_phrases(query)
        matched_phrases = [phrase for phrase in phrase_candidates if phrase in combined_text]
        if matched_phrases:
            score += 35 * len(matched_phrases)
        title_norm = normalize_lookup_key(record.get("name"))
        slug_norm = normalize_lookup_key(record.get("slug"))
        query_norm = normalize_lookup_key(query)
        if query_norm and (query_norm in title_norm or query_norm in slug_norm):
            score += 45
        coverage = len(set(matched_original)) / max(len(original_terms), 1)
        score += coverage * 80
        if "voice" in original_terms and "dictation" in original_terms and "voice memo" in combined_text:
            score += 80
        if {"stream", "consciousness"} <= original_terms and "stream of consciousness" in combined_text:
            score += 60
        reason_bits: list[str] = []
        if matched_phrases:
            reason_bits.append("matched phrase " + ", ".join(matched_phrases[:2]))
        if matched_original:
            reason_bits.append("matched terms " + ", ".join(matched_original[:6]))
        if not reason_bits and matched_terms:
            reason_bits.append("matched related terms " + ", ".join(sorted(matched_terms)[:6]))
        if not reason_bits:
            reason_bits.append("low lexical overlap; included only because filters or taxonomy matched")
        return {
            "score": score,
            "matched_terms": matched_original or sorted(matched_terms)[:8],
            "matched_phrases": matched_phrases[:5],
            "coverage": coverage,
            "relevance_reason": "; ".join(reason_bits) + ".",
        }

    def _query_phrases(self, query: str) -> list[str]:
        text = normalize_text(query).lower()
        phrases = [
            "voice memo",
            "stream of consciousness",
            "prompt cleanup",
            "json schema",
            "function calling",
            "tool calling",
            "tool use",
            "few shot",
            "few-shot",
            "quote first",
            "retrieval grounding",
        ]
        return [phrase for phrase in phrases if phrase in text]

    def _skip_irrelevant_search_result(
        self,
        query: str,
        relevance: dict[str, Any],
        *,
        prompt_type: str | None,
        subject_area: str | None,
        interaction_mode: str | None,
        output_mode: str | None,
        grounding_mode: str | None,
        evaluation_mode: str | None,
    ) -> bool:
        if not self._search_query_terms(query):
            return False
        if relevance["matched_terms"] or relevance["matched_phrases"] or relevance["coverage"] >= 0.15:
            return False
        # Taxonomy-filtered searches can include close records even when wording differs.
        return not any([prompt_type, subject_area, interaction_mode, output_mode, grounding_mode, evaluation_mode])

    def list_anti_patterns(
        self,
        limit: int = 25,
        severity: str | None = None,
        prompt_type: str | None = None,
    ) -> dict[str, Any]:
        results: list[dict[str, Any]] = []
        for record in self.list_all(record_type="anti_pattern"):
            if severity and normalize_text(record.get("severity_default")) != normalize_text(severity):
                continue
            if prompt_type and prompt_type not in record.get("prompt_types", []):
                continue
            results.append(record)
            if len(results) >= max(1, min(limit, 50)):
                break
        return {
            "count": len(results),
            "severity": severity,
            "prompt_type": prompt_type,
            "results": results,
        }

    def save_personal_record(
        self,
        record: dict[str, Any],
        *,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict[str, Any]:
        return self.personal.save_personal_record(record, confirm=confirm, confirmation_token=confirmation_token)

    def seed_personal_overlay(
        self,
        seed_answers: dict[str, Any] | None = None,
        *,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict[str, Any]:
        return self.personal.seed_personal_overlay(seed_answers, confirm=confirm, confirmation_token=confirmation_token)

    def get_preferences(self) -> dict[str, Any]:
        return self.personal.get_preferences()

    def manage_preferences(
        self,
        preferences: dict[str, Any] | None = None,
        *,
        reset: bool = False,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict[str, Any]:
        return self.personal.manage_preferences(
            preferences,
            reset=reset,
            confirm=confirm,
            confirmation_token=confirmation_token,
        )

    def delete_personal_record(
        self,
        value: str,
        *,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict[str, Any]:
        personal = self.personal.resolve_record(value)
        if personal.get("found"):
            return self.personal.delete_personal_record(value, confirm=confirm, confirmation_token=confirmation_token)
        core = self.resolve_entry(value)
        if core.get("found") and normalize_text(core.get("record_layer")) == "core":
            return {
                "deleted": False,
                "found": True,
                "refused": True,
                "reason": "Core Prompt Compass records are immutable. Use flag_core_record instead.",
                "record": {
                    "entry_id": core.get("entry_id"),
                    "name": core.get("name"),
                    "record_type": core.get("record_type"),
                    "record_layer": "core",
                    "mutable": False,
                },
            }
        return {"deleted": False, "found": False, "query": value}

    def save_prompt_library_item(
        self,
        item: dict[str, Any],
        *,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict[str, Any]:
        return self.personal.save_prompt_library_item(item, confirm=confirm, confirmation_token=confirmation_token)

    def delete_prompt_library_item(
        self,
        value: str,
        *,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict[str, Any]:
        return self.personal.delete_prompt_library_item(value, confirm=confirm, confirmation_token=confirmation_token)

    def search_prompt_library(
        self,
        query: str,
        *,
        asset_kind: str | None = None,
        model_target: str | None = None,
        target_surface: str | None = None,
        tags: list[str] | None = None,
        limit: int = 10,
    ) -> dict[str, Any]:
        return self.personal.search_prompt_library(
            query,
            asset_kind=asset_kind,
            model_target=model_target,
            target_surface=target_surface,
            tags=tags,
            limit=limit,
        )

    def prompt_library_item_count(self) -> int:
        return self.personal.prompt_library_item_count()

    def get_prompt_library_item(self, value: str) -> dict[str, Any]:
        return self.personal.get_prompt_library_item(value)

    def flag_core_record(
        self,
        target_entry_id: str,
        reason: str,
        suggested_action: str,
        notes: str | None = None,
    ) -> dict[str, Any]:
        core = self.get_entry(target_entry_id)
        if not core.get("found") or normalize_text(core.get("record_layer")) != "core":
            return {
                "flagged": False,
                "found": False,
                "target_entry_id": target_entry_id,
                "reason": "Only core Prompt Compass records can be flagged through this tool.",
            }
        return self.personal.flag_core_record(target_entry_id, reason, suggested_action, notes=notes)

    def list_core_review_flags(
        self,
        *,
        status: str | None = None,
        target_entry_id: str | None = None,
        limit: int = 25,
    ) -> dict[str, Any]:
        return self.personal.list_core_review_flags(status=status, target_entry_id=target_entry_id, limit=limit)

    def sync_personal_overlay_from_markdown(self) -> dict[str, Any]:
        return self.personal.sync_from_markdown()

    def get_model_profile(self, model_name: str) -> dict[str, Any]:
        return self.resolve_entry(model_name, record_types=["model_profile"])

    def supported_model_ids(self) -> list[str]:
        ids = [
            normalize_text(record.get("model_id") or record.get("slug"))
            for record in self.list_all(record_type="model_profile")
            if normalize_text(record.get("model_id") or record.get("slug"))
        ]
        return list(dict.fromkeys(ids))

    def model_target_variants(self, model_name: str) -> set[str]:
        resolved = self.resolve_entry(model_name, record_types=["model_profile"])
        if not resolved.get("found"):
            normalized = normalize_text(model_name)
            return {normalized} if normalized else set()
        variants = {
            normalize_text(resolved.get("model_id") or resolved.get("slug")),
            normalize_text(resolved.get("slug")),
        }
        for field in ("compatibility_ids", "legacy_model_ids"):
            variants.update(normalize_text(value) for value in resolved.get(field, []) if normalize_text(value))
        return {value for value in variants if value}

    def _record_type_allowed(self, record: dict[str, Any], record_types: list[str] | None) -> bool:
        if not record_types:
            return True
        return record.get("record_type") in set(record_types)

    def _record_matches_filters(
        self,
        record: dict[str, Any],
        record_types: list[str] | None,
        prompt_type: str | None,
        subject_area: str | None,
        model_target: str | None,
        interaction_mode: str | None = None,
        output_mode: str | None = None,
        grounding_mode: str | None = None,
        evaluation_mode: str | None = None,
    ) -> bool:
        if not self._record_type_allowed(record, record_types):
            return False
        if prompt_type:
            prompt_types = {normalize_text(value) for value in record.get("prompt_types", []) if normalize_text(value)}
            if prompt_types and prompt_type not in prompt_types:
                # Prompt type is a ranking hint, not a hard search exclusion.
                # Keep adjacent prompt primitives searchable and let scoring sort them.
                if normalize_text(record.get("record_type")) in {"question", "model_profile"}:
                    return False
        if subject_area and normalize_text(subject_area) != "general":
            subjects = {normalize_text(value) for value in record.get("subject_areas", []) if normalize_text(value)}
            if subjects and subject_area not in subjects and "general" not in subjects:
                # Subject area is a useful ranking hint, but it is too coarse to be a hard
                # exclusion for broadly applicable prompt-engineering records.
                if normalize_text(record.get("record_type")) in {"question", "model_profile"}:
                    return False
        if model_target and not self._record_supports_model(record, model_target):
            return False
        if not self._matches_taxonomy_filter(record, "interaction_mode", interaction_mode):
            return False
        if not self._matches_taxonomy_filter(record, "output_mode", output_mode):
            return False
        if not self._matches_taxonomy_filter(record, "grounding_mode", grounding_mode):
            return False
        if not self._matches_taxonomy_filter(record, "evaluation_mode", evaluation_mode):
            return False
        return True

    def _record_supports_model(self, record: dict[str, Any], model_target: str) -> bool:
        targets = [normalize_text(value) for value in record.get("model_targets", []) if normalize_text(value)]
        if not targets or "generic" in targets:
            return True
        variants = self.model_target_variants(model_target)
        return bool(variants & set(targets))

    def _matches_taxonomy_filter(self, record: dict[str, Any], field: str, requested: str | None) -> bool:
        if not requested:
            return True
        normalized_requested = normalize_text(requested)
        normalized_record = normalize_text(record.get(field))
        default = TAXONOMY_DEFAULTS.get(field, "")
        if normalized_requested == default:
            return True
        if normalized_record in {"", normalized_requested, default}:
            return True
        # Taxonomy mismatches are usually still useful in search because the
        # user often needs adjacent guidance that upgrades a weaker draft into a
        # better runtime shape. Keep strict filtering only for narrow lookup
        # surfaces where a mismatch is likely noise.
        return normalize_text(record.get("record_type")) not in {"question", "model_profile"}
