"""Rewrite helpers for Prompt Compass."""
