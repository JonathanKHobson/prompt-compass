from __future__ import annotations

from typing import Any

from analysis.contracts import merge_question_answers
from common import ensure_list, normalize_text


def apply_question_answers_to_contract(contract: dict[str, Any], question_answers: dict[str, Any] | list[dict[str, Any]] | None) -> dict[str, Any]:
    return merge_question_answers(contract, question_answers)


def render_prompt_contract(contract: dict[str, Any], *, include_assumptions: bool = False) -> str:
    lines: list[str] = []
    role = normalize_text(contract.get("role"))
    if role:
        lines.append(f"Role: {role}")
    if normalize_text(contract.get("objective")):
        lines.append(f"Objective: {normalize_text(contract.get('objective'))}")
    if normalize_text(contract.get("audience")):
        lines.append(f"Audience: {normalize_text(contract.get('audience'))}")
    context = ensure_list(contract.get("context"))
    if context:
        lines.append("Context:")
        lines.extend(f"- {normalize_text(item)}" for item in context if normalize_text(item))
    constraints = ensure_list(contract.get("constraints"))
    if constraints:
        lines.append("Constraints:")
        lines.extend(f"- {normalize_text(item)}" for item in constraints if normalize_text(item))
    steps = ensure_list(contract.get("steps"))
    if steps:
        lines.append("Steps:")
        lines.extend(f"{index}. {normalize_text(item)}" for index, item in enumerate(steps, start=1) if normalize_text(item))
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    if any(normalize_text(output_contract.get(key)) for key in ("format", "success_test", "length")) or output_contract.get("sections"):
        lines.append("Output Contract:")
        if normalize_text(output_contract.get("format")):
            lines.append(f"- Format: {normalize_text(output_contract.get('format'))}")
        if normalize_text(output_contract.get("length")):
            lines.append(f"- Length: {normalize_text(output_contract.get('length'))}")
        if normalize_text(output_contract.get("success_test")):
            lines.append(f"- Success Test: {normalize_text(output_contract.get('success_test'))}")
        for section in ensure_list(output_contract.get("sections")):
            if normalize_text(section):
                lines.append(f"- Include: {normalize_text(section)}")
    examples = ensure_list(contract.get("examples"))
    if examples:
        lines.append("Examples or Reference Style:")
        lines.extend(f"- {normalize_text(item)}" for item in examples if normalize_text(item))
    if normalize_text(contract.get("model_target")):
        lines.append(f"Model Target: {normalize_text(contract.get('model_target'))}")
    if include_assumptions:
        assumptions = ensure_list(contract.get("assumptions"))
        if assumptions:
            lines.append("Assumptions:")
            lines.extend(f"- {normalize_text(item)}" for item in assumptions if normalize_text(item))
    return "\n".join(lines).strip()
