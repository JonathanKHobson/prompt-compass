from __future__ import annotations

from typing import Any

from analysis.contracts import build_prompt_contract
from common import normalize_lookup_key, normalize_text
from repository import PromptCompassRepository
from rewrite.contract_builder import render_prompt_contract


def normalize_model_name(repo: PromptCompassRepository, model_name: str | None) -> str:
    if not model_name:
        return ""
    resolved = repo.resolve_entry(model_name, record_types=["model_profile"])
    if not resolved.get("found"):
        return ""
    return normalize_text(resolved.get("model_id") or resolved.get("slug"))


def infer_model_name(repo: PromptCompassRepository, text: str, *, preferred: str | None = None) -> str:
    if preferred:
        normalized = normalize_model_name(repo, preferred)
        if normalized:
            return normalized
    lookup = normalize_lookup_key(text)
    if not lookup:
        return ""
    for record in repo.list_all(record_type="model_profile"):
        candidates = {
            normalize_lookup_key(record.get("model_id")),
            normalize_lookup_key(record.get("slug")),
            *(normalize_lookup_key(alias) for alias in record.get("aliases", []) if normalize_lookup_key(alias)),
        }
        for candidate in candidates:
            if candidate and candidate in lookup:
                return normalize_text(record.get("model_id") or record.get("slug"))
    return ""


def target_prompt_to_model_payload(
    repo: PromptCompassRepository,
    prompt: str,
    model_name: str,
    prompt_contract: dict[str, Any] | None = None,
) -> dict[str, Any]:
    canonical_model = normalize_model_name(repo, model_name)
    if not canonical_model:
        return {
            "found": False,
            "query": model_name,
            "supported_models": repo.supported_model_ids(),
        }
    profile = repo.get_model_profile(canonical_model)
    if not profile.get("found"):
        return {
            "found": False,
            "query": model_name,
            "supported_models": repo.supported_model_ids(),
        }
    contract = dict(prompt_contract or build_prompt_contract(prompt, model_target=canonical_model))
    contract["model_target"] = canonical_model
    adjusted_contract, adaptation_notes, changed_sections, warnings = apply_model_profile_to_contract(contract, profile)
    adjusted_prompt = render_prompt_contract(adjusted_contract, include_assumptions=True)
    return {
        "found": True,
        "model_name": canonical_model,
        "adjusted_prompt": adjusted_prompt,
        "adaptation_notes": adaptation_notes,
        "changed_sections": changed_sections,
        "model_profile_summary": {
            "verbosity_default": profile.get("verbosity_default"),
            "context_reading": profile.get("context_reading"),
            "instruction_tolerance": profile.get("instruction_tolerance"),
            "tool_agent_support": profile.get("tool_agent_support"),
            "supports_tools": profile.get("supports_tools"),
            "supports_structured_outputs": profile.get("supports_structured_outputs"),
            "supports_multimodal": profile.get("supports_multimodal"),
            "supports_long_context": profile.get("supports_long_context"),
            "reasoning_style": profile.get("reasoning_style"),
            "best_prompt_shape": profile.get("best_prompt_shape"),
            "prompting_style_preference": profile.get("prompting_style_preference"),
            "known_failure_modes": profile.get("known_failure_modes", []),
        },
        "warnings": warnings,
    }


def apply_model_profile_to_contract(contract: dict[str, Any], profile: dict[str, Any]) -> tuple[dict[str, Any], list[str], list[str], list[str]]:
    adjusted = dict(contract)
    output_contract = dict(adjusted.get("output_contract", {}))
    constraints = list(adjusted.get("constraints", []))
    context_items = list(adjusted.get("context", []))
    notes: list[str] = []
    changed_sections: list[str] = []
    warnings: list[str] = []

    supports_structured_outputs = bool(profile.get("supports_structured_outputs"))
    supports_tools = bool(profile.get("supports_tools"))
    supports_multimodal = bool(profile.get("supports_multimodal"))
    supports_long_context = bool(profile.get("supports_long_context"))
    verbosity_default = normalize_text(profile.get("verbosity_default"))
    context_reading = normalize_text(profile.get("context_reading"))
    instruction_tolerance = normalize_text(profile.get("instruction_tolerance"))
    best_prompt_shape = normalize_text(profile.get("best_prompt_shape"))
    reasoning_style = normalize_text(profile.get("reasoning_style"))

    requested_format = normalize_text(output_contract.get("format")).lower()
    wants_schema = any(token in requested_format for token in ["json schema", "schema", "json"])
    wants_tools = any(token in normalize_text(" ".join(constraints + context_items)).lower() for token in ["tool", "function", "api call"])
    wants_multimodal = any(token in normalize_text(" ".join(context_items + constraints)).lower() for token in ["image", "audio", "video", "ocr", "vision"])

    if supports_structured_outputs and wants_schema and not normalize_text(output_contract.get("success_test")):
        output_contract["success_test"] = "Return output that conforms to the requested schema with no extra wrapper text."
        notes.append("Added a schema-valid success test because the selected model supports structured outputs well.")
        changed_sections.append("output_contract")

    if context_reading in {"literal", "moderate"} and context_items and not any("label any assumption" in item.lower() for item in constraints):
        constraints.append("Use only the provided context for grounded claims, and label any material assumption.")
        notes.append("Added an assumptions-and-grounding instruction because this model benefits from explicit context handling.")
        changed_sections.append("constraints")

    if supports_tools and wants_tools and not any("call tools only when needed" in item.lower() for item in constraints):
        constraints.append("Call tools only when they materially improve the answer, then return the final answer after tool results are available.")
        notes.append("Added an explicit tool-use guardrail to keep tool invocation deliberate.")
        changed_sections.append("constraints")

    if not supports_tools and wants_tools:
        warnings.append("The prompt references tool use, but this profile is not marked as tool-capable.")

    if wants_multimodal and not supports_multimodal:
        warnings.append("The prompt appears multimodal, but this model profile is not marked as multimodal-capable.")

    if supports_long_context and len(context_items) >= 3:
        notes.append("This model profile supports long-context prompting, so preserving sectioned context is appropriate.")
    elif len(context_items) >= 3:
        warnings.append("This prompt carries a lot of context for a model not marked as long-context optimized.")

    if verbosity_default in {"high", "medium_high"} and not normalize_text(output_contract.get("length")):
        warnings.append("This model tends verbose by default; specify a length target if you need tighter answers.")

    if instruction_tolerance in {"low", "medium"} and len(constraints) > 5:
        warnings.append("The prompt still has many constraints; this model may benefit from stricter prioritization.")

    if best_prompt_shape:
        notes.append(f"Best prompt shape for this model: {best_prompt_shape}")
    if reasoning_style:
        notes.append(f"Reasoning style to expect: {reasoning_style}")

    adjusted["constraints"] = constraints
    adjusted["output_contract"] = output_contract
    if not changed_sections:
        notes.append("The prompt contract was already structurally aligned with the selected model profile.")
    return adjusted, notes, sorted(set(changed_sections)), warnings
