from __future__ import annotations
import re
from typing import Any

from analysis.contracts import contract_missing_blocks
from analysis.philosophy import (
    build_prompt_fingerprint,
    compress_role_line,
    core_principles_applied,
    detect_primary_pattern,
    guess_primary_deliverable,
)
from analysis.matchers import match_frameworks, match_patterns, suggest_strategy_records
from analysis.phase2s import cap_items_by_budget, phase2s_fields, retrieval_budget_for
from analysis.phase2u import apply_role_domain_calibration
from common import ensure_list, normalize_text
from repository import PromptCompassRepository
from rewrite.contract_builder import apply_question_answers_to_contract, render_prompt_contract
from rewrite.model_targeting import apply_model_profile_to_contract, infer_model_name


def improve_prompt_payload(
    repo: PromptCompassRepository,
    prompt: str,
    analysis: dict[str, Any],
    *,
    model_target: str | None = None,
    question_answers: dict[str, Any] | list[dict[str, Any]] | None = None,
    selected_prompt_library_ids: list[str] | None = None,
    mode: str = "quick",
    preservation_mode: str = "balanced",
) -> dict[str, Any]:
    preservation_mode = _normalize_preservation_mode(preservation_mode)
    retrieval_workflow = "advanced_guided" if normalize_text(mode).lower() == "advanced" else "quick_improve"
    retrieval_budget = retrieval_budget_for(retrieval_workflow)
    contract = apply_question_answers_to_contract(dict(analysis.get("prompt_contract", {})), question_answers)
    behavior_inventory = _behavior_inventory(prompt, contract)
    contract = _apply_behavior_preservation(contract, behavior_inventory, preservation_mode=preservation_mode)
    prompt_fingerprint = build_prompt_fingerprint(prompt, contract)
    inferred_model = infer_model_name(repo, f"{prompt}\n{normalize_text(contract.get('model_target'))}", preferred=model_target)
    contract["model_target"] = inferred_model or normalize_text(contract.get("model_target"))
    contract["assumptions"] = _remaining_assumptions(contract)
    selected_support_entries = cap_items_by_budget(
        _selected_support_entries(repo, analysis, question_answers),
        retrieval_budget,
        "max_support_entries",
    )
    selected_prompt_library_items = cap_items_by_budget(
        _selected_prompt_library_items(repo, selected_prompt_library_ids),
        retrieval_budget,
        "max_prompt_library_items",
    )
    contract = _apply_prompt_library_items(contract, selected_prompt_library_items)

    strategy_records = suggest_strategy_records(
        repo,
        prompt_type=analysis.get("prompt_type") or contract.get("prompt_type") or "generative",
        subject_area=analysis.get("subject_area") or contract.get("subject_area") or "general",
        model_target=contract.get("model_target") or None,
        interaction_mode=analysis.get("interaction_mode"),
        output_mode=analysis.get("output_mode"),
        grounding_mode=analysis.get("grounding_mode"),
        evaluation_mode=analysis.get("evaluation_mode"),
        capability_tags=analysis.get("capability_tags", []),
        anti_patterns=analysis.get("anti_patterns", []),
        missing_building_blocks=contract_missing_blocks(contract),
        prompt_surface=analysis.get("prompt_surface"),
        surface_traits=analysis.get("surface_traits", []),
        query_terms=analysis.get("retrieval_keywords", []),
        limit=int(retrieval_budget.get("max_strategies") or 5),
    )
    frameworks = match_frameworks(repo, strategy_records, limit=int(retrieval_budget.get("max_frameworks") or 3))
    patterns = match_patterns(repo, strategy_records, limit=int(retrieval_budget.get("max_patterns") or 4))

    working_contract = dict(contract)
    rewrite_plan = _apply_rewrite_plan(
        repo,
        prompt=prompt,
        analysis=analysis,
        contract=working_contract,
        frameworks=frameworks,
        patterns=patterns,
        selected_support_entries=selected_support_entries,
        selected_prompt_library_items=selected_prompt_library_items,
        prompt_fingerprint=prompt_fingerprint,
        mode=mode,
    )
    rewritten_prompt = render_prompt_contract(working_contract, include_assumptions=True)
    preservation_report = _preservation_report(behavior_inventory, rewritten_prompt, preservation_mode=preservation_mode)
    rationale_table = [_plan_to_rationale(step) for step in rewrite_plan]
    changes_made = [step["change"] for step in rewrite_plan]
    prompt_delta_summary = _prompt_delta_summary(working_contract, rewrite_plan, preservation_report=preservation_report)
    detected_pattern_primary = detect_primary_pattern(prompt, working_contract, analysis.get("anti_patterns", []))
    core_principles = core_principles_applied(
        prompt,
        working_contract,
        analysis.get("anti_patterns", []),
        workflow_kind="improve",
    )
    post_write_checks = _post_write_checks(working_contract, analysis, rewrite_plan)

    payload = {
        "completed": True,
        "mode_used": normalize_text(mode) or "quick",
        "mode_reason": _mode_reason(mode),
        "rewritten_prompt": rewritten_prompt,
        "matched_frameworks": _compact_entries(frameworks),
        "matched_patterns": _compact_entries(patterns),
        "applied_strategies": strategy_records,
        "selected_support_entries": _compact_entries(selected_support_entries),
        "selected_prompt_library_items": _compact_prompt_library_items(selected_prompt_library_items),
        "analysis_input_normalized": bool(analysis.get("analysis_input_normalized")),
        "analysis_validation_warnings": ensure_list(analysis.get("analysis_validation_warnings")),
        "rewrite_plan": rewrite_plan,
        "rewrite_trace": rewrite_plan,
        "rationale_table": rationale_table,
        "changes_made": changes_made,
        "why": [row["reason"] for row in rationale_table],
        "assumptions_made": ensure_list(working_contract.get("assumptions")),
        "short_follow_up_recommendations": _follow_up_recommendations(analysis, working_contract),
        "remaining_assumptions": ensure_list(working_contract.get("assumptions")),
        "prompt_delta_summary": prompt_delta_summary,
        "behavior_inventory": behavior_inventory,
        "preservation_mode": preservation_mode,
        "preserved_behaviors": preservation_report["preserved_behaviors"],
        "stripped_behaviors": preservation_report["stripped_behaviors"],
        "preservation_warnings": preservation_report["preservation_warnings"],
        "post_write_checks": post_write_checks,
        "remaining_gaps": _remaining_gaps_from_checks(post_write_checks),
        "prompt_contract": working_contract,
        "detected_pattern_primary": detected_pattern_primary,
        "core_principles_applied": core_principles,
    }
    payload.update(
        phase2s_fields(
            prompt,
            {**analysis, "prompt_contract": working_contract},
            tool_name="improve_prompt",
            workflow=retrieval_workflow,
            runtime_payload=payload,
            behavior_inventory=behavior_inventory,
            selected={
                "strategies": strategy_records,
                "frameworks": frameworks,
                "patterns": patterns,
                "support_entries": selected_support_entries,
                "prompt_library_items": selected_prompt_library_items,
            },
        )
    )
    return payload


def _normalize_preservation_mode(value: str) -> str:
    normalized = normalize_text(value).lower()
    if normalized in {"conservative", "balanced", "aggressive"}:
        return normalized
    return "balanced"


def _behavior_inventory(prompt: str, contract: dict[str, Any]) -> list[dict[str, Any]]:
    text = normalize_text(prompt)
    lowered = text.lower()
    inventory: list[dict[str, Any]] = []

    def add(kind: str, label: str, evidence: str, critical: bool = True) -> None:
        normalized_label = normalize_text(label)
        normalized_evidence = normalize_text(evidence)
        if not normalized_label or not normalized_evidence:
            return
        key = (kind, normalized_label.lower())
        if key in {(item["kind"], item["label"].lower()) for item in inventory}:
            return
        inventory.append(
            {
                "kind": kind,
                "label": normalized_label,
                "evidence": normalized_evidence,
                "critical": critical,
            }
        )

    if "json" in lowered or "schema" in lowered or "field" in lowered:
        for field in re.findall(r"`([a-zA-Z][a-zA-Z0-9_]{2,})`|\"([a-zA-Z][a-zA-Z0-9_]{2,})\"|'([a-zA-Z][a-zA-Z0-9_]{2,})'", prompt):
            value = next((item for item in field if item), "")
            add("json_field", value, value)
        for value in re.findall(r"\b[a-z][a-z0-9]+_[a-z0-9_]+\b", lowered):
            add("json_field", value, value)
        field_match = re.search(r"\bfields?\b\s*(?:are|:)?\s*([^.\n]+)", text, flags=re.IGNORECASE)
        if field_match:
            for candidate in re.split(r"[,;]|\band\b", field_match.group(1)):
                cleaned = normalize_text(candidate).strip(" .:")
                if re.match(r"^[A-Za-z][A-Za-z0-9_ -]{2,40}$", cleaned):
                    add("json_field", cleaned, cleaned)

    for match in re.finditer(r"\b(?:max|maximum|no more than|up to)\s+\d+\s+(?:tool calls?|calls?|sources?|citations?)\b", lowered):
        add("tool_limit", match.group(0), match.group(0))
    for sentence in re.split(r"(?<=[.!?])\s+", text):
        sentence_lower = sentence.lower()
        if any(token in sentence_lower for token in ("citation", "cite", "doc_id", "source id", "[doc_id]")):
            add("citation_rule", "citation rule", sentence)
        if any(token in sentence_lower for token in ("do not respond with prose", "no prose", "json-only", "json only")):
            add("prose_restriction", "prose restriction", sentence)
        if any(token in sentence_lower for token in ("tool", "function", "external_search", "fallback")):
            add("tool_rule", "tool rule", sentence)
        if any(token in sentence_lower for token in ("if", "else", "otherwise")) and any(token in sentence_lower for token in ("return", "respond", "output")):
            add("branching_format", "branching output rule", sentence)

    audience = normalize_text(contract.get("audience"))
    if audience:
        add("audience", audience, audience)
    model_target = normalize_text(contract.get("model_target"))
    if model_target:
        add("model_target", model_target, model_target, critical=False)
    return inventory


def _apply_behavior_preservation(
    contract: dict[str, Any],
    behavior_inventory: list[dict[str, Any]],
    *,
    preservation_mode: str,
) -> dict[str, Any]:
    if not behavior_inventory:
        return contract
    updated = dict(contract)
    constraints = list(ensure_list(updated.get("constraints")))
    output_contract = dict(updated.get("output_contract", {})) if isinstance(updated.get("output_contract"), dict) else {}
    sections = list(ensure_list(output_contract.get("sections")))
    for item in behavior_inventory:
        kind = item["kind"]
        label = item["label"]
        evidence = item["evidence"]
        if kind == "json_field":
            sections = _append_unique(sections, f"Preserve JSON field `{label}`.")
        elif kind == "audience" and not normalize_text(updated.get("audience")):
            updated["audience"] = label
        elif preservation_mode in {"conservative", "balanced"} or item.get("critical"):
            constraints = _append_unique(constraints, f"Preserve existing {kind.replace('_', ' ')}: {evidence}")
    if sections:
        output_contract["sections"] = sections
    updated["constraints"] = constraints
    updated["output_contract"] = output_contract
    return updated


def _preservation_report(
    behavior_inventory: list[dict[str, Any]],
    rewritten_prompt: str,
    *,
    preservation_mode: str,
) -> dict[str, Any]:
    lowered = normalize_text(rewritten_prompt).lower()
    preserved: list[dict[str, Any]] = []
    stripped: list[dict[str, Any]] = []
    for item in behavior_inventory:
        label = normalize_text(item.get("label")).lower()
        evidence = normalize_text(item.get("evidence")).lower()
        needle = label or evidence
        found = bool(needle and needle in lowered)
        if found:
            preserved.append(item)
        else:
            stripped.append({**item, "removal_reason": "Not found in rewritten prompt."})
    warnings: list[str] = []
    if behavior_inventory and len(stripped) / len(behavior_inventory) > 0.30:
        warnings.append("More than 30% of the behavior inventory is absent from the rewritten prompt; confirm before shipping.")
    critical_stripped = [item["label"] for item in stripped if item.get("critical")]
    if critical_stripped:
        warnings.append("Critical behaviors are missing from the rewrite: " + ", ".join(critical_stripped) + ".")
    if preservation_mode == "aggressive" and stripped:
        warnings.append("Aggressive preservation mode allowed larger restructuring, but stripped behaviors still require review.")
    return {
        "preserved_behaviors": preserved,
        "stripped_behaviors": stripped,
        "preservation_warnings": warnings,
    }


def _apply_rewrite_plan(
    repo: PromptCompassRepository,
    *,
    prompt: str,
    analysis: dict[str, Any],
    contract: dict[str, Any],
    frameworks: list[dict[str, Any]],
    patterns: list[dict[str, Any]],
    selected_support_entries: list[dict[str, Any]],
    selected_prompt_library_items: list[dict[str, Any]],
    prompt_fingerprint: dict[str, Any],
    mode: str,
) -> list[dict[str, Any]]:
    anti_patterns = ensure_list(analysis.get("anti_patterns"))
    rewrite_plan: list[dict[str, Any]] = []
    output_contract = dict(contract.get("output_contract", {})) if isinstance(contract.get("output_contract"), dict) else {}
    constraints = list(ensure_list(contract.get("constraints")))
    context_items = list(ensure_list(contract.get("context")))
    diagnosis_record = repo.get_entry("pc:strategy:diagnosis-before-rewrite")
    voice_memo_record = repo.get_entry("pc:pattern:voice-memo-dictation-intake")
    fingerprint_record = repo.get_entry("pc:technique:prompt-fingerprinting")
    terminology_record = repo.get_entry("pc:strategy:terminology-lockdown")
    continuation_record = repo.get_entry("pc:technique:continuation-instructions")
    negative_avoidance_record = repo.get_entry("pc:anti_pattern:negative-avoidance-prompting")

    if prompt_fingerprint.get("draft_refinement") or prompt_fingerprint.get("voice_memo_like") or anti_patterns:
        rewrite_plan.append(
            _plan_step(
                step_id="diagnosis-before-rewrite",
                change="Diagnosed the prompt before rewriting it.",
                reason="The rewrite starts by naming the real job, the missing contract pieces, and the active anti-patterns before tightening the prompt.",
                source=diagnosis_record if diagnosis_record.get("found") else None,
                target_section="full_prompt",
                requires_user_answer=False,
            )
        )

    if not normalize_text(contract.get("role")):
        suggested_role = _suggest_role(analysis, prompt)
        if suggested_role:
            contract["role"] = suggested_role
            rewrite_plan.append(
                _plan_step(
                    step_id="normalize-role",
                    change="Added a single-line functional role.",
                    reason="The original draft lacked a stable role line, so the rewrite anchors behavior in one functional role instead of leaving posture implicit.",
                    source=_find_named(frameworks, "RTF") or _find_named(frameworks, "RISEN"),
                    target_section="role",
                    requires_user_answer=False,
                )
            )
    elif prompt_fingerprint.get("role_heavy"):
        compressed_role = compress_role_line(contract.get("role"))
        if compressed_role and compressed_role != normalize_text(contract.get("role")):
            contract["role"] = compressed_role
            rewrite_plan.append(
                _plan_step(
                    step_id="compress-role-frame",
                    change="Compressed the role into a one-line working role.",
                    reason="Role framing should act as a shortcut, not a costume, so the rewrite keeps the role brief and lets the deliverable lead.",
                    source=_find_named(patterns, "Role Framing as Shortcut") or _find_named(frameworks, "RTF"),
                    target_section="role",
                    requires_user_answer=False,
                )
            )

    calibrated_contract, role_assessment = apply_role_domain_calibration(contract, prompt, analysis)
    if calibrated_contract != contract:
        role_before = normalize_text(contract.get("role"))
        contract.clear()
        contract.update(calibrated_contract)
        context_items = list(ensure_list(contract.get("context")))
        constraints = list(ensure_list(contract.get("constraints")))
        if role_assessment["decision"] == "demote_role":
            rewrite_plan.append(
                _plan_step(
                    step_id="demote-generic-role",
                    change="Demoted a generic expert role and anchored behavior in task constraints instead.",
                    reason="Generic persona labels are less reliable than concrete domain vocabulary, output contracts, and success criteria.",
                    source=_find_named(patterns, "Role Framing as Shortcut") or _find_named(frameworks, "RTF"),
                    target_section="role",
                    requires_user_answer=False,
                )
            )
        elif role_before != normalize_text(contract.get("role")) or role_assessment["domain_vocabulary_anchors"]:
            rewrite_plan.append(
                _plan_step(
                    step_id="preserve-domain-vocabulary",
                    change="Preserved domain vocabulary as prompt context.",
                    reason="Domain vocabulary is a safer behavior anchor than adding a broad persona line.",
                    source=_find_named(patterns, "Output Contract First") or (frameworks[0] if frameworks else None),
                    target_section="context",
                    requires_user_answer=False,
                )
            )

    if normalize_text(contract.get("objective")):
        normalized_objective = _normalize_objective(contract.get("objective"))
        if normalized_objective != normalize_text(contract.get("objective")):
            contract["objective"] = normalized_objective
            rewrite_plan.append(
                _plan_step(
                    step_id="tighten-objective",
                    change="Tightened the objective into a clearer job-to-be-done.",
                    reason="The rewrite needed a more explicit first-line objective so the prompt names the real task instead of leaving it as a vague improvement request.",
                    source=_find_named(patterns, "Prompt Refinement First") or (frameworks[0] if frameworks else None),
                    target_section="objective",
                    requires_user_answer=False,
                )
            )
    if prompt_fingerprint.get("voice_memo_like") or prompt_fingerprint.get("multi_deliverable_risk"):
        primary_deliverable = guess_primary_deliverable(prompt, contract)
        if primary_deliverable and primary_deliverable != normalize_text(contract.get("objective")):
            contract["objective"] = primary_deliverable
            rewrite_plan.append(
                _plan_step(
                    step_id="narrow-primary-deliverable",
                    change="Extracted one primary deliverable before rewriting the prompt.",
                    reason="Voice-memo-style or multi-job drafts work better when the rewrite names the single artifact that should win before any follow-up work.",
                    source=voice_memo_record if prompt_fingerprint.get("voice_memo_like") and voice_memo_record.get("found") else _find_named(patterns, "Intent Dump + Constraint Sweep"),
                    target_section="objective",
                    requires_user_answer=False,
                )
            )

    if normalize_text(contract.get("audience")):
        cleaned_audience = _clean_audience(contract.get("audience"))
        if cleaned_audience != normalize_text(contract.get("audience")):
            contract["audience"] = cleaned_audience
            rewrite_plan.append(
                _plan_step(
                    step_id="clean-audience",
                    change="Clarified the intended output audience.",
                    reason="The audience wording needed cleanup so the rewritten prompt points at the reader of the output rather than a product or market target.",
                    source=_find_named(frameworks, "COSTAR"),
                    target_section="audience",
                    requires_user_answer=False,
                )
            )

    if not normalize_text(output_contract.get("format")):
        output_contract["format"] = _default_output_format(analysis)
        rewrite_plan.append(
            _plan_step(
                step_id="add-output-contract",
                change="Added a visible output format.",
                reason="The original draft needed a named artifact so the model knows what shape to return.",
                source=_find_named(patterns, "Output Contract First") or _find_named(frameworks, "CLEAR"),
                target_section="output_contract",
                requires_user_answer=False,
            )
        )
    if not normalize_text(output_contract.get("success_test")):
        output_contract["success_test"] = _default_success_test(output_contract.get("format"))
        rewrite_plan.append(
            _plan_step(
                step_id="add-success-test",
                change="Added a practical success test.",
                reason="The rewrite needed a usable first-pass success condition instead of only naming a format.",
                source=_find_named(frameworks, "CLEAR"),
                target_section="output_contract",
                requires_user_answer=False,
                )
            )

    if prompt_fingerprint.get("voice_memo_like"):
        context_items = _append_unique(context_items, "Separate the raw brief into must-haves, nice-to-haves, and exclusions before finalizing the prompt.")
        constraints = _append_unique(constraints, "Preserve the real goal, important constraints, and useful context, but remove repetition, filler, and side quests.")
        rewrite_plan.append(
            _plan_step(
                step_id="voice-memo-cleanup",
                change="Converted the voice-memo-style brief into a cleaner prompt contract.",
                reason="The rewrite keeps the useful signal from the raw brief, but strips filler and side quests so the real job becomes clear.",
                source=voice_memo_record if voice_memo_record.get("found") else None,
                target_section="context",
                requires_user_answer=False,
            )
        )

    if prompt_fingerprint.get("preserve_voice_requested") or prompt_fingerprint.get("voice_memo_like"):
        constraints = _append_unique(constraints, "Preserve wording or tone that carries real intent, but repair structure where it weakens the task.")
        rewrite_plan.append(
            _plan_step(
                step_id="preserve-useful-voice",
                change="Preserved useful voice while tightening the prompt structure.",
                reason="The rewrite should improve the prompt without flattening the user's useful style, intent, or working posture.",
                source=fingerprint_record if fingerprint_record.get("found") else None,
                target_section="constraints",
                requires_user_answer=False,
            )
        )

    if prompt_fingerprint.get("terminology_sensitive"):
        constraints = _append_unique(constraints, "Use the user's named terms consistently and avoid silent synonym drift.")
        rewrite_plan.append(
            _plan_step(
                step_id="terminology-lockdown",
                change="Added a terminology consistency rule.",
                reason="Vocabulary drift can change the task, so the rewrite keeps the user's named terms stable unless the prompt says otherwise.",
                source=terminology_record if terminology_record.get("found") else None,
                target_section="constraints",
                requires_user_answer=False,
            )
        )

    if prompt_fingerprint.get("continuation_risk"):
        constraints = _append_unique(
            constraints,
            "If the response cannot fit in one message, stop at a clean section boundary and continue from the next section without repeating completed material.",
        )
        rewrite_plan.append(
            _plan_step(
                step_id="continuation-instructions",
                change="Added explicit continuation instructions for long outputs.",
                reason="Long outputs should not silently truncate, so the rewrite adds a clear continuation rule.",
                source=continuation_record if continuation_record.get("found") else None,
                target_section="constraints",
                requires_user_answer=False,
            )
        )

    if prompt_fingerprint.get("negative_avoidance_risk"):
        constraints = _append_unique(constraints, "Name the desired target behavior, not only what to avoid.")
        rewrite_plan.append(
            _plan_step(
                step_id="negative-avoidance-repair",
                change="Converted negative-only steering into a positive target rule.",
                reason="Prompts drift when they only say what not to do, so the rewrite adds a positive target behavior.",
                source=negative_avoidance_record if negative_avoidance_record.get("found") else None,
                target_section="constraints",
                requires_user_answer=False,
            )
        )

    for anti in anti_patterns:
        slug = normalize_text(anti.get("slug"))
        if slug == "scope-sprawl":
            objective = _first_deliverable(contract.get("objective"))
            if objective:
                contract["objective"] = objective
            constraints = _append_unique(constraints, "Focus on the single primary deliverable before expanding into follow-up work.")
            rewrite_plan.append(
                _plan_step(
                    step_id="repair-scope-sprawl",
                    change="Narrowed the rewrite to one primary deliverable.",
                    reason="The original prompt asked for too many jobs at once, so the rewrite makes the primary output win first.",
                    source=_find_named(patterns, "Intent Dump + Constraint Sweep") or _find_named(frameworks, "RISEN"),
                    target_section="objective",
                    requires_user_answer=False,
                )
            )
        elif slug == "stacked-adjectives":
            ranked = _rank_style_pressure(prompt)
            if ranked:
                constraints = _append_unique(constraints, f"Prioritize these quality goals in order: {', '.join(ranked)}.")
                rewrite_plan.append(
                    _plan_step(
                        step_id="repair-stacked-adjectives",
                        change="Converted stacked style pressure into ranked priorities.",
                        reason="The original draft stacked quality words without saying which one should win when tradeoffs appear.",
                        source=_find_named(patterns, "Trait-Stack Output Control"),
                        target_section="constraints",
                        requires_user_answer=False,
                    )
                )
        elif slug == "role-collapse":
            if normalize_text(contract.get("role")):
                rewrite_plan.append(
                    _plan_step(
                        step_id="repair-role-collapse",
                        change="Collapsed competing personas into one working role.",
                        reason="The rewrite keeps one functional role line so the model is not juggling multiple personas at once.",
                        source=_find_named(patterns, "Role Framing as Shortcut") or _find_named(frameworks, "RTF"),
                        target_section="role",
                        requires_user_answer=False,
                    )
                )
        elif slug == "source-pack-with-vague-ask":
            context_items = _append_unique(context_items, "Use the provided sources only to support the named task, not for open-ended summarization.")
            rewrite_plan.append(
                _plan_step(
                    step_id="repair-source-pack",
                    change="Clarified what the source material is for.",
                    reason="The rewrite names the job the source pack should support so the model does not drift into aimless synthesis.",
                    source=_find_named(patterns, "Context Injection via Source Pack"),
                    target_section="context",
                    requires_user_answer=False,
                )
            )
        elif slug == "vague-compression":
            rewrite_plan.append(
                _plan_step(
                    step_id="repair-vague-compression",
                    change="Turned the vague rewrite ask into a concrete artifact request.",
                    reason="The rewrite needed a visible target artifact instead of 'make this better' style compression language.",
                    source=_find_named(patterns, "Prompt Refinement First"),
                    target_section="objective",
                    requires_user_answer=False,
                )
            )
        elif slug == "instruction-wall":
            rewrite_plan.append(
                _plan_step(
                    step_id="repair-instruction-wall",
                    change="Restructured the prompt into clearer sections.",
                    reason="The rewrite uses visible sections so the task is easier to parse than a dense directive block.",
                    source=_find_named(frameworks, "CLEAR"),
                    target_section="full_prompt",
                    requires_user_answer=False,
                )
            )
        elif slug == "ghost-audience" and normalize_text(contract.get("audience")):
            rewrite_plan.append(
                _plan_step(
                    step_id="repair-ghost-audience",
                    change="Made the audience explicit in the contract.",
                    reason="The rewritten prompt names the reader directly instead of leaving tone cues to imply the audience.",
                    source=_find_named(frameworks, "COSTAR"),
                    target_section="audience",
                    requires_user_answer=False,
                )
            )
        elif slug == "ineffective-negative-constraint":
            constraints = _append_unique(
                constraints,
                "If the available context does not support an answer, say what is missing and do not synthesize beyond the evidence.",
            )
            rewrite_plan.append(
                _plan_step(
                    step_id="repair-ineffective-negative-constraint",
                    change="Replaced unenforceable negative wording with a positive grounding rule.",
                    reason="Saying 'do not hallucinate' is weaker than naming the behavior to follow when evidence is missing.",
                    source=negative_avoidance_record if negative_avoidance_record.get("found") else None,
                    target_section="constraints",
                    requires_user_answer=False,
                )
            )
        elif slug == "vague-style-directive":
            constraints = _append_unique(
                constraints,
                "Define creative choices through concrete examples, audience fit, or success criteria instead of using 'be creative' alone.",
            )
            rewrite_plan.append(
                _plan_step(
                    step_id="repair-vague-style-directive",
                    change="Turned vague style direction into concrete style criteria.",
                    reason="Generic creativity requests are hard to satisfy consistently unless the prompt defines what kind of creative result is useful.",
                    source=_find_named(patterns, "Trait-Stack Output Control"),
                    target_section="constraints",
                    requires_user_answer=False,
                )
            )

    contract["constraints"] = _normalize_constraints(constraints)
    contract["context"] = _normalize_context(context_items)
    contract["output_contract"] = output_contract

    for record in selected_support_entries:
        summary = normalize_text(record.get("summary")) or normalize_text(record.get("curation_note"))
        if summary:
            contract["context"] = _append_unique(list(ensure_list(contract.get("context"))), f"Selected support guidance: {summary}")
            rewrite_plan.append(
                _plan_step(
                    step_id=f"support-{normalize_text(record.get('slug')) or normalize_text(record.get('entry_id'))}",
                    change=f"Applied selected support guidance from {record.get('name')}.",
                    reason=summary,
                    source=record,
                    target_section="context",
                    requires_user_answer=False,
                )
            )

    if selected_prompt_library_items:
        rewrite_plan.append(
            _plan_step(
                step_id="selected-prompt-library",
                change="Applied selected prompt-library references.",
                reason="The rewrite used the explicitly selected saved prompts or templates as additional example context.",
                source={
                    "entry_id": selected_prompt_library_items[0].get("item_id"),
                    "name": normalize_text(selected_prompt_library_items[0].get("title")) or normalize_text(selected_prompt_library_items[0].get("id")),
                },
                target_section="examples",
                requires_user_answer=False,
            )
        )

    model_name = normalize_text(contract.get("model_target"))
    if model_name:
        profile = repo.get_model_profile(model_name)
        if profile.get("found"):
            adjusted, notes, changed_sections, warnings = apply_model_profile_to_contract(contract, profile)
            contract.clear()
            contract.update(adjusted)
            for section, note in zip(changed_sections, notes, strict=False):
                rewrite_plan.append(
                    _plan_step(
                        step_id=f"model-target-{section}",
                        change=f"Adjusted the prompt for {model_name}.",
                        reason=note,
                        source=profile,
                        target_section=section,
                        requires_user_answer=False,
                    )
                )
            for warning in warnings:
                contract["assumptions"] = _append_unique(list(ensure_list(contract.get("assumptions"))), warning)

    if mode == "advanced":
        contract["constraints"] = _append_unique(
            list(ensure_list(contract.get("constraints"))),
            "If information is still missing, label the remaining assumption instead of inventing hidden context.",
        )
        rewrite_plan.append(
            _plan_step(
                step_id="advanced-explicit-assumptions",
                change="Added an explicit assumption-handling rule.",
                reason="Advanced mode should preserve open questions visibly instead of silently filling every gap.",
                source=_find_named(frameworks, "CLEAR"),
                target_section="constraints",
                requires_user_answer=False,
            )
        )

    return _dedupe_plan(rewrite_plan)


def _plan_step(
    *,
    step_id: str,
    change: str,
    reason: str,
    source: dict[str, Any] | None,
    target_section: str,
    requires_user_answer: bool,
) -> dict[str, Any]:
    return {
        "step_id": step_id,
        "change": change,
        "reason": reason,
        "source_entry_id": source.get("entry_id") if source else None,
        "source_name": source.get("name") if source else None,
        "target_section": target_section,
        "requires_user_answer": requires_user_answer,
        "expected_effect": _expected_effect_from_change(change),
    }


def _plan_to_rationale(step: dict[str, Any]) -> dict[str, Any]:
    return {
        "change": step["change"],
        "reason": step["reason"],
        "source_entry_id": step.get("source_entry_id"),
        "source_name": step.get("source_name"),
        "expected_effect": step.get("expected_effect"),
    }


def _expected_effect_from_change(change: str) -> str:
    lowered = normalize_text(change).lower()
    if "audience" in lowered:
        return "Improve audience fit and reduce reader ambiguity."
    if "output" in lowered or "success test" in lowered or "schema" in lowered:
        return "Improve first-pass usability and output control."
    if "scope" in lowered or "deliverable" in lowered:
        return "Improve coherence and reduce multi-job drift."
    if "role" in lowered:
        return "Improve behavioral consistency."
    if "support guidance" in lowered or "prompt-library" in lowered:
        return "Improve fit using explicitly selected supporting context."
    return "Improve prompt quality in a visible, explainable way."


def _prompt_delta_summary(
    contract: dict[str, Any],
    rewrite_plan: list[dict[str, Any]],
    *,
    preservation_report: dict[str, Any] | None = None,
) -> dict[str, Any]:
    includes: list[str] = []
    if normalize_text(contract.get("role")):
        includes.append("single-line role framing")
    if normalize_text(contract.get("objective")):
        includes.append("explicit objective")
    if normalize_text(contract.get("audience")):
        includes.append("named audience")
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    if normalize_text(output_contract.get("format")):
        includes.append("visible output contract")
    if normalize_text(output_contract.get("success_test")):
        includes.append("success test")
    if ensure_list(contract.get("context")):
        includes.append("context guidance")
    if ensure_list(contract.get("constraints")):
        includes.append("constraint list")
    reduced = [step["change"] for step in rewrite_plan if any(token in step["step_id"] for token in ("scope", "stacked", "instruction-wall", "role-collapse"))]
    if preservation_report:
        reduced.extend(
            f"Removed or failed to preserve: {item.get('label')}"
            for item in ensure_list(preservation_report.get("stripped_behaviors"))
            if normalize_text(item.get("label"))
        )
    return {
        "now_includes": includes,
        "reduced_or_removed": reduced,
        "assumptions_made": ensure_list(contract.get("assumptions")),
        "remaining_risks": _remaining_risks(contract),
    }


def _post_write_checks(contract: dict[str, Any], analysis: dict[str, Any], rewrite_plan: list[dict[str, Any]]) -> dict[str, Any]:
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    anti_slugs = {normalize_text(item.get("slug")) for item in ensure_list(analysis.get("anti_patterns"))}
    repaired = {
        slug: any(slug_fragment in step["step_id"] for step in rewrite_plan for slug_fragment in slug.split("-"))
        for slug in anti_slugs
    }
    return {
        "has_objective": bool(normalize_text(contract.get("objective"))),
        "has_audience": bool(normalize_text(contract.get("audience"))),
        "has_output_contract": bool(normalize_text(output_contract.get("format"))),
        "has_success_test": bool(normalize_text(output_contract.get("success_test"))),
        "repaired_anti_patterns": repaired,
        "rewrite_step_count": len(rewrite_plan),
    }


def _remaining_gaps_from_checks(checks: dict[str, Any]) -> list[dict[str, str]]:
    gaps: list[dict[str, str]] = []
    if not checks.get("has_audience"):
        gaps.append(
            {
                "gap": "missing_audience",
                "repair_guidance": "Add the intended reader or user group explicitly in the Audience line.",
            }
        )
    if not checks.get("has_success_test"):
        gaps.append(
            {
                "gap": "missing_success_test",
                "repair_guidance": "Add an observable success test that says how the output will be judged.",
            }
        )
    repaired = checks.get("repaired_anti_patterns") if isinstance(checks.get("repaired_anti_patterns"), dict) else {}
    for slug in ("schema-theater", "premature-format-lock"):
        if repaired.get(slug) is False:
            gaps.append(
                {
                    "gap": f"unrepaired_{slug}",
                    "repair_guidance": "Add concrete schema or task-specific contract details instead of relying on a generic format label.",
                }
            )
    return gaps


def _follow_up_recommendations(analysis: dict[str, Any], contract: dict[str, Any]) -> list[str]:
    recommendations: list[str] = []
    if not normalize_text(contract.get("model_target")):
        recommendations.append("Specify a target model if you want the prompt tuned to provider-specific behavior.")
    if not ensure_list(contract.get("examples")):
        recommendations.append("Add one worked example if the task depends on tone, structure, or pattern imitation.")
    if normalize_text(analysis.get("grounding_mode")) in {"retrieval", "quote_first"} and not any(
        "source" in normalize_text(item).lower() for item in ensure_list(contract.get("constraints"))
    ):
        recommendations.append("Add a source-priority rule if your evidence can conflict.")
    return recommendations[:3]


def _remaining_risks(contract: dict[str, Any]) -> list[str]:
    risks: list[str] = []
    if not ensure_list(contract.get("context")):
        risks.append("Context is still thin, so the model may infer more than you want.")
    if not normalize_text(contract.get("audience")):
        risks.append("Audience fit is still partly inferred.")
    return risks


def _mode_reason(mode: str) -> str:
    if normalize_text(mode) == "advanced":
        return "Advanced mode preserves more explicit structure, assumptions, and gating before the final rewrite."
    return "Quick mode optimized for a one-pass rewrite with bounded assumptions."


def _normalize_objective(value: Any) -> str:
    text = normalize_text(value)
    replacements = {
        "make this better": "Rewrite this prompt into a clearer, more usable version.",
        "improve this prompt": "Rewrite this prompt into a clearer, more usable version.",
        "improve this": "Rewrite this into a clearer, more usable prompt.",
        "help me explain": "Write a prompt that clearly explains",
    }
    lowered = text.lower()
    for old, new in replacements.items():
        if lowered.startswith(old):
            return new + text[len(old) :]
    return text


def _clean_audience(value: Any) -> str:
    text = normalize_text(value)
    text = text.replace("the AI's output", "the output")
    if text.lower().startswith("for "):
        return text[4:]
    return text


def _default_output_format(analysis: dict[str, Any]) -> str:
    output_mode = normalize_text(analysis.get("output_mode"))
    if output_mode == "schema_bound":
        return "JSON object matching the required schema"
    if output_mode == "structured":
        surface = normalize_text(analysis.get("prompt_surface"))
        if surface == "parser_bound":
            return "parser-ready structured output with named fields"
        if surface == "tool_workflow":
            return "tool-safe response with decision, tool-use notes, and final answer"
        return "structured response with task-specific sections"
    prompt_type = normalize_text(analysis.get("prompt_type"))
    if prompt_type == "transformative":
        return "rewritten prompt plus short rationale"
    subject = normalize_text(analysis.get("subject_area"))
    if subject and subject != "general":
        return f"{subject} deliverable with clear sections"
    return "task-specific response with clear sections"


def _default_success_test(output_format: Any) -> str:
    format_text = normalize_text(output_format) or "the requested artifact"
    if "json" in format_text.lower() or "schema" in format_text.lower():
        return "Output parses successfully, includes every required field, and avoids prose outside the schema."
    return f"The {format_text} gives the target reader enough specific information to act without another clarification round."


def _suggest_role(analysis: dict[str, Any], prompt: str) -> str:
    subject_area = normalize_text(analysis.get("subject_area"))
    if subject_area == "coding":
        return "Senior prompt engineer for technical workflows"
    if subject_area in {"analysis", "research"}:
        return "Structured research and synthesis assistant"
    if "hiring" in normalize_text(prompt).lower():
        return "Hiring and evaluation writing assistant"
    return "Prompt engineering assistant"


def _first_deliverable(objective: Any) -> str:
    text = normalize_text(objective)
    if " and " in text:
        return text.split(" and ", 1)[0].rstrip(",;:.") + "."
    return text


def _rank_style_pressure(prompt: str) -> list[str]:
    ordered_traits = []
    for trait in ("clarity", "accuracy", "usefulness", "specificity", "strategic judgment", "brevity"):
        if trait.split()[0] in normalize_text(prompt).lower():
            ordered_traits.append(trait)
    if not ordered_traits:
        ordered_traits = ["clarity", "accuracy", "usefulness"]
    return ordered_traits[:3]


def _normalize_constraints(values: list[str]) -> list[str]:
    return [normalize_text(value) for value in values if normalize_text(value)]


def _normalize_context(values: list[str]) -> list[str]:
    return [normalize_text(value) for value in values if normalize_text(value)]


def _append_unique(values: list[str], value: str) -> list[str]:
    normalized = normalize_text(value)
    current = [normalize_text(item) for item in values if normalize_text(item)]
    if normalized and normalized.lower() not in {item.lower() for item in current}:
        current.append(normalized)
    return current


def _dedupe_plan(steps: list[dict[str, Any]]) -> list[dict[str, Any]]:
    deduped: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for step in steps:
        key = (normalize_text(step.get("step_id")).lower(), normalize_text(step.get("change")).lower())
        if key in seen:
            continue
        seen.add(key)
        deduped.append(step)
    return deduped


def _remaining_assumptions(contract: dict[str, Any]) -> list[str]:
    assumptions: list[str] = []
    if not normalize_text(contract.get("audience")):
        assumptions.append("Audience is still inferred rather than confirmed.")
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    if not normalize_text(output_contract.get("success_test")):
        assumptions.append("Success criteria are still implicit.")
    if not ensure_list(contract.get("context")):
        assumptions.append("Context is minimal, so the model may need to label assumptions.")
    return assumptions


def _compact_entries(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "entry_id": record["entry_id"],
            "name": record["name"],
            "summary": record.get("summary"),
        }
        for record in records
    ]


def _find_named(records: list[dict[str, Any]], name: str) -> dict[str, Any] | None:
    for record in records:
        if normalize_text(record.get("name")).lower() == normalize_text(name).lower():
            return record
    return None


def _selected_support_entries(
    repo: PromptCompassRepository,
    analysis: dict[str, Any],
    question_answers: dict[str, Any] | list[dict[str, Any]] | None,
) -> list[dict[str, Any]]:
    requested_ids: list[str] = []
    requested_ids.extend(str(item) for item in ensure_list(analysis.get("selected_entry_ids")))
    if isinstance(question_answers, dict):
        requested_ids.extend(str(item) for item in ensure_list(question_answers.get("_selected_entry_ids")))
    results: list[dict[str, Any]] = []
    seen: set[str] = set()
    for entry_id in requested_ids:
        if not entry_id:
            continue
        record = repo.get_entry(entry_id) if entry_id.startswith(("pc:", "pp:")) else repo.resolve_entry(entry_id)
        if not record.get("found"):
            continue
        if record.get("curation_status") != "supporting" and normalize_text(record.get("record_layer")) != "personal":
            continue
        canonical = record.get("entry_id")
        if canonical in seen:
            continue
        seen.add(canonical)
        results.append(record)
    return results


def _selected_prompt_library_items(
    repo: PromptCompassRepository,
    selected_prompt_library_ids: list[str] | None,
) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw_value in selected_prompt_library_ids or []:
        resolved = repo.get_prompt_library_item(raw_value)
        if not resolved.get("found"):
            continue
        canonical = resolved.get("item_id")
        if canonical in seen:
            continue
        seen.add(canonical)
        items.append(resolved)
    return items


def _apply_prompt_library_items(contract: dict[str, Any], items: list[dict[str, Any]]) -> dict[str, Any]:
    if not items:
        return contract
    updated = dict(contract)
    examples = ensure_list(updated.get("examples"))
    context = ensure_list(updated.get("context"))
    for item in items:
        title = normalize_text(item.get("title")) or normalize_text(item.get("id"))
        prompt_text = normalize_text(item.get("prompt_text"))
        if not prompt_text:
            continue
        examples.append(f"Saved {normalize_text(item.get('asset_kind')) or 'prompt'} reference: {title} — {prompt_text}")
        if normalize_text(item.get("success_notes")):
            context.append(f"Saved prompt success note ({title}): {normalize_text(item.get('success_notes'))}")
    updated["examples"] = examples
    updated["context"] = context
    return updated


def _compact_prompt_library_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "item_id": item.get("item_id"),
            "id": item.get("id"),
            "title": item.get("title"),
            "asset_kind": item.get("asset_kind"),
            "markdown_path": item.get("markdown_path"),
        }
        for item in items
    ]
