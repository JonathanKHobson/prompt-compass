#!/usr/bin/env python3

from __future__ import annotations

import argparse
import os
from pathlib import Path

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

from orientation import tool_description
from orientation import (
    agent_committee_flow_prompt_text,
    advanced_build_flow_prompt_text,
    advanced_improve_flow_prompt_text,
    autopilot_flow_prompt_text,
    browse_resolve_flow_prompt_text,
    personalize_reuse_flow_prompt_text,
    prompt_description,
    quick_build_flow_prompt_text,
    quick_improve_flow_prompt_text,
    route_request_prompt_text,
)
from personal_overlay import DEFAULT_PERSONAL_DB_PATH, DEFAULT_PERSONAL_VAULT_ROOT
from repository import PromptCompassRepository
from rewrite.model_targeting import target_prompt_to_model_payload
from service import (
    analyze_prompt_payload,
    build_prompt_payload,
    compare_prompts_payload,
    delete_personal_record_payload,
    delete_prompt_library_item_payload,
    diagnose_prompt_payload,
    flag_core_record_payload,
    get_started_service_payload,
    get_framework_payload,
    get_model_profile_payload,
    get_prompt_library_item_payload,
    get_record_payload,
    get_pattern_payload,
    get_technique_payload,
    get_term_payload,
    improve_prompt_workflow_payload,
    list_anti_patterns_service_payload,
    list_catalog_categories_service_payload,
    list_frameworks_service_payload,
    list_patterns_service_payload,
    list_prompt_examples_service_payload,
    list_prompt_templates_service_payload,
    list_strategies_service_payload,
    list_techniques_service_payload,
    list_terms_service_payload,
    manage_preferences_payload,
    list_core_review_flags_payload,
    list_tool_surface_service_payload,
    preflight_prompt_payload,
    prompt_compass_overview_service_payload,
    route_prompt_request_payload,
    save_personal_record_payload,
    save_prompt_library_item_payload,
    seed_personal_overlay_payload,
    search_prompt_library_payload,
    search_prompt_patterns_payload,
    suggest_strategies_payload,
    sync_personal_overlay_from_markdown_payload,
    target_prompt_to_surface_workflow_payload,
)
from question_loop.selector import get_clarifying_questions_payload


ROOT = Path(__file__).resolve().parent
DEFAULT_DB_PATH = ROOT / "db" / "prompt-compass.sqlite"
DEFAULT_PERSONAL_DB = Path(os.getenv("PROMPT_COMPASS_PERSONAL_DB_PATH", str(DEFAULT_PERSONAL_DB_PATH))).expanduser()
DEFAULT_PERSONAL_VAULT = Path(os.getenv("PROMPT_COMPASS_PERSONAL_VAULT_ROOT", str(DEFAULT_PERSONAL_VAULT_ROOT))).expanduser()

READ_ONLY = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=False,
)

WRITE_TOOL = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=False,
    openWorldHint=False,
)

DESTRUCTIVE_WRITE_TOOL = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    idempotentHint=False,
    openWorldHint=False,
)


def build_server(repo: PromptCompassRepository) -> FastMCP:
    server = FastMCP(
        name="prompt-compass",
        instructions=(
            "Prompt Compass MCP: local-first prompt engineering retrieval and deterministic prompt scaffolding. "
            "The host AI owns the conversation. Prompt Compass owns the knowledge base, prompt analysis, "
            "question selection, and structured output contracts. Route first when the user did not already name the workflow tool. "
            "For new or unclear sessions, establish the user's interaction pace first: quick fix, guided, or deep dive. "
            "Use plain-language questions by default and ask at most one user-facing question per turn. "
            "Do not browse frameworks first for rewrite/build jobs. When advanced improve/build returns must_pause=true, "
            "use native Claude/Codex question UI first when available, ask only the current stage, and do not continue until that gate clears. "
            "Treat returned runtime_policy_card, interaction_contract, host_validation, and required_tool_sequence as the active host contract; "
            "when native_ui_required=true, do not ask clarification questions in prose unless native UI is unavailable and fallback disclosure is shown. "
            "Agent Mode is advanced-only, explicit opt-in, approval-gated, and host-guided: Prompt Compass returns the committee contract; the host executes it."
        ),
        log_level="ERROR",
    )

    @server.tool(description=tool_description("prompt_compass_overview"), annotations=READ_ONLY)
    def prompt_compass_overview(topic: str | None = None, audience: str | None = "both") -> dict:
        return prompt_compass_overview_service_payload(repo, topic=topic, audience=audience)

    @server.tool(description=tool_description("get_started"), annotations=READ_ONLY)
    def get_started(topic: str | None = None, audience: str | None = "both") -> dict:
        return get_started_service_payload(repo, topic=topic, audience=audience)

    @server.tool(description=tool_description("route_prompt_request"), annotations=READ_ONLY)
    def route_prompt_request(
        user_request: str,
        model_target: str | None = None,
        previous_steps_completed: list[str] | None = None,
        host_capability_profile: dict | None = None,
        interaction_pace: str | None = None,
        delivery_mode: str | None = None,
        question_answers: dict | list[dict] | None = None,
        question_loop_state: dict | None = None,
    ) -> dict:
        return route_prompt_request_payload(
            repo,
            user_request,
            model_target=model_target,
            previous_steps_completed=previous_steps_completed,
            host_capability_profile=host_capability_profile,
            interaction_pace=interaction_pace,
            delivery_mode=delivery_mode,
            question_answers=question_answers,
            question_loop_state=question_loop_state,
        )

    @server.tool(description=tool_description("list_tool_surface"), annotations=READ_ONLY)
    def list_tool_surface(include_write_tools: bool = True, audience: str | None = "both") -> dict:
        return list_tool_surface_service_payload(include_write_tools=include_write_tools, audience=audience)

    @server.tool(description=tool_description("list_catalog_categories"), annotations=READ_ONLY)
    def list_catalog_categories() -> dict:
        return list_catalog_categories_service_payload(repo)

    @server.tool(description="Analyze a prompt for intent, prompt type, anti-patterns, missing building blocks, and RACCCA score.", annotations=READ_ONLY)
    def analyze_prompt(
        prompt: str,
        model_target: str | None = None,
        user_goal: str | None = None,
    ) -> dict:
        return analyze_prompt_payload(repo, prompt, model_target=model_target, user_goal=user_goal)

    @server.tool(description="Diagnose a prompt with detailed evidence, repair priority, and rewrite readiness without rewriting it.", annotations=READ_ONLY)
    def diagnose_prompt(
        prompt: str,
        model_target: str | None = None,
        user_goal: str | None = None,
    ) -> dict:
        return diagnose_prompt_payload(repo, prompt, model_target=model_target, user_goal=user_goal)

    @server.tool(description="Run a visible preflight check that scores prompt readiness, identifies blockers, and recommends the next routing step.", annotations=READ_ONLY)
    def preflight_prompt(
        prompt: str,
        model_target: str | None = None,
        user_goal: str | None = None,
    ) -> dict:
        return preflight_prompt_payload(repo, prompt, model_target=model_target, user_goal=user_goal)

    @server.tool(description="improve_prompt / improve prompt / rewrite prompt: strengthen an existing prompt in quick improve, advanced improve, Auto Flow next-tool, or approval-gated Agent Mode committee planning.", annotations=READ_ONLY)
    def improve_prompt(
        prompt: str,
        model_target: str | None = None,
        analysis: dict | None = None,
        question_answers: dict | list[dict] | None = None,
        question_loop_state: dict | None = None,
        selected_prompt_library_ids: list[str] | None = None,
        mode: str = "auto",
        interaction_style: str | None = None,
        interaction_pace: str | None = None,
        agent_mode: str = "off",
        host_capability_profile: dict | None = None,
        committee_depth: int = 0,
        committee_confirmation_token: str | None = None,
        preservation_mode: str = "balanced",
        delivery_mode: str = "standard",
    ) -> dict:
        return improve_prompt_workflow_payload(
            repo,
            prompt,
            model_target=model_target,
            analysis=analysis,
            question_answers=question_answers,
            question_loop_state=question_loop_state,
            selected_prompt_library_ids=selected_prompt_library_ids,
            mode=mode,
            interaction_style=interaction_style,
            interaction_pace=interaction_pace,
            agent_mode=agent_mode,
            host_capability_profile=host_capability_profile,
            committee_depth=committee_depth,
            committee_confirmation_token=committee_confirmation_token,
            preservation_mode=preservation_mode,
            delivery_mode=delivery_mode,
        )

    @server.tool(description="Compare two prompt versions and report measurable improvements, regressions, and remaining risks.", annotations=READ_ONLY)
    def compare_prompts(
        before_prompt: str,
        after_prompt: str,
        model_target: str | None = None,
    ) -> dict:
        return compare_prompts_payload(repo, before_prompt, after_prompt, model_target=model_target)

    @server.tool(description="Scaffold a new prompt from user intent in quick mode, advanced guided/direct mode, or approval-gated Agent Mode committee planning.", annotations=READ_ONLY)
    def build_prompt(
        user_intent: str,
        model_target: str | None = None,
        question_loop_state: dict | None = None,
        selected_prompt_library_ids: list[str] | None = None,
        mode: str = "auto",
        interaction_style: str | None = None,
        interaction_pace: str | None = None,
        agent_mode: str = "off",
        host_capability_profile: dict | None = None,
        committee_depth: int = 0,
        committee_confirmation_token: str | None = None,
    ) -> dict:
        return build_prompt_payload(
            repo,
            user_intent,
            model_target=model_target,
            question_loop_state=question_loop_state,
            selected_prompt_library_ids=selected_prompt_library_ids,
            mode=mode,
            interaction_style=interaction_style,
            interaction_pace=interaction_pace,
            agent_mode=agent_mode,
            host_capability_profile=host_capability_profile,
            committee_depth=committee_depth,
            committee_confirmation_token=committee_confirmation_token,
        )

    @server.tool(description="Adapt a prompt to a supported model profile.", annotations=READ_ONLY)
    def target_prompt_to_model(
        prompt: str,
        model_name: str,
        prompt_contract: dict | None = None,
    ) -> dict:
        return target_prompt_to_model_payload(repo, prompt, model_name, prompt_contract=prompt_contract)

    @server.tool(description="Adapt a prompt to a named execution surface such as parser-bound, retrieval-grounded, or tool-workflow, optionally followed by model targeting.", annotations=READ_ONLY)
    def target_prompt_to_surface(
        prompt: str,
        surface_name: str,
        model_target: str | None = None,
        prompt_contract: dict | None = None,
    ) -> dict:
        return target_prompt_to_surface_workflow_payload(
            repo,
            prompt,
            surface_name,
            model_target=model_target,
            prompt_contract=prompt_contract,
        )

    @server.tool(description="Search the local Prompt Compass KB across frameworks, strategies, patterns, anti-patterns, techniques, and terms. Use this for browsing after routing, not as the first step for rewrite/build workflows.", annotations=READ_ONLY)
    def search_prompt_patterns(
        query: str,
        record_types: list[str] | None = None,
        prompt_type: str | None = None,
        subject_area: str | None = None,
        model_target: str | None = None,
        interaction_mode: str | None = None,
        output_mode: str | None = None,
        grounding_mode: str | None = None,
        evaluation_mode: str | None = None,
        limit: int = 10,
    ) -> dict:
        return search_prompt_patterns_payload(
            repo,
            query,
            record_types=record_types,
            prompt_type=prompt_type,
            subject_area=subject_area,
            model_target=model_target,
            interaction_mode=interaction_mode,
            output_mode=output_mode,
            grounding_mode=grounding_mode,
            evaluation_mode=evaluation_mode,
            limit=limit,
        )

    @server.tool(description="Resolve a named framework with definition, template, examples, and related records. Do not use this as the first step when Prompt Compass should be improving, building, diagnosing, or preflighting a prompt.", annotations=READ_ONLY)
    def get_framework(name: str) -> dict:
        return get_framework_payload(repo, name)

    @server.tool(description="Resolve a named prompt pattern or anti-pattern. Use this for direct lookup after routing, not as the first workflow step for rewrite/build jobs.", annotations=READ_ONLY)
    def get_pattern(name: str) -> dict:
        return get_pattern_payload(repo, name)

    @server.tool(description="Resolve any named Prompt Compass record, optionally restricted to one or more record types. Use this after routing, not instead of a workflow tool.", annotations=READ_ONLY)
    def get_record(name: str, record_types: list[str] | None = None) -> dict:
        return get_record_payload(repo, name, record_types=record_types)

    @server.tool(description="Resolve a named prompt-engineering technique.", annotations=READ_ONLY)
    def get_technique(name: str) -> dict:
        return get_technique_payload(repo, name)

    @server.tool(description="Resolve a named prompt-engineering term.", annotations=READ_ONLY)
    def get_term(name: str) -> dict:
        return get_term_payload(repo, name)

    @server.tool(description=tool_description("list_frameworks"), annotations=READ_ONLY)
    def list_frameworks(query: str | None = None, limit: int = 10, catalog_scope: str = "core_first") -> dict:
        return list_frameworks_service_payload(repo, query=query, limit=limit, catalog_scope=catalog_scope)

    @server.tool(description=tool_description("list_strategies"), annotations=READ_ONLY)
    def list_strategies(query: str | None = None, limit: int = 10, catalog_scope: str = "core_first") -> dict:
        return list_strategies_service_payload(repo, query=query, limit=limit, catalog_scope=catalog_scope)

    @server.tool(description=tool_description("list_patterns"), annotations=READ_ONLY)
    def list_patterns(query: str | None = None, limit: int = 10, catalog_scope: str = "core_first") -> dict:
        return list_patterns_service_payload(repo, query=query, limit=limit, catalog_scope=catalog_scope)

    @server.tool(description=tool_description("list_techniques"), annotations=READ_ONLY)
    def list_techniques(query: str | None = None, limit: int = 10, catalog_scope: str = "core_first") -> dict:
        return list_techniques_service_payload(repo, query=query, limit=limit, catalog_scope=catalog_scope)

    @server.tool(description=tool_description("list_terms"), annotations=READ_ONLY)
    def list_terms(query: str | None = None, limit: int = 10, catalog_scope: str = "core_first") -> dict:
        return list_terms_service_payload(repo, query=query, limit=limit, catalog_scope=catalog_scope)

    @server.tool(description=tool_description("list_prompt_templates"), annotations=READ_ONLY)
    def list_prompt_templates(
        query: str | None = None,
        limit: int = 10,
        catalog_scope: str = "core_first",
        include_prompt_library: bool = False,
    ) -> dict:
        return list_prompt_templates_service_payload(
            repo,
            query=query,
            limit=limit,
            catalog_scope=catalog_scope,
            include_prompt_library=include_prompt_library,
        )

    @server.tool(description=tool_description("list_prompt_examples"), annotations=READ_ONLY)
    def list_prompt_examples(
        query: str | None = None,
        limit: int = 10,
        catalog_scope: str = "core_first",
        include_prompt_library: bool = False,
    ) -> dict:
        return list_prompt_examples_service_payload(
            repo,
            query=query,
            limit=limit,
            catalog_scope=catalog_scope,
            include_prompt_library=include_prompt_library,
        )

    @server.tool(description="Create or update a personal Prompt Compass record in the writable overlay and Markdown mirror.", annotations=WRITE_TOOL)
    def save_personal_record(
        record: dict,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict:
        return save_personal_record_payload(repo, record, confirm=confirm, confirmation_token=confirmation_token)

    @server.tool(description="Guide and confirm first personal-overlay seed records without mutating the built-in Prompt Compass KB.", annotations=WRITE_TOOL)
    def seed_personal_overlay(
        seed_answers: dict | None = None,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict:
        return seed_personal_overlay_payload(repo, seed_answers, confirm=confirm, confirmation_token=confirmation_token)

    @server.tool(description="Read, preview, confirm, or reset Prompt Compass preferences for Auto Flow without mutating the shared core DB.", annotations=WRITE_TOOL)
    def manage_preferences(
        preferences: dict | None = None,
        reset: bool = False,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict:
        return manage_preferences_payload(
            repo,
            preferences,
            reset=reset,
            confirm=confirm,
            confirmation_token=confirmation_token,
        )

    @server.tool(description="Delete a personal Prompt Compass record from the writable overlay and Markdown mirror.", annotations=DESTRUCTIVE_WRITE_TOOL)
    def delete_personal_record(
        value: str,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict:
        return delete_personal_record_payload(repo, value, confirm=confirm, confirmation_token=confirmation_token)

    @server.tool(description="Create or update a saved prompt, template, or example in the personal prompt library.", annotations=WRITE_TOOL)
    def save_prompt_library_item(
        item: dict,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict:
        return save_prompt_library_item_payload(repo, item, confirm=confirm, confirmation_token=confirmation_token)

    @server.tool(description="Delete a saved prompt, template, or example from the personal prompt library.", annotations=DESTRUCTIVE_WRITE_TOOL)
    def delete_prompt_library_item(
        value: str,
        confirm: bool = False,
        confirmation_token: str | None = None,
    ) -> dict:
        return delete_prompt_library_item_payload(repo, value, confirm=confirm, confirmation_token=confirmation_token)

    @server.tool(description="Search saved prompts, templates, and examples in the personal prompt library.", annotations=READ_ONLY)
    def search_prompt_library(
        query: str,
        asset_kind: str | None = None,
        model_target: str | None = None,
        target_surface: str | None = None,
        tags: list[str] | None = None,
        limit: int = 10,
    ) -> dict:
        return search_prompt_library_payload(
            repo,
            query,
            asset_kind=asset_kind,
            model_target=model_target,
            target_surface=target_surface,
            tags=tags,
            limit=limit,
        )

    @server.tool(description="Get one saved prompt, template, or example from the personal prompt library.", annotations=READ_ONLY)
    def get_prompt_library_item(value: str) -> dict:
        return get_prompt_library_item_payload(repo, value)

    @server.tool(description="Flag a built-in Prompt Compass record for later review without mutating the core corpus.", annotations=WRITE_TOOL)
    def flag_core_record(
        target_entry_id: str,
        reason: str,
        suggested_action: str,
        notes: str | None = None,
    ) -> dict:
        return flag_core_record_payload(
            repo,
            target_entry_id,
            reason,
            suggested_action,
            notes=notes,
        )

    @server.tool(description="List review flags created for immutable core Prompt Compass records.", annotations=READ_ONLY)
    def list_core_review_flags(
        status: str | None = None,
        target_entry_id: str | None = None,
        limit: int = 25,
    ) -> dict:
        return list_core_review_flags_payload(repo, status=status, target_entry_id=target_entry_id, limit=limit)

    @server.tool(description="Scan the personal Prompt Compass vault and upsert personal records and saved prompts into the writable overlay DB.", annotations=WRITE_TOOL)
    def sync_personal_overlay_from_markdown() -> dict:
        return sync_personal_overlay_from_markdown_payload(repo)

    @server.tool(description=tool_description("list_anti_patterns"), annotations=READ_ONLY)
    def list_anti_patterns(
        limit: int = 25,
        severity: str | None = None,
        prompt_type: str | None = None,
        catalog_scope: str = "core_first",
    ) -> dict:
        return list_anti_patterns_service_payload(
            repo,
            limit=limit,
            severity=severity,
            prompt_type=prompt_type,
            catalog_scope=catalog_scope,
        )

    @server.tool(description="Return 3 to 5 targeted clarifying questions for prompt improvement or prompt building.", annotations=READ_ONLY)
    def get_clarifying_questions(analysis: dict, question_loop_state: dict | None = None, limit: int | None = None) -> dict:
        return get_clarifying_questions_payload(repo, analysis, question_loop_state=question_loop_state, limit=limit)

    @server.tool(description="Rank applicable prompt strategies for a prompt type, subject area, and model target.", annotations=READ_ONLY)
    def suggest_strategies(
        prompt_type: str,
        subject_area: str,
        model_target: str | None = None,
        interaction_mode: str | None = None,
        output_mode: str | None = None,
        grounding_mode: str | None = None,
        evaluation_mode: str | None = None,
        capability_tags: list[str] | None = None,
        anti_patterns: list[dict] | None = None,
        missing_building_blocks: list[str] | None = None,
    ) -> dict:
        return suggest_strategies_payload(
            repo,
            prompt_type=prompt_type,
            subject_area=subject_area,
            model_target=model_target,
            interaction_mode=interaction_mode,
            output_mode=output_mode,
            grounding_mode=grounding_mode,
            evaluation_mode=evaluation_mode,
            capability_tags=capability_tags,
            anti_patterns=anti_patterns,
            missing_building_blocks=missing_building_blocks,
        )

    @server.tool(description="Return a supported model profile with prompting preferences and avoid-list notes.", annotations=READ_ONLY)
    def get_model_profile(model_name: str) -> dict:
        return get_model_profile_payload(repo, model_name)

    @server.prompt(description=prompt_description("pc_route_request"))
    def pc_route_request(user_request: str) -> str:
        return route_request_prompt_text(user_request)

    @server.prompt(description=prompt_description("pc_quick_improve_flow"))
    def pc_quick_improve_flow(prompt_text: str) -> str:
        return quick_improve_flow_prompt_text(prompt_text)

    @server.prompt(description=prompt_description("pc_advanced_improve_flow"))
    def pc_advanced_improve_flow(prompt_text: str) -> str:
        return advanced_improve_flow_prompt_text(prompt_text)

    @server.prompt(description=prompt_description("pc_autopilot_flow"))
    def pc_autopilot_flow(user_request: str) -> str:
        return autopilot_flow_prompt_text(user_request)

    @server.prompt(description=prompt_description("pc_quick_build_flow"))
    def pc_quick_build_flow(user_intent: str) -> str:
        return quick_build_flow_prompt_text(user_intent)

    @server.prompt(description=prompt_description("pc_advanced_build_flow"))
    def pc_advanced_build_flow(user_intent: str) -> str:
        return advanced_build_flow_prompt_text(user_intent)

    @server.prompt(description=prompt_description("pc_agent_committee_flow"))
    def pc_agent_committee_flow(user_request: str) -> str:
        return agent_committee_flow_prompt_text(user_request)

    @server.prompt(description=prompt_description("pc_browse_resolve_flow"))
    def pc_browse_resolve_flow(query: str) -> str:
        return browse_resolve_flow_prompt_text(query)

    @server.prompt(description=prompt_description("pc_personalize_reuse_flow"))
    def pc_personalize_reuse_flow(user_goal: str) -> str:
        return personalize_reuse_flow_prompt_text(user_goal)

    return server


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the Prompt Compass MCP server.")
    parser.add_argument("--db-path", default=str(DEFAULT_DB_PATH), help="Path to prompt-compass.sqlite")
    parser.add_argument("--personal-db-path", default=str(DEFAULT_PERSONAL_DB), help="Path to the writable personal overlay SQLite DB.")
    parser.add_argument("--personal-vault-root", default=str(DEFAULT_PERSONAL_VAULT), help="Path to the Prompt Compass Personal Markdown vault root.")
    parser.add_argument("--boot-check", action="store_true", help="Construct the live FastMCP server and exit.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    repo = PromptCompassRepository(
        args.db_path,
        personal_db_path=args.personal_db_path,
        personal_vault_root=args.personal_vault_root,
    )
    try:
        server = build_server(repo)
        if args.boot_check:
            print("Prompt Compass server boot check passed.")
            return
        server.run(transport="stdio")
    finally:
        repo.close()


if __name__ == "__main__":
    main()
