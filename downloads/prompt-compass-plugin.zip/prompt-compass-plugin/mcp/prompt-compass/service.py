from __future__ import annotations

import re
from typing import Any

from analysis.contracts import build_prompt_contract, contract_missing_blocks, merge_question_answers
from analysis.detect import (
    build_output_contract_check,
    build_retrieval_keywords,
    detect_ai_data_risk_warnings,
    detect_capability_tags,
    detect_anti_patterns,
    detect_semantic_conflicts,
    detect_evaluation_mode,
    detect_grounding_mode,
    detect_intent,
    detect_interaction_mode,
    detect_output_mode,
    detect_prompt_type,
    detect_subject_area,
)
from atlas_assets import (
    select_audience_targeting_seeds,
    select_prompt_library_starter_examples,
    select_task_template_examples,
)
from analysis.philosophy import (
    build_prompt_fingerprint,
    compress_role_line,
    core_principles_applied,
    detect_primary_pattern,
    guess_primary_deliverable,
)
from analysis.matchers import suggest_strategy_records
from analysis.phase2s import (
    phase2s_fields,
    postflight_validation_for,
    retrieval_budget_for,
    schema_validation_for,
)
from analysis.phase2u import (
    apply_role_domain_calibration,
    compiled_prompt_artifact,
    role_prompt_assessment,
    success_criteria_contract,
    surface_targeting_profile,
)
from analysis.preflight import build_preflight_fields, classify_prompt_surface
from analysis.score import raccca_score
from committee import (
    allowlist_enforcement_mode,
    artifact_budget,
    build_committee_plan,
    build_confirmation_bundle,
    build_host_execution_instructions,
    build_role_contracts,
    committee_plan_hash,
    committee_stop_reason,
    confirmation_error,
    has_agent_mode_signal,
    normalize_host_capability_profile,
    prefers_direct_interaction,
    prefers_guided_interaction,
    validate_confirmation,
)
from common import ensure_list, normalize_text, short_text, tokenize
from orientation import (
    get_started_payload as orientation_get_started_payload,
    list_anti_patterns_payload,
    list_catalog_categories_payload,
    list_frameworks_payload,
    list_patterns_payload,
    list_prompt_examples_payload,
    list_prompt_templates_payload,
    list_strategies_payload,
    list_techniques_payload,
    list_terms_payload,
    list_tool_surface_payload,
    prompt_compass_overview_payload,
)
from question_loop.selector import get_clarifying_questions_payload
from question_loop.state import merge_question_loop_answers, normalize_question_loop_state, register_pending_questions
from repository import PromptCompassRepository
from rewrite.contract_builder import render_prompt_contract
from rewrite.model_targeting import infer_model_name, normalize_model_name, target_prompt_to_model_payload
from rewrite.prompt_rewriter import improve_prompt_payload
from rewrite.surface_targeting import target_prompt_to_surface_payload as rewrite_target_prompt_to_surface_payload


LOOKUP_FIRST_BLOCKED_TOOLS = [
    "search_prompt_patterns",
    "get_framework",
    "get_pattern",
    "get_record",
    "get_technique",
    "get_term",
    "list_frameworks",
    "list_strategies",
    "list_patterns",
    "list_techniques",
    "list_terms",
    "list_prompt_templates",
    "list_prompt_examples",
    "list_anti_patterns",
]

INTERACTION_PACES = {"quick_fix", "guided", "deep_dive"}
DELIVERY_MODES = {"standard", "autopilot"}
AUTOFLOW_DEFAULT_NUDGE = (
    "Auto Flow is running with balanced defaults. After this task, call manage_preferences to choose whether Auto Flow "
    "runs by default, shows a brief note, and asks before bigger rewrites."
)

PACE_CHOICES = [
    {"label": "Quick fix", "value": "quick_fix"},
    {"label": "Guided", "value": "guided"},
    {"label": "Deep dive", "value": "deep_dive"},
]

ROUTE_SELECTION_ALIASES = {
    "1": "improve_prompt",
    "improve": "improve_prompt",
    "improve a draft": "improve_prompt",
    "make something better": "improve_prompt",
    "make this better": "improve_prompt",
    "fix a draft": "improve_prompt",
    "rewrite": "improve_prompt",
    "rewrite a draft": "improve_prompt",
    "2": "diagnose_prompt",
    "diagnose": "diagnose_prompt",
    "diagnose a draft": "diagnose_prompt",
    "what is wrong": "diagnose_prompt",
    "what's wrong": "diagnose_prompt",
    "3": "build_prompt",
    "build": "build_prompt",
    "build from scratch": "build_prompt",
    "write something new": "build_prompt",
    "new prompt": "build_prompt",
    "from scratch": "build_prompt",
    "4": "preflight_prompt",
    "runtime preflight": "preflight_prompt",
    "preflight": "preflight_prompt",
    "check before using": "preflight_prompt",
    "5": "list_catalog_categories",
    "browse": "list_catalog_categories",
    "browse the kb": "list_catalog_categories",
    "show examples": "list_catalog_categories",
    "examples": "list_catalog_categories",
}


def analyze_prompt_payload(
    repo: PromptCompassRepository,
    prompt: str,
    *,
    model_target: str | None = None,
    user_goal: str | None = None,
) -> dict[str, Any]:
    base = _base_analysis_payload(repo, prompt, model_target=model_target, user_goal=user_goal)
    surface = classify_prompt_surface(
        prompt,
        contract=base["prompt_contract"],
        subject_area=base["subject_area"],
        interaction_mode=base["interaction_mode"],
        output_mode=base["output_mode"],
        grounding_mode=base["grounding_mode"],
        evaluation_mode=base["evaluation_mode"],
        capability_tags=base["capability_tags"],
        anti_patterns=base["anti_patterns"],
    )
    analysis = {
        **base,
        **surface,
    }
    analysis.update(build_preflight_fields(prompt, analysis=analysis))
    analysis.update(
        phase2s_fields(
            prompt,
            analysis,
            tool_name="analyze_prompt",
            workflow="analysis_only",
            runtime_payload=analysis,
        )
    )
    return analysis


def _base_analysis_payload(
    repo: PromptCompassRepository,
    prompt: str,
    *,
    model_target: str | None = None,
    user_goal: str | None = None,
) -> dict[str, Any]:
    resolved_model = normalize_model_name(repo, model_target) if model_target else ""
    subject_area = detect_subject_area(prompt)
    prompt_type = detect_prompt_type(prompt, user_goal=user_goal)
    contract = build_prompt_contract(
        prompt,
        user_goal=user_goal,
        model_target=resolved_model or model_target,
        subject_area=subject_area,
        prompt_type=prompt_type,
    )
    anti_patterns = detect_anti_patterns(prompt, contract)
    semantic_conflicts = detect_semantic_conflicts(prompt, contract)
    ai_data_risk_warnings = detect_ai_data_risk_warnings(prompt, contract)
    missing = contract_missing_blocks(contract)
    output_contract_check = build_output_contract_check(contract)
    raccca = raccca_score(
        prompt,
        contract,
        anti_patterns,
        output_contract_check=output_contract_check,
        semantic_conflicts=semantic_conflicts,
        ai_data_risk_warnings=ai_data_risk_warnings,
    )
    intent = detect_intent(prompt, contract, user_goal=user_goal)
    interaction_mode = detect_interaction_mode(prompt, user_goal=user_goal)
    output_mode = detect_output_mode(prompt, contract)
    grounding_mode = detect_grounding_mode(prompt, contract)
    evaluation_mode = detect_evaluation_mode(prompt, contract)
    capability_tags = detect_capability_tags(prompt, contract)
    prompt_fingerprint = build_prompt_fingerprint(prompt, contract)
    primary_deliverable_guess = guess_primary_deliverable(prompt, contract)
    retrieval_keywords = build_retrieval_keywords(
        intent,
        subject_area,
        prompt_type,
        anti_patterns,
        missing,
        model_target=resolved_model or model_target,
        interaction_mode=interaction_mode,
        output_mode=output_mode,
        grounding_mode=grounding_mode,
        evaluation_mode=evaluation_mode,
        capability_tags=capability_tags,
    )
    return {
        "detected_intent": intent,
        "subject_area": subject_area,
        "prompt_type": prompt_type,
        "interaction_mode": interaction_mode,
        "output_mode": output_mode,
        "grounding_mode": grounding_mode,
        "evaluation_mode": evaluation_mode,
        "capability_tags": capability_tags,
        "anti_patterns": anti_patterns,
        "semantic_conflicts": semantic_conflicts,
        "ai_data_risk_warnings": ai_data_risk_warnings,
        "missing_building_blocks": missing,
        "raccca": raccca,
        "output_contract_check": output_contract_check,
        "retrieval_keywords": retrieval_keywords,
        "prompt_contract": contract,
        "prompt_fingerprint": prompt_fingerprint,
        "primary_deliverable_guess": primary_deliverable_guess,
    }


def preflight_prompt_payload(
    repo: PromptCompassRepository,
    prompt: str,
    *,
    model_target: str | None = None,
    user_goal: str | None = None,
) -> dict[str, Any]:
    analysis = analyze_prompt_payload(repo, prompt, model_target=model_target, user_goal=user_goal)
    strategy_payload = suggest_strategies_payload(
        repo,
        prompt_type=analysis["prompt_type"],
        subject_area=analysis["subject_area"],
        model_target=analysis["prompt_contract"].get("model_target") or model_target,
        interaction_mode=analysis.get("interaction_mode"),
        output_mode=analysis.get("output_mode"),
        grounding_mode=analysis.get("grounding_mode"),
        evaluation_mode=analysis.get("evaluation_mode"),
        capability_tags=analysis.get("capability_tags", []),
        anti_patterns=analysis.get("anti_patterns", []),
        missing_building_blocks=analysis.get("missing_building_blocks", []),
        prompt_surface=analysis.get("prompt_surface"),
        surface_traits=analysis.get("surface_traits", []),
    )
    payload = {
        "prompt_surface": analysis["prompt_surface"],
        "surface_traits": analysis["surface_traits"],
        "preflight_scorecard": analysis["preflight_scorecard"],
        "preflight_status": analysis["preflight_status"],
        "blocking_issues": analysis["blocking_issues"],
        "warning_flags": analysis["warning_flags"],
        "efficiency_flags": analysis["efficiency_flags"],
        "fix_now": analysis["fix_now"],
        "recommended_question_slots": analysis["recommended_question_slots"],
        "recommended_strategies": strategy_payload["strategies"],
        "recommended_next_action": analysis["recommended_next_action"],
        "raccca": analysis["raccca"],
        "semantic_conflicts": analysis.get("semantic_conflicts", []),
        "ai_data_risk_warnings": analysis.get("ai_data_risk_warnings", []),
        "prompt_contract": analysis["prompt_contract"],
    }
    payload.update(
        phase2s_fields(
            prompt,
            {**analysis, **payload},
            tool_name="preflight_prompt",
            workflow="analysis_only",
            runtime_payload=payload,
            selected={"strategies": payload.get("recommended_strategies", [])},
        )
    )
    payload.update(
        surface_targeting_profile(
            payload.get("prompt_surface") or "direct_chat",
            payload.get("prompt_contract", {}),
        )
    )
    return payload


def _deep_merge_dict(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in overlay.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge_dict(merged[key], value)
        elif value is not None:
            merged[key] = value
    return merged


def _normalize_analysis_input(
    repo: PromptCompassRepository,
    prompt: str,
    analysis: dict[str, Any] | None,
    *,
    model_target: str | None = None,
) -> dict[str, Any]:
    base = analyze_prompt_payload(repo, prompt, model_target=model_target)
    if analysis is None:
        return base
    if not isinstance(analysis, dict):
        base["analysis_input_normalized"] = True
        base["analysis_validation_warnings"] = ["Provided analysis was not an object, so Prompt Compass rebuilt analysis from the prompt."]
        return base
    merged = _deep_merge_dict(base, analysis)
    contract = merged.get("prompt_contract") if isinstance(merged.get("prompt_contract"), dict) else {}
    merged["prompt_contract"] = _deep_merge_dict(base.get("prompt_contract", {}), contract)
    merged["missing_building_blocks"] = contract_missing_blocks(merged["prompt_contract"])
    merged.setdefault("anti_patterns", base.get("anti_patterns", []))
    merged.setdefault("semantic_conflicts", base.get("semantic_conflicts", []))
    merged.setdefault("ai_data_risk_warnings", base.get("ai_data_risk_warnings", []))
    merged.setdefault("raccca", base.get("raccca", {}))
    merged.setdefault("output_contract_check", base.get("output_contract_check", {}))
    merged["analysis_input_normalized"] = True
    missing_keys = [
        key
        for key in ("prompt_contract", "raccca", "anti_patterns", "prompt_surface")
        if key not in analysis
    ]
    if missing_keys:
        merged["analysis_validation_warnings"] = [
            "Partial analysis input was merged over a fresh analyze_prompt payload.",
            "Filled missing keys: " + ", ".join(missing_keys) + ".",
        ]
    else:
        merged["analysis_validation_warnings"] = []
    return merged


def diagnose_prompt_payload(
    repo: PromptCompassRepository,
    prompt: str,
    *,
    model_target: str | None = None,
    user_goal: str | None = None,
) -> dict[str, Any]:
    analysis = analyze_prompt_payload(repo, prompt, model_target=model_target, user_goal=user_goal)
    strategies = suggest_strategies_payload(
        repo,
        prompt_type=analysis["prompt_type"],
        subject_area=analysis["subject_area"],
        model_target=analysis["prompt_contract"].get("model_target") or model_target,
        interaction_mode=analysis.get("interaction_mode"),
        output_mode=analysis.get("output_mode"),
        grounding_mode=analysis.get("grounding_mode"),
        evaluation_mode=analysis.get("evaluation_mode"),
        capability_tags=analysis.get("capability_tags", []),
        anti_patterns=analysis.get("anti_patterns", []),
        missing_building_blocks=analysis.get("missing_building_blocks", []),
        prompt_surface=analysis.get("prompt_surface"),
        surface_traits=analysis.get("surface_traits", []),
    )
    questions = get_clarifying_questions_payload(repo, analysis, limit=3)
    payload = {
        "status": "diagnosis_ready",
        "tool": "diagnose_prompt",
        "does_not_rewrite": True,
        "detected_intent": analysis["detected_intent"],
        "prompt_type": analysis["prompt_type"],
        "subject_area": analysis["subject_area"],
        "taxonomy": {
            "interaction_mode": analysis.get("interaction_mode"),
            "output_mode": analysis.get("output_mode"),
            "grounding_mode": analysis.get("grounding_mode"),
            "evaluation_mode": analysis.get("evaluation_mode"),
            "capability_tags": analysis.get("capability_tags", []),
            "prompt_surface": analysis.get("prompt_surface"),
        },
        "structural_measurements": _structural_measurements(prompt),
        "anti_pattern_diagnosis": _anti_pattern_diagnosis(repo, analysis.get("anti_patterns", [])),
        "missing_building_blocks": analysis.get("missing_building_blocks", []),
        "raccca": analysis["raccca"],
        "raccca_evidence": _raccca_evidence(analysis["raccca"]),
        "semantic_conflicts": analysis.get("semantic_conflicts", []),
        "ai_data_risk_warnings": analysis.get("ai_data_risk_warnings", []),
        "prompt_fingerprint": analysis.get("prompt_fingerprint"),
        "primary_deliverable_guess": analysis.get("primary_deliverable_guess"),
        "repair_order": _repair_order(analysis),
        "rewrite_readiness": _rewrite_readiness(analysis),
        "recommended_strategies": strategies.get("strategies", [])[:5],
        "questions_to_ask_before_rewrite": questions.get("questions_for_user", [])[:3],
        "prompt_contract": analysis["prompt_contract"],
    }
    payload.update(
        phase2s_fields(
            prompt,
            {**analysis, **payload},
            tool_name="diagnose_prompt",
            workflow="analysis_only",
            runtime_payload=payload,
            selected={"strategies": payload.get("recommended_strategies", [])},
        )
    )
    return payload


def compare_prompts_payload(
    repo: PromptCompassRepository,
    before_prompt: str,
    after_prompt: str,
    *,
    model_target: str | None = None,
) -> dict[str, Any]:
    before = analyze_prompt_payload(repo, before_prompt, model_target=model_target)
    after = analyze_prompt_payload(repo, after_prompt, model_target=model_target)
    before_slugs = {item.get("slug") for item in before.get("anti_patterns", []) if item.get("slug")}
    after_slugs = {item.get("slug") for item in after.get("anti_patterns", []) if item.get("slug")}
    raccca_delta = _raccca_delta(before["raccca"], after["raccca"])
    resolved = sorted(before_slugs - after_slugs)
    introduced = sorted(after_slugs - before_slugs)
    unchanged = sorted(before_slugs & after_slugs)
    missing_before = set(before.get("missing_building_blocks", []))
    missing_after = set(after.get("missing_building_blocks", []))
    verdict = _comparison_verdict(raccca_delta["total_delta"], resolved, introduced, missing_before, missing_after)
    agentic_delta = _agentic_prompt_delta(before.get("agentic_prompt_score", {}), after.get("agentic_prompt_score", {}))
    budget = retrieval_budget_for("analysis_only")
    payload = {
        "status": "comparison_ready",
        "tool": "compare_prompts",
        "before_summary": _analysis_summary(before),
        "after_summary": _analysis_summary(after),
        "raccca_delta": raccca_delta,
        "contract_schema_version": before.get("contract_schema_version") or after.get("contract_schema_version"),
        "prompt_ir": {
            "before": before.get("prompt_ir", {}),
            "after": after.get("prompt_ir", {}),
        },
        "agentic_prompt_score": {
            "before": before.get("agentic_prompt_score", {}),
            "after": after.get("agentic_prompt_score", {}),
            **agentic_delta,
        },
        "retrieval_budget": budget,
        "retrieval_trace": {
            "workflow": "analysis_only",
            "budget_applied": True,
            "before": before.get("retrieval_trace", {}),
            "after": after.get("retrieval_trace", {}),
        },
        "anti_pattern_delta": {
            "resolved": resolved,
            "introduced": introduced,
            "unchanged": unchanged,
        },
        "missing_block_delta": {
            "resolved": sorted(missing_before - missing_after),
            "introduced": sorted(missing_after - missing_before),
            "unchanged": sorted(missing_before & missing_after),
        },
        "prompt_contract_diff": _contract_diff(before["prompt_contract"], after["prompt_contract"]),
        "recommendation": verdict,
        "is_after_prompt_better": verdict["is_better"],
    }
    payload["schema_validation"] = schema_validation_for(payload, tool_name="compare_prompts")
    payload["postflight_validation"] = postflight_validation_for(payload, tool_name="compare_prompts")
    return payload


def _comparison_summary(comparison: dict[str, Any]) -> dict[str, Any]:
    anti_delta = comparison.get("anti_pattern_delta", {})
    missing_delta = comparison.get("missing_block_delta", {})
    introduced_risks = [
        *ensure_list(anti_delta.get("introduced")),
        *[f"missing:{item}" for item in ensure_list(missing_delta.get("introduced"))],
    ]
    return {
        "raccca_delta": comparison.get("raccca_delta", {}),
        "resolved_anti_patterns": ensure_list(anti_delta.get("resolved")),
        "introduced_risks": introduced_risks,
        "verdict": (comparison.get("recommendation") or {}).get("verdict"),
        "is_after_prompt_better": comparison.get("is_after_prompt_better"),
    }


def _attach_auto_comparison(
    repo: PromptCompassRepository,
    before_prompt: str,
    payload: dict[str, Any],
    *,
    model_target: str | None = None,
) -> dict[str, Any]:
    after_prompt = normalize_text(payload.get("rewritten_prompt"))
    if not after_prompt:
        payload["comparison_auto_run"] = False
        payload["comparison_summary"] = {}
        return payload
    comparison = compare_prompts_payload(repo, before_prompt, after_prompt, model_target=model_target)
    payload["comparison_auto_run"] = True
    payload["comparison_summary"] = _comparison_summary(comparison)
    return payload


def _diagnosis_complexity_cues(analysis: dict[str, Any]) -> list[str]:
    fingerprint = analysis.get("prompt_fingerprint") if isinstance(analysis.get("prompt_fingerprint"), dict) else {}
    cues: list[str] = []
    if fingerprint.get("voice_memo_like"):
        cues.append("voice_memo_like")
    if fingerprint.get("role_heavy"):
        cues.append("role_heavy")
    if fingerprint.get("source_pack_heavy"):
        cues.append("source_pack_heavy")
    if fingerprint.get("trait_stack_heavy"):
        cues.append("trait_stack_heavy")
    if fingerprint.get("multi_deliverable_risk"):
        cues.append("multi_deliverable_sprawl")
    if "output_contract" in ensure_list(analysis.get("missing_building_blocks")):
        cues.append("missing_output_contract")
    return cues


def _analysis_diagnosis_depth(analysis: dict[str, Any], *, explicit_deep: bool = False) -> str:
    fingerprint = analysis.get("prompt_fingerprint") if isinstance(analysis.get("prompt_fingerprint"), dict) else {}
    if explicit_deep:
        return "deep"
    if int(fingerprint.get("word_count") or 0) >= 180:
        return "deep"
    if len(_diagnosis_complexity_cues(analysis)) >= 2:
        return "deep"
    return "light"


def _recommended_diagnosis_depth_for_request(
    repo: PromptCompassRepository,
    request: str,
    *,
    detected_job: str,
) -> str:
    lowered = request.lower()
    if _wants_deep_diagnosis(lowered):
        return "deep"
    if detected_job not in {"diagnose_draft", "rewrite_draft"} and not _has_draft_signal(lowered):
        return "light"
    analysis = analyze_prompt_payload(repo, request)
    return _analysis_diagnosis_depth(analysis)


def _advanced_diagnosis_fields(
    repo: PromptCompassRepository,
    prompt: str,
    analysis: dict[str, Any],
    *,
    model_target: str | None = None,
) -> dict[str, Any]:
    depth = _analysis_diagnosis_depth(analysis)
    fields: dict[str, Any] = {
        "diagnosis_depth_used": depth,
        "diagnosis_complexity_cues": _diagnosis_complexity_cues(analysis),
    }
    if depth != "deep":
        return fields
    diagnosis = diagnose_prompt_payload(repo, prompt, model_target=model_target)
    fields["deep_diagnosis_summary"] = {
        "repair_order": diagnosis.get("repair_order", []),
        "rewrite_readiness": diagnosis.get("rewrite_readiness", {}),
        "anti_patterns": [
            {
                "slug": item.get("slug"),
                "severity": item.get("severity"),
                "why_detected": item.get("why_detected"),
            }
            for item in diagnosis.get("anti_pattern_diagnosis", [])[:4]
        ],
    }
    return fields


def _structural_measurements(prompt: str) -> dict[str, Any]:
    lines = [line for line in prompt.splitlines() if line.strip()]
    lowered = prompt.lower()
    role_cues = len(
        [
            token
            for token in ("act as", "you are", "as an", "as a", "role:", "persona:")
            if token in lowered
        ]
    )
    directive_cues = len(
        [
            token
            for token in tokenize(prompt)
            if token in {"must", "should", "need", "return", "include", "avoid", "ask", "stop", "continue", "follow"}
        ]
    )
    section_count = sum(1 for line in lines if ":" in line[:50])
    adjective_cues = len(
        [
            token
            for token in tokenize(prompt)
            if token in {"clear", "clearer", "sharp", "sharper", "strategic", "compelling", "polished", "professional", "lucid", "pivotal"}
        ]
    )
    return {
        "word_count": len(tokenize(prompt)),
        "line_count": len(lines),
        "visible_section_count": section_count,
        "role_cue_count": role_cues,
        "directive_cue_count": directive_cues,
        "adjective_style_cue_count": adjective_cues,
    }


def _anti_pattern_diagnosis(repo: PromptCompassRepository, anti_patterns: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in anti_patterns:
        entry_id = item.get("entry_id") or f"pc:anti_pattern:{item.get('slug')}"
        record = repo.get_entry(entry_id)
        rows.append(
            {
                "slug": item.get("slug"),
                "name": item.get("name"),
                "severity": item.get("severity"),
                "why_detected": item.get("why_detected"),
                "evidence": item.get("evidence", []),
                "fix": record.get("fix") or short_text(" ".join(record.get("fixes", [])), 220) if record.get("found") else "",
                "what_it_looks_like": record.get("what_it_looks_like", "") if record.get("found") else "",
            }
        )
    return rows


def _raccca_evidence(raccca: dict[str, Any]) -> list[dict[str, Any]]:
    dimensions = raccca.get("dimensions", {}) if isinstance(raccca, dict) else {}
    rows: list[dict[str, Any]] = []
    for name, payload in dimensions.items():
        rows.append(
            {
                "dimension": name,
                "score": payload.get("score"),
                "evidence": payload.get("rationale"),
            }
        )
    return rows


def _repair_order(analysis: dict[str, Any]) -> list[dict[str, Any]]:
    order: list[dict[str, Any]] = []
    priority = 1
    for block in analysis.get("missing_building_blocks", []):
        order.append(
            {
                "priority": priority,
                "repair": f"Fill missing `{block}`",
                "why": "Missing prompt-contract slots should be repaired before polishing style.",
            }
        )
        priority += 1
    severity_rank = {"high": 0, "medium": 1, "low": 2}
    for item in sorted(analysis.get("anti_patterns", []), key=lambda anti: severity_rank.get(normalize_text(anti.get("severity")), 3)):
        order.append(
            {
                "priority": priority,
                "repair": f"Address {item.get('name')}",
                "why": item.get("why_detected"),
            }
        )
        priority += 1
    return order[:8]


def _rewrite_readiness(analysis: dict[str, Any]) -> dict[str, Any]:
    missing = set(analysis.get("missing_building_blocks", []))
    high_risk = [item for item in analysis.get("anti_patterns", []) if item.get("severity") == "high"]
    blocking_missing = sorted(missing & {"objective", "output_contract", "audience"})
    if blocking_missing:
        status = "needs_user_input"
        reason = "The prompt is missing key contract slots that can change the rewrite substantially."
    elif high_risk:
        status = "rewrite_possible_with_assumptions"
        reason = "A rewrite can proceed, but the host should name assumptions and repair high-risk anti-patterns."
    else:
        status = "ready_for_rewrite"
        reason = "The prompt has enough contract signal for a quick rewrite."
    return {
        "status": status,
        "reason": reason,
        "blocking_missing_blocks": blocking_missing,
        "high_risk_anti_patterns": [item.get("slug") for item in high_risk],
    }


def _analysis_summary(analysis: dict[str, Any]) -> dict[str, Any]:
    return {
        "prompt_type": analysis.get("prompt_type"),
        "subject_area": analysis.get("subject_area"),
        "raccca_total": analysis.get("raccca", {}).get("total"),
        "anti_patterns": [item.get("slug") for item in analysis.get("anti_patterns", [])],
        "semantic_conflicts": [item.get("slug") for item in analysis.get("semantic_conflicts", [])],
        "ai_data_risk_warnings": [item.get("slug") for item in analysis.get("ai_data_risk_warnings", [])],
        "missing_building_blocks": analysis.get("missing_building_blocks", []),
    }


def _attach_deep_dive_visibility(
    repo: PromptCompassRepository,
    payload: dict[str, Any],
    source_text: str,
    analysis: dict[str, Any],
    *,
    model_target: str | None = None,
) -> dict[str, Any]:
    updated = dict(payload)
    analysis_with_final_contract = {
        **analysis,
        "prompt_contract": updated.get("prompt_contract", analysis.get("prompt_contract", {})),
    }
    updated["score_visibility"] = "shown"
    updated.setdefault("analysis_summary", _analysis_summary(analysis))
    updated.setdefault("raccca", analysis.get("raccca", {}))
    updated.setdefault("raccca_evidence", _raccca_evidence(analysis.get("raccca", {})))
    updated.setdefault("anti_patterns", analysis.get("anti_patterns", []))
    updated.setdefault("semantic_conflicts", analysis.get("semantic_conflicts", []))
    updated.setdefault("ai_data_risk_warnings", analysis.get("ai_data_risk_warnings", []))
    updated.setdefault("missing_building_blocks", analysis.get("missing_building_blocks", []))
    updated.setdefault("prompt_fingerprint", analysis.get("prompt_fingerprint", {}))
    updated.setdefault("primary_deliverable_guess", analysis.get("primary_deliverable_guess"))
    updated.setdefault(
        "diagnosis_summary",
        _intermediate_findings_summary(analysis_with_final_contract, "stage_2_context_and_repair"),
    )
    for key, value in _advanced_diagnosis_fields(repo, source_text, analysis, model_target=model_target).items():
        updated.setdefault(key, value)
    return updated


def _raccca_delta(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    before_dimensions = before.get("dimensions", {}) if isinstance(before, dict) else {}
    after_dimensions = after.get("dimensions", {}) if isinstance(after, dict) else {}
    dimensions: dict[str, Any] = {}
    for name in sorted(set(before_dimensions) | set(after_dimensions)):
        before_score = int(before_dimensions.get(name, {}).get("score", 0))
        after_score = int(after_dimensions.get(name, {}).get("score", 0))
        dimensions[name] = {
            "before": before_score,
            "after": after_score,
            "delta": after_score - before_score,
        }
    before_total = int(before.get("total", 0))
    after_total = int(after.get("total", 0))
    return {
        "before_total": before_total,
        "after_total": after_total,
        "total_delta": after_total - before_total,
        "dimensions": dimensions,
    }


def _agentic_prompt_delta(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    before_dimensions = before.get("dimensions", {}) if isinstance(before, dict) else {}
    after_dimensions = after.get("dimensions", {}) if isinstance(after, dict) else {}
    dimensions: dict[str, Any] = {}
    for name in sorted(set(before_dimensions) | set(after_dimensions)):
        before_score = int((before_dimensions.get(name) or {}).get("score", 0))
        after_score = int((after_dimensions.get(name) or {}).get("score", 0))
        dimensions[name] = {
            "before": before_score,
            "after": after_score,
            "delta": after_score - before_score,
        }
    before_total = int(before.get("total", 0)) if isinstance(before, dict) else 0
    after_total = int(after.get("total", 0)) if isinstance(after, dict) else 0
    return {
        "before_total": before_total,
        "after_total": after_total,
        "total_delta": after_total - before_total,
        "dimensions": dimensions,
    }


def _contract_diff(before: dict[str, Any], after: dict[str, Any]) -> list[dict[str, Any]]:
    fields = ["objective", "role", "audience", "context", "constraints", "steps", "output_contract", "examples", "model_target"]
    diffs: list[dict[str, Any]] = []
    for field in fields:
        before_value = before.get(field)
        after_value = after.get(field)
        if before_value != after_value:
            diffs.append({"field": field, "before": before_value, "after": after_value})
    return diffs


def _comparison_verdict(
    total_delta: int,
    resolved: list[str],
    introduced: list[str],
    missing_before: set[str],
    missing_after: set[str],
) -> dict[str, Any]:
    resolved_missing = missing_before - missing_after
    introduced_missing = missing_after - missing_before
    is_better = total_delta > 0 and len(introduced) <= len(resolved) and not introduced_missing
    if is_better:
        verdict = "after_prompt_is_better"
        guidance = "Use the after prompt, but still review any unchanged anti-patterns before high-stakes use."
    elif total_delta == 0 and not resolved:
        verdict = "no_clear_improvement"
        guidance = "The after prompt does not show measurable improvement; diagnose before rewriting again."
    else:
        verdict = "mixed_or_regressed"
        guidance = "Do not ship the after prompt without another repair pass."
    return {
        "verdict": verdict,
        "is_better": is_better,
        "why": guidance,
        "resolved_anti_pattern_count": len(resolved),
        "introduced_anti_pattern_count": len(introduced),
        "resolved_missing_blocks": sorted(resolved_missing),
        "introduced_missing_blocks": sorted(introduced_missing),
    }


def search_prompt_patterns_payload(
    repo: PromptCompassRepository,
    query: str,
    *,
    record_types: list[str] | None = None,
    prompt_type: str | None = None,
    subject_area: str | None = None,
    model_target: str | None = None,
    interaction_mode: str | None = None,
    output_mode: str | None = None,
    grounding_mode: str | None = None,
    evaluation_mode: str | None = None,
    limit: int = 10,
) -> dict[str, Any]:
    return repo.search_prompt_patterns(
        query,
        record_types=record_types,
        prompt_type=prompt_type,
        subject_area=subject_area,
        model_target=normalize_model_name(repo, model_target) if model_target else None,
        interaction_mode=interaction_mode,
        output_mode=output_mode,
        grounding_mode=grounding_mode,
        evaluation_mode=evaluation_mode,
        limit=limit,
    )


def get_framework_payload(repo: PromptCompassRepository, name: str) -> dict[str, Any]:
    result = repo.resolve_entry(name, record_types=["framework"])
    if result.get("found"):
        return result
    return {
        "found": False,
        "query": name,
        "supported_lookup_types": ["framework"],
        "nearest_matches": result.get("nearest_matches", []),
    }


def get_pattern_payload(repo: PromptCompassRepository, name: str) -> dict[str, Any]:
    result = repo.resolve_entry(name, record_types=["pattern", "anti_pattern"])
    if result.get("found"):
        return result
    return {
        "found": False,
        "query": name,
        "supported_lookup_types": ["pattern", "anti_pattern"],
        "nearest_matches": result.get("nearest_matches", []),
    }


def get_record_payload(repo: PromptCompassRepository, name: str, record_types: list[str] | None = None) -> dict[str, Any]:
    result = repo.resolve_entry(name, record_types=record_types)
    if result.get("found"):
        return result
    return {
        "found": False,
        "query": name,
        "supported_lookup_types": record_types or ["framework", "strategy", "pattern", "anti_pattern", "technique", "term", "question", "model_profile"],
        "nearest_matches": result.get("nearest_matches", []),
    }


def get_technique_payload(repo: PromptCompassRepository, name: str) -> dict[str, Any]:
    return get_record_payload(repo, name, record_types=["technique"])


def get_term_payload(repo: PromptCompassRepository, name: str) -> dict[str, Any]:
    return get_record_payload(repo, name, record_types=["term"])


def prompt_compass_overview_service_payload(
    repo: PromptCompassRepository,
    *,
    topic: str | None = None,
    audience: str | None = "both",
) -> dict[str, Any]:
    return prompt_compass_overview_payload(repo, topic=topic, audience=audience)


def get_started_service_payload(
    repo: PromptCompassRepository,
    *,
    topic: str | None = None,
    audience: str | None = "both",
) -> dict[str, Any]:
    return orientation_get_started_payload(repo, topic=topic, audience=audience)


def route_prompt_request_payload(
    repo: PromptCompassRepository,
    user_request: str,
    *,
    model_target: str | None = None,
    previous_steps_completed: list[str] | None = None,
    host_capability_profile: dict[str, Any] | None = None,
    interaction_pace: str | None = None,
    delivery_mode: str | None = None,
    question_loop_state: dict[str, Any] | None = None,
    question_answers: dict[str, Any] | list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    request = normalize_text(user_request)
    lowered = request.lower()
    state = merge_question_loop_answers(question_loop_state, question_answers)
    completed_steps = {normalize_text(item).lower() for item in ensure_list(previous_steps_completed) if normalize_text(item)}
    host_profile = normalize_host_capability_profile(host_capability_profile)
    state["host_capability_profile"] = host_profile
    native_question_ui = bool(host_profile.get("native_question_ui", True))
    preferences_payload = repo.get_preferences()
    autoflow_preferences = preferences_payload.get("preferences", {}).get("autoflow", {})
    autoflow_preference_state = preferences_payload.get("autoflow_preference_state", "missing_blank_overlay")
    autoflow_enabled_by_default = bool(autoflow_preferences.get("enabled_by_default")) and autoflow_preference_state == "configured"
    explicit_delivery_mode = _normalize_delivery_mode(delivery_mode)
    resolved_delivery_mode, delivery_mode_reason = _resolve_delivery_mode(lowered, delivery_mode, state)
    if resolved_delivery_mode != "autopilot" and autoflow_enabled_by_default and not explicit_delivery_mode:
        resolved_delivery_mode = "autopilot"
        delivery_mode_reason = "Auto Flow is enabled by saved preferences, so Prompt Compass should improve and execute the request automatically."
    autoflow_suppressed_reason = _autoflow_suppression_reason(lowered, _named_workflow_tool(lowered))
    autoflow_suppressed = bool(resolved_delivery_mode == "autopilot" and autoflow_suppressed_reason)
    if autoflow_suppressed:
        resolved_delivery_mode = "standard"
        delivery_mode_reason = f"Auto Flow stood down: {autoflow_suppressed_reason}"
    state["delivery_mode"] = resolved_delivery_mode
    preferences_nudge = (
        AUTOFLOW_DEFAULT_NUDGE
        if resolved_delivery_mode == "autopilot" and autoflow_preference_state != "configured"
        else ""
    )
    autoflow_disclosure = (
        f"Auto Flow skipped: {autoflow_suppressed_reason}."
        if autoflow_suppressed
        else ""
    )
    autoflow_route_fields = {
        "autoflow_preference_state": autoflow_preference_state,
        "autoflow_enabled_by_default": autoflow_enabled_by_default,
        "autoflow_suppressed": autoflow_suppressed,
        "autoflow_suppressed_reason": autoflow_suppressed_reason if autoflow_suppressed else "",
        "autoflow_disclosure": autoflow_disclosure,
        "preferences_nudge": preferences_nudge,
    }
    if _is_exit_signal(lowered):
        return _attach_runtime_contract({
            "route_status": "user_exit",
            "tool": "route_prompt_request",
            "request": request,
            "detected_job": "user_exit",
            "required_next_tool": None,
            "required_mode": "auto",
            "required_interaction_style": None,
            "required_agent_mode": "off",
            "required_delivery_mode": "standard",
            "delivery_mode_reason": "The user exited before choosing a delivery mode.",
            "recommended_host_prompt": None,
            "interaction_pace": _resolve_interaction_pace(lowered, interaction_pace, state, require_gate=False)[0] or "guided",
            "plain_language_summary": "No problem. Prompt Compass will stop here and you can come back anytime.",
            "user_message": "No problem. Come back anytime.",
            "remaining_recovery_action": "No action needed.",
            "must_ask_user_first": False,
            "questions_for_user": [],
            "routing_question": None,
            "blocked_lookup_tools": [],
            "route_reason": "The user sent a stop/exit signal.",
            "host_instruction": "Stop the Prompt Compass workflow and do not ask another routing question.",
            "native_ui_required": False,
            "question_loop_state": state,
            "workflow_entry_required": False,
            "browse_first_allowed": False,
            **autoflow_route_fields,
        }, host_profile=host_profile, stage="user_exit", include_tool_routing=True)
    meta_task_reason = _prompt_compass_meta_task_reason(lowered)
    if meta_task_reason:
        state["delivery_mode"] = "standard"
        disclosure = f"Auto Flow skipped: {meta_task_reason}."
        return _attach_runtime_contract({
            "route_status": "meta_task_bypassed",
            "tool": "route_prompt_request",
            "request": request,
            "detected_job": "prompt_compass_meta_task",
            "required_next_tool": None,
            "required_mode": "auto",
            "required_interaction_style": None,
            "required_agent_mode": "off",
            "required_delivery_mode": "standard",
            "delivery_mode_reason": "Auto Flow stood down because the user is inspecting or configuring Prompt Compass itself.",
            "recommended_host_prompt": None,
            "interaction_pace": _resolve_interaction_pace(lowered, interaction_pace, state, require_gate=False)[0] or "quick_fix",
            "plain_language_summary": "This is a Prompt Compass QA/configuration request, not a prompt rewrite job.",
            "user_message": disclosure,
            "remaining_recovery_action": "Handle the Prompt Compass task directly. Do not call improve_prompt as Auto Flow.",
            "must_ask_user_first": False,
            "questions_for_user": [],
            "routing_question": None,
            "blocked_lookup_tools": [],
            "route_reason": "The request is about Prompt Compass behavior, testing, bugs, onboarding, or configuration.",
            "host_instruction": "Do not run Auto Flow for this request. Show autoflow_disclosure, then proceed with the Prompt Compass QA/configuration task directly.",
            "native_ui_required": False,
            "fallback_rendering_disclosure": "",
            "question_loop_state": state,
            "model_target": normalize_model_name(repo, model_target) if model_target else None,
            "workflow_entry_required": False,
            "browse_first_allowed": False,
            "autoflow_preference_state": autoflow_preference_state,
            "autoflow_enabled_by_default": autoflow_enabled_by_default,
            "autoflow_suppressed": True,
            "autoflow_suppressed_reason": meta_task_reason,
            "autoflow_disclosure": disclosure,
            "preferences_nudge": "",
        }, host_profile=host_profile, stage="meta_task_bypassed", include_tool_routing=True)
    if resolved_delivery_mode == "autopilot" and not _pace_known_or_inferred(lowered, interaction_pace, state):
        state["interaction_pace"] = "quick_fix"
        state["interaction_pace_reason"] = "Autopilot defaults to quick fix pacing unless the user or host chose another pace."
    if autoflow_suppressed and not _pace_known_or_inferred(lowered, interaction_pace, state):
        state["interaction_pace"] = "quick_fix"
        state["interaction_pace_reason"] = "Auto Flow stood down, but the request still clearly asked for a quick visible result."
    resolved_pace, pace_reason, pace_payload = _resolve_interaction_pace(lowered, interaction_pace, state)
    if pace_payload:
        pace_payload["native_ui_required"] = native_question_ui
        pace_payload["fallback_rendering_disclosure"] = "" if native_question_ui else "Native question UI is unavailable, so render this as one compact plain-text question."
        pace_payload["question_loop_state"]["host_capability_profile"] = host_profile
        pace_payload["question_loop_state"]["delivery_mode"] = resolved_delivery_mode
        pace_payload["required_delivery_mode"] = resolved_delivery_mode
        pace_payload["delivery_mode_reason"] = delivery_mode_reason
        pace_payload["recommended_host_prompt"] = "pc_autopilot_flow" if resolved_delivery_mode == "autopilot" else None
        pace_payload.update(autoflow_route_fields)
        return _attach_runtime_contract(
            pace_payload,
            host_profile=host_profile,
            stage="interaction_pace_selection",
            include_tool_routing=True,
        )
    named_workflow = _named_workflow_tool(lowered)
    typed_route = _typed_route_selection(lowered, state)
    detected_job = _job_for_tool(typed_route) if typed_route else _detect_route_job(lowered)
    if _preflight_already_completed(lowered, completed_steps) and any(
        signal in lowered for signal in ("improve", "rewrite", "fix", "repair", "upgrade", "make this better")
    ):
        detected_job = "rewrite_draft"
    recommended_diagnosis_depth = _recommended_diagnosis_depth_for_request(repo, request, detected_job=detected_job)
    required_mode = "advanced" if (_has_advanced_signal(lowered) or has_agent_mode_signal(lowered) or prefers_direct_interaction(lowered)) else "auto"
    required_interaction_style = _detect_interaction_style(lowered, required_mode)
    required_agent_mode = "committee" if has_agent_mode_signal(lowered) else "off"
    agent_mode_reason = _agent_mode_reason_text(lowered, required_mode, required_agent_mode)
    agent_mode_available = _agent_mode_available_from_host(host_profile, required_mode=required_mode)

    if named_workflow:
        detected_job = _job_for_tool(named_workflow)
        required_next_tool = named_workflow
    elif typed_route:
        detected_job = _job_for_tool(typed_route)
        required_next_tool = typed_route
    elif resolved_delivery_mode == "autopilot":
        detected_job = "rewrite_draft"
        required_next_tool = "improve_prompt"
    elif detected_job == "runtime_preflight":
        required_next_tool = "preflight_prompt"
    elif detected_job == "diagnose_draft":
        required_next_tool = "diagnose_prompt" if recommended_diagnosis_depth == "deep" else "analyze_prompt"
    elif detected_job == "rewrite_draft":
        required_next_tool = "improve_prompt"
    elif detected_job == "build_from_scratch":
        required_next_tool = "build_prompt"
    elif detected_job == "browse_kb":
        required_next_tool = "list_catalog_categories"
    else:
        required_next_tool = ""

    routing_question = None
    must_ask_user_first = False
    route_status = "workflow_routed"
    if not required_next_tool and _is_short_fragment(request) and resolved_pace == "quick_fix":
        detected_job = "build_from_scratch"
        required_next_tool = "build_prompt"
    elif not required_next_tool and _is_short_fragment(request):
        must_ask_user_first = True
        route_status = "clarification_required"
        routing_question = _plain_route_clarification_question()
    if not required_next_tool:
        must_ask_user_first = True
        route_status = route_status if routing_question else "clarification_required"
        routing_question = routing_question or _plain_route_clarification_question()
    if must_ask_user_first:
        state = register_pending_questions(state, [routing_question])
        state["workflow_stage"] = "route_clarification"
        state["current_stage"] = "route_clarification"
        state["stage_status"] = "awaiting_user_answers"
        state["interaction_pace"] = resolved_pace

    workflow_tools = {"improve_prompt", "build_prompt", "analyze_prompt", "diagnose_prompt", "preflight_prompt"}
    blocked_lookup_tools = LOOKUP_FIRST_BLOCKED_TOOLS if required_next_tool in workflow_tools else []
    native_ui_required = bool(native_question_ui and (must_ask_user_first or (required_mode == "advanced" and required_next_tool in {"improve_prompt", "build_prompt"})))
    route_reason = _route_reason_text(
        request,
        detected_job,
        required_next_tool,
        required_mode,
        required_interaction_style,
        required_agent_mode,
        resolved_delivery_mode,
        must_ask_user_first,
    )
    if route_status == "workflow_routed" and typed_route:
        route_reason = "The user typed a routing label, so Prompt Compass accepted it as a valid text selection."
    host_instruction = _route_host_instruction(
        required_next_tool,
        required_mode,
        required_interaction_style,
        required_agent_mode,
        resolved_delivery_mode,
        must_ask_user_first,
        native_ui_required,
    )
    fallback_notice = "" if native_question_ui else "Native question UI is unavailable, so render this as one compact plain-text question."
    return _attach_runtime_contract({
        "route_status": route_status,
        "tool": "route_prompt_request",
        "request": request,
        "detected_job": detected_job or "ambiguous",
        "required_next_tool": required_next_tool or None,
        "required_mode": required_mode,
        "required_interaction_style": required_interaction_style,
        "required_agent_mode": required_agent_mode,
        "required_delivery_mode": resolved_delivery_mode,
        "delivery_mode_reason": delivery_mode_reason,
        "recommended_host_prompt": "pc_autopilot_flow" if resolved_delivery_mode == "autopilot" else None,
        "interaction_pace": resolved_pace,
        "interaction_pace_reason": pace_reason,
        "recommended_diagnosis_depth": recommended_diagnosis_depth,
        "agent_mode_reason": agent_mode_reason,
        "agent_mode_available": agent_mode_available,
        "committee_entry_status": _route_committee_entry_status(required_agent_mode, agent_mode_available),
        "required_capabilities": _committee_required_capabilities(host_profile, required_agent_mode=required_agent_mode),
        "recovery_action": _route_recovery_action(required_agent_mode, agent_mode_available),
        "remaining_recovery_action": _route_remaining_recovery_action(route_status, required_next_tool),
        "plain_language_summary": _route_plain_summary(route_status, required_next_tool, resolved_pace),
        "must_ask_user_first": must_ask_user_first,
        "routing_question": routing_question,
        "questions_for_user": [routing_question] if routing_question else [],
        "blocked_lookup_tools": blocked_lookup_tools,
        "route_reason": route_reason,
        "host_instruction": host_instruction,
        "native_ui_required": native_ui_required,
        "fallback_rendering_disclosure": fallback_notice,
        "question_loop_state": state,
        "model_target": normalize_model_name(repo, model_target) if model_target else None,
        "workflow_entry_required": required_next_tool in workflow_tools,
        "browse_first_allowed": required_next_tool in {"list_catalog_categories", "", None},
        **autoflow_route_fields,
    }, host_profile=host_profile, stage=route_status, include_tool_routing=True)


def _resolve_interaction_pace(
    lowered_request: str,
    requested_pace: str | None,
    state: dict[str, Any],
    *,
    require_gate: bool = True,
) -> tuple[str, str, dict[str, Any] | None]:
    normalized = _normalize_interaction_pace(requested_pace)
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    answered = _normalize_interaction_pace(answers.get("interaction_pace"))
    stored = _normalize_interaction_pace(state.get("interaction_pace"))
    inferred = _infer_interaction_pace(lowered_request)
    skipped_pace_question = "pc:route:interaction-pace" in {
        normalize_text(item)
        for item in ensure_list(state.get("skipped_question_ids"))
        if normalize_text(item)
    }
    default_if_skipped = _normalize_interaction_pace(state.get("interaction_pace_default_if_skipped"))
    resolved = normalized or answered or stored or inferred or (default_if_skipped if skipped_pace_question else "")
    if resolved:
        state["interaction_pace"] = resolved
        source = (
            "explicitly requested"
            if normalized
            else "selected earlier"
            if answered or stored
            else "defaulted after the pace question was skipped"
            if skipped_pace_question and default_if_skipped
            else "inferred from the request"
        )
        return resolved, f"Interaction pace is `{resolved}` because it was {source}.", None
    if not require_gate:
        return "", "Interaction pace was not set.", None
    return "guided", "Interaction pace is not known yet, so Prompt Compass must ask the pace question first.", _interaction_pace_payload(state)


def _normalize_interaction_pace(value: Any) -> str:
    text = normalize_text(value).lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "quick": "quick_fix",
        "quickfix": "quick_fix",
        "quick_fix": "quick_fix",
        "fast": "quick_fix",
        "minimal_questions": "quick_fix",
        "guided": "guided",
        "walk_me_through": "guided",
        "human_in_the_loop": "guided",
        "deep": "deep_dive",
        "deep_dive": "deep_dive",
        "full_analysis": "deep_dive",
        "analysis": "deep_dive",
    }
    return aliases.get(text, text if text in INTERACTION_PACES else "")


def _normalize_delivery_mode(value: Any) -> str:
    text = normalize_text(value).lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "standard": "standard",
        "normal": "standard",
        "show_rewrite": "standard",
        "surface_rewrite": "standard",
        "autopilot": "autopilot",
        "auto_pilot": "autopilot",
        "silent": "autopilot",
        "silent_improve": "autopilot",
        "improve_then_execute": "autopilot",
        "improve_and_execute": "autopilot",
        "improve_and_run": "autopilot",
        "execute_improved_prompt": "autopilot",
    }
    return aliases.get(text, text if text in DELIVERY_MODES else "")


def _resolve_delivery_mode(
    lowered_request: str,
    requested_delivery_mode: str | None,
    state: dict[str, Any],
) -> tuple[str, str]:
    normalized = _normalize_delivery_mode(requested_delivery_mode)
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    answered = _normalize_delivery_mode(answers.get("delivery_mode"))
    stored = _normalize_delivery_mode(state.get("delivery_mode"))
    if normalized:
        return normalized, f"Delivery mode is `{normalized}` because the host explicitly requested it."
    if answered:
        return answered, f"Delivery mode is `{answered}` because the user selected it earlier."
    if stored:
        return stored, f"Delivery mode is `{stored}` because it was stored in the workflow state."
    if _has_autopilot_signal(lowered_request):
        return "autopilot", "The request explicitly asked Prompt Compass to improve the prompt and execute it without surfacing the full rewrite."
    return "standard", "Delivery mode defaults to `standard`, so Prompt Compass surfaces the improved prompt as usual."


def _has_autopilot_signal(lowered_request: str) -> bool:
    simplified = re.sub(r"[^a-z0-9 ]+", " ", lowered_request)
    simplified = re.sub(r"\s+", " ", simplified).strip()
    signals = [
        "auto flow",
        "autoflow",
        "autopilot",
        "auto pilot",
        "silent improve",
        "silently improve",
        "improve then execute",
        "improve and execute",
        "improve and run",
        "improve then run",
        "execute the improved prompt",
        "run the improved prompt",
        "dont show me the rewritten prompt",
        "do not show me the rewritten prompt",
        "without showing the rewritten prompt",
        "use prompt compass automatically",
    ]
    return any(signal in simplified for signal in signals)


def _prompt_compass_meta_task_reason(lowered_request: str) -> str:
    if not lowered_request:
        return ""
    simplified = re.sub(r"[^a-z0-9_ ]+", " ", lowered_request)
    simplified = re.sub(r"\s+", " ", simplified).strip()
    meta_terms = [
        "prompt compass",
        "auto flow",
        "autoflow",
        "autopilot",
        "onboarding",
        "preferences",
        "preference",
        "tool behavior",
        "tool surface",
        "tool search",
        "tool_search",
        "mcp",
        "route_prompt_request",
        "improve_prompt",
        "manage_preferences",
        "pc_autopilot_flow",
    ]
    meta_actions = [
        "test",
        "audit",
        "review",
        "flag",
        "debug",
        "bug",
        "bugs",
        "issue",
        "issues",
        "qa",
        "smoke",
        "verify",
        "check",
        "inspect",
        "configure",
        "configuration",
        "settings",
        "tool_search",
    ]
    if any(term in simplified for term in meta_terms) and any(action in simplified for action in meta_actions):
        return "this is a Prompt Compass QA/configuration task, not a prompt to improve"
    return ""


def _autoflow_suppression_reason(lowered_request: str, named_workflow: str = "") -> str:
    if not lowered_request:
        return ""
    signals = [
        ("advanced", "the user asked for advanced mode rather than automatic execution"),
        ("human in the loop", "the user asked to stay in control of the improvement"),
        ("ask me questions", "the user asked for clarifying questions"),
        ("guided", "the user asked for guided interaction"),
        ("show me the improved prompt", "the user asked to see the improved prompt"),
        ("show the improved prompt", "the user asked to see the improved prompt"),
        ("show me the rewritten prompt", "the user asked to see the rewritten prompt"),
        ("show the rewritten prompt", "the user asked to see the rewritten prompt"),
        ("surface the rewrite", "the user asked to see the rewrite"),
        ("agent mode", "the user asked for Agent Mode"),
        ("committee mode", "the user asked for Agent Mode committee planning"),
        ("agent council", "the user asked for Agent Mode committee planning"),
        ("multi-agent", "the user asked for Agent Mode"),
        ("diagnose", "the user asked for diagnosis instead of automatic execution"),
        ("preflight", "the user asked for preflight instead of automatic execution"),
        ("browse", "the user asked to browse before changing anything"),
        ("lookup", "the user asked for lookup before changing anything"),
        ("get_framework", "the user named a lookup tool"),
        ("list_frameworks", "the user named a lookup tool"),
        ("search_prompt_patterns", "the user named a lookup tool"),
    ]
    for signal, reason in signals:
        if signal in lowered_request:
            return reason
    if named_workflow in {"diagnose_prompt", "analyze_prompt", "preflight_prompt"}:
        return f"the user named `{named_workflow}`, which conflicts with automatic execution"
    return ""


def _pace_known_or_inferred(lowered_request: str, requested_pace: str | None, state: dict[str, Any]) -> bool:
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    return bool(
        _normalize_interaction_pace(requested_pace)
        or _normalize_interaction_pace(answers.get("interaction_pace"))
        or _normalize_interaction_pace(state.get("interaction_pace"))
        or _infer_interaction_pace(lowered_request)
    )


def _infer_interaction_pace(lowered_request: str) -> str:
    if any(signal in lowered_request for signal in ("quick fix", "quick pass", "fast", "minimal questions")):
        return "quick_fix"
    if any(signal in lowered_request for signal in ("deep dive", "full analysis", "explain everything", "score this", "raccca")):
        return "deep_dive"
    if _has_advanced_signal(lowered_request) or has_agent_mode_signal(lowered_request):
        return "guided"
    return ""


def _interaction_pace_payload(state: dict[str, Any]) -> dict[str, Any]:
    question = {
        "id": "pc:route:interaction-pace",
        "slot": "interaction_pace",
        "question": "How do you want to work today?",
        "display_label": "Choose your pace",
        "plain_question": "How do you want to work today?",
        "example_answers": ["Quick fix", "Guided", "Deep dive"],
        "assumption_if_skipped": "I will use Guided mode so you get help without a long setup.",
        "answer_type": "single_choice",
        "choices": PACE_CHOICES,
        "why_i_am_asking": "This sets how many questions Prompt Compass asks and how much explanation it shows.",
        "what_this_can_change": [
            "Quick fix asks 0-1 questions and hides scores.",
            "Guided asks one question at a time and explains assumptions.",
            "Deep dive shows fuller diagnosis and scores.",
        ],
        "on_skip": {"action": "default_to_guided", "value": "guided"},
    }
    updated_state = register_pending_questions(state, [question])
    updated_state["interaction_pace_default_if_skipped"] = "guided"
    updated_state["workflow_stage"] = "interaction_pace_selection"
    updated_state["current_stage"] = "interaction_pace_selection"
    updated_state["stage_status"] = "awaiting_user_answers"
    return {
        "route_status": "interaction_pace_required",
        "tool": "route_prompt_request",
        "detected_job": "pace_selection",
        "required_next_tool": None,
        "required_mode": "auto",
        "required_interaction_style": None,
        "required_agent_mode": "off",
        "interaction_pace": None,
        "default_interaction_pace_if_skipped": "guided",
        "interaction_pace_reason": "Prompt Compass needs the user's preferred pace before choosing the workflow lane.",
        "must_ask_user_first": True,
        "routing_question": question,
        "questions_for_user": [question],
        "plain_language_summary": "First, choose how much guidance you want.",
        "remaining_recovery_action": "Ask the pace question, then call route_prompt_request again with the returned question_loop_state.",
        "blocked_lookup_tools": [],
        "route_reason": "Prompt Compass must establish the interaction pace before routing a new session.",
        "host_instruction": "Use native question UI first when available. Ask only the pace question, then resume route_prompt_request with the answer.",
        "native_ui_required": True,
        "question_loop_state": updated_state,
        "workflow_entry_required": False,
        "browse_first_allowed": False,
        "score_visibility": "hidden_until_requested",
    }


def _typed_route_selection(lowered_request: str, state: dict[str, Any]) -> str:
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    values = [
        lowered_request,
        normalize_text(answers.get("workflow_route")).lower(),
        normalize_text(answers.get("route")).lower(),
    ]
    for value in values:
        normalized = re.sub(r"[^a-z0-9 ]+", "", value.replace("_", " ").replace("-", " "))
        normalized = re.sub(r"\s+", " ", normalized).strip()
        if normalized in ROUTE_SELECTION_ALIASES:
            return ROUTE_SELECTION_ALIASES[normalized]
    return ""


def _plain_route_clarification_question() -> dict[str, Any]:
    return {
        "id": "pc:route:plain-clarify",
        "slot": "workflow_route",
        "question": "What are you trying to do with the AI?",
        "display_label": "What do you need?",
        "plain_question": "What are you trying to do with the AI?",
        "example_answers": ["Write something new", "Make something I wrote better", "Tell me what is wrong"],
        "assumption_if_skipped": "I will assume you want help writing a new AI request.",
        "answer_type": "single_choice",
        "choices": [
            {"label": "Make something I already wrote better", "value": "improve_prompt"},
            {"label": "Tell me what is wrong with something I wrote", "value": "diagnose_prompt"},
            {"label": "Help me write a new AI request", "value": "build_prompt"},
            {"label": "Check if this will work before I use it", "value": "preflight_prompt"},
            {"label": "Show me examples and ideas", "value": "list_catalog_categories"},
        ],
        "why_i_am_asking": "The request is too short or broad to choose the safest next step.",
        "what_this_can_change": ["Which Prompt Compass workflow starts next."],
        "on_skip": {"action": "default_to_build_prompt", "value": "build_prompt"},
    }


def _is_short_fragment(request: str) -> bool:
    tokens = tokenize(request)
    return 0 < len(tokens) <= 3


def _is_exit_signal(lowered_request: str) -> bool:
    stripped = lowered_request.strip()
    if stripped in {"nvm", "never mind", "nevermind", "forget it", "stop", "cancel", "quit", "exit"}:
        return True
    return bool(re.fullmatch(r"(nvm|stop|cancel|forget it|never mind)\W*", stripped))


def _route_plain_summary(route_status: str, required_next_tool: str, interaction_pace: str) -> str:
    if route_status == "clarification_required":
        return "I need one more plain-language answer before choosing the best help path."
    if required_next_tool == "build_prompt":
        return f"I will help write a new AI request using {interaction_pace.replace('_', ' ')} pacing."
    if required_next_tool == "improve_prompt":
        return f"I will help improve what you already wrote using {interaction_pace.replace('_', ' ')} pacing."
    if required_next_tool in {"analyze_prompt", "diagnose_prompt"}:
        return "I will look for what is missing or confusing before changing anything."
    if required_next_tool == "preflight_prompt":
        return "I will check whether this prompt is ready to use."
    return "I will show examples and concepts rather than changing a prompt."


def _route_remaining_recovery_action(route_status: str, required_next_tool: str) -> str:
    if route_status == "clarification_required":
        return "Ask the one clarification question, then resume route_prompt_request with the answer."
    if required_next_tool:
        return f"Call {required_next_tool} next."
    return "Ask the user what they want help writing or improving."


RUNTIME_CONTRACT_VERSION = "pc-runtime-contract-v1"


def _runtime_policy_card() -> dict[str, Any]:
    return {
        "version": RUNTIME_CONTRACT_VERSION,
        "title": "Prompt Compass runtime policy",
        "rules": [
            "Call route_prompt_request before deep tool use when the user did not name a specific Prompt Compass workflow tool.",
            "When questions_for_user is present, use native host question UI first if native_ui_required=true.",
            "Ask at most one user-facing question per turn and do not preview later stages.",
            "Do not browse lookup tools before a routed improve/build/analyze/diagnose/preflight workflow.",
            "If Auto Flow is skipped or suppressed, show autoflow_disclosure before continuing.",
        ],
        "host_boundary": (
            "Prompt Compass returns MCP runtime contracts and validation instructions. "
            "It cannot force Claude API tool_choice from Claude Desktop or Codex."
        ),
    }


def _recommended_tool_subset(required_next_tool: Any, delivery_mode: str = "standard") -> list[str]:
    tool = normalize_text(required_next_tool)
    if not tool:
        return ["route_prompt_request"]
    if tool == "improve_prompt":
        subset = ["route_prompt_request", "improve_prompt"]
        if delivery_mode != "autopilot":
            subset.append("compare_prompts")
        return subset
    if tool == "build_prompt":
        return ["route_prompt_request", "build_prompt", "get_clarifying_questions"]
    if tool == "preflight_prompt":
        return ["route_prompt_request", "preflight_prompt", "improve_prompt"]
    if tool in {"analyze_prompt", "diagnose_prompt"}:
        return ["route_prompt_request", tool, "improve_prompt"]
    if tool == "list_catalog_categories":
        return ["route_prompt_request", "list_catalog_categories", "search_prompt_patterns", "get_record"]
    return ["route_prompt_request", tool]


def _required_tool_sequence(required_next_tool: Any) -> list[str]:
    tool = normalize_text(required_next_tool)
    if not tool:
        return ["route_prompt_request"]
    return ["route_prompt_request", tool]


def _question_ids(questions: Any) -> list[str]:
    ids: list[str] = []
    for question in ensure_list(questions):
        if isinstance(question, dict):
            ids.append(normalize_text(question.get("id") or question.get("slot")))
    return [item for item in ids if item]


def _question_budget_limit(payload: dict[str, Any]) -> int:
    budget = payload.get("question_budget") if isinstance(payload.get("question_budget"), dict) else {}
    try:
        return int(budget.get("max_questions_per_turn") or 1)
    except (TypeError, ValueError):
        return 1


def _interaction_contract(payload: dict[str, Any], *, native_question_ui: bool, stage: str) -> dict[str, Any]:
    native_required = bool(payload.get("native_ui_required", native_question_ui))
    fallback_disclosure = (
        normalize_text(payload.get("fallback_rendering_disclosure"))
        or "Native question UI is unavailable, so render this as one compact plain-text question."
    )
    return {
        "version": RUNTIME_CONTRACT_VERSION,
        "stage": stage,
        "question_ids": _question_ids(payload.get("questions_for_user")),
        "valid_question_surface": "native_host_question_ui" if native_required else "compact_inline_question_block",
        "native_question_ui_required": native_required,
        "freeform_prose_questions_valid": False,
        "compact_inline_fallback_valid": not native_required,
        "fallback_required_disclosure": "" if native_required else fallback_disclosure,
        "max_questions_per_turn": _question_budget_limit(payload),
        "plain_text_violation_examples": [
            "Can you clarify?",
            "Which option do you prefer?",
            "What would you like me to do?",
        ],
        "repair_instruction": (
            "Your previous response asked a user-facing question outside the Prompt Compass interaction contract. "
            "Convert it into the returned questions_for_user payload, use native host question UI when available, "
            "and do not continue the workflow until the answer or skip is captured."
        ),
    }


def _host_validation(
    payload: dict[str, Any],
    *,
    native_question_ui: bool,
    stage: str,
    required_tool_sequence: list[str] | None = None,
) -> dict[str, Any]:
    host_action = payload.get("host_action") if isinstance(payload.get("host_action"), dict) else {}
    has_questions = bool(payload.get("questions_for_user"))
    native_required = bool(payload.get("native_ui_required", native_question_ui)) and has_questions
    must_pause = bool(host_action.get("must_pause") or payload.get("must_ask_user_first") or has_questions)
    disclosure_required = bool(payload.get("autoflow_suppressed") or normalize_text(payload.get("autoflow_disclosure")))
    checks: list[dict[str, Any]] = []
    if has_questions:
        checks.extend(
            [
                {
                    "id": "question_ui_required",
                    "required": native_required,
                    "pass_condition": "If native_ui_required=true, render questions_for_user through native host question UI.",
                },
                {
                    "id": "no_plain_text_user_question",
                    "required": True,
                    "pass_condition": "Do not ask a freeform prose clarification question when questions_for_user is present.",
                },
            ]
        )
    if required_tool_sequence:
        checks.append(
            {
                "id": "required_tool_sequence_followed",
                "required": True,
                "pass_condition": "Follow required_tool_sequence before using unrelated lookup, browse, or execution tools.",
            }
        )
    if disclosure_required:
        checks.append(
            {
                "id": "autoflow_disclosure_shown_when_suppressed",
                "required": True,
                "pass_condition": "Show autoflow_disclosure whenever Auto Flow is skipped, suppressed, or unavailable.",
            }
        )
    if must_pause or host_action.get("do_not_execute_until_gate_clears"):
        checks.append(
            {
                "id": "do_not_execute_until_gate_clears",
                "required": True,
                "pass_condition": "Do not synthesize, rewrite, scaffold, or execute until the blocking gate is answered, skipped, or approved.",
            }
        )
    if host_action.get("do_not_surface_full_rewrite"):
        checks.append(
            {
                "id": "full_rewrite_not_surfaced",
                "required": True,
                "pass_condition": "Do not show rewritten_prompt unless approval_required or the user explicitly asks for it.",
            }
        )
    return {
        "version": RUNTIME_CONTRACT_VERSION,
        "stage": stage,
        "required_checks": [item["id"] for item in checks if item.get("required")],
        "checks": checks,
        "on_failure": (
            "Do not show the violating response to the user. Repair the response by following interaction_contract, "
            "host_action, and required_tool_sequence, then continue only after the repaired gate is satisfied."
        ),
    }


def _attach_runtime_contract(
    payload: dict[str, Any],
    *,
    host_profile: dict[str, Any] | None = None,
    stage: str | None = None,
    include_tool_routing: bool = False,
) -> dict[str, Any]:
    updated = dict(payload)
    question_state = updated.get("question_loop_state") if isinstance(updated.get("question_loop_state"), dict) else {}
    normalized_profile = normalize_host_capability_profile(host_profile or question_state.get("host_capability_profile"))
    native_question_ui = bool(normalized_profile.get("native_question_ui", True))
    stage_name = (
        normalize_text(stage)
        or normalize_text(updated.get("workflow_stage"))
        or normalize_text(updated.get("current_stage"))
        or normalize_text(updated.get("route_status"))
        or "prompt_compass_runtime"
    )
    updated.setdefault("runtime_policy_card", _runtime_policy_card())
    required_sequence: list[str] | None = None
    if include_tool_routing:
        required_next_tool = updated.get("required_next_tool")
        delivery_mode = normalize_text(updated.get("required_delivery_mode")) or normalize_text(updated.get("delivery_mode_used")) or "standard"
        updated["recommended_tool_subset"] = _recommended_tool_subset(required_next_tool, delivery_mode)
        required_sequence = _required_tool_sequence(required_next_tool)
        updated["required_tool_sequence"] = required_sequence
    if updated.get("questions_for_user"):
        updated["interaction_contract"] = _interaction_contract(
            updated,
            native_question_ui=native_question_ui,
            stage=stage_name,
        )
    if (
        updated.get("questions_for_user")
        or isinstance(updated.get("host_action"), dict)
        or updated.get("autoflow_suppressed")
        or updated.get("autoflow_disclosure")
        or include_tool_routing
    ):
        updated["host_validation"] = _host_validation(
            updated,
            native_question_ui=native_question_ui,
            stage=stage_name,
            required_tool_sequence=required_sequence,
        )
    return updated


def _named_workflow_tool(lowered_request: str) -> str:
    tool_markers = {
        "improve_prompt": ["improve_prompt", "improve prompt tool", "advanced improve prompt", "quick improve prompt"],
        "build_prompt": ["build_prompt", "build prompt tool", "advanced build prompt", "quick build prompt", "write prompt from scratch"],
        "diagnose_prompt": ["diagnose_prompt", "diagnose prompt tool"],
        "analyze_prompt": ["analyze_prompt", "analyze prompt tool"],
        "preflight_prompt": ["preflight_prompt", "preflight prompt tool"],
    }
    for tool_name, markers in tool_markers.items():
        if any(marker in lowered_request for marker in markers):
            return tool_name
    return ""


def _detect_route_job(lowered_request: str) -> str:
    preflight_signals = [
        "preflight",
        "runtime-safe",
        "runtime safe",
        "parser",
        "retrieval",
        "tool workflow",
        "tool-safe",
        "tool safe",
        "before using",
    ]
    diagnose_signals = ["diagnose", "audit", "what is wrong", "what's wrong", "analyze this prompt", "find the anti-pattern"]
    improve_signals = ["improve", "rewrite", "make this better", "upgrade this prompt", "refine this prompt", "fix this prompt"]
    build_signals = [
        "build a prompt",
        "build from scratch",
        "write a prompt",
        "create a prompt",
        "prompt from scratch",
        "help me write this prompt",
        "help me write a prompt",
        "help me write this",
        "help me write it",
        "write this properly",
        "write it properly",
        "scaffold a prompt",
    ]
    browse_signals = ["framework", "strategy", "pattern", "technique", "term", "template", "example", "browse", "show me", "list"]

    if any(signal in lowered_request for signal in preflight_signals):
        return "runtime_preflight"
    if any(signal in lowered_request for signal in diagnose_signals) and _has_draft_signal(lowered_request):
        return "diagnose_draft"
    if any(signal in lowered_request for signal in improve_signals):
        return "rewrite_draft"
    if _has_advanced_signal(lowered_request) and "prompt" in lowered_request and "build" not in lowered_request and "write a prompt" not in lowered_request:
        return "rewrite_draft"
    if any(signal in lowered_request for signal in build_signals):
        return "build_from_scratch"
    if any(signal in lowered_request for signal in browse_signals) and not _has_workflow_signal(lowered_request):
        return "browse_kb"
    if _has_draft_signal(lowered_request):
        return "rewrite_draft"
    return ""


def _preflight_already_completed(lowered_request: str, completed_steps: set[str]) -> bool:
    if "preflight_prompt" in completed_steps or "preflight" in completed_steps:
        return True
    return any(
        phrase in lowered_request
        for phrase in (
            "preflight already completed",
            "preflight is complete",
            "after preflight",
            "preflight found",
            "preflight flagged",
            "preflight results",
            "now improve",
            "now rewrite",
        )
    )


def _agent_mode_available_from_host(host_profile: dict[str, Any], *, required_mode: str) -> bool:
    if required_mode != "advanced":
        return False
    if host_profile.get("selected_adapter") in {"claude_native_subagents", "codex_explicit_subagents"}:
        return True
    return bool(host_profile.get("allow_sequential_fallback", True))


def _route_committee_entry_status(required_agent_mode: str, agent_mode_available: bool) -> str:
    if required_agent_mode != "committee":
        return "available" if agent_mode_available else "unavailable_host_capability"
    return "available" if agent_mode_available else "unavailable_host_capability"


def _committee_required_capabilities(host_profile: dict[str, Any], *, required_agent_mode: str) -> list[str]:
    if required_agent_mode != "committee":
        return []
    if host_profile.get("selected_adapter") in {"claude_native_subagents", "codex_explicit_subagents"}:
        return ["workflow_approval", "host_runtime_permissions"]
    if host_profile.get("allow_sequential_fallback", True):
        return ["workflow_approval", "sequential_labeled_fallback"]
    return ["native_subagents_or_allow_sequential_fallback", "workflow_approval"]


def _route_recovery_action(required_agent_mode: str, agent_mode_available: bool) -> str:
    if required_agent_mode != "committee":
        return ""
    if agent_mode_available:
        return "Call the required workflow tool with mode='advanced' and agent_mode='committee'."
    return "Either provide native subagent capability, allow sequential fallback, or rerun with agent_mode='off'."


def _has_workflow_signal(lowered_request: str) -> bool:
    return any(
        signal in lowered_request
        for signal in [
            "improve",
            "rewrite",
            "build",
            "write a prompt",
            "diagnose",
            "analyze",
            "preflight",
            "runtime",
        ]
    )


def _has_draft_signal(lowered_request: str) -> bool:
    return any(
        signal in lowered_request
        for signal in [
            "prompt:",
            "draft prompt",
            "rewrite this",
            "improve this prompt",
            "fix this prompt",
            "existing prompt",
            "this prompt",
        ]
    ) or bool(re.search(r"\bprompt\b.{0,24}\bfor\b", lowered_request))


def _has_advanced_signal(lowered_request: str) -> bool:
    return any(
        signal in lowered_request
        for signal in ["advanced", "human in the loop", "ask me questions", "guided", "walk me through", "interactive"]
    )


def _detect_interaction_style(lowered_request: str, required_mode: str) -> str | None:
    if required_mode != "advanced":
        return None
    if prefers_direct_interaction(lowered_request):
        return "direct"
    if prefers_guided_interaction(lowered_request):
        return "guided"
    return "guided"


def _wants_deep_diagnosis(lowered_request: str) -> bool:
    return any(
        signal in lowered_request
        for signal in [
            "diagnose",
            "audit",
            "anti-pattern",
            "anti pattern",
            "repair order",
            "evidence",
            "why is this failing",
            "why this is failing",
            "why does this fail",
            "what is wrong",
            "what's wrong",
        ]
    )


def _job_for_tool(tool_name: str) -> str:
    return {
        "improve_prompt": "rewrite_draft",
        "build_prompt": "build_from_scratch",
        "diagnose_prompt": "diagnose_draft",
        "analyze_prompt": "diagnose_draft",
        "preflight_prompt": "runtime_preflight",
    }.get(tool_name, "browse_kb")


def _route_reason_text(
    request: str,
    detected_job: str,
    required_next_tool: str,
    required_mode: str,
    required_interaction_style: str | None,
    required_agent_mode: str,
    required_delivery_mode: str,
    must_ask_user_first: bool,
) -> str:
    if must_ask_user_first:
        return (
            "The request does not name a single safe first lane yet, so Prompt Compass should ask the user to choose "
            "between diagnose, improve, build, preflight, or browse before Claude starts using lookup tools."
        )
    mode_suffix = " with advanced human-in-the-loop behavior" if required_mode == "advanced" else ""
    interaction_suffix = f" using the `{required_interaction_style}` advanced lane" if required_interaction_style else ""
    agent_suffix = " with Agent Mode enabled" if required_agent_mode == "committee" else ""
    delivery_suffix = " and Auto Flow delivery" if required_delivery_mode == "autopilot" else ""
    return (
        f"Prompt Compass classified this request as `{detected_job}` and requires `{required_next_tool}`{mode_suffix}"
        f"{interaction_suffix}{agent_suffix}{delivery_suffix} before any browse-first behavior."
    )


def _agent_mode_reason_text(lowered_request: str, required_mode: str, required_agent_mode: str) -> str:
    if required_agent_mode == "committee":
        return "The request explicitly asked for Agent Mode / multi-agent support, so Prompt Compass should route into the bounded committee lane."
    if required_mode == "advanced":
        return "Agent Mode remains available as an explicit advanced-only opt-in, but it is not required unless the user asks for it."
    return "Agent Mode is an advanced-only opt-in lane and is not relevant to this route yet."


def _route_host_instruction(
    required_next_tool: str,
    required_mode: str,
    required_interaction_style: str | None,
    required_agent_mode: str,
    required_delivery_mode: str,
    must_ask_user_first: bool,
    native_ui_required: bool,
) -> str:
    if must_ask_user_first:
        instruction = "Ask the routing question first and do not browse frameworks, strategies, or patterns until the user chooses a lane."
    else:
        instruction = f"Call `{required_next_tool}` next and do not start with lookup tools."
    if required_mode == "advanced":
        instruction += " Use advanced mode"
        if required_interaction_style:
            instruction += f" with the `{required_interaction_style}` lane"
        instruction += " and treat any must_pause response as a blocking gate."
    if required_agent_mode == "committee":
        instruction += " Keep Agent Mode enabled and do not downgrade to the standard lane unless the user declines it."
    if required_delivery_mode == "autopilot":
        instruction += " Use delivery_mode='autopilot'; follow Auto Flow preferences, show only the allowed delta or approval gate, then execute the returned rewritten_prompt in the same turn when permitted."
    if native_ui_required:
        instruction += " Use native Claude question UI first when available."
    return instruction


def list_tool_surface_service_payload(*, include_write_tools: bool = True, audience: str | None = "both") -> dict[str, Any]:
    return list_tool_surface_payload(include_write_tools=include_write_tools, audience=audience)


def list_catalog_categories_service_payload(repo: PromptCompassRepository) -> dict[str, Any]:
    return list_catalog_categories_payload(repo)


def list_frameworks_service_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = 10,
    catalog_scope: str = "core_first",
) -> dict[str, Any]:
    return list_frameworks_payload(repo, query=query, limit=limit, catalog_scope=catalog_scope)


def list_strategies_service_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = 10,
    catalog_scope: str = "core_first",
) -> dict[str, Any]:
    return list_strategies_payload(repo, query=query, limit=limit, catalog_scope=catalog_scope)


def list_patterns_service_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = 10,
    catalog_scope: str = "core_first",
) -> dict[str, Any]:
    return list_patterns_payload(repo, query=query, limit=limit, catalog_scope=catalog_scope)


def list_techniques_service_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = 10,
    catalog_scope: str = "core_first",
) -> dict[str, Any]:
    return list_techniques_payload(repo, query=query, limit=limit, catalog_scope=catalog_scope)


def list_terms_service_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = 10,
    catalog_scope: str = "core_first",
) -> dict[str, Any]:
    return list_terms_payload(repo, query=query, limit=limit, catalog_scope=catalog_scope)


def list_prompt_templates_service_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = 10,
    catalog_scope: str = "core_first",
    include_prompt_library: bool = False,
) -> dict[str, Any]:
    return list_prompt_templates_payload(
        repo,
        query=query,
        limit=limit,
        catalog_scope=catalog_scope,
        include_prompt_library=include_prompt_library,
    )


def list_prompt_examples_service_payload(
    repo: PromptCompassRepository,
    *,
    query: str | None = None,
    limit: int = 10,
    catalog_scope: str = "core_first",
    include_prompt_library: bool = False,
) -> dict[str, Any]:
    return list_prompt_examples_payload(
        repo,
        query=query,
        limit=limit,
        catalog_scope=catalog_scope,
        include_prompt_library=include_prompt_library,
    )


def list_anti_patterns_service_payload(
    repo: PromptCompassRepository,
    *,
    limit: int = 25,
    severity: str | None = None,
    prompt_type: str | None = None,
    catalog_scope: str = "core_first",
) -> dict[str, Any]:
    return list_anti_patterns_payload(
        repo,
        limit=limit,
        severity=severity,
        prompt_type=prompt_type,
        catalog_scope=catalog_scope,
    )


def save_personal_record_payload(
    repo: PromptCompassRepository,
    record: dict[str, Any],
    *,
    confirm: bool = False,
    confirmation_token: str | None = None,
) -> dict[str, Any]:
    return repo.save_personal_record(record, confirm=confirm, confirmation_token=confirmation_token)


def seed_personal_overlay_payload(
    repo: PromptCompassRepository,
    seed_answers: dict[str, Any] | None = None,
    *,
    confirm: bool = False,
    confirmation_token: str | None = None,
) -> dict[str, Any]:
    return repo.seed_personal_overlay(seed_answers, confirm=confirm, confirmation_token=confirmation_token)


def manage_preferences_payload(
    repo: PromptCompassRepository,
    preferences: dict[str, Any] | None = None,
    *,
    reset: bool = False,
    confirm: bool = False,
    confirmation_token: str | None = None,
) -> dict[str, Any]:
    return repo.manage_preferences(
        preferences,
        reset=reset,
        confirm=confirm,
        confirmation_token=confirmation_token,
    )


def delete_personal_record_payload(
    repo: PromptCompassRepository,
    value: str,
    *,
    confirm: bool = False,
    confirmation_token: str | None = None,
) -> dict[str, Any]:
    return repo.delete_personal_record(value, confirm=confirm, confirmation_token=confirmation_token)


def save_prompt_library_item_payload(
    repo: PromptCompassRepository,
    item: dict[str, Any],
    *,
    confirm: bool = False,
    confirmation_token: str | None = None,
) -> dict[str, Any]:
    return repo.save_prompt_library_item(item, confirm=confirm, confirmation_token=confirmation_token)


def delete_prompt_library_item_payload(
    repo: PromptCompassRepository,
    value: str,
    *,
    confirm: bool = False,
    confirmation_token: str | None = None,
) -> dict[str, Any]:
    return repo.delete_prompt_library_item(value, confirm=confirm, confirmation_token=confirmation_token)


def search_prompt_library_payload(
    repo: PromptCompassRepository,
    query: str,
    *,
    asset_kind: str | None = None,
    model_target: str | None = None,
    target_surface: str | None = None,
    tags: list[str] | None = None,
    limit: int = 10,
) -> dict[str, Any]:
    return repo.search_prompt_library(
        query,
        asset_kind=asset_kind,
        model_target=model_target,
        target_surface=target_surface,
        tags=tags,
        limit=limit,
    )


def get_prompt_library_item_payload(repo: PromptCompassRepository, value: str) -> dict[str, Any]:
    return repo.get_prompt_library_item(value)


def flag_core_record_payload(
    repo: PromptCompassRepository,
    target_entry_id: str,
    reason: str,
    suggested_action: str,
    *,
    notes: str | None = None,
) -> dict[str, Any]:
    return repo.flag_core_record(target_entry_id, reason, suggested_action, notes=notes)


def list_core_review_flags_payload(
    repo: PromptCompassRepository,
    *,
    status: str | None = None,
    target_entry_id: str | None = None,
    limit: int = 25,
) -> dict[str, Any]:
    return repo.list_core_review_flags(status=status, target_entry_id=target_entry_id, limit=limit)


def sync_personal_overlay_from_markdown_payload(repo: PromptCompassRepository) -> dict[str, Any]:
    return repo.sync_personal_overlay_from_markdown()


def suggest_strategies_payload(
    repo: PromptCompassRepository,
    *,
    prompt_type: str,
    subject_area: str,
    model_target: str | None = None,
    interaction_mode: str | None = None,
    output_mode: str | None = None,
    grounding_mode: str | None = None,
    evaluation_mode: str | None = None,
    capability_tags: list[str] | None = None,
    anti_patterns: list[dict[str, Any]] | None = None,
    missing_building_blocks: list[str] | None = None,
    prompt_surface: str | None = None,
    surface_traits: list[str] | None = None,
) -> dict[str, Any]:
    strategies = suggest_strategy_records(
        repo,
        prompt_type=prompt_type,
        subject_area=subject_area,
        model_target=normalize_model_name(repo, model_target) if model_target else None,
        interaction_mode=interaction_mode,
        output_mode=output_mode,
        grounding_mode=grounding_mode,
        evaluation_mode=evaluation_mode,
        capability_tags=capability_tags or [],
        anti_patterns=anti_patterns or [],
        missing_building_blocks=missing_building_blocks or [],
        prompt_surface=normalize_text(prompt_surface) or None,
        surface_traits=[normalize_text(item) for item in surface_traits or [] if normalize_text(item)],
        query_terms=[
            prompt_type,
            subject_area,
            interaction_mode or "",
            output_mode or "",
            grounding_mode or "",
            evaluation_mode or "",
            prompt_surface or "",
            *(surface_traits or []),
            *(capability_tags or []),
            *(item.get("name", "") for item in anti_patterns or []),
            *(missing_building_blocks or []),
        ],
        limit=6,
    )
    return {
        "prompt_type": prompt_type,
        "subject_area": subject_area,
        "model_target": normalize_model_name(repo, model_target) if model_target else None,
        "interaction_mode": interaction_mode,
        "output_mode": output_mode,
        "grounding_mode": grounding_mode,
        "evaluation_mode": evaluation_mode,
        "capability_tags": capability_tags or [],
        "prompt_surface": normalize_text(prompt_surface) or None,
        "surface_traits": [normalize_text(item) for item in surface_traits or [] if normalize_text(item)],
        "strategies": strategies,
    }


def improve_prompt_workflow_payload(
    repo: PromptCompassRepository,
    prompt: str,
    *,
    model_target: str | None = None,
    analysis: dict[str, Any] | None = None,
    question_answers: dict[str, Any] | list[dict[str, Any]] | None = None,
    question_loop_state: dict[str, Any] | None = None,
    selected_prompt_library_ids: list[str] | None = None,
    mode: str = "auto",
    interaction_style: str | None = None,
    interaction_pace: str | None = None,
    agent_mode: str = "off",
    host_capability_profile: dict[str, Any] | None = None,
    committee_depth: int = 0,
    committee_confirmation_token: str | None = None,
    preservation_mode: str = "balanced",
    delivery_mode: str = "standard",
) -> dict[str, Any]:
    resolved_analysis = _normalize_analysis_input(repo, prompt, analysis, model_target=model_target)
    state = merge_question_loop_answers(question_loop_state, question_answers)
    resolved_delivery_mode = _normalize_delivery_mode(delivery_mode) or _normalize_delivery_mode(state.get("delivery_mode")) or "standard"
    state["delivery_mode"] = resolved_delivery_mode
    autoflow_preferences_payload = repo.get_preferences() if resolved_delivery_mode == "autopilot" else {}
    resolved_pace = _normalize_interaction_pace(interaction_pace) or _normalize_interaction_pace(state.get("interaction_pace")) or _infer_interaction_pace(normalize_text(prompt).lower()) or "guided"
    state["interaction_pace"] = resolved_pace
    state["committee_depth"] = _coerce_committee_depth(committee_depth, state)
    state["host_capability_profile"] = normalize_host_capability_profile(host_capability_profile or state.get("host_capability_profile"))
    requested_mode = "quick" if resolved_delivery_mode == "autopilot" and normalize_text(mode).lower() == "auto" else mode
    resolved_mode, mode_reason, mode_selection_payload = _resolve_workflow_mode(
        repo,
        workflow_kind="improve",
        text=prompt,
        analysis=resolved_analysis,
        requested_mode=requested_mode,
        state=state,
    )
    if mode_selection_payload:
        return _decorate_user_workflow_payload(
            _decorate_improve_delivery_payload(
                repo,
                mode_selection_payload,
                delivery_mode=resolved_delivery_mode,
                source_prompt=prompt,
                analysis=resolved_analysis,
                model_target=model_target,
                preferences_payload=autoflow_preferences_payload,
            ),
            interaction_pace=resolved_pace,
        )
    resolved_interaction_style, interaction_style_reason = _resolve_interaction_style(
        text=prompt,
        requested_interaction_style=interaction_style,
        state=state,
        resolved_mode=resolved_mode,
    )
    resolved_agent_mode, agent_mode_reason, agent_mode_payload = _resolve_agent_mode(
        workflow_kind="improve",
        text=prompt,
        requested_agent_mode=agent_mode,
        state=state,
        resolved_mode=resolved_mode,
    )
    if agent_mode_payload:
        return _decorate_user_workflow_payload(
            _decorate_improve_delivery_payload(
                repo,
                agent_mode_payload,
                delivery_mode=resolved_delivery_mode,
                source_prompt=prompt,
                analysis=resolved_analysis,
                model_target=model_target,
                preferences_payload=autoflow_preferences_payload,
            ),
            interaction_pace=resolved_pace,
        )
    if resolved_agent_mode == "committee" and resolved_mode != "advanced":
        return _committee_error_payload(
            workflow_kind="improve",
            source_text=prompt,
            mode_used=resolved_mode,
            interaction_style=resolved_interaction_style,
            agent_mode_used=resolved_agent_mode,
            code="QUICK_MODE_COMMITTEE_REJECTED",
        )
    if resolved_agent_mode == "committee" and int(state.get("committee_depth") or 0) >= 1:
        return _committee_error_payload(
            workflow_kind="improve",
            source_text=prompt,
            mode_used=resolved_mode,
            interaction_style=resolved_interaction_style,
            agent_mode_used=resolved_agent_mode,
            code="RECURSIVE_COMMITTEE_BLOCKED",
        )
    if resolved_mode == "advanced":
        if resolved_interaction_style == "direct":
            payload = _direct_advanced_improve_payload(
                repo,
                prompt,
                analysis=resolved_analysis,
                state=state,
                model_target=model_target,
                selected_prompt_library_ids=selected_prompt_library_ids,
                mode_reason=mode_reason,
                interaction_style_reason=interaction_style_reason,
                agent_mode_reason=agent_mode_reason,
                agent_mode=resolved_agent_mode,
                committee_confirmation_token=committee_confirmation_token,
                preservation_mode=preservation_mode,
            )
            if resolved_pace == "deep_dive":
                payload = _attach_deep_dive_visibility(repo, payload, prompt, resolved_analysis, model_target=model_target)
            return _decorate_user_workflow_payload(
                _decorate_improve_delivery_payload(
                    repo,
                    payload,
                    delivery_mode=resolved_delivery_mode,
                    source_prompt=prompt,
                    analysis=resolved_analysis,
                    model_target=model_target,
                    preferences_payload=autoflow_preferences_payload,
                ),
                interaction_pace=resolved_pace,
            )
        payload = _advanced_improve_payload(
            repo,
            prompt,
            analysis=resolved_analysis,
            state=state,
            model_target=model_target,
            selected_prompt_library_ids=selected_prompt_library_ids,
            mode_reason=mode_reason,
            interaction_style_reason=interaction_style_reason,
            agent_mode_reason=agent_mode_reason,
            interaction_style=resolved_interaction_style,
            agent_mode=resolved_agent_mode,
            committee_confirmation_token=committee_confirmation_token,
            preservation_mode=preservation_mode,
        )
        if resolved_pace == "deep_dive":
            payload = _attach_deep_dive_visibility(repo, payload, prompt, resolved_analysis, model_target=model_target)
        return _decorate_user_workflow_payload(
            _decorate_improve_delivery_payload(
                repo,
                payload,
                delivery_mode=resolved_delivery_mode,
                source_prompt=prompt,
                analysis=resolved_analysis,
                model_target=model_target,
                preferences_payload=autoflow_preferences_payload,
            ),
            interaction_pace=resolved_pace,
        )
    clarification_payload = _autoflow_clarification_payload(prompt, state, autoflow_preferences_payload)
    if clarification_payload:
        return _decorate_user_workflow_payload(
            _decorate_improve_delivery_payload(
                repo,
                clarification_payload,
                delivery_mode=resolved_delivery_mode,
                source_prompt=prompt,
                analysis=resolved_analysis,
                model_target=model_target,
                preferences_payload=autoflow_preferences_payload,
            ),
            interaction_pace=resolved_pace,
        )
    result = improve_prompt_payload(
        repo,
        prompt,
        resolved_analysis,
        model_target=normalize_model_name(repo, model_target) if model_target else None,
        question_answers=state.get("answers"),
        selected_prompt_library_ids=selected_prompt_library_ids,
        mode="quick",
        preservation_mode=preservation_mode,
    )
    result.update(
        {
            "workflow_stage": "quick_improve_complete",
            "interaction_style_used": "quick",
            "interaction_style_reason": interaction_style_reason,
            "agent_mode_used": "off",
            "agent_mode_reason": agent_mode_reason,
            "host_action": {
                "must_pause": False,
                "prompt_style": "deliver_result_directly",
                "do_not_preview_future_stages": False,
            },
            "resume_payload_template": {
                "tool": "improve_prompt",
                    "payload": {
                        "prompt": prompt,
                        "mode": "quick",
                        "question_answers": {},
                        "selected_prompt_library_ids": selected_prompt_library_ids or [],
                    },
            },
        }
    )
    if resolved_pace == "deep_dive":
        result = _attach_deep_dive_visibility(repo, result, prompt, resolved_analysis, model_target=model_target)
    return _decorate_user_workflow_payload(
        _decorate_improve_delivery_payload(
            repo,
            result,
            delivery_mode=resolved_delivery_mode,
            source_prompt=prompt,
            analysis=resolved_analysis,
            model_target=model_target,
            preferences_payload=autoflow_preferences_payload,
        ),
        interaction_pace=resolved_pace,
    )


def build_prompt_payload(
    repo: PromptCompassRepository,
    user_intent: str,
    *,
    model_target: str | None = None,
    question_loop_state: dict[str, Any] | None = None,
    selected_prompt_library_ids: list[str] | None = None,
    mode: str = "auto",
    interaction_style: str | None = None,
    interaction_pace: str | None = None,
    agent_mode: str = "off",
    host_capability_profile: dict[str, Any] | None = None,
    committee_depth: int = 0,
    committee_confirmation_token: str | None = None,
) -> dict[str, Any]:
    analysis = analyze_prompt_payload(repo, user_intent, model_target=model_target, user_goal=user_intent)
    state = merge_question_loop_answers(question_loop_state)
    resolved_pace = _normalize_interaction_pace(interaction_pace) or _normalize_interaction_pace(state.get("interaction_pace")) or _infer_interaction_pace(normalize_text(user_intent).lower()) or "guided"
    state["interaction_pace"] = resolved_pace
    state["committee_depth"] = _coerce_committee_depth(committee_depth, state)
    state["host_capability_profile"] = normalize_host_capability_profile(host_capability_profile or state.get("host_capability_profile"))
    contract = merge_question_answers(analysis["prompt_contract"], state.get("answers"))
    selected_prompt_library_items = _selected_prompt_library_items(repo, selected_prompt_library_ids)
    atlas_build_scaffolding = _atlas_build_scaffolding_for_intent(user_intent)
    contract = _apply_prompt_library_items(contract, selected_prompt_library_items)
    contract["model_target"] = normalize_model_name(repo, model_target) or normalize_text(contract.get("model_target"))
    contract = _apply_shared_build_defaults(contract, analysis, user_intent)
    current_missing = contract_missing_blocks(contract)
    detected_pattern_primary = detect_primary_pattern(user_intent, contract, analysis.get("anti_patterns", []))
    core_principles = core_principles_applied(
        user_intent,
        contract,
        analysis.get("anti_patterns", []),
        workflow_kind="build",
    )
    resolved_mode, mode_reason, mode_selection_payload = _resolve_workflow_mode(
        repo,
        workflow_kind="build",
        text=user_intent,
        analysis={**analysis, "prompt_contract": contract, "missing_building_blocks": current_missing},
        requested_mode=mode,
        state=state,
    )
    if mode_selection_payload:
        return _decorate_user_workflow_payload(mode_selection_payload, interaction_pace=resolved_pace)
    resolved_interaction_style, interaction_style_reason = _resolve_interaction_style(
        text=user_intent,
        requested_interaction_style=interaction_style,
        state=state,
        resolved_mode=resolved_mode,
    )
    resolved_agent_mode, agent_mode_reason, agent_mode_payload = _resolve_agent_mode(
        workflow_kind="build",
        text=user_intent,
        requested_agent_mode=agent_mode,
        state=state,
        resolved_mode=resolved_mode,
    )
    if agent_mode_payload:
        return _decorate_user_workflow_payload(agent_mode_payload, interaction_pace=resolved_pace)
    if resolved_agent_mode == "committee" and resolved_mode != "advanced":
        return _committee_error_payload(
            workflow_kind="build",
            source_text=user_intent,
            mode_used=resolved_mode,
            interaction_style=resolved_interaction_style,
            agent_mode_used=resolved_agent_mode,
            code="QUICK_MODE_COMMITTEE_REJECTED",
        )
    if resolved_agent_mode == "committee" and int(state.get("committee_depth") or 0) >= 1:
        return _committee_error_payload(
            workflow_kind="build",
            source_text=user_intent,
            mode_used=resolved_mode,
            interaction_style=resolved_interaction_style,
            agent_mode_used=resolved_agent_mode,
            code="RECURSIVE_COMMITTEE_BLOCKED",
        )
    if resolved_mode == "advanced":
        if resolved_interaction_style == "direct":
            payload = _direct_advanced_build_payload(
                repo,
                user_intent,
                analysis=analysis,
                state=state,
                contract=contract,
                model_target=model_target,
                selected_prompt_library_items=selected_prompt_library_items,
                mode_reason=mode_reason,
                interaction_style_reason=interaction_style_reason,
                agent_mode_reason=agent_mode_reason,
                agent_mode=resolved_agent_mode,
                committee_confirmation_token=committee_confirmation_token,
            )
            if resolved_pace == "deep_dive":
                payload = _attach_deep_dive_visibility(repo, payload, user_intent, analysis, model_target=model_target)
            payload = _attach_atlas_build_scaffolding(payload, atlas_build_scaffolding)
            return _decorate_user_workflow_payload(payload, interaction_pace=resolved_pace)
        payload = _advanced_build_payload(
            repo,
            user_intent,
            analysis=analysis,
            state=state,
            contract=contract,
            model_target=model_target,
            selected_prompt_library_items=selected_prompt_library_items,
            mode_reason=mode_reason,
            interaction_style_reason=interaction_style_reason,
            agent_mode_reason=agent_mode_reason,
            interaction_style=resolved_interaction_style,
            agent_mode=resolved_agent_mode,
            committee_confirmation_token=committee_confirmation_token,
        )
        if resolved_pace == "deep_dive":
            payload = _attach_deep_dive_visibility(repo, payload, user_intent, analysis, model_target=model_target)
        payload = _attach_atlas_build_scaffolding(payload, atlas_build_scaffolding)
        return _decorate_user_workflow_payload(payload, interaction_pace=resolved_pace)
    guardrail_payload = _quick_build_guardrail_payload(repo, analysis, state, user_intent, selected_prompt_library_items)
    if guardrail_payload:
        guardrail_payload.update(
            {
                "completed": False,
                "mode_used": "quick",
                "mode_reason": mode_reason,
                "interaction_style_used": "quick",
                "interaction_style_reason": interaction_style_reason,
                "agent_mode_used": "off",
                "agent_mode_reason": agent_mode_reason,
                "workflow_stage": guardrail_payload.get("workflow_stage", "quick_build_guardrail"),
                "selected_prompt_library_items": [_compact_prompt_library_item(item) for item in selected_prompt_library_items],
                "detected_pattern_primary": detected_pattern_primary,
                "core_principles_applied": core_principles,
            }
        )
        if resolved_pace == "deep_dive":
            guardrail_payload = _attach_deep_dive_visibility(repo, guardrail_payload, user_intent, analysis, model_target=model_target)
        guardrail_payload = _attach_atlas_build_scaffolding(guardrail_payload, atlas_build_scaffolding)
        return _decorate_user_workflow_payload(guardrail_payload, interaction_pace=resolved_pace)

    if _quick_build_needs_one_question(contract, user_intent):
        question_payload = _single_quick_build_question(repo, analysis, state, user_intent, selected_prompt_library_items)
        payload = {
            "completed": False,
            "mode_used": "quick",
            "mode_reason": mode_reason,
            "interaction_style_used": "quick",
            "interaction_style_reason": interaction_style_reason,
            "agent_mode_used": "off",
            "agent_mode_reason": agent_mode_reason,
            **question_payload,
            "workflow_stage": "quick_build_clarify_once",
            "selected_prompt_library_items": [_compact_prompt_library_item(item) for item in selected_prompt_library_items],
            "detected_pattern_primary": detected_pattern_primary,
            "core_principles_applied": core_principles,
        }
        if resolved_pace == "deep_dive":
            payload = _attach_deep_dive_visibility(repo, payload, user_intent, analysis, model_target=model_target)
        payload = _attach_atlas_build_scaffolding(payload, atlas_build_scaffolding)
        return _decorate_user_workflow_payload(payload, interaction_pace=resolved_pace)

    contract["assumptions"] = _build_assumptions(contract)
    strategy_payload = suggest_strategies_payload(
        repo,
        prompt_type=analysis["prompt_type"],
        subject_area=analysis["subject_area"],
        model_target=contract.get("model_target") or None,
        interaction_mode=analysis.get("interaction_mode"),
        output_mode=analysis.get("output_mode"),
        grounding_mode=analysis.get("grounding_mode"),
        evaluation_mode=analysis.get("evaluation_mode"),
        capability_tags=analysis.get("capability_tags", []),
        anti_patterns=analysis.get("anti_patterns", []),
        missing_building_blocks=current_missing,
        prompt_surface=analysis.get("prompt_surface"),
        surface_traits=analysis.get("surface_traits", []),
    )
    payload = {
        "completed": True,
        "mode_used": "quick",
        "mode_reason": mode_reason,
        "interaction_style_used": "quick",
        "interaction_style_reason": interaction_style_reason,
        "agent_mode_used": "off",
        "agent_mode_reason": agent_mode_reason,
        "workflow_stage": "quick_build_complete",
        "scaffolded_prompt": render_prompt_contract(contract, include_assumptions=True),
        "prompt_contract": contract,
        "applied_strategies": strategy_payload["strategies"][:4],
        "selected_prompt_library_items": [_compact_prompt_library_item(item) for item in selected_prompt_library_items],
        "assumptions": contract["assumptions"],
        "detected_pattern_primary": detected_pattern_primary,
        "core_principles_applied": core_principles,
        "host_action": {
            "must_pause": False,
            "prompt_style": "deliver_result_directly",
            "do_not_preview_future_stages": False,
        },
        "resume_payload_template": {
            "tool": "build_prompt",
            "payload": {
                "user_intent": user_intent,
                "mode": "quick",
                "question_loop_state": {"answers": {}},
                "selected_prompt_library_ids": selected_prompt_library_ids or [],
            },
        },
    }
    if resolved_pace == "deep_dive":
        payload = _attach_deep_dive_visibility(repo, payload, user_intent, analysis, model_target=model_target)
    payload = _attach_atlas_build_scaffolding(payload, atlas_build_scaffolding)
    return _decorate_user_workflow_payload(payload, interaction_pace=resolved_pace)


def get_model_profile_payload(repo: PromptCompassRepository, model_name: str) -> dict[str, Any]:
    canonical = normalize_model_name(repo, model_name)
    if not canonical:
        return {
            "found": False,
            "query": model_name,
            "supported_models": repo.supported_model_ids(),
        }
    profile = repo.get_model_profile(canonical)
    if profile.get("found"):
        return profile
    return {
        "found": False,
        "query": model_name,
        "supported_models": repo.supported_model_ids(),
    }


def target_prompt_to_surface_workflow_payload(
    repo: PromptCompassRepository,
    prompt: str,
    surface_name: str,
    *,
    model_target: str | None = None,
    prompt_contract: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload = rewrite_target_prompt_to_surface_payload(
        repo,
        prompt,
        surface_name,
        model_target=model_target,
        prompt_contract=prompt_contract,
    )
    payload.setdefault("audience_targeting_suggestions", select_audience_targeting_seeds(prompt, limit=3))
    payload.setdefault(
        "atlas_scaffolding_note",
        "Audience seeds are support scaffolds only; they do not create persona simulation or a runtime Atlas dependency.",
    )
    surface_for_profile = payload.get("surface_name") if payload.get("found") else surface_name
    payload.update(surface_targeting_profile(surface_for_profile, payload.get("prompt_contract", {})))
    return payload


def _advanced_host_action(
    *,
    workflow_kind: str,
    stage: str,
    interaction_batch: dict[str, Any] | None,
    required_next_step: str,
) -> dict[str, Any]:
    native_ui_directive = (
        "Use Claude Desktop/Codex native question UI first when available. "
        "Do not paraphrase these questions into inline chat unless native UI is unavailable or the user explicitly waives it."
    )
    fallback_directive = (
        "If native UI is unavailable, render one compact inline question block using only `questions_for_user`, "
        "preserve the same wording and choices, and do not preview later stages."
    )
    return {
        "must_pause": True,
        "blocking_gate": f"{workflow_kind}:{stage}:awaiting_user_answers",
        "directive": (
            f"PAUSE before continuing the advanced {workflow_kind} workflow. "
            "Ask only this stage, capture answers or skips, then resume the same tool with the returned question_loop_state."
        ),
        "preferred_interaction_surface": "native_host_question_ui",
        "fallback_interaction_surface": "compact_inline_question_block",
        "native_ui_directive": native_ui_directive,
        "fallback_rendering_directive": fallback_directive,
        "prompt_style": "ask_only_this_stage",
        "do_not_preview_future_stages": True,
        "disallowed_actions_until_resume": [
            "do_not_ask_future_stage_questions",
            "do_not_browse_frameworks_first",
            "do_not_synthesize_final_prompt",
            "do_not_force_a_rewrite_or_scaffold",
        ],
        "required_next_step": required_next_step,
        "route_violation_if_ignored": "Ignoring this gate means Claude is leaving the guided Prompt Compass workflow.",
        "interaction_batch": interaction_batch or {},
    }


def _stage_completion_payload(stage: str, contract: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    answered_slots = set(ensure_list(state.get("answered_slots")))
    awaiting_ids = ensure_list(state.get("awaiting_question_ids"))
    if stage == "stage_1_intent_and_contract":
        required_slots = ["objective", "audience", "output_contract"]
        missing_slots = [slot for slot in required_slots if slot in contract_missing_blocks(contract)]
        answered_required = [slot for slot in required_slots if slot not in missing_slots]
        exit_ready = not missing_slots
    elif stage == "stage_2_context_and_repair":
        required_slots = [
            normalize_text(slot).lower()
            for slot in ensure_list(state.get("active_required_slots"))
            if normalize_text(slot)
        ] or ["context", "constraints", "grounding", "parser_contract", "runtime_layer", "source_priority", "tool_use", "agent_control", "evaluation"]
        answered_required = [slot for slot in required_slots if normalize_text(answers.get(slot)) or slot in answered_slots]
        if ensure_list(contract.get("context")):
            answered_required.append("context")
        if ensure_list(contract.get("constraints")):
            answered_required.append("constraints")
        answered_required = sorted({slot for slot in answered_required if slot})
        missing_slots = [slot for slot in required_slots if slot not in answered_required]
        exit_ready = bool(answered_required) and not awaiting_ids
    else:
        required_slots = []
        answered_required = []
        missing_slots = []
        exit_ready = True
    return {
        "stage": stage,
        "required_slots": required_slots,
        "answered_required_slots": answered_required,
        "missing_required_slots": missing_slots,
        "awaiting_question_ids": awaiting_ids,
        "exit_ready": exit_ready,
    }


def _resolve_workflow_mode(
    repo: PromptCompassRepository,
    *,
    workflow_kind: str,
    text: str,
    analysis: dict[str, Any],
    requested_mode: str | None,
    state: dict[str, Any],
) -> tuple[str, str, dict[str, Any] | None]:
    normalized = normalize_text(requested_mode).lower()
    stored_mode = normalize_text(state.get("mode")).lower()
    answered_mode = normalize_text((state.get("answers") or {}).get("mode") if isinstance(state.get("answers"), dict) else "").lower()
    if normalized in {"quick", "advanced"}:
        state["mode"] = normalized
        return normalized, _mode_reason_text(normalized, explicit=True), None
    if answered_mode in {"quick", "advanced"}:
        state["mode"] = answered_mode
        return answered_mode, _mode_reason_text(answered_mode, explicit=False), None
    if stored_mode in {"quick", "advanced"}:
        return stored_mode, _mode_reason_text(stored_mode, explicit=False), None

    complexity = _workflow_complexity_score(text, analysis)
    if complexity <= 1:
        state["mode"] = "quick"
        return "quick", "Auto-routed to quick mode because the request already looks compact enough for a one-pass result.", None
    if complexity >= 4:
        state["mode"] = "advanced"
        return "advanced", "Auto-routed to advanced mode because the request still has enough ambiguity or structural risk to justify staged guidance.", None

    question = {
        "id": f"pc:{workflow_kind}:mode-selection",
        "slot": "mode",
        "question": f"Do you want a quick {workflow_kind} pass or a more guided advanced {workflow_kind} pass?",
        "answer_type": "single_choice",
        "choices": [
            {"label": "quick", "value": "quick"},
            {"label": "advanced", "value": "advanced"},
        ],
        "why_i_am_asking": "This request could reasonably go through either a fast one-pass flow or a staged guided flow.",
        "what_this_can_change": [
            "Whether Prompt Compass makes bounded assumptions immediately or pauses for staged clarification.",
            "Whether the host should run a short direct pass or a multi-stage guided workflow.",
        ],
        "on_skip": {"action": "default_to_advanced", "value": "advanced"},
    }
    updated_state = normalize_question_loop_state(state)
    updated_state["workflow_stage"] = "mode_selection"
    updated_state["current_stage"] = "mode_selection"
    updated_state["pending_question_ids"] = [question["id"]]
    updated_state["awaiting_question_ids"] = [question["id"]]
    updated_state["asked_question_ids"] = ensure_list(updated_state.get("asked_question_ids")) + [question["id"]]
    updated_state["question_count"] = len(ensure_list(updated_state.get("asked_question_ids")))
    updated_state["round"] = int(updated_state.get("round") or 0) + 1
    updated_state["question_slot_map"] = {**dict(updated_state.get("question_slot_map") or {}), question["id"]: "mode"}
    updated_state["stage_status"] = "awaiting_user_answers"
    updated_state["resume_allowed"] = False
    return "advanced", "Mode is ambiguous, so the host should ask the user to choose quick or advanced first.", {
        "completed": False,
        "mode_used": "auto",
        "mode_reason": "The request could fit either quick or advanced mode, so Prompt Compass is asking the host to route it explicitly.",
        "workflow_stage": "mode_selection",
        "current_stage": "mode_selection",
        "stage_goal": "Choose the workflow depth before continuing.",
        "stage_status": "awaiting_user_answers",
        "stage_exit_criteria": ["User chooses `quick` or `advanced`."],
        "questions_for_user": [question],
        "interaction_batch": {
            "stage": "mode_selection",
            "ask_together": True,
            "max_questions_this_turn": 1,
            "do_not_prefetch_future_questions": True,
            "next_stage": f"{workflow_kind}_workflow",
        },
        "question_loop_state": updated_state,
        "host_action": {
            **_advanced_host_action(
                workflow_kind=workflow_kind,
                stage="mode_selection",
                interaction_batch={
                    "stage": "mode_selection",
                    "ask_together": True,
                    "max_questions_this_turn": 1,
                    "do_not_prefetch_future_questions": True,
                    "next_stage": f"{workflow_kind}_workflow",
                },
                required_next_step="Ask the one mode-selection question, then resume the same workflow tool with the chosen mode.",
            ),
            "prompt_style": "ask_one_mode_question",
        },
        "awaiting_question_ids": ensure_list(updated_state.get("awaiting_question_ids")),
        "answered_question_ids": ensure_list(updated_state.get("answered_question_ids")),
        "answered_slots": ensure_list(updated_state.get("answered_slots")),
        "stage_completion": {
            "stage": "mode_selection",
            "required_slots": ["mode"],
            "answered_required_slots": [],
            "missing_required_slots": ["mode"],
            "awaiting_question_ids": [question["id"]],
            "exit_ready": False,
        },
        "resume_allowed": False,
        "resume_payload_template": {
            "tool": "improve_prompt" if workflow_kind == "improve" else "build_prompt",
            "payload": {
                ("prompt" if workflow_kind == "improve" else "user_intent"): text,
                "mode": "advanced",
                "question_loop_state": {"answers": {"mode": "advanced"}},
            },
        },
    }


def _coerce_committee_depth(requested_depth: int | None, state: dict[str, Any]) -> int:
    if isinstance(requested_depth, int):
        return max(0, requested_depth)
    try:
        return max(0, int(state.get("committee_depth") or 0))
    except (TypeError, ValueError):
        return 0


def _resolve_interaction_style(
    *,
    text: str,
    requested_interaction_style: str | None,
    state: dict[str, Any],
    resolved_mode: str,
) -> tuple[str, str]:
    normalized = normalize_text(requested_interaction_style).lower()
    stored = normalize_text(state.get("interaction_style")).lower()
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    answered = normalize_text(answers.get("interaction_style")).lower()
    if resolved_mode != "advanced":
        state["interaction_style"] = "quick"
        return "quick", "Quick mode does not use the advanced guided/direct split."
    if normalized in {"guided", "direct"}:
        state["interaction_style"] = normalized
        return normalized, f"The host explicitly requested the `{normalized}` advanced lane."
    if answered in {"guided", "direct"}:
        state["interaction_style"] = answered
        return answered, f"Continuing in the `{answered}` advanced lane from the recorded workflow answers."
    if stored in {"guided", "direct"}:
        state["interaction_style"] = stored
        return stored, f"Continuing in the stored `{stored}` advanced lane."
    if prefers_direct_interaction(text):
        state["interaction_style"] = "direct"
        return "direct", "The request explicitly asks for a direct advanced pass without the staged question loop."
    state["interaction_style"] = "guided"
    if prefers_guided_interaction(text):
        return "guided", "The request explicitly asks for guided human-in-the-loop behavior."
    return "guided", "Advanced defaults to the guided lane unless the request clearly asks for the direct lane."


def _resolve_agent_mode(
    *,
    workflow_kind: str,
    text: str,
    requested_agent_mode: str | None,
    state: dict[str, Any],
    resolved_mode: str,
) -> tuple[str, str, dict[str, Any] | None]:
    normalized = normalize_text(requested_agent_mode).lower()
    stored = normalize_text(state.get("agent_mode")).lower()
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    answered = normalize_text(answers.get("agent_mode")).lower()
    if normalize_text(answers.get("committee_approval")).lower() in {"decline", "standard_advanced"}:
        state["agent_mode"] = "off"
        return "off", "The user declined Agent Mode at the plan-review gate.", None
    if resolved_mode == "advanced" and normalize_text(state.get("workflow_stage")) == "mode_selection" and not answered and normalized != "committee":
        return "off", "Advanced was user-selected but Agent Mode has not been chosen yet.", _agent_mode_selection_payload(
            workflow_kind=workflow_kind,
            text=text,
            state=state,
        )
    if normalized in {"off", "committee"}:
        state["agent_mode"] = normalized
        reason = (
            "The host explicitly enabled Agent Mode."
            if normalized == "committee"
            else "The host explicitly kept the workflow on the standard non-committee lane."
        )
        return normalized, reason, None
    if answered in {"off", "committee"}:
        state["agent_mode"] = answered
        return answered, f"Continuing with the recorded `{answered}` Agent Mode choice.", None
    if stored in {"off", "committee"}:
        state["agent_mode"] = stored
        return stored, f"Continuing with the stored `{stored}` Agent Mode choice.", None
    if has_agent_mode_signal(text):
        state["agent_mode"] = "committee"
        return "committee", "The request explicitly asked for Agent Mode / multi-agent support.", None
    if resolved_mode != "advanced":
        state["agent_mode"] = "off"
        return "off", "Agent Mode is advanced-only and stays off outside the advanced lane.", None
    state["agent_mode"] = "off"
    return "off", "Agent Mode remains an explicit opt-in and stays off unless the user or host enables it.", None


def _agent_mode_selection_payload(
    *,
    workflow_kind: str,
    text: str,
    state: dict[str, Any],
) -> dict[str, Any]:
    question = {
        "id": f"pc:{workflow_kind}:agent-mode-selection",
        "slot": "agent_mode",
        "question": "Do you want standard advanced mode or Agent Mode for this prompt job?",
        "answer_type": "single_choice",
        "choices": [
            {"label": "standard_advanced", "value": "off"},
            {"label": "agent_mode", "value": "committee"},
        ],
        "why_i_am_asking": "Agent Mode adds a bounded three-role committee with an approval gate. It should never be enabled silently.",
        "what_this_can_change": [
            "Whether Prompt Compass stays on the standard advanced lane or switches into the bounded committee lane.",
            "Whether the host later receives an approval-gated committee execution contract.",
        ],
        "on_skip": {"action": "default_to_standard_advanced", "value": "off"},
    }
    updated_state = register_pending_questions(state, [question])
    updated_state["workflow_stage"] = "agent_mode_selection"
    updated_state["current_stage"] = "agent_mode_selection"
    updated_state["stage_status"] = "awaiting_user_answers"
    updated_state["stage_history"] = _append_stage_history(updated_state, "agent_mode_selection")
    updated_state["resume_allowed"] = False
    updated_state["agent_mode_prompted"] = True
    updated_state["final_prompt_ready"] = False
    return {
        "completed": False,
        "mode_used": "advanced",
        "mode_reason": "Advanced mode is already selected. Prompt Compass is now confirming whether to stay standard or enable Agent Mode.",
        "interaction_style_used": normalize_text(updated_state.get("interaction_style")) or "guided",
        "interaction_style_reason": "Advanced routing is already active.",
        "agent_mode_used": "off",
        "agent_mode_reason": "Agent Mode is still unresolved and needs explicit user approval before it can run.",
        "workflow_stage": "agent_mode_selection",
        "current_stage": "agent_mode_selection",
        "stage_goal": "Choose between the standard advanced lane and the bounded Agent Mode committee lane.",
        "stage_status": "awaiting_user_answers",
        "stage_exit_criteria": ["User chooses `standard advanced` or `Agent Mode`."],
        "questions_for_user": [question],
        "interaction_batch": {
            "stage": "agent_mode_selection",
            "ask_together": True,
            "max_questions_this_turn": 1,
            "do_not_prefetch_future_questions": True,
            "next_stage": f"{workflow_kind}_workflow",
        },
        "question_loop_state": updated_state,
        "host_action": {
            **_advanced_host_action(
                workflow_kind=workflow_kind,
                stage="agent_mode_selection",
                interaction_batch={
                    "stage": "agent_mode_selection",
                    "ask_together": True,
                    "max_questions_this_turn": 1,
                    "do_not_prefetch_future_questions": True,
                    "next_stage": f"{workflow_kind}_workflow",
                },
                required_next_step="Ask the one Agent Mode selection question, then resume the same workflow tool with the recorded answer.",
            ),
            "prompt_style": "ask_one_agent_mode_question",
        },
        "awaiting_question_ids": ensure_list(updated_state.get("awaiting_question_ids")),
        "answered_question_ids": ensure_list(updated_state.get("answered_question_ids")),
        "answered_slots": ensure_list(updated_state.get("answered_slots")),
        "stage_completion": {
            "stage": "agent_mode_selection",
            "required_slots": ["agent_mode"],
            "answered_required_slots": [],
            "missing_required_slots": ["agent_mode"],
            "awaiting_question_ids": [question["id"]],
            "exit_ready": False,
        },
        "resume_allowed": False,
        "resume_payload_template": {
            "tool": "improve_prompt" if workflow_kind == "improve" else "build_prompt",
            "payload": {
                ("prompt" if workflow_kind == "improve" else "user_intent"): text,
                "mode": "advanced",
                "interaction_style": normalize_text(updated_state.get("interaction_style")) or "guided",
                "question_loop_state": {"answers": {"agent_mode": "off"}},
            },
        },
    }


def _committee_error_payload(
    *,
    workflow_kind: str,
    source_text: str,
    mode_used: str,
    interaction_style: str,
    agent_mode_used: str,
    code: str,
) -> dict[str, Any]:
    if code == "RECURSIVE_COMMITTEE_BLOCKED":
        entry_status = "blocked_recursive"
        stop_reason = "stopped_security_policy_block"
        user_message = "Agent Mode cannot start from inside another Agent Mode committee run."
        recovery_action = "Restart the top-level workflow with committee_depth=0 or omit committee_depth."
        retry_allowed = False
    elif code in {"COMMITTEE_UNAVAILABLE", "HOST_CAPABILITY_MISMATCH", "HOST_CAPABILITY_INSUFFICIENT"}:
        entry_status = "unavailable_host_capability"
        stop_reason = "stopped_missing_host_capability"
        user_message = "Agent Mode is not available for the declared host capability profile."
        recovery_action = "Provide native subagent support, allow sequential fallback, or rerun with agent_mode='off'."
        retry_allowed = True
    elif code.startswith("TOKEN_"):
        entry_status = "awaiting_approval"
        stop_reason = "stopped_invalid_confirmation_token"
        user_message = "The Agent Mode approval token does not match the current committee plan."
        recovery_action = "Return to plan review and approve the current committee plan again."
        retry_allowed = True
    else:
        entry_status = "unavailable_host_capability"
        stop_reason = "stopped_missing_host_capability"
        user_message = "Agent Mode could not proceed with the current request."
        recovery_action = "Use the resume payload to continue with standard advanced mode, or retry with corrected host capability details."
        retry_allowed = code != "RECURSIVE_COMMITTEE_BLOCKED"
    return {
        "completed": False,
        "mode_used": mode_used,
        "interaction_style_used": interaction_style,
        "agent_mode_used": agent_mode_used,
        "workflow_stage": "stage_committee_execution",
        "committee_stage": "stage_committee_execution",
        "committee_entry_status": entry_status,
        "committee_stop_reason": committee_stop_reason(stop_reason),
        "user_message": user_message,
        "required_capabilities": ["workflow_approval", "native_subagents_or_sequential_labeled_fallback"],
        "recovery_action": recovery_action,
        **confirmation_error(code, retry_allowed=retry_allowed),
        "resume_payload_template": {
            "tool": "improve_prompt" if workflow_kind == "improve" else "build_prompt",
            "payload": {
                ("prompt" if workflow_kind == "improve" else "user_intent"): source_text,
                "mode": mode_used,
                "interaction_style": interaction_style,
                "agent_mode": "off",
            },
        },
    }


def _committee_plan_tuple(
    *,
    workflow_kind: str,
    interaction_style: str,
    analysis: dict[str, Any],
    prompt_contract: dict[str, Any],
    committee_plan: dict[str, Any],
    role_contracts: list[dict[str, Any]],
    fallback_strategy: str,
) -> dict[str, Any]:
    return {
        "workflow_kind": workflow_kind,
        "interaction_style": interaction_style,
        "analysis_summary": {
            "prompt_type": analysis.get("prompt_type"),
            "subject_area": analysis.get("subject_area"),
            "anti_patterns": [item.get("slug") or item.get("name") for item in analysis.get("anti_patterns", [])],
            "missing_building_blocks": list(analysis.get("missing_building_blocks", []) or []),
            "prompt_fingerprint": analysis.get("prompt_fingerprint", {}),
        },
        "repaired_context": {
            "objective": normalize_text(prompt_contract.get("objective")),
            "audience": normalize_text(prompt_contract.get("audience")),
            "role": normalize_text(prompt_contract.get("role")),
            "model_target": normalize_text(prompt_contract.get("model_target")),
            "output_contract": prompt_contract.get("output_contract", {}),
        },
        "committee_plan": committee_plan,
        "role_contracts": role_contracts,
        "tool_allowlists": {
            contract["role"]: list(contract.get("allowed_tools", []))
            for contract in role_contracts
        },
        "fallback_strategy": fallback_strategy,
    }


def _default_judge_revision_state() -> dict[str, Any]:
    return {
        "revision_requested": False,
        "revision_pass_count": 0,
        "max_revision_passes": 1,
        "comparison_required": False,
        "comparison_completed": False,
        "revision_request_payload": None,
        "stop_condition_reached": False,
        "stop_reason": "awaiting_initial_judge_review",
    }


def _committee_plan_or_execution_payload(
    repo: PromptCompassRepository,
    *,
    workflow_kind: str,
    source_text: str,
    analysis: dict[str, Any],
    contract: dict[str, Any],
    state: dict[str, Any],
    mode_reason: str,
    interaction_style: str,
    interaction_style_reason: str,
    agent_mode_reason: str,
    committee_confirmation_token: str | None,
    selected_prompt_library_ids: list[str] | None,
    model_target: str | None,
) -> dict[str, Any]:
    role_contracts = build_role_contracts(workflow_kind, source_text=source_text, prompt_contract=contract)
    committee_plan = build_committee_plan(
        workflow_kind,
        interaction_style=interaction_style,
        source_text=source_text,
        prompt_contract=contract,
        role_contracts=role_contracts,
    )
    host_profile = normalize_host_capability_profile(state.get("host_capability_profile"))
    if host_profile.get("selected_adapter") == "sequential_labeled_fallback" and not host_profile.get("allow_sequential_fallback", True):
        return _committee_error_payload(
            workflow_kind=workflow_kind,
            source_text=source_text,
            mode_used="advanced",
            interaction_style=interaction_style,
            agent_mode_used="committee",
            code="HOST_CAPABILITY_MISMATCH",
        )
    host_instructions = build_host_execution_instructions(
        host_profile,
        workflow_kind=workflow_kind,
        role_contracts=role_contracts,
    )
    fallback_mode = "sequential_labeled_fallback"
    plan_tuple = _committee_plan_tuple(
        workflow_kind=workflow_kind,
        interaction_style=interaction_style,
        analysis=analysis,
        prompt_contract=contract,
        committee_plan=committee_plan,
        role_contracts=role_contracts,
        fallback_strategy=fallback_mode,
    )
    current_plan_hash = committee_plan_hash(plan_tuple)

    if not committee_confirmation_token:
        bundle = build_confirmation_bundle(plan_tuple)
        approval_question = {
            "id": f"pc:{workflow_kind}:committee-approval",
            "slot": "committee_approval",
            "question": "Do you want to run Agent Mode with this bounded three-role committee?",
            "answer_type": "single_choice",
            "choices": [
                {"label": "run_agent_mode", "value": "approve"},
                {"label": "stay_standard_advanced", "value": "decline"},
            ],
            "why_i_am_asking": "Agent Mode is an explicit advanced-only committee lane. It should run only after the user approves the plan.",
            "what_this_can_change": [
                "Whether the host executes the committee plan or stays on the standard advanced lane.",
                "Whether native subagents or the sequential fallback instructions are used next.",
            ],
            "on_skip": {"action": "default_to_standard_advanced", "value": "decline"},
        }
        updated_state = register_pending_questions(state, [approval_question])
        updated_state["mode"] = "advanced"
        updated_state["interaction_style"] = interaction_style
        updated_state["agent_mode"] = "committee"
        updated_state["workflow_stage"] = "stage_committee_plan_review"
        updated_state["current_stage"] = "stage_committee_plan_review"
        updated_state["stage_history"] = _append_stage_history(updated_state, "stage_committee_plan_review")
        updated_state["stage_status"] = "awaiting_user_approval"
        updated_state["resume_allowed"] = False
        updated_state["committee_run_id"] = bundle["committee_run_id"]
        updated_state["committee_plan_hash"] = bundle["committee_plan_hash"]
        updated_state["committee_confirmation_token"] = bundle["committee_confirmation_token"]
        updated_state["committee_confirmation_issued_at"] = bundle["issued_at"]
        updated_state["committee_confirmation_expires_at"] = bundle["expires_at"]
        updated_state["committee_plan"] = committee_plan
        updated_state["role_contracts"] = role_contracts
        updated_state["judge_revision_state"] = _default_judge_revision_state()
        updated_state["judge_revision_state"]["comparison_required"] = workflow_kind == "improve"
        updated_state["committee_stop_reason"] = "awaiting_user_approval"
        return {
            "completed": False,
            "mode_used": "advanced",
            "mode_reason": mode_reason,
            "interaction_style_used": interaction_style,
            "interaction_style_reason": interaction_style_reason,
            "agent_mode_used": "committee",
            "agent_mode_reason": agent_mode_reason,
            "workflow_stage": "stage_committee_plan_review",
            "current_stage": "stage_committee_plan_review",
            "committee_stage": "stage_committee_plan_review",
            "committee_entry_status": "awaiting_approval",
            "plain_language_summary": "Agent Mode will use three focused roles to improve this prompt. It takes longer, and it only runs if you approve this plan.",
            "user_message": "Agent Mode is ready to review. Approve it only if you want the three-role committee path; otherwise stay in standard advanced mode.",
            "token_expires_in_seconds": 30 * 60,
            "token_expiry_message": "You have 30 minutes to approve this Agent Mode plan before Prompt Compass needs to make a fresh plan.",
            "fallback_disclosure": host_instructions.get("sequential_labeled_fallback", {}).get("disclosure_text", ""),
            "stage_goal": "Review and explicitly approve the bounded Agent Mode committee plan before any execution starts.",
            "stage_status": "awaiting_user_approval",
            "stage_exit_criteria": [
                "The user approves the committee plan and the host resumes with the returned confirmation token.",
                "Or the user declines and the host falls back to the standard advanced lane.",
            ],
            "questions_for_user": [approval_question],
            "question_loop_state": updated_state,
            "host_action": {
                **_advanced_host_action(
                    workflow_kind=workflow_kind,
                    stage="stage_committee_plan_review",
                    interaction_batch={
                        "stage": "stage_committee_plan_review",
                        "ask_together": True,
                        "max_questions_this_turn": 1,
                        "do_not_prefetch_future_questions": True,
                        "next_stage": "stage_committee_execution",
                    },
                    required_next_step="Present the committee plan, ask for approval in native UI first, then resume the same workflow tool with the returned committee_confirmation_token.",
                ),
                "prompt_style": "ask_committee_approval",
            },
            "committee_run_id": bundle["committee_run_id"],
            "committee_plan_hash": bundle["committee_plan_hash"],
            "committee_confirmation_token": bundle["committee_confirmation_token"],
            "token_scope": bundle["token_scope"],
            "token_bound_to": bundle["token_bound_to"],
            "committee_roles": [contract_payload["role"] for contract_payload in role_contracts],
            "role_contracts": role_contracts,
            "committee_plan": committee_plan,
            "host_execution_instructions": host_instructions,
            "recommended_host_prompt": "pc_agent_committee_flow",
            "committee_fallback_mode": fallback_mode,
            "judge_revision_state": updated_state["judge_revision_state"],
            "judge_comparison_required": workflow_kind == "improve",
            "committee_stop_reason": "awaiting_user_approval",
            "allowlist_enforcement_mode": allowlist_enforcement_mode(),
            "artifact_budget": artifact_budget(),
            "requires_committee_approval": True,
            "awaiting_question_ids": ensure_list(updated_state.get("awaiting_question_ids")),
            "answered_question_ids": ensure_list(updated_state.get("answered_question_ids")),
            "answered_slots": ensure_list(updated_state.get("answered_slots")),
            "stage_completion": {
                "stage": "stage_committee_plan_review",
                "required_slots": ["committee_approval"],
                "answered_required_slots": [],
                "missing_required_slots": ["committee_approval"],
                "awaiting_question_ids": [approval_question["id"]],
                "exit_ready": False,
            },
            "resume_allowed": False,
            "resume_payload_template": {
                "tool": "improve_prompt" if workflow_kind == "improve" else "build_prompt",
                "payload": {
                    ("prompt" if workflow_kind == "improve" else "user_intent"): source_text,
                    "mode": "advanced",
                    "interaction_style": interaction_style,
                    "agent_mode": "committee",
                    "committee_confirmation_token": bundle["committee_confirmation_token"],
                    "question_loop_state": updated_state,
                    "selected_prompt_library_ids": selected_prompt_library_ids or [],
                },
            },
        }

    validation_error = validate_confirmation(
        expected_token=normalize_text(state.get("committee_confirmation_token")),
        provided_token=committee_confirmation_token,
        expected_hash=normalize_text(state.get("committee_plan_hash")),
        current_hash=current_plan_hash,
        issued_at=int(state.get("committee_confirmation_issued_at") or 0) or None,
    )
    if validation_error:
        return {
            "completed": False,
            "mode_used": "advanced",
            "mode_reason": mode_reason,
            "interaction_style_used": interaction_style,
            "interaction_style_reason": interaction_style_reason,
            "agent_mode_used": "committee",
            "agent_mode_reason": agent_mode_reason,
            "workflow_stage": "stage_committee_execution",
            "current_stage": "stage_committee_execution",
            "committee_stage": "stage_committee_execution",
            "committee_entry_status": "awaiting_approval",
            "committee_stop_reason": "stopped_invalid_confirmation_token",
            "user_message": "The Agent Mode approval token does not match the current committee plan.",
            "required_capabilities": ["workflow_approval"],
            "recovery_action": "Return to plan review and approve the current committee plan again.",
            **validation_error,
        }

    execution_state = normalize_question_loop_state(state)
    execution_state["workflow_stage"] = "stage_committee_execution"
    execution_state["current_stage"] = "stage_committee_execution"
    execution_state["stage_status"] = "execution_required"
    execution_state["awaiting_question_ids"] = []
    execution_state["pending_question_ids"] = []
    execution_state["resume_allowed"] = True
    execution_state["committee_plan"] = committee_plan
    execution_state["role_contracts"] = role_contracts
    execution_state["committee_stop_reason"] = "awaiting_host_execution"
    execution_state["judge_revision_state"] = execution_state.get("judge_revision_state") or _default_judge_revision_state()
    execution_state["judge_revision_state"]["comparison_required"] = workflow_kind == "improve"
    return {
        "completed": False,
        "mode_used": "advanced",
        "mode_reason": mode_reason,
        "interaction_style_used": interaction_style,
        "interaction_style_reason": interaction_style_reason,
        "agent_mode_used": "committee",
        "agent_mode_reason": agent_mode_reason,
        "workflow_stage": "stage_committee_execution",
        "current_stage": "stage_committee_execution",
        "committee_stage": "stage_committee_execution",
        "committee_entry_status": "available",
        "plain_language_summary": "Agent Mode is approved. The host should now run the three roles and present one final prompt with risks and rationale.",
        "user_message": "Agent Mode is approved and ready to run. If native subagents are unavailable, the host must disclose that it is using a sequential fallback.",
        "fallback_disclosure": host_instructions.get("sequential_labeled_fallback", {}).get("disclosure_text", ""),
        "user_facing_execution_brief": {
            "what_happens_next": "The host runs the approved roles in order, then presents one final result.",
            "roles": [contract_payload["role"] for contract_payload in role_contracts],
            "fallback_mode": fallback_mode,
            "must_not_claim_spawned_agents_when_using_fallback": True,
        },
        "stage_goal": "Execute the approved Agent Mode committee plan through the selected host adapter or the disclosed sequential fallback.",
        "stage_status": "execution_required",
        "stage_exit_criteria": [
            "The host executes the approved role contracts in order.",
            "Only the top-level host may ask the user questions during committee execution.",
            "The final synthesis must disclose fallback mode if native subagents were not used.",
        ],
        "committee_run_id": normalize_text(state.get("committee_run_id")),
        "committee_plan_hash": current_plan_hash,
        "committee_confirmation_token": normalize_text(state.get("committee_confirmation_token")),
        "token_scope": "session",
        "token_bound_to": ["route_result", "repaired_context", "committee_plan", "role_contracts", "tool_allowlists", "fallback_strategy"],
        "committee_roles": [contract_payload["role"] for contract_payload in role_contracts],
        "role_contracts": role_contracts,
        "committee_plan": committee_plan,
        "host_execution_instructions": host_instructions,
        "recommended_host_prompt": "pc_agent_committee_flow",
        "committee_fallback_mode": fallback_mode,
        "judge_revision_state": execution_state["judge_revision_state"],
        "judge_comparison_required": workflow_kind == "improve",
        "committee_stop_reason": "awaiting_host_execution",
        "allowlist_enforcement_mode": allowlist_enforcement_mode(),
        "artifact_budget": artifact_budget(),
        "execution_required": True,
        "questions_for_user": [],
        "question_loop_state": execution_state,
        "host_action": {
            "must_pause": False,
            "blocking_gate": "",
            "directive": "Execute the approved committee plan using the selected host adapter. Do not let committee roles ask the user questions directly.",
            "preferred_interaction_surface": "host_orchestration_layer",
            "fallback_interaction_surface": "sequential_labeled_fallback",
            "native_ui_directive": "Native question UI is not needed during committee execution unless the top-level host asks a new user-facing question outside the committee roles.",
            "fallback_rendering_directive": "If native subagents are unavailable, disclose the fallback and execute the role contracts sequentially with the provided labels.",
            "prompt_style": "execute_committee_contract",
            "do_not_preview_future_stages": True,
            "disallowed_actions_until_resume": [
                "do_not_spawn_recursive_committees",
                "do_not_let_roles_ask_user_questions",
                "do_not_exceed_single_judge_revision_budget",
            ],
            "required_next_step": "Run the role contracts in order through the selected adapter, then present the final synthesis.",
            "route_violation_if_ignored": "Ignoring the committee contract means leaving the approved Agent Mode lane.",
        },
        "resume_payload_template": {
            "tool": "improve_prompt" if workflow_kind == "improve" else "build_prompt",
            "payload": {
                ("prompt" if workflow_kind == "improve" else "user_intent"): source_text,
                "mode": "advanced",
                "interaction_style": interaction_style,
                "agent_mode": "committee",
                "committee_confirmation_token": normalize_text(state.get("committee_confirmation_token")),
                "question_loop_state": execution_state,
                "selected_prompt_library_ids": selected_prompt_library_ids or [],
                "model_target": normalize_model_name(repo, model_target) if model_target else None,
            },
        },
    }


def _direct_advanced_improve_payload(
    repo: PromptCompassRepository,
    prompt: str,
    *,
    analysis: dict[str, Any],
    state: dict[str, Any],
    model_target: str | None,
    selected_prompt_library_ids: list[str] | None,
    mode_reason: str,
    interaction_style_reason: str,
    agent_mode_reason: str,
    agent_mode: str,
    committee_confirmation_token: str | None,
    preservation_mode: str,
) -> dict[str, Any]:
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    contract = merge_question_answers(analysis["prompt_contract"], answers)
    if agent_mode == "committee":
        return _committee_plan_or_execution_payload(
            repo,
            workflow_kind="improve",
            source_text=prompt,
            analysis=analysis,
            contract=contract,
            state=state,
            mode_reason=mode_reason,
            interaction_style="direct",
            interaction_style_reason=interaction_style_reason,
            agent_mode_reason=agent_mode_reason,
            committee_confirmation_token=committee_confirmation_token,
            selected_prompt_library_ids=selected_prompt_library_ids,
            model_target=model_target,
        )
    final_payload = improve_prompt_payload(
        repo,
        prompt,
        analysis,
        model_target=normalize_model_name(repo, model_target) if model_target else None,
        question_answers=answers,
        selected_prompt_library_ids=selected_prompt_library_ids,
        mode="advanced",
        preservation_mode=preservation_mode,
    )
    final_payload.update(
        {
            "mode_used": "advanced",
            "mode_reason": mode_reason,
            "interaction_style_used": "direct",
            "interaction_style_reason": interaction_style_reason,
            "agent_mode_used": "off",
            "agent_mode_reason": agent_mode_reason,
            "workflow_stage": "stage_3_optional_reflection",
            "current_stage": "stage_3_optional_reflection",
            "diagnosis_summary": _intermediate_findings_summary(
                {**analysis, "prompt_contract": final_payload.get("prompt_contract", analysis.get("prompt_contract", {}))},
                "stage_2_context_and_repair",
            ),
            "stage_goal": "Deliver the improved prompt immediately after a direct advanced pass.",
            "stage_status": "final_prompt_ready",
            "stage_exit_criteria": ["The user receives the improved prompt. Reflection is optional."],
            "questions_for_user": _reflection_questions("improve"),
            "host_action": {
                "must_pause": False,
                "blocking_gate": "",
                "directive": "Deliver the improved prompt now. Reflection is optional and must not block delivery.",
                "preferred_interaction_surface": "native_host_question_ui",
                "fallback_interaction_surface": "compact_inline_question_block",
                "native_ui_directive": "If you ask the optional reflection question, use native UI first when available.",
                "fallback_rendering_directive": "If native UI is unavailable, render one compact inline reflection prompt only.",
                "prompt_style": "optional_reflection_follow_up",
                "do_not_preview_future_stages": True,
                "disallowed_actions_until_resume": [],
                "required_next_step": "Present the improved prompt. Reflection is optional.",
                "route_violation_if_ignored": "",
            },
            "awaiting_question_ids": [],
            "answered_question_ids": ensure_list(state.get("answered_question_ids")),
            "answered_slots": ensure_list(state.get("answered_slots")),
            "stage_completion": {
                "stage": "stage_3_optional_reflection",
                "required_slots": [],
                "answered_required_slots": [],
                "missing_required_slots": [],
                "awaiting_question_ids": [],
                "exit_ready": True,
            },
            "resume_allowed": True,
            "resume_payload_template": {
                "tool": "improve_prompt",
                "payload": {
                    "prompt": prompt,
                    "mode": "advanced",
                    "interaction_style": "direct",
                    "agent_mode": "off",
                    "question_loop_state": {
                        "mode": "advanced",
                        "interaction_style": "direct",
                        "agent_mode": "off",
                        "workflow_stage": "stage_3_optional_reflection",
                        "answers": answers,
                    },
                    "selected_prompt_library_ids": selected_prompt_library_ids or [],
                },
            },
        }
    )
    final_payload.update(_advanced_diagnosis_fields(repo, prompt, analysis, model_target=model_target))
    return _attach_auto_comparison(repo, prompt, final_payload, model_target=model_target)


def _direct_advanced_build_payload(
    repo: PromptCompassRepository,
    user_intent: str,
    *,
    analysis: dict[str, Any],
    state: dict[str, Any],
    contract: dict[str, Any],
    model_target: str | None,
    selected_prompt_library_items: list[dict[str, Any]],
    mode_reason: str,
    interaction_style_reason: str,
    agent_mode_reason: str,
    agent_mode: str,
    committee_confirmation_token: str | None,
) -> dict[str, Any]:
    if _quick_build_needs_one_question(contract, user_intent):
        question_payload = _single_quick_build_question(repo, analysis, state, user_intent, selected_prompt_library_items)
        question_payload["resume_payload_template"] = {
            "tool": "build_prompt",
            "payload": {
                "user_intent": user_intent,
                "mode": "advanced",
                "interaction_style": "direct",
                "agent_mode": agent_mode,
                "question_loop_state": question_payload["question_loop_state"],
                "selected_prompt_library_ids": [item.get("item_id") for item in selected_prompt_library_items if item.get("item_id")],
            },
        }
        question_payload.update(
            {
                "completed": False,
                "mode_used": "advanced",
                "mode_reason": mode_reason,
                "interaction_style_used": "direct",
                "interaction_style_reason": interaction_style_reason,
                "agent_mode_used": agent_mode,
                "agent_mode_reason": agent_mode_reason,
                "workflow_stage": "direct_build_clarify_once",
                "current_stage": "direct_build_clarify_once",
                "stage_goal": "Ask one high-value clarification because the direct advanced build is still too underspecified to proceed safely.",
            }
        )
        return question_payload

    if agent_mode == "committee":
        committee_contract = _apply_shared_build_defaults(contract, analysis, user_intent)
        committee_contract["assumptions"] = _build_assumptions(committee_contract)
        return _committee_plan_or_execution_payload(
            repo,
            workflow_kind="build",
            source_text=user_intent,
            analysis=analysis,
            contract=committee_contract,
            state=state,
            mode_reason=mode_reason,
            interaction_style="direct",
            interaction_style_reason=interaction_style_reason,
            agent_mode_reason=agent_mode_reason,
            committee_confirmation_token=committee_confirmation_token,
            selected_prompt_library_ids=[item.get("item_id") for item in selected_prompt_library_items if item.get("item_id")],
            model_target=model_target,
        )

    contract = _apply_shared_build_defaults(contract, analysis, user_intent)
    contract["assumptions"] = _build_assumptions(contract)
    strategy_payload = suggest_strategies_payload(
        repo,
        prompt_type=analysis["prompt_type"],
        subject_area=analysis["subject_area"],
        model_target=contract.get("model_target") or normalize_model_name(repo, model_target) or None,
        interaction_mode=analysis.get("interaction_mode"),
        output_mode=analysis.get("output_mode"),
        grounding_mode=analysis.get("grounding_mode"),
        evaluation_mode=analysis.get("evaluation_mode"),
        capability_tags=analysis.get("capability_tags", []),
        anti_patterns=analysis.get("anti_patterns", []),
        missing_building_blocks=contract_missing_blocks(contract),
        prompt_surface=analysis.get("prompt_surface"),
        surface_traits=analysis.get("surface_traits", []),
    )
    return {
        "completed": True,
        "mode_used": "advanced",
        "mode_reason": mode_reason,
        "interaction_style_used": "direct",
        "interaction_style_reason": interaction_style_reason,
        "agent_mode_used": "off",
        "agent_mode_reason": agent_mode_reason,
        "workflow_stage": "stage_3_optional_reflection",
        "current_stage": "stage_3_optional_reflection",
        "stage_goal": "Deliver the scaffolded prompt immediately after a direct advanced pass.",
        "stage_status": "final_prompt_ready",
        "stage_exit_criteria": ["The user receives the scaffolded prompt. Reflection is optional."],
        "scaffolded_prompt": render_prompt_contract(contract, include_assumptions=True),
        "prompt_contract": contract,
        "applied_strategies": strategy_payload["strategies"][:4],
        "selected_prompt_library_items": [_compact_prompt_library_item(item) for item in selected_prompt_library_items],
        "assumptions": contract["assumptions"],
        "detected_pattern_primary": detect_primary_pattern(user_intent, contract, analysis.get("anti_patterns", [])),
        "core_principles_applied": core_principles_applied(
            user_intent,
            contract,
            analysis.get("anti_patterns", []),
            workflow_kind="build",
        ),
        "questions_for_user": _reflection_questions("build"),
        "host_action": {
            "must_pause": False,
            "blocking_gate": "",
            "directive": "Deliver the scaffolded prompt now. Reflection is optional and must not block delivery.",
            "preferred_interaction_surface": "native_host_question_ui",
            "fallback_interaction_surface": "compact_inline_question_block",
            "native_ui_directive": "If you ask the optional reflection question, use native UI first when available.",
            "fallback_rendering_directive": "If native UI is unavailable, render one compact inline reflection prompt only.",
            "prompt_style": "optional_reflection_follow_up",
            "do_not_preview_future_stages": True,
            "disallowed_actions_until_resume": [],
            "required_next_step": "Present the scaffolded prompt. Reflection is optional.",
            "route_violation_if_ignored": "",
        },
        "awaiting_question_ids": [],
        "answered_question_ids": ensure_list(state.get("answered_question_ids")),
        "answered_slots": ensure_list(state.get("answered_slots")),
        "stage_completion": {
            "stage": "stage_3_optional_reflection",
            "required_slots": [],
            "answered_required_slots": [],
            "missing_required_slots": [],
            "awaiting_question_ids": [],
            "exit_ready": True,
        },
        "resume_allowed": True,
        "resume_payload_template": {
            "tool": "build_prompt",
            "payload": {
                "user_intent": user_intent,
                "mode": "advanced",
                "interaction_style": "direct",
                "agent_mode": "off",
                "question_loop_state": {
                    "mode": "advanced",
                    "interaction_style": "direct",
                    "agent_mode": "off",
                    "workflow_stage": "stage_3_optional_reflection",
                    "answers": state.get("answers", {}),
                },
                "selected_prompt_library_ids": [item.get("item_id") for item in selected_prompt_library_items if item.get("item_id")],
            },
        },
    }


def _advanced_improve_payload(
    repo: PromptCompassRepository,
    prompt: str,
    *,
    analysis: dict[str, Any],
    state: dict[str, Any],
    model_target: str | None,
    selected_prompt_library_ids: list[str] | None,
    mode_reason: str,
    interaction_style_reason: str,
    agent_mode_reason: str,
    interaction_style: str,
    agent_mode: str,
    committee_confirmation_token: str | None,
    preservation_mode: str,
) -> dict[str, Any]:
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    if normalize_text(answers.get("mode")).lower() in {"quick", "advanced"}:
        state["mode"] = normalize_text(answers.get("mode")).lower()
        if state["mode"] == "quick":
            return improve_prompt_workflow_payload(
                repo,
                prompt,
                model_target=model_target,
                analysis=analysis,
                question_answers=answers,
                question_loop_state=state,
                selected_prompt_library_ids=selected_prompt_library_ids,
                mode="quick",
                preservation_mode=preservation_mode,
            )
    state["mode"] = "advanced"
    contract = merge_question_answers(analysis["prompt_contract"], answers)
    current_missing = contract_missing_blocks(contract)
    stage = normalize_text(state.get("workflow_stage")) or "stage_1_intent_and_contract"
    if stage in {"", "mode_selection"}:
        stage = "stage_1_intent_and_contract"
    if stage == "stage_1_intent_and_contract":
        stage1_questions = _advanced_stage_questions(
            repo,
            analysis={**analysis, "prompt_contract": contract, "missing_building_blocks": current_missing},
            state=state,
            workflow_kind="improve",
            stage="stage_1_intent_and_contract",
            source_text=prompt,
            interaction_style=interaction_style,
            agent_mode=agent_mode,
        )
        if stage1_questions["questions_for_user"]:
            stage1_questions.update(
                {
                    "mode_used": "advanced",
                    "mode_reason": mode_reason,
                    "interaction_style_used": interaction_style,
                    "interaction_style_reason": interaction_style_reason,
                    "agent_mode_used": agent_mode,
                    "agent_mode_reason": agent_mode_reason,
                    "completed": False,
                }
            )
            return stage1_questions
        stage = "stage_2_context_and_repair"

    if stage == "stage_2_context_and_repair":
        stage2_questions = _advanced_stage_questions(
            repo,
            analysis={**analysis, "prompt_contract": contract, "missing_building_blocks": current_missing},
            state=state,
            workflow_kind="improve",
            stage="stage_2_context_and_repair",
            source_text=prompt,
            interaction_style=interaction_style,
            agent_mode=agent_mode,
        )
        if stage2_questions["questions_for_user"] and not _stage_two_ready(state, contract):
            stage2_questions.update(
                {
                    "mode_used": "advanced",
                    "mode_reason": mode_reason,
                    "interaction_style_used": interaction_style,
                    "interaction_style_reason": interaction_style_reason,
                    "agent_mode_used": agent_mode,
                    "agent_mode_reason": agent_mode_reason,
                    "completed": False,
                }
            )
            return stage2_questions

    if agent_mode == "committee":
        return _committee_plan_or_execution_payload(
            repo,
            workflow_kind="improve",
            source_text=prompt,
            analysis=analysis,
            contract=contract,
            state=state,
            mode_reason=mode_reason,
            interaction_style=interaction_style,
            interaction_style_reason=interaction_style_reason,
            agent_mode_reason=agent_mode_reason,
            committee_confirmation_token=committee_confirmation_token,
            selected_prompt_library_ids=selected_prompt_library_ids,
            model_target=model_target,
        )

    final_payload = improve_prompt_payload(
        repo,
        prompt,
        analysis,
        model_target=normalize_model_name(repo, model_target) if model_target else None,
        question_answers=answers,
        selected_prompt_library_ids=selected_prompt_library_ids,
        mode="advanced",
        preservation_mode=preservation_mode,
    )
    final_payload.update(
        {
            "mode_used": "advanced",
            "mode_reason": mode_reason,
            "interaction_style_used": interaction_style,
            "interaction_style_reason": interaction_style_reason,
            "agent_mode_used": agent_mode,
            "agent_mode_reason": agent_mode_reason,
            "workflow_stage": "stage_3_optional_reflection",
            "current_stage": "stage_3_optional_reflection",
            "diagnosis_summary": _intermediate_findings_summary(
                {**analysis, "prompt_contract": final_payload.get("prompt_contract", analysis.get("prompt_contract", {}))},
                "stage_2_context_and_repair",
            ),
            "stage_goal": "Deliver the improved prompt and optionally invite reflection.",
            "stage_status": "final_prompt_ready",
            "stage_exit_criteria": ["The user receives the improved prompt and can skip or answer the optional reflection prompts."],
            "questions_for_user": _reflection_questions("improve"),
            "host_action": {
                "must_pause": False,
                "blocking_gate": "",
                "directive": "Deliver the improved prompt now. Reflection is optional and must not block delivery.",
                "preferred_interaction_surface": "native_host_question_ui",
                "fallback_interaction_surface": "compact_inline_question_block",
                "native_ui_directive": "If you ask the optional reflection question, use native UI first when available.",
                "fallback_rendering_directive": "If native UI is unavailable, render one compact inline reflection prompt only.",
                "prompt_style": "optional_reflection_follow_up",
                "do_not_preview_future_stages": True,
                "disallowed_actions_until_resume": [],
                "required_next_step": "Present the improved prompt. Reflection is optional.",
                "route_violation_if_ignored": "",
            },
            "awaiting_question_ids": [],
            "answered_question_ids": ensure_list(state.get("answered_question_ids")),
            "answered_slots": ensure_list(state.get("answered_slots")),
            "stage_completion": {
                "stage": "stage_3_optional_reflection",
                "required_slots": [],
                "answered_required_slots": [],
                "missing_required_slots": [],
                "awaiting_question_ids": [],
                "exit_ready": True,
            },
            "resume_allowed": True,
            "resume_payload_template": {
                "tool": "improve_prompt",
                "payload": {
                    "prompt": prompt,
                    "mode": "advanced",
                    "interaction_style": interaction_style,
                    "agent_mode": agent_mode,
                    "question_loop_state": {
                        "mode": "advanced",
                        "interaction_style": interaction_style,
                        "agent_mode": agent_mode,
                        "workflow_stage": "stage_3_optional_reflection",
                        "answers": answers,
                    },
                    "selected_prompt_library_ids": selected_prompt_library_ids or [],
                },
            },
        }
    )
    final_payload.update(_advanced_diagnosis_fields(repo, prompt, analysis, model_target=model_target))
    return _attach_auto_comparison(repo, prompt, final_payload, model_target=model_target)


def _advanced_build_payload(
    repo: PromptCompassRepository,
    user_intent: str,
    *,
    analysis: dict[str, Any],
    state: dict[str, Any],
    contract: dict[str, Any],
    model_target: str | None,
    selected_prompt_library_items: list[dict[str, Any]],
    mode_reason: str,
    interaction_style_reason: str,
    agent_mode_reason: str,
    interaction_style: str,
    agent_mode: str,
    committee_confirmation_token: str | None,
) -> dict[str, Any]:
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    if normalize_text(answers.get("mode")).lower() in {"quick", "advanced"}:
        state["mode"] = normalize_text(answers.get("mode")).lower()
        if state["mode"] == "quick":
            return build_prompt_payload(
                repo,
                user_intent,
                model_target=model_target,
                question_loop_state={"answers": answers},
                selected_prompt_library_ids=[item.get("item_id") for item in selected_prompt_library_items if item.get("item_id")],
                mode="quick",
            )
    state["mode"] = "advanced"
    stage = normalize_text(state.get("workflow_stage")) or "stage_1_intent_and_contract"
    current_missing = contract_missing_blocks(contract)
    if stage in {"", "mode_selection"}:
        stage = "stage_1_intent_and_contract"
    if stage == "stage_1_intent_and_contract":
        stage1_questions = _advanced_stage_questions(
            repo,
            analysis={**analysis, "prompt_contract": contract, "missing_building_blocks": current_missing},
            state=state,
            workflow_kind="build",
            stage="stage_1_intent_and_contract",
            source_text=user_intent,
            interaction_style=interaction_style,
            agent_mode=agent_mode,
        )
        if stage1_questions["questions_for_user"]:
            stage1_questions.update(
                {
                    "mode_used": "advanced",
                    "mode_reason": mode_reason,
                    "interaction_style_used": interaction_style,
                    "interaction_style_reason": interaction_style_reason,
                    "agent_mode_used": agent_mode,
                    "agent_mode_reason": agent_mode_reason,
                    "completed": False,
                    "selected_prompt_library_items": [_compact_prompt_library_item(item) for item in selected_prompt_library_items],
                    "detected_pattern_primary": detect_primary_pattern(user_intent, contract, analysis.get("anti_patterns", [])),
                    "core_principles_applied": core_principles_applied(
                        user_intent,
                        contract,
                        analysis.get("anti_patterns", []),
                        workflow_kind="build",
                    ),
                }
            )
            return stage1_questions
        stage = "stage_2_context_and_repair"

    if stage == "stage_2_context_and_repair":
        stage2_questions = _advanced_stage_questions(
            repo,
            analysis={**analysis, "prompt_contract": contract, "missing_building_blocks": current_missing},
            state=state,
            workflow_kind="build",
            stage="stage_2_context_and_repair",
            source_text=user_intent,
            interaction_style=interaction_style,
            agent_mode=agent_mode,
        )
        if stage2_questions["questions_for_user"] and not _stage_two_ready(state, contract):
            stage2_questions.update(
                {
                    "mode_used": "advanced",
                    "mode_reason": mode_reason,
                    "interaction_style_used": interaction_style,
                    "interaction_style_reason": interaction_style_reason,
                    "agent_mode_used": agent_mode,
                    "agent_mode_reason": agent_mode_reason,
                    "completed": False,
                    "selected_prompt_library_items": [_compact_prompt_library_item(item) for item in selected_prompt_library_items],
                    "detected_pattern_primary": detect_primary_pattern(user_intent, contract, analysis.get("anti_patterns", [])),
                    "core_principles_applied": core_principles_applied(
                        user_intent,
                        contract,
                        analysis.get("anti_patterns", []),
                        workflow_kind="build",
                    ),
                }
            )
            return stage2_questions

    if agent_mode == "committee":
        committee_contract = _apply_shared_build_defaults(contract, analysis, user_intent)
        committee_contract["assumptions"] = _build_assumptions(committee_contract)
        return _committee_plan_or_execution_payload(
            repo,
            workflow_kind="build",
            source_text=user_intent,
            analysis=analysis,
            contract=committee_contract,
            state=state,
            mode_reason=mode_reason,
            interaction_style=interaction_style,
            interaction_style_reason=interaction_style_reason,
            agent_mode_reason=agent_mode_reason,
            committee_confirmation_token=committee_confirmation_token,
            selected_prompt_library_ids=[item.get("item_id") for item in selected_prompt_library_items if item.get("item_id")],
            model_target=model_target,
        )

    contract = _apply_shared_build_defaults(contract, analysis, user_intent)
    contract["assumptions"] = _build_assumptions(contract)
    strategy_payload = suggest_strategies_payload(
        repo,
        prompt_type=analysis["prompt_type"],
        subject_area=analysis["subject_area"],
        model_target=contract.get("model_target") or normalize_model_name(repo, model_target) or None,
        interaction_mode=analysis.get("interaction_mode"),
        output_mode=analysis.get("output_mode"),
        grounding_mode=analysis.get("grounding_mode"),
        evaluation_mode=analysis.get("evaluation_mode"),
        capability_tags=analysis.get("capability_tags", []),
        anti_patterns=analysis.get("anti_patterns", []),
        missing_building_blocks=current_missing,
        prompt_surface=analysis.get("prompt_surface"),
        surface_traits=analysis.get("surface_traits", []),
    )
    return {
        "completed": True,
        "mode_used": "advanced",
        "mode_reason": mode_reason,
        "interaction_style_used": interaction_style,
        "interaction_style_reason": interaction_style_reason,
        "agent_mode_used": agent_mode,
        "agent_mode_reason": agent_mode_reason,
        "workflow_stage": "stage_3_optional_reflection",
        "current_stage": "stage_3_optional_reflection",
        "stage_goal": "Deliver the scaffolded prompt and optionally invite reflection.",
        "stage_status": "final_prompt_ready",
        "stage_exit_criteria": ["The user receives the scaffolded prompt and can skip or answer the optional reflection prompts."],
        "scaffolded_prompt": render_prompt_contract(contract, include_assumptions=True),
        "prompt_contract": contract,
        "applied_strategies": strategy_payload["strategies"][:4],
        "selected_prompt_library_items": [_compact_prompt_library_item(item) for item in selected_prompt_library_items],
        "assumptions": contract["assumptions"],
        "detected_pattern_primary": detect_primary_pattern(user_intent, contract, analysis.get("anti_patterns", [])),
        "core_principles_applied": core_principles_applied(
            user_intent,
            contract,
            analysis.get("anti_patterns", []),
            workflow_kind="build",
        ),
        "questions_for_user": _reflection_questions("build"),
        "host_action": {
            "must_pause": False,
            "blocking_gate": "",
            "directive": "Deliver the scaffolded prompt now. Reflection is optional and must not block delivery.",
            "preferred_interaction_surface": "native_host_question_ui",
            "fallback_interaction_surface": "compact_inline_question_block",
            "native_ui_directive": "If you ask the optional reflection question, use native UI first when available.",
            "fallback_rendering_directive": "If native UI is unavailable, render one compact inline reflection prompt only.",
            "prompt_style": "optional_reflection_follow_up",
            "do_not_preview_future_stages": True,
            "disallowed_actions_until_resume": [],
            "required_next_step": "Present the scaffolded prompt. Reflection is optional.",
            "route_violation_if_ignored": "",
        },
        "awaiting_question_ids": [],
        "answered_question_ids": ensure_list(state.get("answered_question_ids")),
        "answered_slots": ensure_list(state.get("answered_slots")),
        "stage_completion": {
            "stage": "stage_3_optional_reflection",
            "required_slots": [],
            "answered_required_slots": [],
            "missing_required_slots": [],
            "awaiting_question_ids": [],
            "exit_ready": True,
        },
        "resume_allowed": True,
        "resume_payload_template": {
            "tool": "build_prompt",
            "payload": {
                "user_intent": user_intent,
                "mode": "advanced",
                "interaction_style": interaction_style,
                "agent_mode": agent_mode,
                "question_loop_state": {
                    "mode": "advanced",
                    "interaction_style": interaction_style,
                    "agent_mode": agent_mode,
                    "workflow_stage": "stage_3_optional_reflection",
                    "answers": answers,
                },
            },
        },
    }


def _advanced_stage_questions(
    repo: PromptCompassRepository,
    *,
    analysis: dict[str, Any],
    state: dict[str, Any],
    workflow_kind: str,
    stage: str,
    source_text: str,
    interaction_style: str,
    agent_mode: str,
) -> dict[str, Any]:
    preferred_slots, categories, stage_goal, exit_criteria = _stage_config(workflow_kind, stage, analysis)
    summary = _intermediate_findings_summary(analysis, stage)
    payload = get_clarifying_questions_payload(
        repo,
        analysis,
        question_loop_state=state,
        limit=3,
        preferred_slots=preferred_slots,
        allowed_categories=categories,
        workflow_stage=stage,
        stage_goal=stage_goal,
        stage_exit_criteria=exit_criteria,
        prelude_summary=summary,
        prompt_style="ask_only_this_stage",
    )
    payload["diagnosis_summary"] = summary
    payload["question_loop_state"]["mode"] = "advanced"
    payload["question_loop_state"]["interaction_style"] = interaction_style
    payload["question_loop_state"]["agent_mode"] = agent_mode
    payload["question_loop_state"]["workflow_stage"] = stage
    payload["question_loop_state"]["current_stage"] = stage
    payload["question_loop_state"]["stage_history"] = _append_stage_history(state, stage)
    payload["question_loop_state"]["active_required_slots"] = preferred_slots
    payload["question_loop_state"]["stage_completion"] = _stage_completion_payload(stage, analysis.get("prompt_contract", {}), payload["question_loop_state"])
    payload["question_loop_state"]["resume_allowed"] = False
    payload["current_stage"] = stage
    payload["awaiting_question_ids"] = ensure_list(payload["question_loop_state"].get("awaiting_question_ids"))
    payload["answered_question_ids"] = ensure_list(payload["question_loop_state"].get("answered_question_ids"))
    payload["answered_slots"] = ensure_list(payload["question_loop_state"].get("answered_slots"))
    payload["stage_completion"] = payload["question_loop_state"]["stage_completion"]
    payload["resume_allowed"] = False
    payload["host_action"] = {
        **_advanced_host_action(
            workflow_kind=workflow_kind,
            stage=stage,
            interaction_batch=payload.get("interaction_batch"),
            required_next_step="Ask this stage in native UI first, then resume the same workflow tool with updated answers.",
        ),
        "prompt_style": "ask_only_this_stage",
    }
    payload["resume_payload_template"] = {
        "tool": "improve_prompt" if workflow_kind == "improve" else "build_prompt",
        "payload": {
            ("prompt" if workflow_kind == "improve" else "user_intent"): source_text,
            "mode": "advanced",
            "interaction_style": interaction_style,
            "agent_mode": agent_mode,
            "question_loop_state": payload["question_loop_state"],
        },
    }
    return payload


def _stage_config(
    workflow_kind: str,
    stage: str,
    analysis: dict[str, Any],
) -> tuple[list[str], list[str], str, list[str]]:
    if stage == "stage_1_intent_and_contract":
        missing = set(analysis.get("missing_building_blocks", []) or [])
        preferred_slots = [slot for slot in ["objective", "audience", "output_contract"] if slot in missing]
        if not preferred_slots:
            preferred_slots = ["objective", "audience", "output_contract"]
        categories = ["deliverable", "audience", "output_contract", "success_test"]
        goal = "Lock the core job, audience, and output artifact before moving into deeper repair."
        exit_criteria = [
            "Objective is explicit enough to drive the prompt.",
            "Audience is named or intentionally inferred.",
            "Output contract is visible enough to produce a usable artifact.",
        ]
        return preferred_slots, categories, goal, exit_criteria
    preferred_slots = _stage_two_slots_for_analysis(analysis)
    category_by_slot = {
        "context": "context_depth",
        "constraints": "scope",
        "grounding": "grounding",
        "parser_contract": "parser_contract",
        "runtime_layer": "runtime_layer",
        "evaluation": "evaluation",
        "source_priority": "source_priority",
        "tool_use": "tool_use",
        "agent_control": "agent_control",
    }
    categories = [category_by_slot[slot] for slot in preferred_slots if slot in category_by_slot]
    if "constraints" in preferred_slots:
        categories.append("trait_ranking")
    goal = "Gather the missing context, constraints, runtime boundaries, and repair details needed for a stronger final prompt."
    exit_criteria = [
        "The remaining context or constraint gaps are either answered or intentionally skipped into assumptions.",
        "Any runtime or grounding rules that matter for this prompt are explicit enough to steer the final result.",
    ]
    if workflow_kind == "build" and not any(item.get("slug") == "scope-sprawl" for item in analysis.get("anti_patterns", [])):
        exit_criteria.append("The prompt feels build-ready rather than still under-specified.")
    return preferred_slots, categories, goal, exit_criteria


def _stage_two_slots_for_analysis(analysis: dict[str, Any]) -> list[str]:
    prompt_surface = normalize_text(analysis.get("prompt_surface")).lower()
    output_mode = normalize_text(analysis.get("output_mode")).lower()
    grounding_mode = normalize_text(analysis.get("grounding_mode")).lower()
    capability_tags = {normalize_text(item).lower() for item in ensure_list(analysis.get("capability_tags"))}
    slots = ["context", "constraints"]
    if prompt_surface in {"retrieval_grounded"} or grounding_mode in {"retrieval", "quote_first"} or "retrieval_grounding" in capability_tags:
        slots.extend(["grounding", "source_priority"])
    if prompt_surface in {"parser_bound"} or output_mode == "schema_bound" or "structured_output" in capability_tags:
        slots.extend(["parser_contract", "evaluation"])
    if prompt_surface in {"tool_workflow"} or "tool_use" in capability_tags or "function_calling" in capability_tags:
        slots.extend(["runtime_layer", "tool_use", "agent_control", "evaluation"])
    return list(dict.fromkeys(slots))


def _intermediate_findings_summary(analysis: dict[str, Any], stage: str) -> str:
    missing = list(analysis.get("missing_building_blocks", []) or [])
    anti_patterns = [item.get("name") for item in analysis.get("anti_patterns", []) if item.get("name")]
    if stage == "stage_2_context_and_repair":
        parts: list[str] = []
        if anti_patterns:
            parts.append("Current diagnosis flags: " + ", ".join(anti_patterns[:3]))
        if missing:
            parts.append("The main remaining gaps are: " + ", ".join(missing[:4]))
        if not parts:
            parts.append("The core contract is now visible; this stage is for the higher-value context and repair details.")
        return ". ".join(parts) + "."
    return "This stage is about locking the core contract before the prompt is rewritten or scaffolded."


def _stage_two_ready(state: dict[str, Any], contract: dict[str, Any]) -> bool:
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    stage_two_slots = {"context", "constraints", "grounding", "parser_contract", "runtime_layer", "evaluation", "source_priority", "tool_use", "agent_control"}
    if any(normalize_text(answers.get(slot)) for slot in stage_two_slots if slot in answers):
        return True
    if stage_two_slots & {normalize_text(slot).lower() for slot in ensure_list(state.get("answered_slots"))}:
        return True
    return bool(ensure_list(contract.get("context")) and ensure_list(contract.get("constraints")))


def _quick_build_needs_one_question(contract: dict[str, Any], user_intent: str) -> bool:
    missing = set(contract_missing_blocks(contract))
    token_count = len(normalize_text(user_intent).split())
    return token_count <= 8 and {"objective", "audience", "output_contract"} & missing


def _quick_build_guardrail_payload(
    repo: PromptCompassRepository,
    analysis: dict[str, Any],
    state: dict[str, Any],
    user_intent: str,
    selected_prompt_library_items: list[dict[str, Any]],
) -> dict[str, Any] | None:
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    if _looks_like_off_target_content(user_intent) and not _has_answer_value_for(answers, "content_intent"):
        return _single_plain_guardrail_question(
            state,
            user_intent,
            selected_prompt_library_items,
            slot="content_intent",
            stage="quick_build_content_check",
            question="This looks like it might be an assignment or document, not a prompt. What do you want me to do with it?",
            choices=[
                {"label": "Turn it into an AI prompt", "value": "build_prompt"},
                {"label": "I pasted the wrong thing", "value": "exit"},
                {"label": "Use it as background for a prompt", "value": "source_context"},
            ],
            assumption="I will treat the pasted material as background for writing a new AI request.",
            warning_type="content_type_mismatch",
        )
    conflicts = _quick_trait_conflicts(user_intent)
    if conflicts and not _has_answer_value_for(answers, "trait_priority"):
        return _single_plain_guardrail_question(
            state,
            user_intent,
            selected_prompt_library_items,
            slot="trait_priority",
            stage="quick_build_trait_conflict",
            question=f"I noticed a possible conflict: {conflicts[0]}. Which direction matters more?",
            choices=[
                {"label": "Prioritize clarity and usefulness", "value": "clarity"},
                {"label": "Prioritize brevity", "value": "brevity"},
                {"label": "Keep both and make a balanced assumption", "value": "balanced"},
            ],
            assumption="I will balance the conflicting traits and make the tradeoff visible.",
            warning_type="trait_conflict",
        )
    return None


def _single_plain_guardrail_question(
    state: dict[str, Any],
    user_intent: str,
    selected_prompt_library_items: list[dict[str, Any]],
    *,
    slot: str,
    stage: str,
    question: str,
    choices: list[dict[str, str]],
    assumption: str,
    warning_type: str,
) -> dict[str, Any]:
    question_payload = {
        "id": f"pc:build:{slot}",
        "slot": slot,
        "question": question,
        "display_label": "Quick check",
        "plain_question": question,
        "example_answers": [item["label"] for item in choices],
        "assumption_if_skipped": assumption,
        "answer_type": "single_choice",
        "choices": choices,
        "why_i_am_asking": "This prevents Prompt Compass from silently building the wrong prompt.",
        "what_this_can_change": ["The assumption used in the generated prompt."],
        "on_skip": {"action": "use_visible_assumption", "value": assumption},
    }
    updated_state = register_pending_questions(state, [question_payload])
    updated_state["workflow_stage"] = stage
    updated_state["current_stage"] = stage
    updated_state["stage_status"] = "awaiting_user_answers"
    return {
        "workflow_stage": stage,
        "current_stage": stage,
        "stage_goal": "Resolve one plain-language issue before producing the quick build.",
        "stage_status": "awaiting_user_answers",
        "stage_exit_criteria": ["The user answers or skips this one check."],
        "questions_for_user": [question_payload],
        "question_loop_state": updated_state,
        "visible_assumptions": [assumption],
        "preservation_warnings": [
            {
                "type": warning_type,
                "message": question,
                "recovery_action": "Ask the one quick check, then resume build_prompt with the answer.",
            }
        ],
        "host_action": _advanced_host_action(
            workflow_kind="build",
            stage=stage,
            interaction_batch={
                "stage": stage,
                "ask_together": True,
                "max_questions_this_turn": 1,
                "do_not_prefetch_future_questions": True,
                "next_stage": "quick_build_complete",
            },
            required_next_step="Ask this one plain-language question, then resume build_prompt with the answer.",
        ),
        "awaiting_question_ids": ensure_list(updated_state.get("awaiting_question_ids")),
        "answered_question_ids": ensure_list(updated_state.get("answered_question_ids")),
        "answered_slots": ensure_list(updated_state.get("answered_slots")),
        "stage_completion": {
            "stage": stage,
            "required_slots": [slot],
            "answered_required_slots": [],
            "missing_required_slots": [slot],
            "awaiting_question_ids": [question_payload["id"]],
            "exit_ready": False,
        },
        "resume_allowed": False,
        "resume_payload_template": {
            "tool": "build_prompt",
            "payload": {
                "user_intent": user_intent,
                "mode": "quick",
                "question_loop_state": updated_state,
                "selected_prompt_library_ids": [item.get("item_id") for item in selected_prompt_library_items if item.get("item_id")],
            },
        },
    }


def _looks_like_off_target_content(text: str) -> bool:
    lowered = normalize_text(text).lower()
    markers = [
        "assignment",
        "homework",
        "rubric",
        "submit",
        "due date",
        "professor",
        "teacher says",
        "instructions:",
        "answer the following",
        "write an essay",
    ]
    return any(marker in lowered for marker in markers)


def _quick_trait_conflicts(text: str) -> list[str]:
    lowered = normalize_text(text).lower()
    checks = [
        (("professional", "formal"), ("casual", "informal"), "formal/professional tone versus casual tone"),
        (("short", "brief", "concise"), ("comprehensive", "detailed", "thorough"), "short output versus comprehensive detail"),
        (("motivate", "encourage", "supportive"), ("call out", "criticize", "mistakes"), "motivating tone versus corrective criticism"),
    ]
    conflicts: list[str] = []
    for left_terms, right_terms, label in checks:
        if any(term in lowered for term in left_terms) and any(term in lowered for term in right_terms):
            conflicts.append(label)
    return conflicts


def _has_answer_value_for(answers: dict[str, Any], slot: str) -> bool:
    if slot not in answers:
        return False
    value = answers.get(slot)
    if isinstance(value, dict):
        return any(_has_answer_value_for({key: item}, key) for key, item in value.items())
    if isinstance(value, list):
        return any(normalize_text(item) for item in value)
    return bool(normalize_text(value))


def _decorate_user_workflow_payload(payload: dict[str, Any], *, interaction_pace: str) -> dict[str, Any]:
    pace = _normalize_interaction_pace(interaction_pace) or "guided"
    decorated = dict(payload)
    question_state = decorated.get("question_loop_state") if isinstance(decorated.get("question_loop_state"), dict) else {}
    host_profile = normalize_host_capability_profile(question_state.get("host_capability_profile") if isinstance(question_state, dict) else None)
    native_question_ui = bool(host_profile.get("native_question_ui", True))
    decorated["interaction_pace"] = pace
    decorated.setdefault("question_budget", _question_budget_for_pace(pace))
    decorated.setdefault("score_visibility", "shown" if pace == "deep_dive" else "hidden_until_requested")
    decorated.setdefault("plain_language_summary", _workflow_plain_summary(decorated, pace))
    decorated.setdefault("remaining_recovery_action", _workflow_remaining_recovery_action(decorated))
    assumptions = list(ensure_list(decorated.get("visible_assumptions")))
    assumptions.extend(ensure_list(decorated.get("assumptions")))
    contract = decorated.get("prompt_contract") if isinstance(decorated.get("prompt_contract"), dict) else {}
    assumptions.extend(_build_assumptions(contract) if contract else [])
    decorated["visible_assumptions"] = _dedupe_strings(assumptions)
    if isinstance(decorated.get("question_loop_state"), dict):
        decorated["question_loop_state"]["interaction_pace"] = pace
    if decorated.get("questions_for_user"):
        decorated["native_ui_required"] = native_question_ui
        decorated["fallback_rendering_disclosure"] = (
            ""
            if native_question_ui
            else "Native question UI is unavailable, so render this as one compact plain-text question."
            )
    decorated = _attach_runtime_contract(
        decorated,
        host_profile=host_profile,
        stage=normalize_text(decorated.get("workflow_stage")) or "workflow_payload",
        include_tool_routing=False,
    )
    phase_prompt = _phase2s_source_text_for_workflow(decorated)
    phase_analysis = _phase2s_analysis_for_workflow(decorated)
    if phase_prompt and phase_analysis.get("prompt_contract"):
        workflow = _phase2s_workflow_name(decorated)
        decorated.update(
            phase2s_fields(
                phase_prompt,
                phase_analysis,
                tool_name=_phase2s_tool_name(decorated),
                workflow=workflow,
                runtime_payload=decorated,
                behavior_inventory=decorated.get("behavior_inventory", []),
                selected={
                    "strategies": ensure_list(decorated.get("applied_strategies") or decorated.get("recommended_strategies")),
                    "frameworks": ensure_list(decorated.get("matched_frameworks")),
                    "patterns": ensure_list(decorated.get("matched_patterns")),
                    "support_entries": ensure_list(decorated.get("selected_support_entries")),
                    "prompt_library_items": ensure_list(decorated.get("selected_prompt_library_items")),
                },
            )
        )
    decorated = _attach_phase2v_backlog_fields(decorated, source_text=phase_prompt, analysis=phase_analysis)
    return decorated


def _attach_phase2v_backlog_fields(
    payload: dict[str, Any],
    *,
    source_text: str,
    analysis: dict[str, Any],
) -> dict[str, Any]:
    contract = payload.get("prompt_contract") if isinstance(payload.get("prompt_contract"), dict) else {}
    if not contract:
        return payload
    updated = dict(payload)
    source = normalize_text(source_text) or _phase2s_source_text_for_workflow(updated)
    updated.setdefault("success_criteria_contract", success_criteria_contract(source, contract, analysis))
    updated.setdefault("role_prompt_assessment", role_prompt_assessment(source, contract, analysis))
    if updated.get("completed") is True and (
        normalize_text(updated.get("rewritten_prompt")) or normalize_text(updated.get("scaffolded_prompt"))
    ):
        updated.setdefault("compiled_prompt_artifact", compiled_prompt_artifact(source, updated, analysis))
    return updated


def _phase2s_source_text_for_workflow(payload: dict[str, Any]) -> str:
    resume = payload.get("resume_payload_template") if isinstance(payload.get("resume_payload_template"), dict) else {}
    resume_payload = resume.get("payload") if isinstance(resume.get("payload"), dict) else {}
    return (
        normalize_text(resume_payload.get("prompt"))
        or normalize_text(resume_payload.get("user_intent"))
        or normalize_text(payload.get("rewritten_prompt"))
        or normalize_text(payload.get("scaffolded_prompt"))
        or normalize_text(payload.get("plain_language_summary"))
    )


def _phase2s_analysis_for_workflow(payload: dict[str, Any]) -> dict[str, Any]:
    taxonomy = payload.get("taxonomy") if isinstance(payload.get("taxonomy"), dict) else {}
    return {
        "prompt_contract": payload.get("prompt_contract", {}),
        "prompt_type": payload.get("prompt_type") or taxonomy.get("prompt_type") or "",
        "subject_area": payload.get("subject_area") or taxonomy.get("subject_area") or "general",
        "interaction_mode": payload.get("interaction_mode") or taxonomy.get("interaction_mode") or "",
        "output_mode": payload.get("output_mode") or taxonomy.get("output_mode") or "",
        "grounding_mode": payload.get("grounding_mode") or taxonomy.get("grounding_mode") or "",
        "evaluation_mode": payload.get("evaluation_mode") or taxonomy.get("evaluation_mode") or "",
        "capability_tags": payload.get("capability_tags") or taxonomy.get("capability_tags") or [],
        "anti_patterns": payload.get("anti_patterns") or payload.get("anti_pattern_diagnosis") or [],
        "semantic_conflicts": payload.get("semantic_conflicts", []),
        "ai_data_risk_warnings": payload.get("ai_data_risk_warnings", []),
        "missing_building_blocks": payload.get("missing_building_blocks", []),
        "prompt_surface": payload.get("prompt_surface") or taxonomy.get("prompt_surface") or "",
        "retrieval_keywords": payload.get("retrieval_keywords", []),
    }


def _phase2s_workflow_name(payload: dict[str, Any]) -> str:
    if normalize_text(payload.get("agent_mode_used")) == "committee" or payload.get("committee_stage"):
        return "agent_committee"
    if normalize_text(payload.get("mode_used")) == "advanced":
        return "advanced_guided"
    return "quick_improve"


def _phase2s_tool_name(payload: dict[str, Any]) -> str:
    resume = payload.get("resume_payload_template") if isinstance(payload.get("resume_payload_template"), dict) else {}
    tool = normalize_text(resume.get("tool"))
    if tool:
        return tool
    if payload.get("rewritten_prompt"):
        return "improve_prompt"
    if payload.get("scaffolded_prompt"):
        return "build_prompt"
    return "prompt_compass_workflow"


def _atlas_build_scaffolding_for_intent(user_intent: str) -> dict[str, Any]:
    return {
        "atlas_task_template_examples": select_task_template_examples(user_intent, limit=3),
        "audience_targeting_suggestions": select_audience_targeting_seeds(user_intent, limit=3),
        "prompt_library_starter_examples": select_prompt_library_starter_examples(user_intent, limit=3),
        "atlas_scaffolding_note": (
            "Atlas-informed examples are support scaffolds only. They do not change routing, create a runtime Atlas dependency, "
            "or add a new workflow category."
        ),
    }


def _attach_atlas_build_scaffolding(payload: dict[str, Any], scaffolding: dict[str, Any]) -> dict[str, Any]:
    updated = dict(payload)
    for key, value in scaffolding.items():
        updated.setdefault(key, value)
    return updated


def _decorate_improve_delivery_payload(
    repo: PromptCompassRepository,
    payload: dict[str, Any],
    *,
    delivery_mode: str,
    source_prompt: str = "",
    analysis: dict[str, Any] | None = None,
    model_target: str | None = None,
    preferences_payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    resolved_delivery_mode = _normalize_delivery_mode(delivery_mode) or "standard"
    decorated = dict(payload)
    if resolved_delivery_mode != "autopilot":
        return decorated
    preferences_payload = preferences_payload or repo.get_preferences()
    preferences = preferences_payload.get("preferences", {})
    autoflow_preferences = preferences.get("autoflow", {}) if isinstance(preferences.get("autoflow"), dict) else {}
    preference_state = normalize_text(preferences_payload.get("autoflow_preference_state")) or "missing_blank_overlay"
    hitl_level = normalize_text(autoflow_preferences.get("hitl_level")) or "soft_gate"
    summary_visibility = normalize_text(autoflow_preferences.get("summary_visibility")) or "brief"
    decorated["delivery_mode_used"] = "autopilot"
    decorated["autoflow_preference_state"] = preference_state
    decorated["autoflow_enabled_by_default"] = bool(autoflow_preferences.get("enabled_by_default")) and preference_state == "configured"
    onboarding_payload: dict[str, Any] = {}
    if preference_state != "configured":
        decorated["preferences_nudge"] = AUTOFLOW_DEFAULT_NUDGE
        workflow_state = decorated.get("question_loop_state") if isinstance(decorated.get("question_loop_state"), dict) else {}
        host_profile = workflow_state.get("host_capability_profile") if isinstance(workflow_state, dict) else {}
        native_ui_required = bool((host_profile if isinstance(host_profile, dict) else {}).get("native_question_ui", True))
        onboarding_payload = {
            "status": "required_after_current_task",
            "plain_language_summary": "After this Auto Flow run, show the Auto Flow setup questions so the user can choose their defaults.",
            "native_ui_required": native_ui_required,
            "fallback_rendering_disclosure": ""
            if native_ui_required
            else "Native question UI is unavailable, so render the setup as compact plain-text choices.",
            "setup_questions": preferences_payload.get("setup_questions", []),
            "additional_preferences_available": bool(preferences_payload.get("additional_preferences_available", True)),
            "additional_preferences_gate": preferences_payload.get("additional_preferences_gate"),
            "host_instruction": "After executing the current rewritten_prompt, surface these setup questions via native question UI when available. Do not block the current Auto Flow task.",
        }
        decorated["autoflow_post_execution_onboarding"] = onboarding_payload
    if isinstance(decorated.get("question_loop_state"), dict):
        decorated["question_loop_state"]["delivery_mode"] = "autopilot"
    resume_template = decorated.get("resume_payload_template")
    if isinstance(resume_template, dict) and isinstance(resume_template.get("payload"), dict):
        resume_template["payload"]["delivery_mode"] = "autopilot"

    host_action = dict(decorated.get("host_action") or {})
    host_action["do_not_surface_full_rewrite"] = True
    if onboarding_payload:
        host_action["post_execution_required_next_step"] = onboarding_payload["host_instruction"]
    if decorated.get("completed") is True and normalize_text(decorated.get("rewritten_prompt")):
        assessment = _autoflow_change_assessment(
            repo,
            source_prompt,
            decorated,
            analysis=analysis,
            model_target=model_target,
            hitl_level=hitl_level,
            summary_visibility=summary_visibility,
        )
        decorated["autoflow_change_assessment"] = assessment
        approval_required = _autoflow_approval_required(assessment, hitl_level)
        if approval_required:
            question = _autoflow_execute_approval_question()
            state = dict(decorated.get("question_loop_state") or {})
            state = register_pending_questions(state, [question])
            state["workflow_stage"] = "autoflow_execution_approval"
            state["current_stage"] = "autoflow_execution_approval"
            state["stage_status"] = "awaiting_user_answers"
            state["delivery_mode"] = "autopilot"
            decorated["question_loop_state"] = state
            decorated["questions_for_user"] = [question]
            decorated["autoflow_execution_decision"] = "approval_required"
            decorated["autoflow_hitl_reason"] = assessment["decision_reason"]
            decorated["autopilot_delta_summary"] = _autopilot_delta_summary(decorated, suffix="review before executing")
            decorated["plain_language_summary"] = decorated["autopilot_delta_summary"]
            decorated["remaining_recovery_action"] = "Show rewritten_prompt and ask the execute approval question before running it."
            host_action.update(
                {
                    "must_pause": True,
                    "prompt_style": "autoflow_show_rewrite_then_ask_execute",
                    "required_next_step": "Show rewritten_prompt, ask `Execute this improved version?`, and execute only if the user approves.",
                    "do_not_surface_full_rewrite": False,
                    "do_not_preview_future_stages": False,
                }
            )
        else:
            silent_allowed = preference_state == "configured" and summary_visibility == "silent"
            summary = "" if silent_allowed else _autopilot_delta_summary(decorated)
            host_action.update(
                {
                    "must_pause": False,
                    "prompt_style": "autoflow_execute_silently" if silent_allowed else "autopilot_delta_then_execute",
                    "required_next_step": (
                        "Execute rewritten_prompt in the same turn without surfacing the full rewrite or delta summary."
                        if silent_allowed
                        else "Show autopilot_delta_summary, then execute rewritten_prompt in the same turn without surfacing the full rewrite."
                    ),
                    "do_not_preview_future_stages": False,
                }
            )
            decorated["autoflow_execution_decision"] = "execute_now"
            decorated["autoflow_hitl_reason"] = assessment["decision_reason"]
            decorated["autopilot_delta_summary"] = summary
            if summary:
                decorated["plain_language_summary"] = summary
                decorated["remaining_recovery_action"] = "Show autopilot_delta_summary, then execute rewritten_prompt without displaying the full rewritten prompt."
            else:
                decorated["plain_language_summary"] = "Auto Flow is ready to execute using saved silent-summary preferences."
                decorated["remaining_recovery_action"] = "Execute rewritten_prompt without displaying the full rewritten prompt or delta summary."
    else:
        host_action["do_not_execute_until_gate_clears"] = True
        host_action["required_next_step"] = (
            host_action.get("required_next_step")
            or "Clear the blocking Prompt Compass gate first. Autopilot can execute only after the improved prompt is ready."
        )
        decorated["autopilot_delta_summary"] = ""
        decorated["autoflow_execution_decision"] = "blocked_for_clarification"
        decorated["autoflow_hitl_reason"] = "Auto Flow cannot execute while Prompt Compass is waiting on a blocking question or workflow gate."
        decorated["autoflow_change_assessment"] = {
            "status": "not_assessed_until_rewrite_ready",
            "hitl_level": hitl_level,
            "summary_visibility": summary_visibility,
        }
        decorated["remaining_recovery_action"] = (
            "Clear the current blocking gate, then resume improve_prompt with delivery_mode='autopilot'."
        )
    decorated["host_action"] = host_action
    return decorated


def _autopilot_delta_summary(payload: dict[str, Any], *, suffix: str = "executing now") -> str:
    delta = payload.get("prompt_delta_summary") if isinstance(payload.get("prompt_delta_summary"), dict) else {}
    candidates: list[str] = []
    candidates.extend(ensure_list(delta.get("now_includes")))
    candidates.extend(ensure_list(delta.get("reduced_or_removed")))
    if not candidates:
        candidates.extend(ensure_list(payload.get("changes_made")))
    selected = [normalize_text(item).rstrip(".") for item in candidates if normalize_text(item)]
    selected = _dedupe_strings(selected)[:2]
    if not selected:
        selected = ["tightened the prompt"]
    return f"Prompt Compass: {', '.join(selected)} -> {suffix}."


def _autoflow_change_assessment(
    repo: PromptCompassRepository,
    source_prompt: str,
    payload: dict[str, Any],
    *,
    analysis: dict[str, Any] | None = None,
    model_target: str | None = None,
    hitl_level: str = "soft_gate",
    summary_visibility: str = "brief",
) -> dict[str, Any]:
    rewritten = normalize_text(payload.get("rewritten_prompt"))
    before_text = normalize_text(source_prompt)
    if not before_text or not rewritten:
        return {
            "status": "not_assessed",
            "raccca_total_delta": 0,
            "resolved_anti_patterns": [],
            "resolved_high_severity_anti_patterns": [],
            "significant_change": False,
            "hitl_level": hitl_level,
            "summary_visibility": summary_visibility,
            "decision_reason": "No comparable before/after prompt was available.",
        }
    before_analysis = analysis if isinstance(analysis, dict) and analysis.get("raccca") else analyze_prompt_payload(repo, before_text, model_target=model_target)
    comparison = compare_prompts_payload(repo, before_text, rewritten, model_target=model_target)
    resolved = ensure_list((comparison.get("anti_pattern_delta") or {}).get("resolved"))
    high_before = {
        normalize_text(item.get("slug"))
        for item in ensure_list(before_analysis.get("anti_patterns"))
        if normalize_text(item.get("severity")) == "high"
    }
    resolved_high = sorted(slug for slug in resolved if normalize_text(slug) in high_before)
    total_delta = int((comparison.get("raccca_delta") or {}).get("total_delta", 0))
    significant = total_delta > 2 or bool(resolved_high)
    if hitl_level == "always":
        reason = "Saved Auto Flow preferences say to ask before every execution."
    elif hitl_level == "none":
        reason = "Saved Auto Flow preferences allow execution without approval unless a blocking gate appears."
    elif significant:
        reason = "The rewrite materially changed the prompt, so Auto Flow should ask before executing."
    else:
        reason = "The rewrite was minor enough to execute with the configured Auto Flow notice."
    return {
        "status": "assessed",
        "raccca_total_delta": total_delta,
        "resolved_anti_patterns": resolved,
        "resolved_high_severity_anti_patterns": resolved_high,
        "significant_change": significant,
        "hitl_level": hitl_level,
        "summary_visibility": summary_visibility,
        "comparison_summary": _comparison_summary(comparison),
        "decision_reason": reason,
    }


def _autoflow_approval_required(assessment: dict[str, Any], hitl_level: str) -> bool:
    if hitl_level == "always":
        return True
    if hitl_level == "none":
        return False
    return bool(assessment.get("significant_change"))


def _autoflow_execute_approval_question() -> dict[str, Any]:
    return {
        "id": "pc:autoflow:execute-approval",
        "slot": "autoflow_execute_approval",
        "question": "Execute this improved version?",
        "display_label": "Run improved version?",
        "plain_question": "Execute this improved version?",
        "example_answers": ["Yes, execute it", "No, show me changes first"],
        "assumption_if_skipped": "Do not execute until the user approves.",
        "answer_type": "single_choice",
        "choices": [
            {"label": "Yes, execute it", "value": "yes"},
            {"label": "No, do not run it yet", "value": "no"},
        ],
        "why_i_am_asking": "Auto Flow changed enough that running it without approval could hide important prompt behavior.",
        "what_this_can_change": ["Whether the host executes the improved prompt in this turn."],
    }


def _autoflow_clarification_payload(
    prompt: str,
    state: dict[str, Any],
    preferences_payload: dict[str, Any],
) -> dict[str, Any] | None:
    if not preferences_payload:
        return None
    autoflow = preferences_payload.get("preferences", {}).get("autoflow", {})
    if normalize_text(autoflow.get("clarifying_questions")) == "never":
        return None
    answers = state.get("answers") if isinstance(state.get("answers"), dict) else {}
    if answers.get("autoflow_clarification") or answers.get("pc:autoflow:clarify"):
        return None
    simplified = re.sub(r"\b(auto flow|autoflow|autopilot|use prompt compass|prompt compass|improve|then|execute|run|this|prompt)\b", " ", prompt.lower())
    tokens = tokenize(simplified)
    if len(tokens) > 3:
        return None
    question = {
        "id": "pc:autoflow:clarify",
        "slot": "autoflow_clarification",
        "question": "What should the AI produce from this?",
        "display_label": "What should it make?",
        "plain_question": "What should the AI produce from this?",
        "example_answers": ["A short reply", "A list of quote options", "A polished email"],
        "assumption_if_skipped": "Auto Flow will make the safest broad assumption and keep the output simple.",
        "answer_type": "short_text",
        "why_i_am_asking": "The input is too short to safely improve and execute without guessing the deliverable.",
        "what_this_can_change": ["The prompt's objective and output format."],
    }
    updated_state = register_pending_questions(state, [question])
    updated_state["workflow_stage"] = "autoflow_clarification"
    updated_state["current_stage"] = "autoflow_clarification"
    updated_state["stage_status"] = "awaiting_user_answers"
    updated_state["delivery_mode"] = "autopilot"
    return {
        "completed": False,
        "workflow_stage": "autoflow_clarification",
        "stage_status": "awaiting_user_answers",
        "question_loop_state": updated_state,
        "questions_for_user": [question],
        "plain_language_summary": "Auto Flow needs one plain answer before it can safely improve and run this.",
        "visible_assumptions": ["The request is too short to infer the desired deliverable safely."],
        "host_action": {
            "must_pause": True,
            "blocking_gate": True,
            "prompt_style": "ask_one_autoflow_clarifier",
            "required_next_step": "Ask this one clarification question, then resume improve_prompt with delivery_mode='autopilot'.",
        },
    }


def _question_budget_for_pace(pace: str) -> dict[str, Any]:
    if pace == "quick_fix":
        return {"max_questions_per_turn": 1, "max_total_questions": 1, "approval_gates": "none"}
    if pace == "deep_dive":
        return {"max_questions_per_turn": 1, "max_total_questions": 9, "approval_gates": "phase_boundaries"}
    return {"max_questions_per_turn": 1, "max_total_questions": 4, "approval_gates": "after_draft"}


def _workflow_plain_summary(payload: dict[str, Any], pace: str) -> str:
    if payload.get("completed") is False and payload.get("questions_for_user"):
        return "I need one answer before I can safely continue."
    if payload.get("rewritten_prompt"):
        return f"Here is the improved prompt using {pace.replace('_', ' ')} pacing."
    if payload.get("scaffolded_prompt"):
        return f"Here is a new prompt draft using {pace.replace('_', ' ')} pacing."
    if normalize_text(payload.get("committee_stage")) == "stage_committee_execution":
        return "Agent Mode is ready for the host to execute the approved committee plan."
    return "Prompt Compass is ready for the next step."


def _workflow_remaining_recovery_action(payload: dict[str, Any]) -> str:
    if payload.get("completed") is False and payload.get("questions_for_user"):
        return "Ask the one visible question, then resume this tool with the returned question_loop_state."
    if payload.get("completed") is True:
        return "Present the result. Offer a deeper review only if the user asks."
    return payload.get("recovery_action") or "Continue with the resume payload if more work is needed."


def _dedupe_strings(values: list[Any]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        text = normalize_text(value)
        if text and text.lower() not in seen:
            seen.add(text.lower())
            result.append(text)
    return result


def _single_quick_build_question(
    repo: PromptCompassRepository,
    analysis: dict[str, Any],
    state: dict[str, Any],
    user_intent: str,
    selected_prompt_library_items: list[dict[str, Any]],
) -> dict[str, Any]:
    question_payload = get_clarifying_questions_payload(
        repo,
        analysis,
        question_loop_state=state,
        limit=1,
        preferred_slots=["objective", "output_contract", "audience"],
        workflow_stage="quick_build_clarify_once",
        stage_goal="Ask one high-value clarification only because the request is too thin for a useful quick scaffold.",
        stage_exit_criteria=["The one blocking ambiguity is answered or intentionally skipped into assumptions."],
        prompt_style="ask_only_this_question",
    )
    question_payload["resume_payload_template"] = {
        "tool": "build_prompt",
        "payload": {
            "user_intent": user_intent,
            "mode": "quick",
            "question_loop_state": question_payload["question_loop_state"],
            "selected_prompt_library_ids": [item.get("item_id") for item in selected_prompt_library_items if item.get("item_id")],
        },
    }
    return question_payload


def _workflow_complexity_score(text: str, analysis: dict[str, Any]) -> int:
    score = 0
    lowered = normalize_text(text).lower()
    anti_slugs = {normalize_text(item.get("slug")) for item in analysis.get("anti_patterns", [])}
    missing = set(analysis.get("missing_building_blocks", []) or [])
    token_count = len(normalize_text(text).split())
    if token_count > 90:
        score += 2
    elif token_count > 35:
        score += 1
    if len(missing & {"objective", "audience", "output_contract"}) >= 2:
        score += 2
    if anti_slugs & {"scope-sprawl", "instruction-wall", "role-collapse", "context-hoarding"}:
        score += 2
    if anti_slugs & {"stacked-adjectives", "vague-compression", "source-pack-with-vague-ask"}:
        score += 1
    if " and also " in lowered or lowered.count(",") >= 3:
        score += 2
    return score


def _mode_reason_text(mode: str, *, explicit: bool) -> str:
    if explicit:
        return f"The host explicitly requested `{mode}` mode."
    return f"Continuing in `{mode}` mode from the existing workflow state."


def _append_stage_history(state: dict[str, Any], stage: str) -> list[str]:
    history = [normalize_text(item) for item in ensure_list(state.get("stage_history")) if normalize_text(item)]
    if stage not in history:
        history.append(stage)
    return history


def _reflection_questions(workflow_kind: str) -> list[dict[str, Any]]:
    label = "improved prompt" if workflow_kind == "improve" else "scaffolded prompt"
    return [
        {
            "id": f"pc:{workflow_kind}:reflection-what-helped",
            "slot": "reflection_feedback",
            "question": f"What part of this {label} feels most useful, and what would you want handled differently next time?",
            "answer_type": "free_text",
            "choices": [],
            "why_i_am_asking": "Captures reflection and feedback without blocking delivery of the final prompt.",
            "what_this_can_change": ["Future prompt guidance and personalization choices."],
            "on_skip": {"action": "skip_optional_reflection", "value": "skip"},
        }
    ]


def _build_assumptions(contract: dict[str, Any]) -> list[str]:
    assumptions: list[str] = []
    if not normalize_text(contract.get("role")):
        assumptions.append("Role is inferred from the task rather than explicitly supplied.")
    output_contract = contract.get("output_contract") if isinstance(contract.get("output_contract"), dict) else {}
    if not normalize_text(output_contract.get("success_test")):
        assumptions.append("Success criteria are inferred from the requested format.")
    if not contract.get("context"):
        assumptions.append("Background context remains minimal.")
    return assumptions


def _append_unique(values: list[str], value: str) -> list[str]:
    normalized = normalize_text(value)
    current = [normalize_text(item) for item in values if normalize_text(item)]
    if normalized and normalized.lower() not in {item.lower() for item in current}:
        current.append(normalized)
    return current


def _apply_shared_build_defaults(contract: dict[str, Any], analysis: dict[str, Any], user_intent: str) -> dict[str, Any]:
    updated = dict(contract)
    fingerprint = build_prompt_fingerprint(user_intent, updated)
    constraints = list(ensure_list(updated.get("constraints")))
    context_items = list(ensure_list(updated.get("context")))
    output_contract = dict(updated.get("output_contract", {})) if isinstance(updated.get("output_contract"), dict) else {}

    if fingerprint.get("voice_memo_like") or fingerprint.get("multi_deliverable_risk"):
        primary_deliverable = guess_primary_deliverable(user_intent, updated)
        if primary_deliverable:
            updated["objective"] = primary_deliverable
        context_items = _append_unique(context_items, "Separate must-haves, nice-to-haves, and exclusions before finalizing the prompt.")
        constraints = _append_unique(constraints, "Preserve the real goal and useful context, but remove side quests and filler.")
    if fingerprint.get("trait_stack_heavy"):
        constraints = _append_unique(constraints, "Rank the top three quality priorities and let lower-priority traits yield in tradeoffs.")
    if fingerprint.get("role_heavy") and normalize_text(updated.get("role")):
        updated["role"] = compress_role_line(updated.get("role"))
    updated, _role_assessment = apply_role_domain_calibration(updated, user_intent, analysis)
    constraints = list(ensure_list(updated.get("constraints")))
    context_items = list(ensure_list(updated.get("context")))
    output_contract = dict(updated.get("output_contract", {})) if isinstance(updated.get("output_contract"), dict) else {}
    if fingerprint.get("source_pack_heavy"):
        context_items = _append_unique(context_items, "Use the source material only for the named extraction targets.")
    if fingerprint.get("terminology_sensitive"):
        constraints = _append_unique(constraints, "Use the user's named terms consistently and avoid silent synonym drift.")
    if fingerprint.get("continuation_risk"):
        constraints = _append_unique(
            constraints,
            "If the response cannot fit in one message, stop at a clean section boundary and continue from the next section without repeating completed material.",
        )
    if fingerprint.get("negative_avoidance_risk"):
        constraints = _append_unique(constraints, "Name the desired target behavior, not only what to avoid.")
    if not normalize_text(output_contract.get("format")):
        output_contract["format"] = _default_build_output_format(analysis)
    if not normalize_text(output_contract.get("success_test")):
        output_contract["success_test"] = _default_build_success_test(output_contract.get("format"))

    updated["constraints"] = constraints
    updated["context"] = context_items
    updated["output_contract"] = output_contract
    return updated


def _selected_prompt_library_items(repo: PromptCompassRepository, item_ids: list[str] | None) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw_value in item_ids or []:
        resolved = repo.get_prompt_library_item(raw_value)
        if not resolved.get("found"):
            continue
        canonical = resolved.get("item_id")
        if canonical in seen:
            continue
        seen.add(canonical)
        items.append(resolved)
    return items


def _apply_prompt_library_items(contract: dict[str, Any], items: list[dict[str, Any]]) -> dict[str, Any]:
    if not items:
        return contract
    updated = dict(contract)
    examples = ensure_list(updated.get("examples"))
    context = ensure_list(updated.get("context"))
    for item in items:
        title = normalize_text(item.get("title")) or normalize_text(item.get("id"))
        prompt_text = normalize_text(item.get("prompt_text"))
        if not prompt_text:
            continue
        prefix = {
            "example": "Example reference",
            "template": "Template reference",
            "prompt": "Saved prompt reference",
        }.get(normalize_text(item.get("asset_kind")), "Reference")
        examples.append(f"{prefix}: {title} — {prompt_text}")
        if normalize_text(item.get("success_notes")):
            context.append(f"Saved prompt success note ({title}): {normalize_text(item.get('success_notes'))}")
    updated["examples"] = examples
    updated["context"] = context
    return updated


def _compact_prompt_library_item(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "item_id": item.get("item_id"),
        "id": item.get("id"),
        "title": item.get("title"),
        "asset_kind": item.get("asset_kind"),
        "markdown_path": item.get("markdown_path"),
    }


def _default_build_output_format(analysis: dict[str, Any]) -> str:
    output_mode = normalize_text(analysis.get("output_mode"))
    if output_mode == "schema_bound":
        return "JSON object matching the required schema"
    if output_mode == "structured":
        return "structured response with clear sections"
    return "structured prompt with clear sections"


def _default_build_success_test(output_format: Any) -> str:
    format_text = normalize_text(output_format) or "the requested prompt"
    return f"Usable on the first pass with no extra clarification beyond {format_text}."
