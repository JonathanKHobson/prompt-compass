# Prompt Compass Anti-Pattern Records

## Ghost Audience

```yaml
id: ghost-audience
title: Ghost Audience
record_type: anti_pattern
source_tier: manual_core
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 2
  target: 1
  search: 3
search_weight: 24
curation_status: core
curation_note: One of the most common prompt failures is persuasive or tone-heavy instruction with no named reader.
summary: The prompt asks for persuasive or audience-tuned output without naming who the output is for.
description: Ghost Audience appears when a prompt asks for clear, compelling, persuasive, or resonant writing without identifying the audience the output should serve. The model is then forced to imagine a reader, which often produces generic tone or the wrong framing entirely.
aliases:
  - missing audience
  - unnamed audience
related_entry_ids:
  - costar
  - output-contract-first
  - intended-reader
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - audience
  - diagnostics
  - anti-pattern
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - marketing
model_targets:
  - generic
signals:
  - persuasive wording
  - tone request
  - audience missing
contraindications:
  - internal notes or private working drafts where no audience exists
what_it_looks_like: "Make this persuasive, clear, and compelling for the right people."
fix: Name the intended reader or user directly, then let the prompt tune tone and framing around that audience instead of guessing.
detection_signal: Persuasion, tone, or resonance language is present while no audience or reader is specified.
severity_default: medium
```

## Hallucination Bait

```yaml
id: hallucination-bait
title: Hallucination Bait
record_type: anti_pattern
source_tier: manual_core
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 2
  target: 1
  search: 3
search_weight: 23
curation_status: core
curation_note: Prompt Compass needs a clear diagnostic for prompts that pressure certainty without grounding.
summary: The prompt pushes the model toward confident completion while withholding the context or evidence needed to answer safely.
description: Hallucination Bait appears when a prompt asks for a definitive, complete, or high-confidence answer while leaving key facts, sources, or context unstated. This combination encourages the model to fill in gaps with plausible but invented detail.
aliases:
  - forced certainty
  - unsupported certainty
related_entry_ids:
  - context-injection-via-source-pack
  - clear
  - calibrated-confidence-prompting
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - grounding
  - certainty
  - diagnostics
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - research
  - coding
  - strategy
  - general
model_targets:
  - generic
signals:
  - requests certainty
  - missing evidence
  - context thin
contraindications:
  - creative generation where invention is explicitly desired
what_it_looks_like: "Give me a definitive answer and fill in whatever details are missing."
fix: Add grounding context, source material, or explicit assumption-labeling rules so the model does not need to invent unsupported facts.
detection_signal: The prompt demands certainty, completeness, or decisiveness while key background or evidence is absent.
severity_default: high
```

## Ineffective Negative Constraint

```yaml
id: ineffective-negative-constraint
title: Ineffective Negative Constraint
record_type: anti_pattern
source_tier: house_curated
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 5
  build: 3
  target: 2
  search: 4
search_weight: 22
curation_status: core
curation_note: Added from Phase 2H/2J user testing because phrases like "do not hallucinate" read as safety instructions but do not define enforceable grounding behavior.
summary: The prompt tells the model what not to do without naming the positive behavior that should replace it.
description: Ineffective Negative Constraint appears when a prompt says "do not hallucinate" or similar negative-only safety language without specifying source priority, evidence rules, uncertainty handling, or what the model should do when information is missing.
aliases:
  - do not hallucinate
  - negative-only safety constraint
  - unenforceable negative constraint
related_entry_ids:
  - negative-avoidance-prompting
  - retrieval-grounding
  - quote-first-evidence-extraction
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - grounding
  - safety
  - constraints
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - research
  - coding
model_targets:
  - generic
signals:
  - do not hallucinate
  - do not be wrong
  - never make mistakes
contraindications:
  - prompts that already define evidence handling, source priority, and uncertainty behavior
what_it_looks_like: "Do not hallucinate."
fix: Replace the negative reminder with a positive grounding rule, such as "If the source material does not contain the answer, say what is missing and do not synthesize beyond the evidence."
detection_signal: The prompt contains negative-only safety language without an operational grounding rule.
severity_default: medium
```

## Vague Style Directive

```yaml
id: vague-style-directive
title: Vague Style Directive
record_type: anti_pattern
source_tier: house_curated
corpus_zone: anti_pattern
tool_fit:
  analyze: 4
  improve: 4
  build: 3
  target: 1
  search: 4
search_weight: 19
curation_status: core
curation_note: Added from Phase 2H/2J user testing because "be creative" was missed as an unmeasurable instruction.
summary: The prompt asks for a style quality without defining what that quality means for the task.
description: Vague Style Directive appears when a prompt says "be creative," "make it compelling," or similar language without examples, ranked traits, anti-traits, or an observable success test.
aliases:
  - be creative
  - undefined style target
  - vague tone instruction
related_entry_ids:
  - trait-stack-output-control
  - output-contract-first
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - style
  - tone
  - diagnostics
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - marketing
model_targets:
  - generic
signals:
  - be creative
  - make it creative
  - vague style word
contraindications:
  - prompts that define the desired style with examples or ranked quality traits
what_it_looks_like: "Be creative."
fix: Define the style target with examples, ranked traits, anti-traits, or a task-specific success test.
detection_signal: A style adjective is present but the prompt does not define how that style should show up in the output.
severity_default: low
```

## Dual-Model Targeting Conflict

```yaml
id: dual-model-targeting-conflict
title: Dual-Model Targeting Conflict
record_type: anti_pattern
source_tier: house_curated
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 2
  target: 5
  search: 4
search_weight: 21
curation_status: core
curation_note: Added from Phase 2H/2J user testing because prompts targeting Claude and GPT-style models equally can produce contradictory optimization rules.
summary: The prompt tries to target multiple model families as if one instruction style will be optimal for all of them.
description: Dual-Model Targeting Conflict appears when a prompt asks to target two or more model families equally, such as GPT and Claude, without choosing a primary model or defining provider-specific variants.
aliases:
  - multi-model prompt conflict
  - incompatible model targeting
  - target both GPT and Claude
related_entry_ids:
  - target-prompt-to-model
  - model-family-targeting
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - model-targeting
  - portability
  - diagnostics
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - research
model_targets:
  - generic
signals:
  - target both GPT and Claude
  - multiple named model families
  - equally optimized for multiple models
contraindications:
  - prompts that explicitly request separate variants per model family
what_it_looks_like: "Target both GPT-4o and Claude Opus equally."
fix: Choose one primary model target, or generate separate prompt variants for each model family.
detection_signal: Multiple model families are named as simultaneous targets without a variant strategy.
severity_default: medium
```

## Unresolved Output Branch Conflict

```yaml
id: unresolved-output-branch-conflict
title: Unresolved Output Branch Conflict
record_type: anti_pattern
source_tier: house_curated
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 5
  build: 3
  target: 2
  search: 4
search_weight: 22
curation_status: core
curation_note: Added from Phase 2H/2J user testing because mutually exclusive output shapes can pass structural preflight while still breaking runtime behavior.
summary: The prompt names competing output formats without clear routing logic.
description: Unresolved Output Branch Conflict appears when a prompt asks for mutually exclusive outputs, such as code-only and JSON plus prose, without a clear if/else rule for when each output shape should be used.
aliases:
  - mutually exclusive output formats
  - output branch conflict
  - format conflict
related_entry_ids:
  - schema-first-output-contract
  - json-schema-outputs
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - output-contract
  - parser
  - diagnostics
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - research
model_targets:
  - generic
signals:
  - code-only plus prose
  - JSON plus conflicting format
  - no routing logic
contraindications:
  - prompts with explicit conditional routing for each output branch
what_it_looks_like: "If the user asks for code return code-only, also return JSON plus prose."
fix: Add routing logic that names exactly when each output branch applies, or choose one output contract.
detection_signal: Multiple incompatible output formats appear without a clear conditional rule.
severity_default: high
```

## Missing Source Precedence

```yaml
id: missing-source-precedence
title: Missing Source Precedence
record_type: anti_pattern
source_tier: house_curated
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 5
  build: 3
  target: 2
  search: 4
search_weight: 22
curation_status: core
curation_note: Added from Phase 2H/2J user testing because retrieval plus tool fallback needs an explicit conflict rule.
summary: The prompt combines retrieval and tool fallback without saying which source wins when they conflict.
description: Missing Source Precedence appears when a prompt uses retrieved context, source documents, tools, or external search together without a source-priority rule.
aliases:
  - weak source priority
  - retrieval tool precedence gap
  - no source priority
related_entry_ids:
  - retrieval-grounding
  - source-priority
  - quote-first-evidence-extraction
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - retrieval
  - tool-use
  - grounding
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - research
  - coding
  - general
model_targets:
  - generic
signals:
  - retrieved context
  - external search fallback
  - no precedence rule
contraindications:
  - prompts that clearly state retrieved context wins or tools are fallback-only
what_it_looks_like: "Use retrieved docs and external_search to answer."
fix: Add a source-priority rule, such as "Retrieved context is authoritative; use tools only when retrieved context is missing or stale, and label tool-derived facts."
detection_signal: Retrieval and tool or external-search language co-occur without a precedence rule.
severity_default: high
```

## Negative Avoidance Prompting

```yaml
id: negative-avoidance-prompting
title: Negative Avoidance Prompting
record_type: anti_pattern
source_tier: house_curated
corpus_zone: anti_pattern
tool_fit:
  analyze: 4
  improve: 4
  build: 2
  target: 1
  search: 5
search_weight: 21
curation_status: supporting
curation_note: Added from Prompt Master guidance for prompts that only tell the model what not to do without defining the desired replacement behavior.
summary: The prompt relies on prohibitions without naming the positive target behavior.
description: Negative Avoidance Prompting appears when a prompt says what the AI should not do but never defines what it should do instead. This often causes drift because the model has a list of forbidden moves but no positive target, output contract, or success test. Prompt Compass treats it as support knowledge for rewrite diagnosis and style repair.
aliases:
  - negative prompting without target
  - do not only prompting
  - avoidance-only prompting
related_entry_ids:
  - output-contract-first
  - must-haves-nice-to-haves-exclusions
  - missing-success-test
source_refs:
  - project://support/library/curated/anti_patterns.md
  - /mnt/skills/user/prompt-master/
template: ""
tags:
  - avoidance
  - constraints
  - prompt-master
  - support-anti-pattern
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - strategy
model_targets:
  - generic
signals:
  - prompt says do not do this but never defines the desired alternative
  - prohibitions dominate the instructions
  - output success is framed only by what to avoid
contraindications:
  - prompts that pair exclusions with clear positive criteria and examples
what_it_looks_like: "Do not be generic, do not be vague, do not sound like AI." without saying what specific style, format, or success test should replace those failures.
fix: Convert each negative rule into a positive target behavior, then keep only the exclusions that still matter.
detection_signal: Multiple avoidance rules appear without a matching positive output contract, trait priority, or example.
severity_default: medium
```

## Context Hoarding

```yaml
id: context-hoarding
title: Context Hoarding
record_type: anti_pattern
source_tier: house_curated
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 3
  target: 1
  search: 4
search_weight: 21
curation_status: core
curation_note: Included because long-context failures often come from dumping everything into the prompt instead of selecting the smallest sufficient context.
summary: The prompt includes far more context than the live task needs, with no visible prioritization or trimming.
description: Context Hoarding appears when a user pastes every document, transcript, note, or prior decision into the prompt without ranking what matters for the current step. The model may technically see all of it, but the useful signal gets diluted and important requirements become harder to recover.
aliases:
  - context dump
  - overpacked context
related_entry_ids:
  - must-haves-nice-to-haves-exclusions
  - long-context-layout
  - compaction
source_refs:
  - project://support/library/curated/anti_patterns.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - context
  - long-context
  - diagnostics
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - research
  - coding
  - analysis
model_targets:
  - generic
signals:
  - large source dump
  - weak source priority
  - stale or low-value context mixed with live task
contraindications:
  - tasks where the entire source set is genuinely required and already structured clearly
what_it_looks_like: "Here are the transcript, all my notes, the roadmap, old drafts, five docs, and our whole Slack thread. Use everything."
fix: Trim the prompt to the smallest sufficient context, rank the sources, and add a compact carry-forward note for what still matters now.
detection_signal: The prompt contains heavy source or history context without visible source priority, exclusions, or compaction.
severity_default: medium
```

## Middle-Buried Requirement

```yaml
id: middle-buried-requirement
title: Middle-Buried Requirement
record_type: anti_pattern
source_tier: house_curated
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 3
  target: 1
  search: 4
search_weight: 19
curation_status: core
curation_note: Included because long prompts often hide the real constraint in the middle of a source pack where it loses salience.
summary: A critical requirement is hidden inside the middle of a long prompt or source block instead of being surfaced in a priority section.
description: Middle-Buried Requirement appears when an important instruction, exclusion, or decision rule is embedded deep inside a long prompt or source pack. The requirement may exist, but it is easy for both humans and models to miss because the prompt never promotes it into the visible task contract.
aliases:
  - buried requirement
  - lost in the middle requirement
related_entry_ids:
  - instruction-wall
  - long-context-salience-management
  - context-engineering
source_refs:
  - project://support/library/curated/anti_patterns.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - salience
  - long-context
  - diagnostics
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - research
  - coding
  - analysis
model_targets:
  - generic
signals:
  - long prompt
  - critical rule appears late
  - constraint not surfaced near the task
contraindications:
  - short prompts where the entire instruction set is already easy to scan
what_it_looks_like: A 900-word prompt where the only "do not use outside evidence" rule appears halfway through the attached documents.
fix: Move the live task, hard constraints, and success test into a visible priority block near the top or just before the final ask.
detection_signal: A long prompt with source-heavy context places a hard requirement or exclusion late instead of surfacing it in the main task contract.
severity_default: medium
```

## Schema Theater

```yaml
id: schema-theater
title: Schema Theater
record_type: anti_pattern
source_tier: house_curated
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 3
  target: 2
  search: 4
search_weight: 21
curation_status: core
curation_note: Included because many modern prompt failures say return JSON without defining a real parser contract.
summary: The prompt gestures at machine-readable structure without specifying a real schema, field contract, or failure behavior.
description: Schema Theater appears when a prompt says return JSON, use a table, or match a schema, but never actually defines the fields, allowed values, missing-data behavior, or what should happen if the model cannot satisfy the contract cleanly. The result often looks structured while still being brittle or unusable downstream.
aliases:
  - fake schema
  - return json theater
related_entry_ids:
  - schema-first-output-contract
  - json-schema-outputs
  - parser-aware-prompting
source_refs:
  - project://support/library/curated/anti_patterns.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - schema
  - structured-output
  - diagnostics
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - coding
  - operations
  - analysis
  - research
model_targets:
  - generic
signals:
  - vague json request
  - parser contract missing
  - output shape named without schema detail
contraindications:
  - tasks where approximate human-readable structure is sufficient
what_it_looks_like: "Return valid JSON." with no fields, schema, null policy, or error behavior.
fix: Add a schema-first output contract with required fields, allowed values, empty-value behavior, and a success test for valid output.
detection_signal: The prompt names machine-readable output but does not specify the schema or contract details needed to validate it.
severity_default: high
```

## Tool Thrash

```yaml
id: tool-thrash
title: Tool Thrash
record_type: anti_pattern
source_tier: house_curated
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 3
  target: 2
  search: 4
search_weight: 20
curation_status: core
curation_note: Included because tool-capable prompts fail when they encourage repeated low-value tool calls without boundaries or stopping rules.
summary: The prompt encourages repeated tool calls without a clear tool budget, confirmation boundary, or stop condition.
description: Tool Thrash appears when a prompt tells the model to keep calling tools, searching again, or exploring until it feels satisfied, but never explains when tool use is necessary, when it is wasteful, or how to stop. This creates latency, noisy traces, and brittle results even when the right answer was already within reach.
aliases:
  - tool spam
  - tool overuse
related_entry_ids:
  - tool-contract-prompting
  - ask-vs-act-threshold
  - stop-condition-contract
source_refs:
  - project://support/library/curated/anti_patterns.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - tools
  - agent-control
  - diagnostics
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - coding
  - operations
  - research
  - analysis
model_targets:
  - generic
signals:
  - repeated tool directives
  - no stop condition
  - tool use framed as default behavior
contraindications:
  - prompts that already define a tight tool contract and completion boundary
what_it_looks_like: "Use tools until you are fully satisfied, keep searching if anything is missing, and do not stop early."
fix: Add tool preconditions, an ask-vs-act threshold, and a stop-condition contract so tool use stays bounded and intentional.
detection_signal: The prompt repeatedly pushes tool use without a visible completion boundary or confirmation rule.
severity_default: medium
```

## Agentic Overrun

```yaml
id: agentic-overrun
title: Agentic Overrun
record_type: anti_pattern
source_tier: house_curated
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 3
  target: 2
  search: 4
search_weight: 18
curation_status: core
curation_note: Included because agent-like prompts fail when they keep going past the user’s actual success condition.
summary: The prompt encourages the model or agent to continue acting after the useful stopping point.
description: Agentic Overrun appears when a prompt values persistence but never defines what counts as complete. The result is an assistant that keeps planning, browsing, revising, or calling tools long after the user’s real deliverable is already satisfied.
aliases:
  - overrun
  - runaway agent
related_entry_ids:
  - stop-condition-contract
  - ask-vs-act-threshold
  - one-primary-deliverable-narrowing
source_refs:
  - project://support/library/curated/anti_patterns.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - agentic
  - stop-condition
  - diagnostics
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - coding
  - operations
  - research
  - analysis
model_targets:
  - generic
signals:
  - keep going language
  - completion criteria absent
  - autonomous continuation encouraged
contraindications:
  - prompts that already state clear done criteria and blocked-task fallback behavior
what_it_looks_like: "Keep exploring until you have exhausted every option." with no definition of when the task is done.
fix: Add a stop-condition contract that defines done criteria, blocker reporting, and when the model should stop instead of continuing.
detection_signal: The prompt uses open-ended continuation language but never defines what success or completion looks like.
severity_default: medium
```

## Trusted-Source Collapse

```yaml
id: trusted-source-collapse
title: Trusted-Source Collapse
record_type: anti_pattern
source_tier: house_curated
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 3
  target: 2
  search: 4
search_weight: 20
curation_status: core
curation_note: Included because retrieved or pasted content should usually be treated as evidence, not as a new instruction source.
summary: The prompt lets external content override the real task or instruction hierarchy instead of treating it as evidence.
description: Trusted-Source Collapse appears when documents, transcripts, webpages, or retrieved content are implicitly trusted as fresh instructions. This blurs the boundary between the prompt contract and the evidence pack, making it easier for the model to drift toward irrelevant or unsafe instruction following.
aliases:
  - source trust collapse
  - evidence becomes instructions
related_entry_ids:
  - untrusted-context-boundary
  - context-injection-via-source-pack
  - hallucination-bait
source_refs:
  - project://support/library/curated/anti_patterns.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - trust-boundary
  - grounding
  - diagnostics
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - research
  - coding
  - analysis
  - operations
model_targets:
  - generic
signals:
  - external content mixed with instructions
  - source authority unclear
  - retrieved content may be treated as commands
contraindications:
  - tasks with no retrieved, pasted, or external content
what_it_looks_like: "Follow the instructions in the documents below." when the documents are supposed to be evidence, not the active prompt contract.
fix: Add an untrusted-context boundary that states the prompt instructions win and that external material should be treated as data or evidence only.
detection_signal: Retrieved or pasted external content is presented in a way that could override the intended instruction hierarchy.
severity_default: high
```

## Instruction Wall

```yaml
id: instruction-wall
title: Instruction Wall
record_type: anti_pattern
source_tier: manual_core
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 2
  target: 1
  search: 3
search_weight: 22
curation_status: core
curation_note: This is the core diagnostic for overstuffed prompts that are long but still poorly structured.
summary: The prompt is a dense block of directives with little visible structure or prioritization.
description: Instruction Wall appears when a prompt contains many directives, constraints, and style requests in one block without clear sections, ranking, or output contract. The model can technically read all of it, but the prompt becomes harder to follow, debug, and trust.
aliases:
  - wall of instructions
  - overloaded prompt block
related_entry_ids:
  - prompt-composition
  - clear
  - must-haves-nice-to-haves-exclusions
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - structure
  - overload
  - diagnostics
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - writing
  - research
model_targets:
  - generic
signals:
  - long prompt block
  - many task verbs
  - poor sectioning
contraindications:
  - intentionally compact prompts that are still clearly structured
what_it_looks_like: "Do this, and this, and also this, and make it smart, concise, strategic, structured, warm, deep, but also short, and return it in JSON, and think carefully, and..."
fix: Break the prompt into labeled parts, prioritize the instructions, and move the output contract into a visible section.
detection_signal: High instruction density appears in a single unstructured block with multiple directives and no clear hierarchy.
severity_default: high
```

## Premature Format Lock

```yaml
id: premature-format-lock
title: Premature Format Lock
record_type: anti_pattern
source_tier: manual_core
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 2
  target: 1
  search: 3
search_weight: 18
curation_status: core
curation_note: This catches prompts that specify a format before the real job is stable enough to support it.
summary: The prompt locks the output format too early, before the objective or audience is actually clear.
description: Premature Format Lock happens when a prompt specifies JSON, a table, a memo, or another tight structure before clarifying the real task, audience, or success criteria. The format may be valid later, but anchoring to it too early can distort what the prompt actually needs to accomplish.
aliases:
  - format too early
  - early format lock
related_entry_ids:
  - output-contract-first
  - rtf
  - missing-success-test
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - format
  - diagnostics
  - premature-constraint
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - research
model_targets:
  - generic
signals:
  - explicit format
  - unclear objective
  - unclear audience
contraindications:
  - prompts where the format is genuinely the primary job
what_it_looks_like: "Return this as JSON with these fields..." before the prompt clearly states what problem the JSON is solving.
fix: Clarify the job, audience, and success test first, then decide whether a rigid format still makes sense.
detection_signal: A strong output format is specified while the core task or audience remains underspecified.
severity_default: medium
```

## Role Collapse

```yaml
id: role-collapse
title: Role Collapse
record_type: anti_pattern
source_tier: manual_core
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 2
  target: 1
  search: 3
search_weight: 19
curation_status: core
curation_note: Prompt Compass needs a distinct anti-pattern for competing persona stacks because they regularly crowd out the deliverable.
summary: The prompt stacks multiple roles or personas that compete with one another.
description: Role Collapse appears when a prompt asks the model to be several people at once or mixes too many expertise frames in a way that blurs the job. Instead of helping, the stacked personas create ambiguity about what kind of judgment the model should use.
aliases:
  - role stack
  - competing personas
related_entry_ids:
  - short-functional-role-framing
  - role-framing-as-shortcut
  - rtf
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - role
  - diagnostics
  - persona
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - strategy
  - coding
model_targets:
  - generic
signals:
  - multiple role cues
  - persona stack
  - expertise ambiguity
contraindications:
  - deliberate debate or comparison prompts where multiple viewpoints are the explicit design
what_it_looks_like: "Act as a therapist, startup founder, conversion copywriter, product strategist, and philosopher all at once."
fix: Choose one short functional role that best matches the real task, then let the deliverable and constraints do the rest of the steering.
detection_signal: Two or more conflicting role or persona frames are present in the same prompt.
severity_default: medium
```

## Scope Sprawl

```yaml
id: scope-sprawl
title: Scope Sprawl
record_type: anti_pattern
source_tier: manual_core
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 5
  build: 3
  target: 1
  search: 3
search_weight: 26
curation_status: core
curation_note: Scope Sprawl is a flagship Prompt Compass diagnostic because the product exists partly to turn sprawling asks into one usable prompt.
summary: The prompt tries to cover too many jobs, outputs, or decisions in one pass.
description: Scope Sprawl appears when a prompt asks for several deliverables, several decision frames, or several stages of work at once without a clear primary lane. The result is often a diluted answer, an overlong prompt, or a response that does many things poorly instead of one thing well.
aliases:
  - too many jobs
  - sprawling ask
related_entry_ids:
  - one-primary-deliverable-narrowing
  - risen
  - belongs-in-follow-up
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - scope
  - diagnostics
  - prioritization
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - strategy
  - writing
  - coding
model_targets:
  - generic
signals:
  - multiple deliverables
  - many task verbs
  - mixed planning and execution asks
contraindications:
  - intentionally multi-stage prompts that clearly sequence the work and still end in one primary artifact
what_it_looks_like: "Help me think through my course, my audience, my pricing, my brand, and write the launch page and email sequence too."
fix: Force one primary deliverable now, move the rest into exclusions or follow-up prompts, and rewrite around that single lane.
detection_signal: The prompt contains multiple distinct jobs or outputs without a declared primary deliverable.
severity_default: high
```

## Stacked Adjectives

```yaml
id: stacked-adjectives
title: Stacked Adjectives
record_type: anti_pattern
source_tier: manual_core
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 2
  target: 1
  search: 3
search_weight: 21
curation_status: core
curation_note: Prompt Compass needs a direct diagnosis for trait stacks without priority because this is one of the most common style failures.
summary: The prompt piles on quality words without ranking or tradeoff logic.
description: Stacked Adjectives happens when a prompt asks for clear, concise, compelling, strategic, warm, deep, and nuanced output all at once with no indication of what matters most. The model then has to guess how to trade off those qualities.
aliases:
  - adjective pile
  - unranked trait stack
related_entry_ids:
  - top-three-traits-ranking
  - trait-stack-output-control
  - output-contract-first
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - style
  - diagnostics
  - priorities
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - marketing
model_targets:
  - generic
signals:
  - many adjectives
  - no ranking
  - style overload
contraindications:
  - prompts with already-ranked style traits
what_it_looks_like: "Make it clear, concise, strategic, emotionally attuned, bold, deep, compelling, and highly polished."
fix: Cut the stack to the top three qualities in priority order and connect them to the actual deliverable.
detection_signal: Four or more style or quality adjectives appear without explicit priority or tradeoff guidance.
severity_default: medium
```

## Vague Compression

```yaml
id: vague-compression
title: Vague Compression
record_type: anti_pattern
source_tier: manual_core
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 4
  build: 2
  target: 1
  search: 3
search_weight: 20
curation_status: core
curation_note: This anti-pattern catches the common rewrite request that asks for “better” without defining what “better” means.
summary: The prompt asks to tighten, improve, or make something better without stating the target outcome.
description: Vague Compression appears when the user asks for a better, tighter, sharper, or clearer version of something but does not say what the improved version should do differently or what artifact it should become. The model then compresses in a direction that may not match the actual need.
aliases:
  - make it better
  - unclear rewrite target
related_entry_ids:
  - prompt-refinement-first
  - output-contract-first
  - missing-success-test
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - rewrite
  - diagnostics
  - ambiguity
phase: 1
prompt_types:
  - transformative
subject_areas:
  - general
  - writing
  - strategy
model_targets:
  - generic
signals:
  - better/tighter/improve language
  - no target artifact
  - unclear rewrite goal
contraindications:
  - prompts where the output contract is already explicit and only wording cleanup is requested
what_it_looks_like: "Make this better." or "Tighten this up." with no definition of what the result should become.
fix: State the target artifact, format, and success test before asking for compression or refinement.
detection_signal: Improvement language is present while the prompt lacks a visible output contract or concrete rewrite goal.
severity_default: medium
```

## Source Pack with Vague Ask

```yaml
id: source-pack-with-vague-ask
title: Source Pack with Vague Ask
record_type: anti_pattern
source_tier: manual_core
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 5
  build: 3
  target: 1
  search: 3
search_weight: 22
curation_status: core
curation_note: This is the specific grounding anti-pattern for prompts that attach sources but never clarify the real job those sources should support.
summary: The prompt includes source material, but the actual task remains vague or under-specified.
description: Source Pack with Vague Ask appears when a prompt provides documents, notes, transcripts, or research links but does not clearly say what the model should do with them. The model may summarize aimlessly, over-index on surface patterns, or choose the wrong analytic lens.
aliases:
  - vague ask with sources
  - unclear source pack prompt
related_entry_ids:
  - context-injection-via-source-pack
  - must-haves-nice-to-haves-exclusions
  - hallucination-bait
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - grounding
  - source-pack
  - diagnostics
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - research
  - strategy
  - writing
  - coding
model_targets:
  - generic
signals:
  - source material present
  - ask vague
  - objective under-specified
contraindications:
  - clearly grounded prompts with explicit task, audience, and output contract
what_it_looks_like: "Here are my notes and transcripts. Use them to help me with this."
fix: Keep the source pack, but state the exact task, decision frame, and output contract immediately beside it.
detection_signal: Source materials are attached or referenced, but the prompt does not clearly specify what deliverable or decision they should support.
severity_default: high
```

## Missing Success Test

```yaml
id: missing-success-test
title: Missing Success Test
record_type: anti_pattern
source_tier: manual_core
corpus_zone: anti_pattern
tool_fit:
  analyze: 5
  improve: 5
  build: 3
  target: 2
  search: 3
search_weight: 25
curation_status: core
curation_note: Prompt Compass needs a distinct anti-pattern for prompts that name outputs but never say what would make them usable.
summary: The prompt names an output but does not state what would make that output successful or usable.
description: Missing Success Test appears when a prompt specifies the artifact or format but leaves out the standard by which the answer should be judged. Without that test, the model may satisfy the form of the request while missing the practical job the output is meant to do.
aliases:
  - no success criteria
  - missing usability test
related_entry_ids:
  - output-contract-first
  - clear
  - successful-response-look-like
source_refs:
  - project://support/library/curated/anti_patterns.md
template: ""
tags:
  - success-test
  - diagnostics
  - output-contract
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - research
model_targets:
  - generic
signals:
  - output exists
  - no usability criteria
  - quality threshold unstated
contraindications:
  - exploratory prompts where no success threshold is needed yet
what_it_looks_like: "Write a one-page memo." with no mention of what the memo should help the reader decide or do.
fix: Add a short success test that explains what would make the output usable on the first pass.
detection_signal: A deliverable or format is specified, but the prompt lacks any statement of what good or usable output looks like.
severity_default: high
```
