# Prompt Compass Framework Records

## Golden Circle

```yaml
id: golden-circle
title: Golden Circle
record_type: framework
source_tier: manual_core
corpus_zone: framework
tool_fit:
  analyze: 4
  improve: 3
  build: 4
  target: 1
  search: 4
search_weight: 21
curation_status: core
curation_note: Keeps Prompt Compass anchored to purpose-first prompt design when users start with outputs before intent.
summary: Start with why, then decide what the prompt must produce, then specify how the model should work.
description: Golden Circle is a purpose-first prompt framework. It makes the user name the underlying purpose before jumping to deliverables or wording. In Prompt Compass, it is especially useful when a user knows what they want the AI to output but has not clarified why that output matters or how the prompt should be shaped to serve the real objective.
aliases:
  - why-how-what
  - why what how
  - golden circle why how what
related_entry_ids:
  - costar
  - one-primary-deliverable-narrowing
  - prompt-composition
source_refs:
  - project://support/library/curated/frameworks.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/thinking-lenses/design/golden-circle-framework.json
template: |
  Why: [Why this prompt exists and what downstream outcome it should help create]
  What: [The single deliverable or result the AI should produce]
  How: [The approach, constraints, and framing the AI should follow]

  Return the result in this format: [format]
tags:
  - purpose
  - framing
  - intent
  - prompt-design
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - strategy
  - writing
  - marketing
model_targets:
  - generic
signals:
  - user knows the output but not the purpose
  - prompt starts with format before intent
  - need to clarify why this prompt exists
contraindications:
  - direct extraction tasks with already-clear intent
  - prompts that already state a crisp objective and success test
framework_components:
  - Why
  - What
  - How
when_to_use:
  - The prompt is artifact-first and purpose-blind
  - The user is unclear about the real job behind the request
  - A strategy or messaging prompt needs stronger intent alignment
required_slots:
  - objective
  - output_contract
output_shapes:
  - brief
  - memo
  - plan
  - outline
```

## RACCCA

```yaml
id: raccca
title: RACCCA
record_type: framework
source_tier: manual_core
corpus_zone: framework
tool_fit:
  analyze: 5
  improve: 4
  build: 2
  target: 1
  search: 4
search_weight: 27
curation_status: core
curation_note: RACCCA is the primary diagnostic rubric for Prompt Compass and anchors the scoring layer.
summary: Diagnose prompts by rating relevance, accuracy, completeness, clarity, coherence, and appropriateness.
description: RACCCA is the core prompt-diagnosis framework in Prompt Compass. It evaluates whether a prompt is aimed at the right job, grounded in sane assumptions, complete enough to reduce guessing, clear in its ask, coherent in its internal structure, and appropriate to the audience and model context. It is the main audit framework behind prompt diagnosis and repair.
aliases:
  - relevance accuracy completeness clarity coherence appropriateness
  - raccca rubric
related_entry_ids:
  - missing-success-test
  - ghost-audience
  - output-contract-first
source_refs:
  - project://support/library/curated/frameworks.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/methodology-checks/audit/raccca-framework.json
template: |
  Evaluate the prompt below using RACCCA.

  Prompt:
  [prompt]

  Score each dimension from 1-5:
  - Relevance
  - Accuracy
  - Completeness
  - Clarity
  - Coherence
  - Appropriateness

  Then return:
  1. the lowest-scoring dimensions
  2. what is missing or broken
  3. the highest-leverage repair move
tags:
  - rubric
  - diagnostics
  - scoring
  - evaluation
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - research
  - strategy
model_targets:
  - generic
signals:
  - user wants diagnosis
  - prompt quality feels uneven
  - need a structured scoring pass
contraindications:
  - rapid one-line prompt cleanup where full scoring would be overkill
framework_components:
  - Relevance
  - Accuracy
  - Completeness
  - Clarity
  - Coherence
  - Appropriateness
when_to_use:
  - A user asks why a prompt is weak
  - Multiple failure modes may be present
  - You need a consistent diagnostic rubric before rewriting
required_slots:
  - objective
  - audience
  - context
  - output_contract
output_shapes:
  - scorecard
  - audit
  - rewrite-brief
```

## RISEN

```yaml
id: risen
title: RISEN
record_type: framework
source_tier: manual_core
corpus_zone: framework
tool_fit:
  analyze: 3
  improve: 4
  build: 5
  target: 2
  search: 4
search_weight: 24
curation_status: core
curation_note: RISEN is the main scope-control scaffold for turning messy user intent into a single focused prompt.
summary: Structure a prompt around role, instructions, steps, end goal, and narrowing so the job stays visible and bounded.
description: RISEN is a practical prompt-building framework for messy briefs and scope-heavy drafts. It helps the user name a functional role, define the core instructions, order the work into steps, specify the end goal, and explicitly narrow what not to do yet. In Prompt Compass, RISEN is one of the strongest frameworks for scope control and prompt scaffolding from scratch.
aliases:
  - risen framework
  - role instructions steps end goal narrowing
related_entry_ids:
  - one-primary-deliverable-narrowing
  - scope-sprawl
  - short-functional-role-framing
source_refs:
  - project://support/library/curated/frameworks.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/other/adjacent/risen-framework.json
template: |
  Role: [short functional role]
  Instructions: [the core job to do]
  Steps:
  1. [step one]
  2. [step two]
  3. [step three]
  End Goal: [single final deliverable]
  Narrowing: [what to ignore, defer, or avoid]
tags:
  - scaffolding
  - narrowing
  - sequencing
  - build
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - strategy
  - writing
  - coding
model_targets:
  - generic
  - claude-sonnet
  - claude-opus
  - gpt-4o
  - gpt-4-turbo
signals:
  - scope sprawl
  - user brief tries to do too much
  - need one deliverable and a visible sequence
contraindications:
  - tiny extraction prompts
  - already well-bounded prompts that only need a format fix
framework_components:
  - Role
  - Instructions
  - Steps
  - End Goal
  - Narrowing
when_to_use:
  - Starting from a messy user intent
  - Repairing multi-deliverable prompts
  - Sequencing work instead of letting the prompt sprawl
required_slots:
  - objective
  - output_contract
output_shapes:
  - brief
  - plan
  - recommendation
  - memo
```

## COSTAR

```yaml
id: costar
title: COSTAR
record_type: framework
source_tier: manual_core
corpus_zone: framework
tool_fit:
  analyze: 4
  improve: 5
  build: 5
  target: 2
  search: 4
search_weight: 26
curation_status: core
curation_note: COSTAR is the most complete all-purpose prompt scaffold in Phase 1 and is especially strong for rewrite and build flows.
summary: Make prompts explicit about context, objective, style, tone, audience, and response format.
description: COSTAR is a comprehensive prompt-construction framework that helps users specify the situational context, the real objective, the desired style and tone, the target audience, and the exact response shape. In Prompt Compass it functions as a high-coverage scaffold for users who need a prompt to become complete, readable, and usable on the first pass.
aliases:
  - costar framework
  - context objective style tone audience response
related_entry_ids:
  - output-contract-first
  - ghost-audience
  - prompt-composition
source_refs:
  - project://support/library/curated/frameworks.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/thinking-lenses/design/costar-framework.json
template: |
  Context: [what the model needs to know]
  Objective: [the single job to do]
  Style: [the top 1-3 qualities that matter most]
  Tone: [voice or register]
  Audience: [who the output is for]
  Response: [format, length, and success test]
tags:
  - complete-scaffold
  - prompt-structure
  - audience
  - output-contract
phase: 1
prompt_types:
  - transformative
  - generative
  - reductive
subject_areas:
  - general
  - writing
  - coding
  - research
  - marketing
model_targets:
  - generic
  - claude-sonnet
  - claude-opus
  - gpt-4o
  - gpt-4-turbo
signals:
  - missing audience
  - incomplete prompt contract
  - user wants a strong scaffold from scratch
contraindications:
  - minimal prompts where only a role/task/format cleanup is needed
framework_components:
  - Context
  - Objective
  - Style
  - Tone
  - Audience
  - Response
when_to_use:
  - A draft lacks multiple prompt building blocks
  - The user needs a general-purpose prompt scaffold
  - Audience and response format both need to be made explicit
required_slots:
  - objective
  - audience
  - output_contract
output_shapes:
  - memo
  - plan
  - email
  - table
  - brief
```

## RTF

```yaml
id: rtf
title: RTF
record_type: framework
source_tier: manual_core
corpus_zone: framework
tool_fit:
  analyze: 3
  improve: 4
  build: 4
  target: 1
  search: 4
search_weight: 19
curation_status: core
curation_note: RTF is the fastest lightweight cleanup scaffold when a prompt mostly works but lacks explicit framing.
summary: Use role, task, and format to repair a prompt quickly without overcomplicating it.
description: RTF is a minimal prompt-repair framework for cases where the user already has a reasonable ask but the prompt is under-specified. It forces a short functional role, a clear task statement, and a visible output format. Prompt Compass uses it for compact cleanup and fast rewrite passes.
aliases:
  - role task format
  - role-task-format
  - rtf framework
related_entry_ids:
  - short-functional-role-framing
  - output-contract-first
  - risen
source_refs:
  - project://support/library/curated/frameworks.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/other/adjacent/rtf-framework.json
template: |
  Role: [short functional role]
  Task: [exact job to do]
  Format: [required output shape, length, or structure]
tags:
  - minimal
  - cleanup
  - structure
  - quick-fix
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - operations
model_targets:
  - generic
  - gpt-4o
  - gpt-4-turbo
signals:
  - draft is mostly usable
  - role missing
  - format missing
contraindications:
  - prompts that need deep context repair or scope reduction
framework_components:
  - Role
  - Task
  - Format
when_to_use:
  - The draft needs a quick structure pass
  - The user wants a compact rewrite instead of a full scaffold
required_slots:
  - objective
  - output_contract
output_shapes:
  - list
  - table
  - brief
  - json
```

## CLEAR

```yaml
id: clear
title: CLEAR
record_type: framework
source_tier: manual_core
corpus_zone: framework
tool_fit:
  analyze: 4
  improve: 4
  build: 4
  target: 1
  search: 4
search_weight: 20
curation_status: core
curation_note: CLEAR is the Phase 1 framework for prompts that need explicit limits and execution expectations, not just more context.
summary: Structure prompts around context, limitations, expectations, approach, and response format.
description: CLEAR is a prompt-building framework for cases where prompts fail because boundaries and execution expectations are implicit. It makes the user specify what context matters, what limitations the AI must respect, what good performance looks like, what approach to follow, and what final response format is required. Prompt Compass uses it when constraint quality matters as much as the task itself.
aliases:
  - clear prompting
  - context limitations expectations approach response format
  - clear framework
related_entry_ids:
  - missing-success-test
  - instruction-wall
  - output-contract-first
source_refs:
  - project://support/library/curated/frameworks.md
template: |
  Context: [the essential background or source material]
  Limitations: [what the model must not assume, invent, or exceed]
  Expectations: [what a good answer must accomplish]
  Approach: [how the model should work through the task]
  Response Format: [the exact output shape, length, and structure]
tags:
  - constraints
  - expectations
  - response-format
  - control
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - research
  - writing
model_targets:
  - generic
  - claude-sonnet
  - gpt-4o
  - gpt-4-turbo
signals:
  - constraints are missing or weak
  - success test is unclear
  - prompt needs stronger execution boundaries
contraindications:
  - very short prompts where a minimal RTF cleanup is enough
framework_components:
  - Context
  - Limitations
  - Expectations
  - Approach
  - Response Format
when_to_use:
  - The draft needs clearer boundaries and quality expectations
  - Missing success criteria are causing weak answers
  - The user wants a stricter execution scaffold
required_slots:
  - objective
  - context
  - constraints
  - output_contract
output_shapes:
  - specification
  - checklist
  - memo
  - structured-answer
```

## Chain-of-Thought / Deliberative Prompting

```yaml
id: chain-of-thought-deliberative-prompting
title: Chain-of-Thought / Deliberative Prompting
record_type: framework
source_tier: manual_core
corpus_zone: framework
tool_fit:
  analyze: 3
  improve: 3
  build: 3
  target: 1
  search: 4
search_weight: 17
curation_status: core
curation_note: This is the main Phase 1 reasoning scaffold for tasks that genuinely require staged thinking before a final answer.
summary: Ask the model to reason through the task deliberately before returning the visible deliverable.
description: Chain-of-Thought / Deliberative Prompting is a reasoning framework for tasks that benefit from explicit staged thinking before synthesis. Prompt Compass treats it as a fit-sensitive scaffold rather than a default. It is useful for complex reasoning, debugging, tradeoff analysis, and decomposition, but it should not replace a clear objective or output contract. In Phase 1.8 it is explicitly conditional: some modern reasoning-capable models work better with concise goals, constraints, and checks than with heavy visible reasoning scripts.
aliases:
  - chain of thought
  - deliberative prompting
  - cot
related_entry_ids:
  - least-to-most-prompting
  - self-discover
  - deliberative-pausing
  - eval-first-prompting
source_refs:
  - project://support/library/curated/frameworks.md
template: |
  Task: [exact task]
  Think through the problem step by step before deciding on the final answer.
  Keep your reasoning aligned to this goal: [goal]
  Return only this final deliverable: [format and success test]
tags:
  - reasoning
  - decomposition
  - analysis
  - deliberate
phase: 1
prompt_types:
  - reductive
  - generative
subject_areas:
  - coding
  - research
  - analysis
  - strategy
model_targets:
  - generic
  - claude-opus
  - claude-sonnet
  - gpt-4o
signals:
  - task requires multi-step reasoning
  - user needs diagnostic or tradeoff work
  - answer quality depends on decomposition
contraindications:
  - simple one-shot content generation
  - prompts already bloated by too many instructions
  - reasoning-oriented models where explicit visible CoT adds verbosity without improving the result
framework_components:
  - Task
  - Deliberation
  - Final Deliverable
when_to_use:
  - The problem has multiple reasoning steps
  - The model should not jump to the first plausible answer
  - Debugging or analysis quality matters more than speed
required_slots:
  - objective
  - output_contract
output_shapes:
  - diagnosis
  - recommendation
  - explanation
  - plan
```

## Eval-First Prompting

```yaml
id: eval-first-prompting
title: Eval-First Prompting
record_type: framework
source_tier: manual_core
corpus_zone: framework
tool_fit:
  analyze: 4
  improve: 5
  build: 4
  target: 2
  search: 5
search_weight: 25
curation_status: core
curation_note: Included because reusable prompt improvement now needs explicit success criteria and test cases before revision, not just better wording.
summary: Define success criteria, failure criteria, and test cases before rewriting or operationalizing a prompt.
description: Eval-First Prompting is the framework for treating prompt improvement as a measurable loop instead of a stylistic rewrite. Prompt Compass uses it when the prompt will be reused, migrated across models, or embedded in a workflow. The framework starts by naming the target behavior, pass criteria, fail criteria, and representative test cases. Only then does it move into rewrite or optimization. This keeps prompt changes tied to outcomes that can be checked later.
aliases:
  - evaluation first prompting
  - prompt eval first
  - prompt regression framing
related_entry_ids:
  - evaluator-optimizer-loop
  - raccca
  - prompt-based-evaluation
source_refs:
  - project://support/library/curated/frameworks.md
  - project://docs/specs/deep_research_recommendations.md
  - import-source://deep-research-recommendations-b
template: |
  Target behavior:
  [what good output should do]

  Pass criteria:
  - [criterion]
  - [criterion]

  Fail criteria:
  - [failure mode]
  - [failure mode]

  Test cases:
  1. Input: [case]
     Expected properties: [properties]
  2. Input: [case]
     Expected properties: [properties]

  Then rewrite or optimize the prompt against this eval frame.
tags:
  - evaluation
  - criteria
  - regression
  - core-framework
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - research
  - analysis
  - operations
model_targets:
  - generic
signals:
  - the prompt will be reused or operationalized
  - a migration or optimization needs measurable criteria
  - the rewrite should be tied to pass and fail behavior
contraindications:
  - one-off low-stakes prompts where a direct rewrite is enough
interaction_mode: multi_turn
output_mode: structured
grounding_mode: none
evaluation_mode: grader
capability_tags:
  - judge_evaluation
framework_components:
  - Target Behavior
  - Pass Criteria
  - Fail Criteria
  - Test Cases
  - Revision Pass
when_to_use:
  - The prompt will be reused across many inputs
  - Prompt quality needs to be measurable rather than aesthetic
  - A model or prompt migration risks silent regressions
required_slots:
  - objective
  - output_contract
  - examples
output_shapes:
  - prompt
  - eval-pack
  - scorecard
  - revision-brief
```

## SELF-DISCOVER

```yaml
id: self-discover
title: SELF-DISCOVER
record_type: framework
source_tier: manual_core
corpus_zone: framework
tool_fit:
  analyze: 3
  improve: 4
  build: 3
  target: 1
  search: 4
search_weight: 18
curation_status: core
curation_note: SELF-DISCOVER is the Phase 1 framework for prompts where method selection itself is part of the problem.
summary: Have the model select the best reasoning structure first, then adapt and apply it to the task.
description: SELF-DISCOVER is a meta-reasoning framework that asks the model to choose the most useful reasoning structure before answering. In Prompt Compass it is most valuable when the task is open-ended, the method is not obvious, and a prompt would benefit from making the reasoning choice explicit rather than hidden.
aliases:
  - self discover
  - select adapt implement reasoning structures
related_entry_ids:
  - meta-prompting-self-discover-selection
  - tree-of-thoughts
  - chain-of-thought-deliberative-prompting
source_refs:
  - project://support/library/curated/frameworks.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/reasoning-frameworks/inference/self-discover-framework.json
template: |
  Task: [task]
  First select the most useful reasoning structure for this problem.
  Then adapt that structure to the task.
  Then implement it to produce this final deliverable: [format]
tags:
  - meta-reasoning
  - method-selection
  - open-ended
  - strategy-choice
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - analysis
  - research
  - strategy
  - coding
model_targets:
  - generic
  - claude-opus
  - gpt-4o
signals:
  - open-ended task
  - multiple reasoning approaches might fit
  - method choice matters
contraindications:
  - routine formatting or summarization tasks
framework_components:
  - Select
  - Adapt
  - Implement
when_to_use:
  - The reasoning structure is not obvious
  - The prompt should make approach selection explicit
  - An advanced analysis prompt needs better method choice
required_slots:
  - objective
  - output_contract
output_shapes:
  - memo
  - recommendation
  - analysis
  - plan
```

## Tree of Thoughts

```yaml
id: tree-of-thoughts
title: Tree of Thoughts
record_type: framework
source_tier: manual_core
corpus_zone: framework
tool_fit:
  analyze: 3
  improve: 3
  build: 2
  target: 1
  search: 4
search_weight: 16
curation_status: core
curation_note: Tree of Thoughts is the comparison-heavy reasoning scaffold for prompts where alternatives need to be explored before committing.
summary: Explore multiple candidate paths, compare them, and then choose the best final answer.
description: Tree of Thoughts is a branching reasoning framework for prompts where the model should consider several possible paths before committing to one answer. Prompt Compass uses it for strategy, creative ideation, option comparison, and cases where premature convergence would reduce answer quality.
aliases:
  - tot
  - tree of thoughts
related_entry_ids:
  - self-discover
  - least-to-most-prompting
  - multi-axis-organizing-prompt
source_refs:
  - project://support/library/curated/frameworks.md
template: |
  Task: [task]
  Generate [number] candidate approaches.
  Compare them using these criteria: [criteria].
  Choose the strongest path.
  Return the final answer in this format: [format]
tags:
  - alternatives
  - branching
  - comparison
  - strategy
phase: 1
prompt_types:
  - generative
  - reductive
subject_areas:
  - strategy
  - research
  - creative
  - coding
model_targets:
  - generic
  - claude-opus
  - gpt-4o
signals:
  - alternatives matter
  - user needs option comparison
  - risk of premature convergence
contraindications:
  - deterministic extraction work
  - very tight token budgets
framework_components:
  - Task
  - Candidate Paths
  - Comparison
  - Selection
when_to_use:
  - The model should compare alternatives before answering
  - The task benefits from branching exploration
  - A strategic or creative prompt needs option selection
required_slots:
  - objective
  - output_contract
output_shapes:
  - recommendation
  - comparison
  - shortlist
  - plan
```

## Least-to-Most Prompting

```yaml
id: least-to-most-prompting
title: Least-to-Most Prompting
record_type: framework
source_tier: manual_core
corpus_zone: framework
tool_fit:
  analyze: 2
  improve: 3
  build: 4
  target: 1
  search: 4
search_weight: 17
curation_status: core
curation_note: Least-to-Most is the staged decomposition scaffold for prompts that are too large to solve in one leap.
summary: Break the task into smaller subproblems, solve them in order, then synthesize the final output.
description: Least-to-Most Prompting is a staged decomposition framework for tasks that overwhelm the model when phrased as one large ask. Prompt Compass uses it when the right move is to simplify the work sequence rather than add more prose or more formatting instructions.
aliases:
  - least to most
  - least-to-most
  - least to most prompting
related_entry_ids:
  - chain-of-thought-deliberative-prompting
  - decomposed-sequential-prompting
  - risen
source_refs:
  - project://support/library/curated/frameworks.md
template: |
  Goal: [final goal]
  Break the task into smaller subproblems:
  1. [subproblem one]
  2. [subproblem two]
  3. [subproblem three]

  Solve them in order, then return this final deliverable: [format]
tags:
  - decomposition
  - staging
  - sequential
  - complexity
phase: 1
prompt_types:
  - reductive
  - generative
subject_areas:
  - coding
  - research
  - education
  - analysis
model_targets:
  - generic
  - claude-sonnet
  - gpt-4o
signals:
  - task is too large in one pass
  - ordered breakdown will improve output quality
  - user needs staged problem solving
contraindications:
  - simple tasks already well-scaffolded
framework_components:
  - Goal
  - Subproblems
  - Solve in Order
  - Final Deliverable
when_to_use:
  - The task needs staged decomposition
  - The current prompt is too broad or cognitively dense
  - The model should not attempt the whole job in one leap
required_slots:
  - objective
  - output_contract
output_shapes:
  - plan
  - analysis
  - curriculum
  - solution
```

## Prompt Architecture

```yaml
id: prompt-architecture
title: Prompt Architecture
record_type: framework
source_tier: manual_core
corpus_zone: framework
tool_fit:
  analyze: 4
  improve: 4
  build: 5
  target: 3
  search: 4
search_weight: 23
curation_status: core
curation_note: Prompt Architecture is the systems-level framework for arranging prompt layers, memory, tools, and checks without losing the core user job.
summary: Design the prompt system as an arrangement of roles, layers, tools, memory, checks, and output contracts.
description: Prompt Architecture is a systems-level framework for composing prompt systems that behave predictably across repeated use. In Prompt Compass, it helps the user think beyond a single monolithic prompt and instead arrange instruction layers, reusable templates, context packs, tool affordances, memory assumptions, and evaluative checks in an intentional structure.
aliases:
  - prompt system design
  - prompt-layered architecture
  - prompt architecture framework
related_entry_ids:
  - prompt-composition
  - prompt-template-engineering
  - context-injection-via-source-pack
source_refs:
  - project://support/library/curated/frameworks.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/other/adjacent/prompt-architecture.json
template: |
  System Role: [persistent role or posture]
  User Goal: [the current job]
  Context Layer: [what background is injected]
  Constraint Layer: [rules and boundaries]
  Tool/Memory Layer: [optional tools, memory, or source packs]
  Evaluation Layer: [how quality is checked]
  Final Output Contract: [format, length, and success test]
tags:
  - systems
  - layering
  - architecture
  - prompt-system
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - research
  - strategy
model_targets:
  - generic
  - claude-sonnet
  - claude-opus
  - gpt-4o
  - gpt-4-turbo
signals:
  - prompt needs layered structure
  - user wants reusable prompting scaffolds
  - context, tools, or checks need clear placement
contraindications:
  - one-off prompts that do not need system-level design
framework_components:
  - System Role
  - User Goal
  - Context Layer
  - Constraint Layer
  - Tool or Memory Layer
  - Evaluation Layer
  - Final Output Contract
when_to_use:
  - The prompt will be reused or templated
  - The user is building a scaffold, not just a one-off draft
  - Context, tools, and checks need deliberate arrangement
required_slots:
  - objective
  - context
  - constraints
  - output_contract
output_shapes:
  - prompt-system
  - specification
  - template
  - architecture-note
```

## Prompt Composition

```yaml
id: prompt-composition
title: Prompt Composition
record_type: framework
source_tier: manual_core
corpus_zone: framework
tool_fit:
  analyze: 4
  improve: 5
  build: 5
  target: 2
  search: 4
search_weight: 25
curation_status: core
curation_note: Prompt Composition is the main framework for assembling layered prompt parts into a clean final prompt without instruction sprawl.
summary: Build prompts from labeled parts such as role, goals, constraints, examples, checks, and output contract.
description: Prompt Composition is the framework for assembling a strong prompt from explicit labeled parts rather than one long undifferentiated paragraph. It is central to Prompt Compass because it reinforces modular structure, makes prompt repair easier, and supports reusable templates without sacrificing clarity.
aliases:
  - layered prompt construction
  - prompt composition framework
  - composed prompt
related_entry_ids:
  - prompt-architecture
  - output-contract-first
  - prompt-template-engineering
source_refs:
  - project://support/library/curated/frameworks.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/other/adjacent/prompt-composition.json
template: |
  Role: [short functional role]
  Goal: [single objective]
  Context: [must-know background]
  Constraints: [what to avoid or stay within]
  Examples: [optional example or reference]
  Checks: [what to verify before finalizing]
  Output Contract: [format, length, success test]
tags:
  - composition
  - modular
  - templates
  - assembly
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - research
  - strategy
model_targets:
  - generic
  - claude-sonnet
  - claude-opus
  - gpt-4o
  - gpt-4-turbo
signals:
  - prompt parts are mixed together
  - user needs a cleaner modular structure
  - prompt should be reusable or easier to debug
contraindications:
  - ultra-minimal prompts where composition would add unnecessary overhead
framework_components:
  - Role
  - Goal
  - Context
  - Constraints
  - Examples
  - Checks
  - Output Contract
when_to_use:
  - The draft is an instruction wall
  - The user wants a reusable template
  - A prompt needs explicit labeled sections to stay clear
required_slots:
  - objective
  - context
  - constraints
  - output_contract
output_shapes:
  - prompt
  - template
  - specification
  - scaffold
```
