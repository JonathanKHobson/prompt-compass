# Prompt Compass Model Profile Records

## GPT-5.4

```yaml
id: gpt-5.4
title: GPT-5.4
record_type: model_profile
source_tier: manual_core
corpus_zone: model_profile
tool_fit:
  analyze: 2
  improve: 4
  build: 3
  target: 5
  search: 4
search_weight: 27
curation_status: core
curation_note: Current OpenAI flagship family profile for long-context, structured prompting, and schema-sensitive output work.
summary: GPT-5.4 works best with explicit prompt sections, stable prefixes, and a clearly named output contract or schema.
description: GPT-5.4 is a high-capability OpenAI model family with a 1,050,000-token context window, reasoning-token support, image input, and strong fit for explicit output contracts. In Prompt Compass it should be targeted with stable instructions first, variable context later, and a clearly visible response shape so long context and structured output features are used intentionally rather than implicitly.
aliases:
  - gpt 5.4
  - gpt-5.4
  - chatgpt 5.4
  - chatgpt-5.4
  - gpt 5.4 thinking
  - gpt-5.4-thinking
  - gpt 5.4 pro
  - gpt-5.4-pro
related_entry_ids:
  - structured-outputs
  - json-schema-outputs
  - prompt-caching
source_refs:
  - project://support/library/curated/model_profiles.md
  - https://developers.openai.com/api/docs/models/gpt-5.4
  - https://openai.com/index/introducing-gpt-5-4/
  - https://developers.openai.com/api/docs/guides/prompt-caching
template: ""
tags:
  - model-profile
  - openai
  - gpt
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - research
  - analysis
model_targets:
  - gpt-5.4
signals:
  - model-specific targeting
  - long context
  - schema-bound output
contraindications:
  - prompts that bury the output contract or put volatile content before stable instructions
model_id: gpt-5.4
verbosity_default: medium_high
context_reading: strong
instruction_tolerance: high
tool_agent_support: true
prompting_style_preference: GPT-5.4 responds best when the prompt is sectioned, the stable instructions and examples appear before variable request data, and the output contract is explicit. It is a strong target for long-context prompts, structured outputs, and schema-bound workflows when the prompt makes those expectations visible instead of implied.
known_failure_modes:
  - Long prompts with weak prioritization can still hide the real job.
  - Vague output contracts waste its structured-output strengths.
  - Cache-friendly prompt layout is easy to miss if volatile context comes first.
recommended_strategies:
  - output-contract-first
  - prompt-composition
  - json-schema-outputs
  - long-context-layout
supports_tools: true
supports_structured_outputs: true
supports_multimodal: true
supports_long_context: true
reasoning_style: Strong at deliberate, format-sensitive reasoning when the prompt names the task and the response contract explicitly.
best_prompt_shape: Stable instructions and examples first, variable context after, then an explicit format or schema plus the current task.
compatibility_ids:
  - gpt-5.4-pro
profile_version: 2026-04-23
```

## GPT-5.5

```yaml
id: gpt-5.5
title: GPT-5.5
record_type: model_profile
source_tier: manual_core
corpus_zone: model_profile
tool_fit:
  analyze: 2
  improve: 4
  build: 4
  target: 5
  search: 4
search_weight: 28
curation_status: core
curation_note: Current OpenAI frontier family profile for agentic coding, long-horizon tool use, and real-work knowledge tasks.
summary: GPT-5.5 is best targeted with clear goals, long-horizon stop conditions, tool-use boundaries, and a visible output contract.
description: GPT-5.5 is OpenAI's current frontier family for real work across coding, research, data analysis, documents, spreadsheets, computer use, and tool-heavy workflows. OpenAI describes it as rolling out to ChatGPT and Codex now, with API availability coming soon, so Prompt Compass treats it as a family-level targeting profile with explicit availability notes rather than a package-specific deployment guarantee.
aliases:
  - gpt 5.5
  - gpt-5.5
  - chatgpt 5.5
  - chatgpt-5.5
  - gpt 5.5 thinking
  - gpt-5.5-thinking
  - gpt 5.5 pro
  - gpt-5.5-pro
related_entry_ids:
  - long-context-layout
  - tool-use-control
  - stop-condition-contract
  - output-contract-first
source_refs:
  - project://support/library/curated/model_profiles.md
  - https://openai.com/index/introducing-gpt-5-5/
  - https://openai.com/index/gpt-5-5-system-card/
  - https://developers.openai.com/api/docs/models
template: ""
tags:
  - model-profile
  - openai
  - gpt
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - research
  - analysis
  - knowledge-work
model_targets:
  - gpt-5.5
signals:
  - model-specific targeting
  - long-horizon agentic work
  - tool-heavy workflow
contraindications:
  - prompts that assume the model should infer hidden goals, unstated tool permissions, or unlimited continuation behavior
model_id: gpt-5.5
verbosity_default: medium_high
context_reading: strong
instruction_tolerance: high
tool_agent_support: true
prompting_style_preference: GPT-5.5 is a strong target for messy, multi-part work, but Prompt Compass should still make the objective, available tools, stop conditions, verification step, and output contract explicit. For coding or computer-use work, give it room to plan and verify while naming the final artifact and boundaries up front.
known_failure_modes:
  - Ambiguous multi-part requests can still spend effort on the wrong artifact.
  - Tool-heavy tasks need explicit stop conditions and verification requirements.
  - Availability differs by surface while API rollout is still being staged.
recommended_strategies:
  - output-contract-first
  - stop-condition-contract
  - tool-use-control
  - long-context-layout
supports_tools: true
supports_structured_outputs: true
supports_multimodal: true
supports_long_context: true
reasoning_style: Strong long-horizon reasoning for coding, research, and tool-coordinated knowledge work when the prompt names the goal, boundaries, and verification loop.
best_prompt_shape: State the job and final artifact first, then tool permissions and stop conditions, then context, then verification and output contract.
availability_note: GPT-5.5 is available in ChatGPT and Codex as of OpenAI's April 23, 2026 announcement; OpenAI says API availability is coming soon.
compatibility_ids:
  - gpt-5.5-pro
profile_version: 2026-04-23
```

## Claude Sonnet 4

```yaml
id: claude-sonnet-4
title: Claude Sonnet 4
record_type: model_profile
source_tier: manual_core
corpus_zone: model_profile
tool_fit:
  analyze: 2
  improve: 4
  build: 3
  target: 5
  search: 4
search_weight: 26
curation_status: core
curation_note: Current Anthropic Sonnet family profile for structured prompts, long context, and tool-capable workflows.
summary: Claude Sonnet 4 rewards sectioned prompts, XML-style structure, and explicit grounding when context is large.
description: Claude Sonnet 4 is Prompt Compass's family-level target for the current Claude Sonnet line. Anthropic's current docs position the Sonnet 4 family as strong on long-context handling, image input, tool use, and structured prompting with tags. Prompt Compass should target it with visible sections, grounded source handling, and a direct deliverable rather than a dense wall of prose.
aliases:
  - claude sonnet 4
  - claude-sonnet-4
  - claude sonnet
  - claude-sonnet
  - sonnet 4
  - sonnet
  - claude sonnet 4.6
  - claude-sonnet-4-6
related_entry_ids:
  - xml-or-delimiter-structuring
  - context-injection-via-source-pack
  - long-context-layout
source_refs:
  - project://support/library/curated/model_profiles.md
  - https://platform.claude.com/docs/en/about-claude/models/overview
  - https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#structure-prompts-with-xml-tags
template: ""
tags:
  - model-profile
  - anthropic
  - claude
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - research
  - analysis
model_targets:
  - claude-sonnet-4
signals:
  - model-specific targeting
  - xml tags
  - grounded source packs
contraindications:
  - prompts that mix instructions, sources, and examples into one unstructured block
model_id: claude-sonnet-4
verbosity_default: medium_high
context_reading: strong
instruction_tolerance: high
tool_agent_support: true
prompting_style_preference: Claude Sonnet 4 works best when the prompt separates instructions, context, examples, and inputs into visible sections. It handles long context well, but it performs more reliably when the prompt names the final artifact early and keeps source material clearly delimited. XML-style tags and grounded source framing are especially effective for this family.
known_failure_modes:
  - Long unsectioned prompts can blur instruction priority.
  - Rich context without a clear deliverable can turn into drift.
  - Tone-heavy prompts without grounding can still produce polished but misaligned answers.
recommended_strategies:
  - xml-or-delimiter-structuring
  - output-contract-first
  - long-context-layout
  - retrieval-grounding
supports_tools: true
supports_structured_outputs: true
supports_multimodal: true
supports_long_context: true
reasoning_style: Strong contextual reasoning with good recovery from large source packs when the prompt is explicitly structured.
best_prompt_shape: Clear task first, XML-like structure for instructions and context, source blocks labeled, then a specific output contract.
compatibility_ids:
  - claude-sonnet
  - claude-sonnet-4-6
profile_version: 2026-04-23
```

## Claude Opus 4

```yaml
id: claude-opus-4
title: Claude Opus 4
record_type: model_profile
source_tier: manual_core
corpus_zone: model_profile
tool_fit:
  analyze: 2
  improve: 4
  build: 3
  target: 5
  search: 4
search_weight: 25
curation_status: core
curation_note: Current Anthropic Opus family profile for high-depth reasoning, long context, and tool-aware prompting.
summary: Claude Opus 4 is strongest with rich, sectioned context and a sharply narrowed final deliverable.
description: Claude Opus 4 is Prompt Compass's family-level target for the current Claude Opus line. Anthropic's current docs position the Opus 4 family as their most capable generally available reasoning line, with strong long-context handling, image input, and tool use. Prompt Compass should target it with explicit narrowing, grounded evidence, and a visible success test so its depth is directed instead of sprawling.
aliases:
  - claude opus 4
  - claude-opus-4
  - claude opus
  - claude-opus
  - opus 4
  - opus
  - claude opus 4.7
  - claude-opus-4-7
related_entry_ids:
  - one-primary-deliverable-narrowing
  - self-discover
  - retrieval-grounding
source_refs:
  - project://support/library/curated/model_profiles.md
  - https://platform.claude.com/docs/en/about-claude/models/overview
  - https://platform.claude.com/docs/en/release-notes/overview
template: ""
tags:
  - model-profile
  - anthropic
  - claude
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - research
  - strategy
model_targets:
  - claude-opus-4
signals:
  - model-specific targeting
  - deep reasoning
  - large source pack
contraindications:
  - prompts that mistake model capacity for permission to leave the job vague
model_id: claude-opus-4
verbosity_default: high
context_reading: strong
instruction_tolerance: high
tool_agent_support: true
prompting_style_preference: Claude Opus 4 works best when the prompt gives it rich but ordered context, a concrete deliverable, and a strong success test. It is a good target for complex synthesis and reasoning-heavy work, but it still benefits from explicit narrowing and grounded evidence requirements so its depth stays tied to the user's real job.
known_failure_modes:
  - Overstuffed prompts can waste its depth on side paths.
  - Weak success tests lead to expansive but less useful answers.
  - Too many parallel asks can turn thoughtful synthesis into scope drift.
recommended_strategies:
  - one-primary-deliverable-narrowing
  - retrieval-grounding
  - quote-first-evidence-extraction
  - meta-prompting-self-discover-selection
supports_tools: true
supports_structured_outputs: true
supports_multimodal: true
supports_long_context: true
reasoning_style: Deep, synthesis-heavy reasoning that benefits from explicit bounds and evidence anchoring.
best_prompt_shape: State the one deliverable first, then provide ordered context, then specify evidence rules and the final output contract.
compatibility_ids:
  - claude-opus
  - claude-opus-4-7
profile_version: 2026-04-23
```

## Claude Haiku 4

```yaml
id: claude-haiku-4
title: Claude Haiku 4
record_type: model_profile
source_tier: manual_core
corpus_zone: model_profile
tool_fit:
  analyze: 2
  improve: 3
  build: 3
  target: 5
  search: 4
search_weight: 24
curation_status: core
curation_note: Current Anthropic Haiku family profile for fast, cost-aware prompting with near-frontier intelligence.
summary: Claude Haiku 4 is best targeted with compact instructions, tight output contracts, and explicit priority rules.
description: Claude Haiku 4 is Prompt Compass's family-level target for the current Claude Haiku line. Anthropic's current docs position Haiku 4.5 as the fastest current Claude model with near-frontier intelligence, 200k context, tool support, and strong fit for responsive workflows. Prompt Compass should target it with compact sectioning, priority-ranked constraints, and clear output limits so speed does not turn into under-specified output.
aliases:
  - claude haiku 4
  - claude-haiku-4
  - claude haiku
  - claude-haiku
  - haiku 4
  - haiku
  - claude haiku 4.5
  - claude-haiku-4-5
  - claude-haiku-4-5-20251001
related_entry_ids:
  - output-contract-first
  - trait-stack-output-control
  - short-functional-role-framing
source_refs:
  - project://support/library/curated/model_profiles.md
  - https://platform.claude.com/docs/en/about-claude/models/overview
template: ""
tags:
  - model-profile
  - anthropic
  - claude
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - research
  - analysis
model_targets:
  - claude-haiku-4
signals:
  - model-specific targeting
  - fast response
  - compact output
contraindications:
  - prompts that rely on long implicit instruction stacks instead of visible priorities
model_id: claude-haiku-4
verbosity_default: medium
context_reading: strong
instruction_tolerance: medium
tool_agent_support: true
prompting_style_preference: Claude Haiku 4 works best when the prompt is compact, sectioned, and explicit about what matters most. Use it for fast workflows where the output contract, priority order, and tool-use permission are visible rather than implied.
known_failure_modes:
  - Unranked constraints can blur priority in fast workflows.
  - Vague output size expectations can produce answers that are too thin or too broad.
  - Large context still needs labeled sections and a clear final artifact.
recommended_strategies:
  - output-contract-first
  - trait-stack-output-control
  - short-functional-role-framing
supports_tools: true
supports_structured_outputs: true
supports_multimodal: true
supports_long_context: true
reasoning_style: Fast contextual reasoning that benefits from tight priorities and explicit output limits.
best_prompt_shape: Compact task, ranked priorities, necessary context only, then a clear format, length, and success test.
compatibility_ids:
  - claude-haiku
  - claude-haiku-4-5
profile_version: 2026-04-23
```

## Gemini 2.5 Pro

```yaml
id: gemini-2.5-pro
title: Gemini 2.5 Pro
record_type: model_profile
source_tier: manual_core
corpus_zone: model_profile
tool_fit:
  analyze: 2
  improve: 4
  build: 3
  target: 5
  search: 4
search_weight: 24
curation_status: core
curation_note: Current Gemini high-capability profile for long-context reasoning, structured outputs, and function calling.
summary: Gemini 2.5 Pro is a strong target for long-context, schema-bound, and function-calling prompts when the structure is explicit.
description: Gemini 2.5 Pro is Google's high-capability Gemini 2.5 family target for Prompt Compass. Official Gemini docs position the 2.5 Pro line as strong on long context, structured outputs, function calling, and multimodal inputs. Prompt Compass should target it with explicit response schemas, clear tool behavior, and visible evidence or source handling instead of assuming it will infer the desired workflow.
aliases:
  - gemini 2.5 pro
  - gemini-2.5-pro
  - gemini pro 2.5
related_entry_ids:
  - json-schema-outputs
  - tool-use-prompting
  - retrieval-grounding
source_refs:
  - project://support/library/curated/model_profiles.md
  - https://ai.google.dev/gemini-api/docs/models
  - https://ai.google.dev/gemini-api/docs/structured-output
  - https://ai.google.dev/gemini-api/docs/function-calling
template: ""
tags:
  - model-profile
  - google
  - gemini
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - research
  - analysis
  - operations
model_targets:
  - gemini-2.5-pro
signals:
  - model-specific targeting
  - function calling
  - structured outputs
contraindications:
  - prompts that assume tool or schema behavior without explicitly defining it
model_id: gemini-2.5-pro
verbosity_default: medium
context_reading: strong
instruction_tolerance: high
tool_agent_support: true
prompting_style_preference: Gemini 2.5 Pro works best when prompts clearly separate instructions, source context, tool rules, and the final response schema. It is a strong fit for schema-bound output, function calling, and long-context tasks when the prompt makes the workflow explicit rather than conversationally implied.
known_failure_modes:
  - Tool or function behavior can get muddy if the prompt does not define the trigger clearly.
  - Long prompts without sectioning can still bury the real task.
  - Weak schemas lead to more drift than fully specified structured-output requests.
recommended_strategies:
  - json-schema-outputs
  - tool-use-prompting
  - retrieval-grounding
  - long-context-layout
supports_tools: true
supports_structured_outputs: true
supports_multimodal: true
supports_long_context: true
reasoning_style: Strong reasoning with good fit for structured workflows, tools, and long-context synthesis when the workflow is explicit.
best_prompt_shape: Separate instructions, context, tool rules, and output schema into visible blocks, then place the current task last.
compatibility_ids: []
profile_version: 2026-04-21
```

## Gemini 2.5 Flash

```yaml
id: gemini-2.5-flash
title: Gemini 2.5 Flash
record_type: model_profile
source_tier: manual_core
corpus_zone: model_profile
tool_fit:
  analyze: 2
  improve: 4
  build: 3
  target: 5
  search: 4
search_weight: 23
curation_status: core
curation_note: Current Gemini fast profile for tool use, structured outputs, and multimodal inputs with tighter prompt discipline.
summary: Gemini 2.5 Flash benefits from concise explicit structure, strong schemas, and tightly scoped tool instructions.
description: Gemini 2.5 Flash is Google's faster Gemini 2.5 family target for Prompt Compass. Official Gemini docs show it supports multimodal inputs, function calling, structured outputs, search grounding, and a large context window. Prompt Compass should target it with a tighter scope than the Pro profile, clearer schemas, and direct tool rules so the speed/latency benefits do not come at the cost of sloppy prompt boundaries.
aliases:
  - gemini 2.5 flash
  - gemini-2.5-flash
  - gemini flash 2.5
related_entry_ids:
  - tool-use-prompting
  - structured-output-steering
  - output-contract-first
source_refs:
  - project://support/library/curated/model_profiles.md
  - https://ai.google.dev/gemini-api/docs/models
  - https://ai.google.dev/gemini-api/docs/structured-output
  - https://ai.google.dev/gemini-api/docs/function-calling
template: ""
tags:
  - model-profile
  - google
  - gemini
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - research
  - analysis
  - operations
model_targets:
  - gemini-2.5-flash
signals:
  - model-specific targeting
  - fast structured output
  - multimodal inputs
contraindications:
  - prompts that rely on loose implicit structure or many competing instructions
model_id: gemini-2.5-flash
verbosity_default: medium
context_reading: moderate
instruction_tolerance: medium
tool_agent_support: true
prompting_style_preference: Gemini 2.5 Flash tends to work best when the prompt is compact, sectioned, and explicit about both tool behavior and output structure. It is a strong fast-path target for schema-bound and function-calling work, but it benefits from tighter prioritization than the Pro profile when prompts start to sprawl.
known_failure_modes:
  - Competing instructions can crowd out the core task faster than on larger models.
  - Loose schemas or underspecified output formats create drift quickly.
  - Tool usage prompts need clear boundaries or the final answer can feel under-synthesized.
recommended_strategies:
  - output-contract-first
  - structured-output-steering
  - tool-use-prompting
  - json-schema-outputs
supports_tools: true
supports_structured_outputs: true
supports_multimodal: true
supports_long_context: true
reasoning_style: Fast, capable reasoning with better reliability when instructions are short, ranked, and structurally explicit.
best_prompt_shape: Keep the job and output shape near the top, keep constraints short, and make tool or schema rules explicit instead of implied.
compatibility_ids: []
profile_version: 2026-04-21
```

## GPT-4o

```yaml
id: gpt-4o
title: GPT-4o
record_type: model_profile
source_tier: manual_core
corpus_zone: model_profile
tool_fit:
  analyze: 2
  improve: 4
  build: 3
  target: 4
  search: 4
search_weight: 21
curation_status: core
curation_note: Legacy compatibility OpenAI profile kept because many existing prompts and host UIs still target GPT-4o explicitly.
summary: GPT-4o rewards direct prompts, visible format instructions, and minimal ambiguity.
description: GPT-4o remains in Prompt Compass as a compatibility profile for existing prompts and host environments that still target it directly. It works best with explicit task verbs, compact sections, and clearly stated output format rather than implicit structure.
aliases:
  - chatgpt-4o
  - gpt 4o
  - chatgpt 4o
  - 4o
related_entry_ids:
  - output-contract-first
  - rtf
  - structured-output-steering
source_refs:
  - project://support/library/curated/model_profiles.md
  - https://developers.openai.com/api/docs/models/gpt-5.4
template: ""
tags:
  - model-profile
  - openai
  - chatgpt
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - research
  - strategy
model_targets:
  - gpt-4o
signals:
  - model-specific targeting
  - direct task verbs
  - explicit format
contraindications:
  - prompts that rely on buried instructions or highly implicit structure
model_id: gpt-4o
verbosity_default: medium
context_reading: moderate
instruction_tolerance: high
tool_agent_support: true
prompting_style_preference: GPT-4o tends to perform best when the prompt is explicit, compact, and visibly structured. It usually benefits from strong output-format instructions, direct task verbs, and clearly labeled assumptions instead of hidden expectations.
known_failure_modes:
  - Buried instructions can get lost when the prompt is too prose-heavy.
  - Weak output contracts often lead to format drift or overinterpretation.
  - Broad open-ended asks can produce energetic but less tightly bounded answers.
recommended_strategies:
  - output-contract-first
  - rtf
  - structured-output-steering
  - top-three-traits-ranking
supports_tools: true
supports_structured_outputs: true
supports_multimodal: true
supports_long_context: true
reasoning_style: Direct and responsive when the task and response shape are explicit.
best_prompt_shape: State the task clearly, name the output format, then add only the context and constraints that materially matter.
compatibility_ids: []
profile_version: 2026-04-21
```

## GPT-4 Turbo

```yaml
id: gpt-4-turbo
title: GPT-4 Turbo
record_type: model_profile
source_tier: manual_core
corpus_zone: model_profile
tool_fit:
  analyze: 2
  improve: 4
  build: 3
  target: 4
  search: 4
search_weight: 19
curation_status: core
curation_note: Legacy compatibility OpenAI profile retained for existing integrations that still name GPT-4 Turbo.
summary: GPT-4 Turbo is most reliable with concise sections, clear scope, and a visible output contract.
description: GPT-4 Turbo remains in Prompt Compass as a compatibility profile for older host environments and prompt libraries. It is generally well served by prompts that stay direct, sectioned, and explicit about constraints and output requirements. In Prompt Compass it should be targeted with compact framing, visible deliverables, and assumptions that are surfaced rather than implied.
aliases:
  - chatgpt-4-turbo
  - gpt-4-turbo
  - gpt 4 turbo
  - chatgpt 4 turbo
related_entry_ids:
  - rtf
  - output-contract-first
  - clear
source_refs:
  - project://support/library/curated/model_profiles.md
  - https://developers.openai.com/api/docs/models/gpt-5.4
template: ""
tags:
  - model-profile
  - openai
  - chatgpt
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - research
  - strategy
model_targets:
  - gpt-4-turbo
signals:
  - model-specific targeting
  - concise structured prompt
  - explicit constraints
contraindications:
  - long diffuse prompts with hidden priorities
model_id: gpt-4-turbo
verbosity_default: medium
context_reading: moderate
instruction_tolerance: medium
tool_agent_support: true
prompting_style_preference: GPT-4 Turbo generally responds best to concise sectioned prompts that tell it exactly what to do and what shape to return. It benefits from visible constraints, direct instructions, and clear boundaries on scope.
known_failure_modes:
  - Diffuse prompts can blur priority and reduce consistency.
  - If the format is implied rather than stated, the answer shape may wander.
  - Too many competing style instructions can crowd out the actual task.
recommended_strategies:
  - rtf
  - output-contract-first
  - short-functional-role-framing
  - must-haves-nice-to-haves-exclusions
supports_tools: true
supports_structured_outputs: true
supports_multimodal: true
supports_long_context: true
reasoning_style: Best with direct instructions and explicit constraints rather than inference-heavy prompt design.
best_prompt_shape: Keep the prompt compact, lead with the task, and state the response format and constraints clearly.
compatibility_ids: []
profile_version: 2026-04-21
```
