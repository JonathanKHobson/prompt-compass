# Prompt Compass Question Records

## What Does a Successful Response Look Like to You?

```yaml
id: successful-response-look-like
title: What Does a Successful Response Look Like to You?
record_type: question
source_tier: manual_core
corpus_zone: question
tool_fit:
  analyze: 1
  improve: 5
  build: 5
  target: 1
  search: 3
search_weight: 23
curation_status: core
curation_note: This is a top-priority question because it surfaces the success test that many weak prompts never state.
summary: Ask the user to define success in practical terms before the prompt is rewritten.
description: This question elicits what “good” or “usable” actually means for the user so the rewritten prompt can optimize for a real outcome instead of generic quality words.
aliases:
  - success test question
related_entry_ids:
  - missing-success-test
  - output-contract-first
  - clear
source_refs:
  - project://support/library/curated/questions.md
template: ""
tags:
  - question
  - output-contract
  - success-test
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - output contract weak
  - success test missing
  - rewrite would require guessing
contraindications:
  - none
slot: output_contract
question_text: What does a successful response look like to you?
triggers_when:
  - missing:output_contract
  - anti_pattern:missing-success-test
  - output_contract:success_test_missing
question_category: output_contract
sequence_priority: 1
answer_type: short_text
choices: []
on_skip: leave success criteria inferred from the task
```

## Output Format and Length Limit

```yaml
id: output-format-and-length-limit
title: Output Format and Length Limit
record_type: question
source_tier: manual_core
corpus_zone: question
tool_fit:
  analyze: 1
  improve: 5
  build: 5
  target: 2
  search: 3
search_weight: 24
curation_status: core
curation_note: This is one of the first output-contract questions because missing format guidance causes large quality swings.
summary: Ask for the desired output shape and whether length should be constrained.
description: This question makes the output shape concrete by asking what format the result should take and whether there is a meaningful length ceiling or range. It keeps the rewritten prompt from defaulting to a shape the user did not actually want.
aliases:
  - output shape question
related_entry_ids:
  - output-contract-first
  - premature-format-lock
  - rtf
source_refs:
  - project://support/library/curated/questions.md
template: ""
tags:
  - question
  - output-contract
  - format
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - no visible format
  - length missing
  - artifact unclear
contraindications:
  - none
slot: output_contract
question_text: What format do you need the output in, and is there a length limit?
triggers_when:
  - missing:output_contract
  - output_contract:format_missing
  - anti_pattern:vague-compression
question_category: output_contract
sequence_priority: 1
answer_type: short_text
choices: []
on_skip: use a reasonable default format inferred from the task
```

## Single Most Important Thing

```yaml
id: single-most-important-thing
title: Single Most Important Thing
record_type: question
source_tier: manual_core
corpus_zone: question
tool_fit:
  analyze: 1
  improve: 5
  build: 5
  target: 1
  search: 3
search_weight: 24
curation_status: core
curation_note: This is the highest-leverage narrowing question for prompts that are trying to do too much.
summary: Ask the user to name the one output that matters most if the prompt can only do one job.
description: This question forces prioritization when the draft is broad, messy, or multi-track. It gives Prompt Compass the main deliverable to optimize around before any downstream shaping work begins.
aliases:
  - one main thing question
related_entry_ids:
  - one-primary-deliverable-narrowing
  - scope-sprawl
  - golden-circle
source_refs:
  - project://support/library/curated/questions.md
template: ""
tags:
  - question
  - deliverable
  - narrowing
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - prompt too broad
  - objective weak
  - multiple asks
contraindications:
  - none
slot: objective
question_text: What is the single most important thing you need this prompt to produce?
triggers_when:
  - missing:objective
  - anti_pattern:scope-sprawl
  - anti_pattern:source-pack-with-vague-ask
question_category: deliverable
sequence_priority: 1
answer_type: short_text
choices: []
on_skip: use the most obvious deliverable inferred from the draft
```

## One Thing Only

```yaml
id: one-thing-only
title: One Thing Only
record_type: question
source_tier: manual_core
corpus_zone: question
tool_fit:
  analyze: 1
  improve: 5
  build: 5
  target: 1
  search: 3
search_weight: 22
curation_status: core
curation_note: Reinforces scope reduction by forcing the user to choose one artifact under pressure.
summary: Ask the user what the AI should return if only one thing can come back.
description: This question is a scope-compression move. It is especially useful when the user keeps naming several plausible outputs and needs help choosing the one the prompt should optimize for now.
aliases:
  - if only one thing
related_entry_ids:
  - one-primary-deliverable-narrowing
  - scope-sprawl
  - risen
source_refs:
  - project://support/library/curated/questions.md
template: ""
tags:
  - question
  - deliverable
  - prioritization
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - multiple possible outputs
  - user not choosing one deliverable
  - prompt needs compression
contraindications:
  - none
slot: objective
question_text: If the AI could only return one thing, what would it be?
triggers_when:
  - anti_pattern:scope-sprawl
  - anti_pattern:vague-compression
  - missing:objective
question_category: deliverable
sequence_priority: 1
answer_type: short_text
choices: []
on_skip: default to the first viable artifact implied by the task
```

## What Should the AI Explicitly Not Do or Cover?

```yaml
id: what-not-to-cover
title: What Should the AI Explicitly Not Do or Cover?
record_type: question
source_tier: manual_core
corpus_zone: question
tool_fit:
  analyze: 1
  improve: 4
  build: 5
  target: 1
  search: 3
search_weight: 20
curation_status: core
curation_note: This question is the clearest way to turn vague scope control into an explicit exclusion list.
summary: Ask the user to define exclusions so the prompt can stop trying to do everything.
description: This question collects hard boundaries for the prompt by asking what the model should not do, include, or cover. It is especially effective when scope sprawl or source-heavy prompting makes the task too broad.
aliases:
  - exclusion question
related_entry_ids:
  - must-haves-nice-to-haves-exclusions
  - scope-sprawl
  - clear
source_refs:
  - project://support/library/curated/questions.md
template: ""
tags:
  - question
  - scope
  - exclusions
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - no exclusions
  - scope too broad
  - user has not stated boundaries
contraindications:
  - none
slot: constraints
question_text: What should the AI explicitly NOT do or cover in this response?
triggers_when:
  - anti_pattern:scope-sprawl
  - missing:constraints
  - anti_pattern:instruction-wall
question_category: scope
sequence_priority: 2
answer_type: short_text
choices: []
on_skip: leave exclusions empty and infer only obvious limits
```

## Belongs in a Follow-Up

```yaml
id: belongs-in-follow-up
title: Belongs in a Follow-Up
record_type: question
source_tier: manual_core
corpus_zone: question
tool_fit:
  analyze: 1
  improve: 4
  build: 5
  target: 1
  search: 3
search_weight: 19
curation_status: core
curation_note: This question helps split prompts into now versus later, which is central to Prompt Compass’s narrowing posture.
summary: Ask the user whether some parts of the current draft should be deferred to a later prompt.
description: This question supports sequencing by helping the user move second-order asks, optional requests, and side quests into a follow-up prompt instead of cramming them into the current one.
aliases:
  - follow-up split question
related_entry_ids:
  - one-primary-deliverable-narrowing
  - scope-sprawl
  - risen
source_refs:
  - project://support/library/curated/questions.md
template: ""
tags:
  - question
  - scope
  - sequencing
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - draft includes optional extras
  - prompt needs follow-up separation
  - user may be mixing stages
contraindications:
  - none
slot: constraints
question_text: Is there anything in your current draft that feels like it belongs in a follow-up prompt rather than this one?
triggers_when:
  - anti_pattern:scope-sprawl
  - anti_pattern:instruction-wall
  - anti_pattern:source-pack-with-vague-ask
question_category: scope
sequence_priority: 2
answer_type: short_text
choices: []
on_skip: keep all current asks in scope unless obviously deferable
```

## Intended Reader

```yaml
id: intended-reader
title: Intended Reader
record_type: question
source_tier: manual_core
corpus_zone: question
tool_fit:
  analyze: 1
  improve: 4
  build: 4
  target: 1
  search: 3
search_weight: 21
curation_status: core
curation_note: Audience clarity is a high-leverage repair step for prompts that are persuasive, stylistic, or decision-facing.
summary: Ask who the output is actually for so the prompt can tune tone and detail correctly.
description: This question identifies the intended reader or user of the AI output so the prompt can adapt tone, detail, framing, and success criteria to a real audience instead of an imaginary one.
aliases:
  - audience question
related_entry_ids:
  - ghost-audience
  - costar
  - role-playing-prompting
source_refs:
  - project://support/library/curated/questions.md
template: ""
tags:
  - question
  - audience
  - fit
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - audience absent
  - tone or persuasion language present
  - output usefulness depends on reader fit
contraindications:
  - none
slot: audience
question_text: Who is the intended reader of the AI's output?
triggers_when:
  - missing:audience
  - anti_pattern:ghost-audience
question_category: audience
sequence_priority: 2
answer_type: short_text
choices: []
on_skip: leave audience generic
```

## Which Model or Product?

```yaml
id: model-or-product
title: Which Model or Product?
record_type: question
source_tier: manual_core
corpus_zone: question
tool_fit:
  analyze: 1
  improve: 3
  build: 3
  target: 5
  search: 3
search_weight: 18
curation_status: core
curation_note: This question supports the model-targeting pass without forcing it before the core contract is stable.
summary: Ask which AI model or product the prompt will be used with so a model-specific or workflow-specific pass can happen later.
description: This question identifies the execution surface for the prompt. Prompt Compass uses it after the basic prompt contract is stable so it can adapt instruction density, structure, output shape, and workflow fit without guessing the target system. In Phase 1.8 it also helps route between ordinary chat prompting and more runtime-aware guidance.
aliases:
  - model target question
related_entry_ids:
  - claude-sonnet
  - gpt-4o
  - model-targeting-pass
  - eval-first-prompting
source_refs:
  - project://support/library/curated/questions.md
template: ""
tags:
  - question
  - model-target
  - targeting
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - no model target
  - user may want model-specific tuning
contraindications:
  - none
slot: model_target
question_text: Which AI model or product will you be using this prompt with?
triggers_when:
  - missing:model_target
  - model_target:generic
question_category: model_target
sequence_priority: 3
answer_type: single_select
choices:
  - claude-sonnet
  - claude-opus
  - gpt-4o
  - gpt-4-turbo
  - generic
on_skip: use generic targeting
```

## Runtime Layer

```yaml
id: runtime-layer
title: Runtime Layer
record_type: question
source_tier: house_curated
corpus_zone: question
tool_fit:
  analyze: 2
  improve: 4
  build: 4
  target: 2
  search: 3
search_weight: 20
curation_status: core
curation_note: Included because many prompt problems are really workflow-shape problems rather than wording-only problems.
summary: Ask whether the prompt is for a one-off answer, a reusable template, a multi-turn workflow, or a tool-using agent.
description: This question helps Prompt Compass route the request into the right runtime frame before overfitting the wording. It is useful when the draft looks like it might really be a workflow, tool-use prompt, or reusable prompt asset rather than a single message.
aliases:
  - workflow layer question
related_entry_ids:
  - context-engineering
  - ask-vs-act-threshold
  - tool-contract-prompting
source_refs:
  - project://support/library/curated/questions.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - question
  - runtime
  - workflow
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - prompt may really be a workflow or agent brief
  - runtime shape is not obvious
  - wording alone is not the main problem
contraindications:
  - none
slot: runtime_layer
question_text: Is this prompt meant for a one-time answer, a reusable template, a multi-turn workflow, or an agent with tools?
triggers_when:
  - prompt_type:generative
  - anti_pattern:scope-sprawl
question_category: runtime_layer
sequence_priority: 2
answer_type: single_select
choices:
  - one-time answer
  - reusable template
  - multi-turn workflow
  - agent with tools
on_skip: assume a single-turn prompt unless the draft clearly implies a workflow
```

## Context Source of Truth

```yaml
id: context-source-of-truth
title: Context Source of Truth
record_type: question
source_tier: house_curated
corpus_zone: question
tool_fit:
  analyze: 2
  improve: 4
  build: 4
  target: 1
  search: 3
search_weight: 20
curation_status: core
curation_note: Included because source-grounded prompts need an explicit boundary between instructions and supporting evidence.
summary: Ask which parts of the context are authoritative instructions and which parts are only evidence or background.
description: This question helps Prompt Compass keep the prompt contract separate from pasted or retrieved material. It is especially useful when the draft contains long notes, transcripts, or documents that may otherwise blur into the instruction layer.
aliases:
  - source of truth question
related_entry_ids:
  - untrusted-context-boundary
  - context-injection-via-source-pack
  - trusted-source-collapse
source_refs:
  - project://support/library/curated/questions.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - question
  - grounding
  - trust-boundary
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - source material is present
  - instruction and evidence layers may be mixed
  - trust boundaries matter
contraindications:
  - none
slot: grounding
question_text: Which parts of the context are authoritative instructions, and which are only evidence or background?
triggers_when:
  - anti_pattern:source-pack-with-vague-ask
  - anti_pattern:trusted-source-collapse
  - missing:context
question_category: grounding
sequence_priority: 2
answer_type: long_text
choices: []
on_skip: assume the prompt text is authoritative and treat external material as evidence only
```

## Parser or Human Reader

```yaml
id: parser-or-human-reader
title: Parser or Human Reader
record_type: question
source_tier: house_curated
corpus_zone: question
tool_fit:
  analyze: 2
  improve: 5
  build: 4
  target: 2
  search: 3
search_weight: 21
curation_status: core
curation_note: Included because machine-readable prompts need different output-contract repair than human-readable ones.
summary: Ask whether a human will read the output or whether another system needs to parse it.
description: This question helps Prompt Compass choose between ordinary structured output and parser-ready schema guidance. It matters when the user asks for JSON, tables, YAML, API payloads, function arguments, or any output that will feed another workflow.
aliases:
  - parser question
related_entry_ids:
  - schema-first-output-contract
  - parser-aware-prompting
  - json-schema-outputs
source_refs:
  - project://support/library/curated/questions.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - question
  - parser
  - output-contract
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - the prompt asks for structured output
  - machine readability may matter
  - schema details are not yet clear
contraindications:
  - none
slot: parser_contract
question_text: Will a human read this output, or will another system parse it?
triggers_when:
  - output_contract:format_missing
  - anti_pattern:schema-theater
question_category: parser_contract
sequence_priority: 1
answer_type: single_select
choices:
  - human reader
  - parser or automation
on_skip: assume a human-readable output unless the draft clearly names a parser-ready format
```

## Failure Examples

```yaml
id: failure-examples
title: Failure Examples
record_type: question
source_tier: house_curated
corpus_zone: question
tool_fit:
  analyze: 2
  improve: 4
  build: 4
  target: 1
  search: 3
search_weight: 19
curation_status: core
curation_note: Included because explicit failure cases improve evaluation quality more than vague quality adjectives.
summary: Ask for examples of outputs that would be considered wrong, weak, or unusable.
description: This question gives Prompt Compass a concrete failure frame instead of forcing it to infer what bad looks like. It is useful for eval-first improvement, schema design, and any prompt that will be reused enough for regression risk to matter.
aliases:
  - bad output examples
related_entry_ids:
  - eval-first-prompting
  - evaluator-optimizer-loop
  - missing-success-test
source_refs:
  - project://support/library/curated/questions.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - question
  - evaluation
  - failure-modes
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - prompt quality needs explicit criteria
  - a rewrite should avoid repeatable failure modes
  - eval framing would improve the prompt
contraindications:
  - none
slot: evaluation
question_text: What are 2-3 examples of outputs that would be considered wrong or unusable?
triggers_when:
  - anti_pattern:missing-success-test
  - anti_pattern:schema-theater
question_category: evaluation
sequence_priority: 2
answer_type: long_text
choices: []
on_skip: infer likely failure modes from the task and anti-patterns
```

## Agent Stop Condition

```yaml
id: agent-stop-condition
title: Agent Stop Condition
record_type: question
source_tier: house_curated
corpus_zone: question
tool_fit:
  analyze: 2
  improve: 4
  build: 4
  target: 2
  search: 3
search_weight: 20
curation_status: core
curation_note: Included because tool-using and agent-like prompts need a clear definition of done.
summary: Ask what should tell the model or agent that the task is complete.
description: This question forces completion logic into the prompt contract. It is useful when the draft suggests tools, iterative work, or open-ended execution but never defines when the model should stop and return control.
aliases:
  - stop condition question
related_entry_ids:
  - stop-condition-contract
  - agentic-overrun
  - ask-vs-act-threshold
source_refs:
  - project://support/library/curated/questions.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - question
  - stop-condition
  - agent-control
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - the prompt suggests tool use or autonomous continuation
  - done criteria are not obvious
  - the user needs bounded execution
contraindications:
  - none
slot: agent_control
question_text: What should tell the agent that the task is complete?
triggers_when:
  - anti_pattern:agentic-overrun
  - prompt_type:generative
question_category: agent_control
sequence_priority: 2
answer_type: short_text
choices: []
on_skip: stop once the named deliverable is complete and blockers are reported
```

## Tool Confirmation Boundary

```yaml
id: tool-confirmation-boundary
title: Tool Confirmation Boundary
record_type: question
source_tier: house_curated
corpus_zone: question
tool_fit:
  analyze: 2
  improve: 4
  build: 4
  target: 3
  search: 3
search_weight: 18
curation_status: core
curation_note: Included because tool-using prompts often need a clear user-confirmation boundary before high-impact actions.
summary: Ask which actions require explicit confirmation before the model proceeds.
description: This question helps Prompt Compass define the safety and trust boundary for tool use without turning the prompt into a full security framework. It matters when the model may browse, modify files, spend money, publish, or take any action the user might want to approve first.
aliases:
  - confirmation boundary question
related_entry_ids:
  - tool-contract-prompting
  - ask-vs-act-threshold
  - tool-thrash
source_refs:
  - project://support/library/curated/questions.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - question
  - tools
  - confirmation
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - tool use is implied or explicit
  - action boundaries are unclear
  - the prompt may need user approval rules
contraindications:
  - none
slot: tool_use
question_text: Which actions require explicit user confirmation before the model proceeds?
triggers_when:
  - anti_pattern:tool-thrash
  - anti_pattern:agentic-overrun
question_category: tool_use
sequence_priority: 3
answer_type: long_text
choices: []
on_skip: assume high-impact or irreversible actions require confirmation
```

## Source Priority

```yaml
id: source-priority
title: Source Priority
record_type: question
source_tier: house_curated
corpus_zone: question
tool_fit:
  analyze: 2
  improve: 4
  build: 4
  target: 1
  search: 3
search_weight: 18
curation_status: core
curation_note: Included because grounded prompts need a visible rule for what source should win when documents conflict.
summary: Ask which source should win if the context conflicts or the evidence points in different directions.
description: This question helps Prompt Compass rank authority instead of letting every source count equally. It is most useful for research, retrieval, and source-pack prompts that mix recency, expertise, and user-provided material.
aliases:
  - source ranking question
related_entry_ids:
  - long-context-salience-management
  - context-engineering
  - trusted-source-collapse
source_refs:
  - project://support/library/curated/questions.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - question
  - source-priority
  - grounding
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - multiple sources may conflict
  - retrieval or source packs are involved
  - authority ranking matters
contraindications:
  - none
slot: source_priority
question_text: Which source should win if the context conflicts?
triggers_when:
  - anti_pattern:context-hoarding
  - anti_pattern:trusted-source-collapse
  - anti_pattern:source-pack-with-vague-ask
question_category: source_priority
sequence_priority: 3
answer_type: short_text
choices: []
on_skip: prioritize the most authoritative and directly relevant source
```

## Missing Context Needed

```yaml
id: missing-context-needed
title: Missing Context Needed
record_type: question
source_tier: manual_core
corpus_zone: question
tool_fit:
  analyze: 1
  improve: 4
  build: 4
  target: 1
  search: 3
search_weight: 20
curation_status: core
curation_note: This question fills high-leverage context gaps without encouraging the user to dump every possible detail.
summary: Ask what context the AI truly needs that is not already in the draft.
description: This question helps the user supply missing background while keeping the context disciplined. It avoids both unsupported inference and unnecessary context overload by asking for only the essential missing material.
aliases:
  - missing context question
related_entry_ids:
  - hallucination-bait
  - context-injection-via-source-pack
  - purposeful-contextual-absences
source_refs:
  - project://support/library/curated/questions.md
template: ""
tags:
  - question
  - context
  - grounding
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - context thin
  - grounding needed
  - prompt would otherwise guess
contraindications:
  - none
slot: context
question_text: What context does the AI need to know that isn't already in your draft?
triggers_when:
  - missing:context
  - anti_pattern:hallucination-bait
  - anti_pattern:source-pack-with-vague-ask
question_category: context_depth
sequence_priority: 2
answer_type: long_text
choices: []
on_skip: keep context minimal
```

## Trait Priority

```yaml
id: trait-priority
title: Trait Priority
record_type: question
source_tier: manual_core
corpus_zone: question
tool_fit:
  analyze: 1
  improve: 4
  build: 3
  target: 1
  search: 3
search_weight: 17
curation_status: core
curation_note: This question operationalizes the house rule that adjective piles must be ranked, not merely collected.
summary: Ask the user which quality matters most when too many output traits are requested at once.
description: This question converts an unranked style stack into a clear priority. It is most useful when the prompt is full of desirable qualities but gives the model no tradeoff logic for which one should win.
aliases:
  - trait ranking question
related_entry_ids:
  - stacked-adjectives
  - top-three-traits-ranking
  - trait-stack-output-control
source_refs:
  - project://support/library/curated/questions.md
template: ""
tags:
  - question
  - traits
  - priority
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - too many qualities listed
  - tradeoff needed
  - style dominates the prompt
contraindications:
  - none
slot: constraints
question_text: You've listed several qualities you want. Which one matters most if you can only get one right?
triggers_when:
  - anti_pattern:stacked-adjectives
  - trait_stack:count>3
question_category: trait_ranking
sequence_priority: 3
answer_type: short_text
choices: []
on_skip: infer the top trait from the first quality mentioned
```

## First-Pass Usability Test

```yaml
id: first-pass-usability-test
title: First-Pass Usability Test
record_type: question
source_tier: manual_core
corpus_zone: question
tool_fit:
  analyze: 1
  improve: 5
  build: 4
  target: 1
  search: 3
search_weight: 22
curation_status: core
curation_note: This is the second success-test question so Prompt Compass does not stop at format and still miss practical usefulness.
summary: Ask how the user would judge whether the output is usable immediately, not just formally correct.
description: This question turns an abstract quality request into a practical usability bar. It gives Prompt Compass a concrete way to define what “good enough” means in the user’s actual workflow.
aliases:
  - usability test question
related_entry_ids:
  - missing-success-test
  - output-contract-first
  - successful-response-look-like
source_refs:
  - project://support/library/curated/questions.md
template: ""
tags:
  - question
  - success-test
  - usability
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
model_targets:
  - generic
signals:
  - output exists
  - usable criteria absent
  - first-pass quality matters
contraindications:
  - none
slot: output_contract
question_text: What would make this output usable on the first pass?
triggers_when:
  - anti_pattern:missing-success-test
  - output_contract:success_test_missing
question_category: success_test
sequence_priority: 1
answer_type: short_text
choices: []
on_skip: infer a basic success test from the artifact type
```
