# Prompt Compass Strategy Records

## One-Primary-Deliverable Narrowing

```yaml
id: one-primary-deliverable-narrowing
title: One-Primary-Deliverable Narrowing
record_type: strategy
source_tier: house_curated
corpus_zone: strategy
tool_fit:
  analyze: 4
  improve: 5
  build: 5
  target: 1
  search: 3
search_weight: 24
curation_status: core
curation_note: Encodes the house rule that every prompt should drive one concrete deliverable instead of several parallel asks.
summary: Force the prompt to name one primary deliverable and defer everything else.
description: One-Primary-Deliverable Narrowing is the house strategy for collapsing scope sprawl into one real output. When a brief contains multiple asks, side quests, or stacked ambitions, this strategy chooses the one deliverable the prompt must produce now and explicitly moves the rest into exclusions or follow-up prompts. It protects against planning-shaped avoidance and keeps the prompt shippable.
aliases:
  - one deliverable
  - single deliverable narrowing
  - primary deliverable narrowing
related_entry_ids:
  - risen
  - scope-sprawl
  - intent-dump-constraint-sweep
source_refs:
  - project://support/library/curated/strategies.md
  - reference://kyle-prompt-playbook/profile
template: |
  Before rewriting, decide the one deliverable this prompt must produce now.

  Primary deliverable: [single output]
  Defer for later: [follow-up items]
  Explicitly exclude: [what this prompt should not try to do]

  Then write the final prompt around the primary deliverable only.
tags:
  - narrowing
  - scope-control
  - deliverable
  - house-style
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - strategy
  - writing
  - coding
model_targets:
  - generic
signals:
  - multiple deliverables in one draft
  - user intent is sprawling
  - the ask mixes planning and execution
contraindications:
  - prompts that are already tightly bounded to one outcome
goal_fit:
  - diagnose
  - improve
  - build
works_best_for:
  - scope-sprawl
  - intent-dump
  - broad briefs that need one lane
apply_order: 1
```

## Output-Contract-First

```yaml
id: output-contract-first
title: Output-Contract-First
record_type: strategy
source_tier: house_curated
corpus_zone: strategy
tool_fit:
  analyze: 4
  improve: 5
  build: 5
  target: 2
  search: 4
search_weight: 25
curation_status: core
curation_note: Encodes the house rule that the format, length, and success test should be visible before stylistic polishing.
summary: State the final artifact, its shape, and the success test before tuning style or tone.
description: Output-Contract-First is the Prompt Compass strategy for anchoring the prompt to a usable artifact early. It requires the writer to state what the output is, what format it should take, how long it should be if length matters, and what would make the answer successful on the first pass. It prevents prompts from becoming style-heavy but outcome-light. In Phase 1.8 it explicitly branches into schema-first output contracts when another system, parser, or tool depends on exact structure.
aliases:
  - output contract first
  - artifact first
  - response contract first
related_entry_ids:
  - costar
  - rtf
  - missing-success-test
  - schema-first-output-contract
source_refs:
  - project://support/library/curated/strategies.md
  - reference://kyle-prompt-playbook/profile
template: |
  Deliverable: [what the AI should return]
  Format: [table, memo, bullets, JSON, etc.]
  Length: [if relevant]
  Success test: [what makes it usable on the first pass]

  Only after this is clear, add the context, constraints, and style guidance.
tags:
  - output-contract
  - artifact
  - success-test
  - house-style
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - research
model_targets:
  - generic
  - claude-sonnet
  - gpt-4o
  - gpt-4-turbo
signals:
  - no visible output format
  - prompt talks about quality more than artifact
  - success criteria are missing
contraindications:
  - prompts where the artifact is already explicit and stable
output_mode: structured
capability_tags:
  - structured_output
goal_fit:
  - diagnose
  - improve
  - build
  - target
works_best_for:
  - vague-compression
  - missing-success-test
  - weak output-contracts
apply_order: 2
```

## Schema-First Output Contract

```yaml
id: schema-first-output-contract
title: Schema-First Output Contract
record_type: strategy
source_tier: manual_core
corpus_zone: strategy
tool_fit:
  analyze: 4
  improve: 5
  build: 5
  target: 3
  search: 5
search_weight: 26
curation_status: core
curation_note: Included because parser-ready and automation-facing prompts need field-level contracts, not just loose formatting instructions.
summary: Replace loose format requests with explicit schemas, required fields, and failure behavior when another system depends on the output.
description: Schema-First Output Contract is the strategy for prompts whose output will be parsed, validated, or passed into another workflow. Prompt Compass uses it to move beyond vague requests like return JSON or make a table. The strategy makes the contract explicit by naming required fields, allowed values, empty-value policy, refusal behavior, and what counts as a valid response shape before style or tone decisions are layered on.
aliases:
  - schema first output contract
  - schema first prompting
  - parser-ready output contract
related_entry_ids:
  - output-contract-first
  - json-schema-outputs
  - parser-aware-prompting
source_refs:
  - project://support/library/curated/strategies.md
  - import-source://deep-research-recommendations-b
template: |
  Output contract:
  - Required fields: [fields]
  - Allowed values or schema rules: [rules]
  - Empty or null behavior: [policy]
  - Refusal or error behavior: [policy]
  - Success test: [what valid output must satisfy]

  Then write the final prompt around that contract.
tags:
  - schema
  - parser
  - output-contract
  - core-strategy
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - coding
  - operations
  - analysis
  - research
model_targets:
  - generic
signals:
  - the output will be parsed or validated downstream
  - return json is not strict enough
  - field-level structure matters more than prose elegance
contraindications:
  - purely human-readable tasks where loose structure is acceptable
interaction_mode: single_turn
output_mode: schema_bound
grounding_mode: none
evaluation_mode: rubric
capability_tags:
  - structured_output
  - json_schema
  - parser_aware
goal_fit:
  - diagnose
  - improve
  - build
  - target
works_best_for:
  - schema-theater
  - machine-readable outputs
  - automation-facing prompts
apply_order: 3
```

## Long-Context Salience Management

```yaml
id: long-context-salience-management
title: Long-Context Salience Management
record_type: strategy
source_tier: house_curated
corpus_zone: strategy
tool_fit:
  analyze: 3
  improve: 4
  build: 3
  target: 2
  search: 5
search_weight: 19
curation_status: supporting
curation_note: Included as support guidance because large context windows still need explicit prioritization and salience control.
summary: Make the live task, source priority, and decision-relevant evidence easier to recover inside long prompts.
description: Long-Context Salience Management is the strategy of keeping the most important instructions, constraints, and evidence visible when the prompt includes many documents or long history. Prompt Compass uses it as support guidance for contexts where the model can technically read everything but still benefits from source maps, priority ordering, quote-first evidence, and explicit carry-forward notes.
aliases:
  - salience management
  - long context salience
  - lost in the middle mitigation
related_entry_ids:
  - long-context-layout
  - context-engineering
  - context-hoarding
source_refs:
  - project://support/library/curated/strategies.md
  - import-source://deep-research-recommendations-b
template: |
  Before writing the final prompt:
  - rank sources by authority or relevance
  - move the live task and constraints into a visible priority block
  - surface 3-5 key evidence points before the long context
  - carry forward only decisions that still matter
tags:
  - long-context
  - salience
  - support-strategy
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - research
  - analysis
  - coding
  - operations
model_targets:
  - generic
signals:
  - important requirements are getting buried in long context
  - many sources or transcripts are competing for attention
  - source priority is not visible
contraindications:
  - short prompts where salience is already obvious
interaction_mode: single_turn
output_mode: structured
grounding_mode: source_pack
evaluation_mode: none
capability_tags:
  - long_context
  - source_priority
goal_fit:
  - improve
  - build
works_best_for:
  - context-hoarding
  - middle-buried-requirement
  - long source packs
apply_order: 6
```

## Ask-vs-Act Threshold

```yaml
id: ask-vs-act-threshold
title: Ask-vs-Act Threshold
record_type: strategy
source_tier: house_curated
corpus_zone: strategy
tool_fit:
  analyze: 3
  improve: 4
  build: 4
  target: 3
  search: 5
search_weight: 20
curation_status: supporting
curation_note: Included as support guidance because tool-using and agent-like prompts need an explicit rule for when to ask versus act.
summary: Define when the model should ask a clarifying question, make a bounded assumption, or proceed with tools.
description: Ask-vs-Act Threshold is the strategy for controlling eagerness in tool-using or multi-step prompts. Prompt Compass uses it to prevent two common failures: agents that ask endless questions instead of making safe progress, and agents that barrel ahead with tools or assumptions when clarification was required. The strategy makes the boundary explicit by naming low-risk assumptions, high-risk actions, and when the user must be consulted first.
aliases:
  - ask versus act
  - clarification threshold
  - eagerness control
related_entry_ids:
  - tool-contract-prompting
  - stop-condition-contract
  - iterative-clarification-through-follow-up
source_refs:
  - project://support/library/curated/strategies.md
  - import-source://deep-research-recommendations-b
template: |
  Ask a clarifying question when:
  - [high-risk ambiguity]

  Make a bounded assumption when:
  - [low-risk ambiguity]

  Use tools or proceed without asking when:
  - [clear preconditions]
tags:
  - agentic
  - tool-use
  - control
  - support-strategy
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - coding
  - operations
  - research
  - analysis
model_targets:
  - generic
signals:
  - the prompt involves tools, autonomy, or action-taking
  - missing information should not always block progress
  - the user needs an explicit clarification threshold
contraindications:
  - simple one-shot prompts with no action or ambiguity management
interaction_mode: agentic
output_mode: structured
grounding_mode: none
evaluation_mode: none
capability_tags:
  - agentic_tool_use
  - stop_conditions
goal_fit:
  - improve
  - build
  - target
works_best_for:
  - tool-thrash
  - agentic-overrun
  - tool-using prompts with ambiguous autonomy
apply_order: 7
```

## Top-Three-Traits Ranking

```yaml
id: top-three-traits-ranking
title: Top-Three-Traits Ranking
record_type: strategy
source_tier: house_curated
corpus_zone: strategy
tool_fit:
  analyze: 4
  improve: 5
  build: 4
  target: 1
  search: 3
search_weight: 22
curation_status: core
curation_note: Encodes the house rule to rank the top three traits instead of piling adjectives into the prompt.
summary: Reduce a long quality stack to the top three traits in priority order.
description: Top-Three-Traits Ranking is the house strategy for turning vague style pressure into a usable prompt constraint. Instead of letting a prompt ask for clear, strategic, warm, deep, concise, insightful, compelling, and emotionally attuned all at once, this strategy chooses the three qualities that matter most and ranks them. That makes tradeoffs explicit and gives the model clearer steering.
aliases:
  - rank the top three traits
  - trait ranking
  - adjective stack reduction
related_entry_ids:
  - trait-stack-output-control
  - stacked-adjectives
  - short-functional-role-framing
source_refs:
  - project://support/library/curated/strategies.md
  - reference://kyle-prompt-playbook/profile
template: |
  Desired qualities in priority order:
  1. [most important trait]
  2. [second-most important trait]
  3. [third-most important trait]

  Drop all other style words unless they are truly essential.
tags:
  - style-control
  - ranking
  - traits
  - house-style
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - marketing
  - coaching
model_targets:
  - generic
signals:
  - too many adjectives
  - style pressure outweighs task clarity
  - user wants voice tuning without priority
contraindications:
  - highly technical extraction tasks with no stylistic component
goal_fit:
  - diagnose
  - improve
  - build
works_best_for:
  - stacked-adjectives
  - tone-heavy prompts
  - rewrite requests that are vague about quality
apply_order: 4
```

## Must-Haves / Nice-to-Haves / Exclusions

```yaml
id: must-haves-nice-to-haves-exclusions
title: Must-Haves / Nice-to-Haves / Exclusions
record_type: strategy
source_tier: house_curated
corpus_zone: strategy
tool_fit:
  analyze: 4
  improve: 5
  build: 5
  target: 1
  search: 3
search_weight: 23
curation_status: core
curation_note: Encodes the house rule to convert context dumps into priorities and boundaries instead of carrying every detail forward equally.
summary: Sort prompt inputs into required context, optional extras, and explicit exclusions.
description: Must-Haves / Nice-to-Haves / Exclusions is the house strategy for cleaning up raw briefs and overloaded context. It turns an undifferentiated input dump into three priority levels: information the model truly needs, information that helps but is not essential, and content that should be ignored or deferred. That makes prompt scaffolds lighter, more intentional, and easier to trust.
aliases:
  - must haves nice to haves exclusions
  - context triage
  - context priority sorting
related_entry_ids:
  - intent-dump-constraint-sweep
  - source-pack-with-vague-ask
  - clear
source_refs:
  - project://support/library/curated/strategies.md
  - reference://kyle-prompt-playbook/profile
template: |
  Must-haves:
  - [required context or constraints]

  Nice-to-haves:
  - [helpful but optional details]

  Exclusions:
  - [what to ignore, defer, or not cover]

  Build the final prompt from the must-haves first.
tags:
  - context
  - prioritization
  - exclusions
  - house-style
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - strategy
  - writing
  - coding
model_targets:
  - generic
signals:
  - context dump
  - mixed priorities
  - user provides too much background with no ranking
contraindications:
  - prompts with already-curated source packs and explicit asks
goal_fit:
  - diagnose
  - improve
  - build
works_best_for:
  - intent-dump
  - source-pack-with-vague-ask
  - noisy briefs with unclear priorities
apply_order: 3
```

## Short Functional Role Framing

```yaml
id: short-functional-role-framing
title: Short Functional Role Framing
record_type: strategy
source_tier: house_curated
corpus_zone: strategy
tool_fit:
  analyze: 3
  improve: 4
  build: 4
  target: 2
  search: 3
search_weight: 20
curation_status: core
curation_note: Encodes the house rule that role framing should be one short functional line, not a persona stack that crowds out the real job.
summary: Use a short functional role to load judgment without turning the prompt into a persona performance.
description: Short Functional Role Framing is the house strategy for using role cues without overburdening the prompt. It keeps the role to one useful line such as “Act as a careful B2B positioning strategist” or “You are a senior debugging partner,” then moves immediately to the deliverable. This keeps expertise available while avoiding role collapse and tone theater.
aliases:
  - short role framing
  - functional role framing
  - role line first
related_entry_ids:
  - rtf
  - role-collapse
  - role-framing-as-shortcut
source_refs:
  - project://support/library/curated/strategies.md
  - reference://kyle-prompt-playbook/profile
template: |
  Act as a [short functional role].
  Your job is to produce [single deliverable].
  Use the context and constraints below, but do not turn this into a persona performance.
tags:
  - role
  - framing
  - brevity
  - house-style
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - strategy
model_targets:
  - generic
  - claude-sonnet
  - gpt-4o
signals:
  - user wants expertise loaded quickly
  - prompt has too many persona cues
  - role framing is useful but should stay short
contraindications:
  - prompts that already have clean role framing or need no role at all
goal_fit:
  - improve
  - build
  - target
works_best_for:
  - role-collapse
  - role-heavy prompts
  - drafts that need judgment cues without bloat
apply_order: 5
```

## Conditional Prompting

```yaml
id: conditional-prompting
title: Conditional Prompting
record_type: strategy
source_tier: aiglossary_curated
corpus_zone: strategy
tool_fit:
  analyze: 2
  improve: 4
  build: 3
  target: 2
  search: 4
search_weight: 15
curation_status: core
curation_note: Included from AIGlossary because conditional logic is useful when prompt behavior should change based on missing context, confidence, or user answers.
summary: Use if-then logic so the prompt behaves differently when conditions are met.
description: Conditional Prompting is a strategy for prompts that should branch based on information quality, confidence, user state, or diagnostic findings. In Prompt Compass it is helpful when a prompt needs to say what the model should do if context is missing, if uncertainty is high, or if a requested format cannot be completed safely.
aliases:
  - if-then prompting
  - conditional logic prompting
related_entry_ids:
  - clear
  - missing-success-test
  - target-prompt-to-model
source_refs:
  - project://support/library/curated/strategies.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/methodology-checks/calibration/conditional-prompting.json
template: |
  If [condition], do [behavior A].
  If [condition], do [behavior B].
  Otherwise, proceed with [default behavior].

  Final output format: [format]
tags:
  - conditional
  - branching
  - fallback
  - aiglossary
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - research
model_targets:
  - generic
  - claude-sonnet
  - gpt-4o
signals:
  - different behaviors are needed under different conditions
  - fallback logic should be explicit
  - missing information should trigger alternate behavior
contraindications:
  - simple direct prompts that do not need branching logic
goal_fit:
  - improve
  - build
  - target
works_best_for:
  - prompts with conditional fallback needs
  - uncertainty-aware prompts
  - tool or schema dependent instructions
apply_order: 6
```

## Decomposed / Sequential Prompting

```yaml
id: decomposed-sequential-prompting
title: Decomposed / Sequential Prompting
record_type: strategy
source_tier: aiglossary_curated
corpus_zone: strategy
tool_fit:
  analyze: 2
  improve: 4
  build: 4
  target: 1
  search: 4
search_weight: 16
curation_status: core
curation_note: Included from AIGlossary because sequential decomposition is useful when a task needs staged prompt passes instead of one overloaded instruction block.
summary: Break the work into focused prompt stages and pass forward only the needed outputs.
description: Decomposed / Sequential Prompting is a strategy for solving larger tasks across multiple smaller prompt stages. It reduces cognitive load, improves debuggability, and makes it easier to isolate where the prompt is failing. Prompt Compass uses it when a single draft is trying to retrieve, analyze, synthesize, and format all at once.
aliases:
  - decomposed prompting
  - sequential prompting
  - linear prompting
related_entry_ids:
  - least-to-most-prompting
  - chain-of-thought-deliberative-prompting
  - prompt-architecture
source_refs:
  - project://support/library/curated/strategies.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/reasoning-frameworks/argumentation/decomposed-prompting.json
  - external-corpus://AIGlossary/data/critical-thinking/normalized/other/adjacent/sequential-linear-prompting.json
template: |
  Stage 1: [retrieve / gather / inspect]
  Stage 2: [analyze / sort / interpret]
  Stage 3: [draft / synthesize / decide]
  Stage 4: [verify / tighten / format]

  Pass forward only the needed outputs from each stage.
tags:
  - decomposition
  - sequential
  - workflow
  - aiglossary
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - coding
  - research
  - strategy
  - writing
model_targets:
  - generic
signals:
  - prompt is trying to do multiple cognitive jobs at once
  - task quality depends on staging
  - one-pass prompting is failing
contraindications:
  - small tasks where decomposition adds overhead
goal_fit:
  - improve
  - build
works_best_for:
  - complex prompt flows
  - overloaded instruction walls
  - multi-stage deliverables
apply_order: 7
```

## Meta-Prompting / SELF-DISCOVER Selection

```yaml
id: meta-prompting-self-discover-selection
title: Meta-Prompting / SELF-DISCOVER Selection
record_type: strategy
source_tier: aiglossary_curated
corpus_zone: strategy
tool_fit:
  analyze: 2
  improve: 4
  build: 3
  target: 1
  search: 4
search_weight: 14
curation_status: core
curation_note: Included from AIGlossary because it helps prompts choose the right reasoning pattern instead of assuming one default approach.
summary: Tell the model to choose the most fitting reasoning approach before solving the task.
description: Meta-Prompting / SELF-DISCOVER Selection is a strategy for prompts where the core difficulty is selecting the right reasoning mode. Instead of hard-coding one method, the prompt asks the model to choose the best approach from the task context, then apply it. Prompt Compass uses this when method choice should become visible and adjustable.
aliases:
  - meta prompting
  - self-discover selection
  - choose the reasoning approach
related_entry_ids:
  - self-discover
  - chain-of-thought-deliberative-prompting
  - tree-of-thoughts
source_refs:
  - project://support/library/curated/strategies.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/reasoning-frameworks/inference/meta-prompting.json
template: |
  Task: [task]
  Before answering, choose the most useful reasoning approach for this task.
  Briefly state the approach you selected.
  Then apply it to produce: [final deliverable]
tags:
  - meta-prompting
  - method-selection
  - reasoning-choice
  - aiglossary
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - analysis
  - research
  - strategy
  - coding
model_targets:
  - generic
signals:
  - reasoning structure should be chosen, not assumed
  - task is open-ended or ambiguous
  - prompt needs more explicit method control
contraindications:
  - simple formatting, summarization, or extraction tasks
goal_fit:
  - improve
  - build
works_best_for:
  - open-ended analysis
  - complex reasoning prompts
  - advanced prompt scaffolding
apply_order: 8
```

## Diagnosis Before Rewrite

```yaml
id: diagnosis-before-rewrite
title: Diagnosis Before Rewrite
record_type: strategy
source_tier: house_curated
corpus_zone: strategy
tool_fit:
  analyze: 5
  improve: 5
  build: 2
  target: 1
  search: 5
search_weight: 24
curation_status: core
curation_note: Added from Prompt Master principles so Prompt Compass can name the rule that diagnosis should precede substantive prompt rewrites.
summary: Diagnose what is missing, weak, or risky before rewriting the prompt.
description: Diagnosis Before Rewrite is the strategy of making the prompt's failure modes explicit before producing the improved version. It prevents the host AI from jumping straight to a polished rewrite that hides assumptions, misses the real weakness, or changes the user's intent. In Prompt Compass it pairs especially well with diagnose_prompt, Prompt Fingerprinting, anti-pattern repair, and the quick versus advanced routing decision.
aliases:
  - diagnose before rewrite
  - diagnosis first
  - audit before rewrite
related_entry_ids:
  - prompt-fingerprinting
  - prompt-refinement-first
  - analyze_prompt
source_refs:
  - project://support/library/curated/strategies.md
  - /mnt/skills/user/prompt-master/
template: |
  Before rewriting, diagnose:
  - real job
  - missing prompt-contract slots
  - anti-patterns
  - likely assumptions

  Then rewrite only after the diagnosis is visible.
tags:
  - diagnosis
  - rewrite
  - prompt-master
  - support-strategy
phase: 1
prompt_types:
  - transformative
subject_areas:
  - general
  - writing
  - strategy
  - coding
model_targets:
  - generic
signals:
  - user asks to improve a prompt
  - rewrite quality depends on understanding what is broken
  - host AI may be about to polish before diagnosing
contraindications:
  - very small prompts where a quick rewrite is enough and risks are low
interaction_mode: single_turn
output_mode: structured
grounding_mode: none
evaluation_mode: rubric
capability_tags:
  - judge_evaluation
goal_fit:
  - improve
works_best_for:
  - rewrite requests
  - vague prompts
  - prompt critique workflows
apply_order: 1
```

## Terminology Lockdown

```yaml
id: terminology-lockdown
title: Terminology Lockdown
record_type: strategy
source_tier: house_curated
corpus_zone: strategy
tool_fit:
  analyze: 3
  improve: 5
  build: 4
  target: 2
  search: 5
search_weight: 23
curation_status: supporting
curation_note: Added from Prompt Master vocabulary-drift guidance for prompts where term consistency changes the quality or safety of the output.
summary: Define key terms up front so the model does not drift across synonyms, labels, or domain-specific vocabulary.
description: Terminology Lockdown is a strategy for prompts where vocabulary drift can create wrong outputs. The prompt names the terms that must be used, terms that must be avoided, and how ambiguous terms should be handled. Prompt Compass uses this as support guidance for legal, medical, research, product, education, and worldbuilding prompts where terminology changes meaning.
aliases:
  - vocabulary lockdown
  - term table
  - terminology guardrail
related_entry_ids:
  - output-contract-first
  - purposeful-contextual-absences
  - parser-aware-prompting
source_refs:
  - project://support/library/curated/strategies.md
  - /mnt/skills/user/prompt-master/
template: |
  Terminology:
  - Use this term: [term] = [definition]
  - Do not substitute: [forbidden synonyms]
  - If unclear, ask before changing terminology.

  Apply this vocabulary consistently in the final output.
tags:
  - terminology
  - vocabulary
  - consistency
  - prompt-master
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - research
  - coding
  - legal
  - education
model_targets:
  - generic
signals:
  - domain terms must remain stable
  - vocabulary drift would change the answer
  - user has named terms, labels, or canonical language
contraindications:
  - exploratory brainstorming where vocabulary can stay flexible
interaction_mode: single_turn
output_mode: structured
grounding_mode: none
evaluation_mode: none
capability_tags:
  - structured_output
goal_fit:
  - improve
  - build
works_best_for:
  - domain-specific prompts
  - parser-bound outputs
  - style or vocabulary preservation
apply_order: 4
```

## Source-Priority Instructions

```yaml
id: source-priority-instructions
title: Source-Priority Instructions
record_type: strategy
source_tier: house_curated
corpus_zone: strategy
tool_fit:
  analyze: 3
  improve: 4
  build: 4
  target: 3
  search: 5
search_weight: 21
curation_status: supporting
curation_note: Added in Phase 2N to support retrieval, source-pack, and tool-fallback prompts without making broad Atlas browsing a runtime dependency.
summary: State which source wins when retrieved documents, tools, notes, or user claims conflict.
description: Source-Priority Instructions turn source authority into an explicit prompt contract. The prompt names source order, recency rules, conflict handling, and what the model should do when no source is strong enough. This reduces unsupported synthesis and prevents retrieved text, tool output, or meeting notes from being treated as equal when they should not be.
aliases:
  - source priority
  - source hierarchy
  - source precedence
related_entry_ids:
  - missing-source-precedence
  - retrieval-grounding
  - quote-first-evidence-extraction
  - untrusted-context-boundary
source_refs:
  - project://support/library/curated/strategies.md
  - reference://compass-suite-atlas-enhancement-analysis/prompt-compass-enhancement-suggestions
template: |
  Source priority:
  1. [highest-authority source]
  2. [secondary source]
  3. [fallback source]

  If sources conflict, use the highest-authority source and name the conflict.
  If no source answers the question, say what is missing instead of guessing.
tags:
  - source-priority
  - grounding
  - support-strategy
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - research
  - analysis
  - coding
  - operations
model_targets:
  - generic
signals:
  - retrieved documents and tools may conflict
  - multiple source types are present
  - source authority matters
contraindications:
  - prompts with one trusted source and no fallback source
interaction_mode: single_turn
output_mode: structured
grounding_mode: retrieval
evaluation_mode: none
capability_tags:
  - source_priority
  - retrieval_grounding
goal_fit:
  - improve
  - build
  - target
works_best_for:
  - retrieval-grounded prompts
  - source-pack prompts
  - tool fallback prompts
apply_order: 3
```

## Guardrail Configuration Prompting

```yaml
id: guardrail-configuration-prompting
title: Guardrail Configuration Prompting
record_type: strategy
source_tier: house_curated
corpus_zone: strategy
tool_fit:
  analyze: 2
  improve: 4
  build: 4
  target: 3
  search: 5
search_weight: 18
curation_status: supporting
curation_note: Added in Phase 2N as narrow support for prompts that need boundaries, fallback behavior, and validation without expanding Prompt Compass into a safety framework.
summary: Convert vague safety or quality wishes into explicit allowed behavior, fallback behavior, and validation checks.
description: Guardrail Configuration Prompting is a strategy for prompts that need operational boundaries. Instead of saying "be safe" or "do not hallucinate," the prompt states allowed sources, forbidden actions, confirmation rules, fallback behavior, and post-output checks. In Prompt Compass this supports tool, parser, retrieval, and high-stakes writing prompts.
aliases:
  - guardrail prompt
  - guardrails config builder
  - boundary configuration prompt
related_entry_ids:
  - ineffective-negative-constraint
  - tool-contract-prompting
  - stop-condition-contract
  - source-priority-instructions
source_refs:
  - project://support/library/curated/strategies.md
  - reference://compass-suite-atlas-enhancement-analysis/prompt-compass-enhancement-suggestions
template: |
  Guardrails:
  - Allowed sources/actions: [list]
  - Not allowed: [list]
  - Ask before: [high-impact actions]
  - If evidence is missing: [fallback behavior]
  - Validate before final answer: [checks]
tags:
  - guardrails
  - boundaries
  - support-strategy
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - operations
  - research
model_targets:
  - generic
signals:
  - prompt has vague safety language
  - tool use or parser behavior needs boundaries
  - fallback behavior matters
contraindications:
  - low-stakes creative prompts where constraints would block the goal
interaction_mode: tool_calling
output_mode: structured
grounding_mode: retrieval
evaluation_mode: rubric
capability_tags:
  - tool_use
  - parser_aware
  - source_priority
goal_fit:
  - improve
  - build
  - target
works_best_for:
  - tool-workflow prompts
  - parser-bound prompts
  - retrieval-grounded prompts
apply_order: 5
```
