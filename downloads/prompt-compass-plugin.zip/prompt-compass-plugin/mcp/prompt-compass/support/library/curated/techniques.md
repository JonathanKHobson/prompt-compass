# Prompt Compass Technique Records

## Role-Playing Prompting

```yaml
id: role-playing-prompting
title: Role-Playing Prompting
record_type: technique
source_tier: aiglossary_curated
corpus_zone: technique
tool_fit:
  analyze: 2
  improve: 5
  build: 3
  target: 2
  search: 5
search_weight: 18
curation_status: core
curation_note: Included because role-playing is a useful tactical move when a prompt needs a tighter judgment posture without a full framework swap.
summary: Add one targeted role cue to steer judgment, tone, or domain posture.
description: Role-Playing Prompting is the tactic of asking the model to adopt a specific functional role for the task at hand. In Prompt Compass it is treated as a single-move intervention, not a full prompt strategy: a role can quickly sharpen relevance or tone, but it should remain brief and subordinate to the deliverable. A role is a posture cue, not a substitute for grounding, evidence, or tool support.
aliases:
  - role prompting
  - role play prompting
related_entry_ids:
  - short-functional-role-framing
  - role-framing-as-shortcut
  - role-collapse
source_refs:
  - project://support/library/curated/techniques.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/heuristics/judgment/role-playing-prompting.json
template: |
  Act as a [short functional role] with expertise in [domain].
  Use that perspective to produce: [deliverable].
tags:
  - role
  - tactic
  - expertise
  - aiglossary
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - strategy
  - coding
model_targets:
  - generic
signals:
  - user wants expert judgment
  - prompt needs a faster domain cue
  - role would sharpen tone or lens
contraindications:
  - prompts already overloaded with persona language
  - tasks that need no role at all
  - cases where the persona implies expertise the prompt cannot ground
tactic_type: framing
expected_effect: Adds a fast, compact expertise cue that can improve relevance without restructuring the whole prompt.
```

## Divergent Intern

```yaml
id: divergent-intern
title: Divergent Intern
record_type: technique
source_tier: house_curated
corpus_zone: technique
tool_fit:
  analyze: 1
  improve: 4
  build: 4
  target: 1
  search: 5
search_weight: 22
curation_status: supporting
curation_note: Added from Prompt Master style guidance as a safe ideation tactic for generating intentionally naive alternative framings without letting them become the final answer.
summary: Ask the model to generate a naive or lateral alternative framing, then have the main prompt choose what survives.
description: Divergent Intern is a technique for temporarily assigning the model a deliberately naive, lateral, or outsider role so it can surface overlooked framings. Prompt Compass treats it as an ideation move, not a final-answer persona. It works best when the prompt separates the divergent pass from the final synthesis and requires the final response to explain what was adopted, rejected, or refined.
aliases:
  - naive intern pass
  - divergent framing pass
  - outsider framing
related_entry_ids:
  - compression-after-expansion
  - meta-prompting-self-discover-selection
  - diagnosis-before-rewrite
source_refs:
  - project://support/library/curated/techniques.md
  - /mnt/skills/user/prompt-master/
template: |
  First, generate three naive or outsider framings of this prompt.
  Then decide which framing is most useful and why.
  Use only the useful parts in the final prompt.
tags:
  - ideation
  - divergent-thinking
  - prompt-master
  - support-technique
phase: 1
prompt_types:
  - generative
  - transformative
subject_areas:
  - general
  - writing
  - strategy
  - creative
model_targets:
  - generic
signals:
  - the prompt is stuck in one framing
  - the user wants alternate angles before finalizing
  - brainstorming needs a controlled divergent pass
contraindications:
  - parser-bound or high-stakes prompts where speculative alternatives add noise
interaction_mode: single_turn
output_mode: structured
grounding_mode: none
evaluation_mode: none
tactic_type: ideation
expected_effect: Surfaces alternative prompt framings while preserving a disciplined final synthesis step.
```

## Prompt Fingerprinting

```yaml
id: prompt-fingerprinting
title: Prompt Fingerprinting
record_type: technique
source_tier: house_curated
corpus_zone: technique
tool_fit:
  analyze: 3
  improve: 4
  build: 2
  target: 1
  search: 5
search_weight: 22
curation_status: supporting
curation_note: Added from Prompt Master style guidance to help Prompt Compass notice prompt voice, habits, and recurring structure before rewriting.
summary: Identify the style, structure, and recurring habits of a prompt before changing it.
description: Prompt Fingerprinting is the technique of describing a prompt's observable style, structure, and failure tendencies before rewriting it. It can identify whether a prompt is terse, sprawling, role-heavy, source-heavy, adjective-heavy, schema-first, or voice-memo-like. Prompt Compass uses it as support guidance for style-matched improvement and for avoiding rewrites that erase the user's useful working style.
aliases:
  - prompt style fingerprinting
  - prompt voice fingerprint
  - prompt signature
related_entry_ids:
  - diagnosis-before-rewrite
  - trait-stack-output-control
  - voice-memo-dictation-intake
source_refs:
  - project://support/library/curated/techniques.md
  - /mnt/skills/user/prompt-master/
template: |
  Before rewriting, fingerprint the prompt:
  - structure pattern
  - voice and tone
  - recurring strengths
  - recurring failure modes

  Preserve the useful parts and repair only what weakens the task.
tags:
  - diagnosis
  - style
  - prompt-master
  - support-technique
phase: 1
prompt_types:
  - transformative
subject_areas:
  - general
  - writing
  - strategy
model_targets:
  - generic
signals:
  - the rewrite should preserve user voice
  - the prompt has a recognizable style or structure
  - diagnosis should happen before rewriting
contraindications:
  - tiny utility prompts where style preservation is irrelevant
interaction_mode: single_turn
output_mode: structured
grounding_mode: none
evaluation_mode: rubric
capability_tags:
  - judge_evaluation
tactic_type: diagnosis
expected_effect: Helps rewrites improve the prompt without flattening useful style, structure, or intent.
```

## Continuation Instructions

```yaml
id: continuation-instructions
title: Continuation Instructions
record_type: technique
source_tier: house_curated
corpus_zone: technique
tool_fit:
  analyze: 2
  improve: 4
  build: 3
  target: 2
  search: 5
search_weight: 21
curation_status: supporting
curation_note: Added from Prompt Master anti-silent-cap guidance for prompts where length limits or long outputs could cause silent truncation.
summary: Add explicit instructions for what to do when an answer cannot fit in one response.
description: Continuation Instructions tell the model what to do if the response reaches a length, context, or message boundary before the job is complete. In Prompt Compass this is support guidance for long-form writing, large audits, source-heavy synthesis, and multi-part prompt outputs. The instruction should specify how to pause, label continuation state, and resume without silently dropping sections.
aliases:
  - anti silent cap
  - continue instruction
  - continuation protocol
related_entry_ids:
  - long-context-layout
  - compaction
  - stop-condition-contract
source_refs:
  - project://support/library/curated/techniques.md
  - /mnt/skills/user/prompt-master/
template: |
  If the response cannot fit in one message, stop at a clean section boundary.
  End with:
  CONTINUATION NEEDED - last completed section: [section]
  On resume, continue from the next section without repeating completed material.
tags:
  - continuation
  - long-output
  - prompt-master
  - support-technique
phase: 1
prompt_types:
  - generative
  - reductive
  - transformative
subject_areas:
  - writing
  - research
  - coding
  - analysis
model_targets:
  - generic
signals:
  - long output may exceed one message
  - the prompt asks for a full audit, full plan, or complete file
  - silent truncation would be harmful
contraindications:
  - short single-artifact prompts where continuation would add unnecessary ceremony
interaction_mode: multi_turn
output_mode: structured
grounding_mode: none
evaluation_mode: none
capability_tags:
  - long_context
  - stop_conditions
tactic_type: boundary_control
expected_effect: Prevents silent truncation by making continuation behavior explicit and resumable.
```

## Goal Prompting

```yaml
id: goal-prompting
title: Goal Prompting
record_type: technique
source_tier: aiglossary_curated
corpus_zone: technique
tool_fit:
  analyze: 2
  improve: 4
  build: 4
  target: 1
  search: 5
search_weight: 17
curation_status: core
curation_note: Included because it is a clean tactical move for centering a prompt on one outcome when intent is diffuse.
summary: State the primary goal explicitly before adding supporting instructions.
description: Goal Prompting is the tactic of centering the prompt on one explicit goal and treating everything else as support. In Prompt Compass it is useful for narrowing, reframing, and keeping the user’s real job visible when the draft is drifting toward a list of wishes instead of a defined objective.
aliases:
  - goal-first prompting
  - primary goal prompting
related_entry_ids:
  - one-primary-deliverable-narrowing
  - golden-circle
  - single-most-important-thing
source_refs:
  - project://support/library/curated/techniques.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/thinking-lenses/design/goal-prompting.json
template: |
  Primary goal: [the one thing this prompt must accomplish]
  Supporting conditions: [constraints or supporting needs]
  Final deliverable: [artifact]
tags:
  - goal
  - focus
  - tactic
  - aiglossary
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - strategy
  - writing
model_targets:
  - generic
signals:
  - goal is buried
  - user has too many competing wants
  - prompt needs a single center of gravity
contraindications:
  - prompts whose primary goal is already explicit and stable
tactic_type: framing
expected_effect: Pulls the prompt back to one central objective so downstream instructions support a real job instead of competing with it.
```

## Prompt Template Engineering

```yaml
id: prompt-template-engineering
title: Prompt Template Engineering
record_type: technique
source_tier: aiglossary_curated
corpus_zone: technique
tool_fit:
  analyze: 1
  improve: 4
  build: 4
  target: 2
  search: 5
search_weight: 16
curation_status: core
curation_note: Included because template thinking is a reusable tactical move for repeatable prompt classes and scaffolds.
summary: Convert a successful prompt shape into a reusable template with fillable slots.
description: Prompt Template Engineering is the tactic of turning a one-off successful prompt into a reusable scaffold with named slots. Prompt Compass uses it as a way to make strong prompt structures repeatable across similar tasks without rebuilding the logic from scratch each time. In modern prompt workflows, the template should also preserve the change rationale, success criteria, and the small eval examples that keep later revisions honest.
aliases:
  - template engineering
  - prompt templating
  - reusable prompt template
related_entry_ids:
  - prompt-composition
  - specification-by-example
  - prompt-architecture
  - eval-first-prompting
source_refs:
  - project://support/library/curated/techniques.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/other/adjacent/prompt-template-engineering.json
template: |
  Role: [role]
  Objective: [objective]
  Context: [context]
  Constraints: [constraints]
  Output Contract: [format + success test]
tags:
  - templates
  - reuse
  - scaffolding
  - aiglossary
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - writing
  - research
model_targets:
  - generic
signals:
  - prompt pattern repeats often
  - user wants a reusable scaffold
  - stable slot structure exists
contraindications:
  - highly bespoke one-off prompts with no reuse value
tactic_type: templating
expected_effect: Makes a successful prompt structure reusable and easier to fill, adapt, and debug later.
```

## Self-Critique Prompting

```yaml
id: self-critique-prompting
title: Self-Critique Prompting
record_type: technique
source_tier: aiglossary_curated
corpus_zone: technique
tool_fit:
  analyze: 2
  improve: 5
  build: 3
  target: 1
  search: 5
search_weight: 18
curation_status: core
curation_note: Included because self-critique is a practical tactical move for tightening drafts before finalizing them.
summary: Ask the model to critique its own draft for errors, gaps, or bias before returning the final result.
description: Self-Critique Prompting is the tactic of inserting one review pass in which the model checks its own draft for weaknesses before finalizing it. Prompt Compass uses it as a lightweight same-model quality pass, not as the default answer for higher-stakes evaluation. When the task needs explicit criteria, failure examples, or a stronger revision loop, Prompt Compass should prefer Eval-First Prompting or an Evaluator-Optimizer Loop.
aliases:
  - self critique
  - critique then revise
related_entry_ids:
  - raccca
  - prompt-refinement-first
  - missing-success-test
  - eval-first-prompting
  - evaluator-optimizer-loop
source_refs:
  - project://support/library/curated/techniques.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/biases/ai/self-critique-prompting.json
template: |
  Draft the answer.
  Then critique your draft for:
  - errors
  - missing context
  - weak reasoning
  - unclear structure
  Revise once before returning the final answer.
tags:
  - critique
  - revision
  - quality
  - aiglossary
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - research
  - writing
model_targets:
  - generic
signals:
  - draft likely needs a quality pass
  - user wants stronger reliability
  - one extra revision loop would help
contraindications:
  - extremely time-sensitive prompts where a critique pass would add unwanted latency
tactic_type: revision
expected_effect: Adds a lightweight quality-control pass that can catch gaps or weak spots before the answer is finalized.
```

## Calibrated Confidence Prompting (CCP)

```yaml
id: calibrated-confidence-prompting
title: Calibrated Confidence Prompting (CCP)
record_type: technique
source_tier: aiglossary_curated
corpus_zone: technique
tool_fit:
  analyze: 2
  improve: 4
  build: 3
  target: 2
  search: 5
search_weight: 17
curation_status: core
curation_note: Included because confidence labeling is a useful tactical move whenever a prompt risks false certainty.
summary: Require the model to label confidence and uncertainty instead of sounding equally certain about every claim.
description: Calibrated Confidence Prompting is the tactic of asking the model to express confidence levels, uncertainty, or evidence gaps explicitly. Prompt Compass uses it for prompts where unsupported certainty would be misleading and where the user would benefit from knowing which parts of the answer are solid versus speculative.
aliases:
  - ccp
  - confidence labeling
  - calibrated certainty
related_entry_ids:
  - hallucination-bait
  - clear
  - conditional-prompting
source_refs:
  - project://support/library/curated/techniques.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/reasoning-frameworks/uncertainty/calibrated-confidence-prompting-ccp.json
template: |
  Answer the question.
  For each important claim, label confidence as:
  - high
  - medium
  - low

  If confidence is not high, say what information would raise it.
tags:
  - confidence
  - uncertainty
  - grounding
  - aiglossary
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - research
  - coding
  - strategy
  - general
model_targets:
  - generic
signals:
  - certainty needs to be calibrated
  - missing evidence is likely
  - user would benefit from explicit uncertainty
contraindications:
  - purely creative tasks where confidence labeling adds noise
tactic_type: calibration
expected_effect: Reduces false certainty by making confidence and evidence gaps explicit inside the answer.
```

## Deliberative Prompting (Reflective Pausing)

```yaml
id: deliberative-pausing
title: Deliberative Prompting (Reflective Pausing)
record_type: technique
source_tier: manual_core
corpus_zone: technique
tool_fit:
  analyze: 2
  improve: 4
  build: 3
  target: 1
  search: 4
search_weight: 19
curation_status: core
curation_note: Gives Prompt Compass a lightweight tactical version of deliberate reasoning without invoking a full reasoning framework every time.
summary: Insert one reflective pause so the model checks the task and plan before answering.
description: Deliberative Prompting (Reflective Pausing) is the tactic of telling the model to pause, inspect the task, and think through the likely pitfalls before finalizing the answer. Unlike a full chain-of-thought scaffold, this is a compact move meant to improve care and reduce impulsive first-pass responses.
aliases:
  - reflective pausing
  - deliberate pause
  - think before finalizing
related_entry_ids:
  - chain-of-thought-deliberative-prompting
  - self-critique-prompting
  - missing-success-test
source_refs:
  - project://support/library/curated/techniques.md
template: |
  Before answering, pause and check:
  - what the task is really asking
  - what could go wrong
  - what the final output must include

  Then return the final answer only.
tags:
  - deliberation
  - pause
  - care
  - tactic
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - coding
  - research
  - analysis
  - writing
model_targets:
  - generic
signals:
  - prompt is likely to invite a rushed answer
  - quality depends on one reflective check
  - task has hidden pitfalls
contraindications:
  - trivial tasks where added reflection adds only latency
tactic_type: reflection
expected_effect: Encourages one brief quality pause before the final answer, improving care without requiring a full decomposition scaffold.
```

## Keyword Prompting

```yaml
id: keyword-prompting
title: Keyword Prompting
record_type: technique
source_tier: manual_core
corpus_zone: technique
tool_fit:
  analyze: 1
  improve: 4
  build: 2
  target: 1
  search: 4
search_weight: 15
curation_status: core
curation_note: Included as a lightweight tactical move for anchoring prompts around a few high-signal terms when full prose instructions are not yet stable.
summary: Use a small set of high-signal task keywords to anchor the prompt around what matters most.
description: Keyword Prompting is the tactic of identifying a few high-signal task nouns or labels that the prompt should keep visible, especially when the user’s brief is diffuse. Prompt Compass uses it as a tactical way to tighten retrieval keywords, preserve domain specificity, and reduce drift in early drafts.
aliases:
  - keyword anchor prompting
  - prompt keyword anchoring
related_entry_ids:
  - intent-dump-constraint-sweep
  - output-contract-first
  - prompt-template-engineering
source_refs:
  - project://support/library/curated/techniques.md
template: |
  Keep these anchor terms central to the task:
  - [keyword]
  - [keyword]
  - [keyword]

  Use them to keep the prompt focused while writing the final instruction.
tags:
  - keywords
  - anchoring
  - focus
  - tactic
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - research
  - strategy
model_targets:
  - generic
signals:
  - important task nouns are getting buried
  - prompt needs stronger anchor terms
  - early draft is diffuse
contraindications:
  - already-clear prompts where keywords would just repeat what is obvious
tactic_type: anchoring
expected_effect: Keeps the prompt centered on a few high-signal concepts so the final wording drifts less.
```

## Contextual Absences

```yaml
id: purposeful-contextual-absences
title: Contextual Absences
record_type: technique
source_tier: house_curated
corpus_zone: technique
tool_fit:
  analyze: 1
  improve: 4
  build: 3
  target: 1
  search: 4
search_weight: 16
curation_status: core
curation_note: This is the intentional version of context removal: a tactical move for trimming irrelevant background so the prompt stays sharp.
summary: Remove non-essential context on purpose so the real job stays visible.
description: Contextual Absences is the tactic of deliberately leaving out context that does not materially help the model complete the task. In Prompt Compass it is the positive, intentional opposite of sloppy missing context. The move is to preserve only essential background and let unnecessary history, side details, or stylistic clutter drop away.
aliases:
  - purposeful contextual absences
  - contextual absences
  - contextual-absences
  - intentional context removal
  - context trimming
related_entry_ids:
  - must-haves-nice-to-haves-exclusions
  - instruction-wall
  - one-primary-deliverable-narrowing
source_refs:
  - project://support/library/curated/techniques.md
template: |
  Keep only the context that is essential for this task.
  Remove:
  - historical detail that does not change the answer
  - side quests
  - flavor text that does not affect the deliverable

  Final task: [task]
tags:
  - context
  - trimming
  - focus
  - house-style
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - strategy
model_targets:
  - generic
signals:
  - too much background is crowding out the task
  - prompt can improve by subtraction
  - context should be trimmed, not expanded
contraindications:
  - tasks where the omitted context would materially change the answer
tactic_type: pruning
expected_effect: Sharpens the prompt by removing irrelevant background so the model can see the real task more clearly.
```

## Few-Shot Prompting

```yaml
id: few-shot-prompting
title: Few-Shot Prompting
record_type: technique
source_tier: manual_core
corpus_zone: technique
tool_fit:
  analyze: 2
  improve: 5
  build: 4
  target: 2
  search: 5
search_weight: 20
curation_status: core
curation_note: Included because examples are now a first-class prompt primitive and often outperform extra prose instructions.
summary: Show a small number of examples that demonstrate what good output looks like.
description: Few-Shot Prompting is the tactic of steering the model with a handful of clear examples rather than relying only on abstract instructions. In Prompt Compass it is useful when formatting, phrasing, scope, or judgment style need to be demonstrated concretely. The preferred form is minimum canonical examples, not a giant edge-case dump. Start with the smallest set that makes the pattern obvious, then add more only when the model keeps missing the same behavior.
aliases:
  - few shot prompting
  - example driven prompting
  - demonstration prompting
related_entry_ids:
  - specification-by-example
  - prompt-template-engineering
  - output-contract-first
source_refs:
  - project://support/library/curated/techniques.md
  - https://ai.google.dev/gemini-api/docs/prompting-strategies
template: |
  Task:
  [task]

  Follow the pattern shown in these minimum canonical examples:
  Example 1:
  Input: [input]
  Output: [ideal output]

  Example 2:
  Input: [input]
  Output: [ideal output]

  Now complete:
  [new input]
tags:
  - examples
  - few-shot
  - formatting
  - prompt-primitive
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - research
model_targets:
  - generic
signals:
  - instructions alone are too vague
  - desired format or phrasing is easier to show than describe
  - the task depends on pattern imitation
contraindications:
  - examples would introduce the wrong style or narrow the task too much
  - the task is so simple that one clear instruction is enough
interaction_mode: single_turn
output_mode: structured
grounding_mode: none
evaluation_mode: none
capability_tags:
  - few_shot_examples
tactic_type: demonstration
expected_effect: Makes the target behavior visible so the model can copy the right pattern instead of inferring it from vague instruction prose.
```

## XML Or Delimiter Structuring

```yaml
id: xml-or-delimiter-structuring
title: XML Or Delimiter Structuring
record_type: technique
source_tier: manual_core
corpus_zone: technique
tool_fit:
  analyze: 2
  improve: 5
  build: 4
  target: 3
  search: 5
search_weight: 21
curation_status: core
curation_note: Included because XML-style structure is a modern high-signal tactic for separating instructions, context, examples, and inputs.
summary: Separate instructions, context, examples, and inputs with explicit tags or delimiters.
description: XML Or Delimiter Structuring is the tactic of wrapping prompt parts in clear boundaries so the model can parse them unambiguously. Prompt Compass uses it when prompts mix instructions, context, source material, and user inputs that would otherwise blur together. The goal is not XML for its own sake; it is structural separation that reduces confusion and format drift.
aliases:
  - xml prompting
  - xml tags
  - delimiter structuring
related_entry_ids:
  - prompt-composition
  - instruction-wall
  - structured-outputs
source_refs:
  - project://support/library/curated/techniques.md
  - https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices#structure-prompts-with-xml-tags
template: |
  <instructions>
  [what the model should do]
  </instructions>

  <context>
  [relevant background]
  </context>

  <examples>
  [optional examples]
  </examples>

  <input>
  [the current task input]
  </input>
tags:
  - xml
  - delimiters
  - structure
  - prompt-primitive
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - research
  - analysis
model_targets:
  - generic
signals:
  - prompt parts are bleeding together
  - multiple documents or source blocks are involved
  - formatting or instruction boundaries keep getting lost
contraindications:
  - trivial prompts where tags would add more noise than clarity
interaction_mode: single_turn
output_mode: structured
grounding_mode: source_pack
evaluation_mode: none
capability_tags:
  - xml_structure
  - structured_output
tactic_type: structuring
expected_effect: Makes prompt parts legible and separable, which reduces misinterpretation and keeps complex prompts easier to follow.
```

## Structured Output Steering

```yaml
id: structured-output-steering
title: Structured Output Steering
record_type: technique
source_tier: manual_core
corpus_zone: technique
tool_fit:
  analyze: 3
  improve: 5
  build: 4
  target: 3
  search: 5
search_weight: 22
curation_status: core
curation_note: Included because structured outputs are now a core prompt primitive and a common repair target for weak drafts.
summary: Tell the model exactly what shape to return, not just what topic to address.
description: Structured Output Steering is the tactic of specifying the output shape in concrete structural terms such as fields, sections, keys, or table columns. Prompt Compass applies it when users need predictable formatting, downstream parsing, or easier evaluation. The technique treats output shape as part of the task contract, not an afterthought. When another system must parse the result reliably, Prompt Compass should push further toward schema-first contracts instead of relying on formatting prose alone.
aliases:
  - structured output steering
  - output structuring
  - schema aware prompting
related_entry_ids:
  - output-contract-first
  - json-schema-outputs
  - missing-success-test
  - schema-first-output-contract
source_refs:
  - project://support/library/curated/techniques.md
  - https://ai.google.dev/gemini-api/docs/structured-output
template: |
  Return the answer in this structure:
  - [field or section]
  - [field or section]
  - [field or section]

  Do not add extra wrapper text outside that structure.
tags:
  - structure
  - output-control
  - parsing
  - prompt-primitive
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - research
  - analysis
model_targets:
  - generic
signals:
  - output needs to be parseable or checkable
  - the user cares about stable sections or fields
  - a weak draft needs stronger response boundaries
contraindications:
  - open-ended ideation where rigid structure would prematurely narrow the response
interaction_mode: single_turn
output_mode: structured
grounding_mode: none
evaluation_mode: rubric
capability_tags:
  - structured_output
tactic_type: output_control
expected_effect: Produces more predictable, reusable output and reduces format drift in the final answer.
```

## JSON Schema Outputs

```yaml
id: json-schema-outputs
title: JSON Schema Outputs
record_type: technique
source_tier: manual_core
corpus_zone: technique
tool_fit:
  analyze: 3
  improve: 5
  build: 4
  target: 4
  search: 5
search_weight: 22
curation_status: core
curation_note: Included because schema-bound outputs are a modern prompt primitive for reliable machine-readable results.
summary: Bind the output to a JSON schema when the response needs strict machine-readable structure.
description: JSON Schema Outputs is the tactic of telling the model to produce JSON that conforms to an explicit schema. Prompt Compass uses it when the prompt needs reliable downstream parsing, validation, or tool chaining. It is stronger than a casual “return JSON” instruction because the schema makes the contract explicit and testable. In Phase 1.8 it sits inside a schema-first cluster: define fields, required values, null behavior, and validation expectations before worrying about stylistic phrasing.
aliases:
  - json schema output
  - schema bound json
  - schema bound outputs
related_entry_ids:
  - structured-output-steering
  - output-contract-first
  - function-calling
  - schema-first-output-contract
source_refs:
  - project://support/library/curated/techniques.md
  - https://ai.google.dev/gemini-api/docs/structured-output
template: |
  Return valid JSON only.
  The response must match this schema:
  {
    "type": "object",
    "properties": {
      "[field]": {"type": "string"},
      "[field]": {"type": "array"}
    },
    "required": ["[field]"]
  }
tags:
  - json
  - schema
  - structured-output
  - prompt-primitive
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - coding
  - research
  - analysis
  - operations
model_targets:
  - generic
signals:
  - output is consumed by code or another tool
  - stable field validation matters
  - plain JSON instructions have been drifting
contraindications:
  - tasks where freeform prose is the desired final artifact
interaction_mode: single_turn
output_mode: schema_bound
grounding_mode: none
evaluation_mode: rubric
capability_tags:
  - structured_output
  - json_schema
tactic_type: schema_control
expected_effect: Increases machine-readability and lowers the chance that the model returns loosely formatted JSON-like text instead of valid schema-shaped output.
```

## Tool-Use Prompting

```yaml
id: tool-use-prompting
title: Tool-Use Prompting
record_type: technique
source_tier: manual_core
corpus_zone: technique
tool_fit:
  analyze: 3
  improve: 5
  build: 4
  target: 4
  search: 5
search_weight: 21
curation_status: core
curation_note: Included because tool-using models need explicit guidance on when to call tools and when to synthesize the final answer.
summary: Specify when the model should call tools, what tools are for, and what to do after tool results return.
description: Tool-Use Prompting is the tactic of making tool invocation explicit inside the prompt contract. Prompt Compass uses it for prompts that rely on APIs, search, retrieval, or function execution so the model does not guess blindly or over-call tools. The technique works best when it states the trigger for tool use, the intended output after tool use, and any constraints on unnecessary calls.
aliases:
  - tool use
  - tool calling prompting
  - function-aware prompting
related_entry_ids:
  - function-calling
  - retrieval-grounding
  - structured-output-steering
source_refs:
  - project://support/library/curated/techniques.md
  - https://ai.google.dev/gemini-api/docs/function-calling
template: |
  Use available tools only when they materially improve the answer.
  Call a tool when:
  - [condition]
  - [condition]

  After tool results return:
  - synthesize the final answer
  - cite or label tool-derived facts
  - do not call more tools unless the result is still incomplete
tags:
  - tools
  - function-calling
  - orchestration
  - prompt-primitive
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - coding
  - research
  - operations
  - analysis
model_targets:
  - generic
signals:
  - the prompt depends on external tools or APIs
  - the model needs a rule for when to call tools
  - the final answer should synthesize tool results, not just dump them
contraindications:
  - models or contexts where no tools are actually available
interaction_mode: tool_calling
output_mode: structured
grounding_mode: retrieval
evaluation_mode: none
capability_tags:
  - function_calling
  - tool_use
tactic_type: orchestration
expected_effect: Makes tool behavior more deliberate so the model knows when to fetch help and when to finish the job itself.
```

## Long-Context Layout

```yaml
id: long-context-layout
title: Long-Context Layout
record_type: technique
source_tier: manual_core
corpus_zone: technique
tool_fit:
  analyze: 3
  improve: 5
  build: 4
  target: 3
  search: 5
search_weight: 20
curation_status: core
curation_note: Included because modern models can take large context, but poor layout still causes drift, priority loss, and retrieval misses.
summary: Arrange long prompts so the job, priority instructions, and source blocks stay easy to recover.
description: Long-Context Layout is the tactic of ordering a large prompt so the model can keep track of the job, source material, and response contract without getting lost in a wall of context. Prompt Compass uses it when the user provides long transcripts, many documents, or heavy background. The emphasis is on hierarchy: stable instructions first, structured source blocks next, variable request details last. In Phase 1.8 it also links to compaction, carry-forward notes, and source-priority handling so long context becomes a managed working state rather than a giant dump.
aliases:
  - long context prompting
  - context layout
  - long prompt layout
related_entry_ids:
  - xml-or-delimiter-structuring
  - context-injection-via-source-pack
  - prompt-caching
  - compaction
  - long-context-salience-management
source_refs:
  - project://support/library/curated/techniques.md
  - https://developers.openai.com/api/docs/models/gpt-5.4
  - https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices
template: |
  Priority instructions:
  [core job and output contract]

  Context map:
  - Source 1: [what it contains]
  - Source 2: [what it contains]

  Source blocks:
  [documents or excerpts]

  Current task:
  [what to do with the context]
tags:
  - long-context
  - hierarchy
  - layout
  - prompt-primitive
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - research
  - coding
  - strategy
  - analysis
model_targets:
  - generic
signals:
  - the prompt contains long transcripts or many documents
  - important instructions are getting buried under context
  - the model needs a map for large context
contraindications:
  - short prompts where extra hierarchy would be unnecessary ceremony
interaction_mode: single_turn
output_mode: structured
grounding_mode: source_pack
evaluation_mode: none
capability_tags:
  - long_context
  - structured_output
tactic_type: layout
expected_effect: Preserves priority and navigation inside large prompts so the model can find the job and the sources without instruction drift.
```

## Retrieval Grounding

```yaml
id: retrieval-grounding
title: Retrieval Grounding
record_type: technique
source_tier: manual_core
corpus_zone: technique
tool_fit:
  analyze: 3
  improve: 5
  build: 4
  target: 3
  search: 5
search_weight: 21
curation_status: core
curation_note: Included because retrieval-backed prompts need explicit grounding instructions, not just access to a knowledge source.
summary: Tell the model how to use retrieved material and what to do when retrieval is thin or conflicting.
description: Retrieval Grounding is the tactic of making retrieved evidence part of the prompt contract. Prompt Compass uses it when the model should answer from search results, a vector store, or a knowledge base rather than from free recall. The move is to define how retrieval should be used, how evidence should be prioritized, and how uncertainty should be handled if relevant information is missing.
aliases:
  - rag grounding
  - retrieval based prompting
  - knowledge grounded prompting
related_entry_ids:
  - tool-use-prompting
  - quote-first-evidence-extraction
  - source-pack-with-vague-ask
source_refs:
  - project://support/library/curated/techniques.md
  - https://ai.google.dev/gemini-api/docs/function-calling
template: |
  Use retrieved context as the primary evidence base.
  Prioritize:
  1. the most relevant retrieved passages
  2. explicit contradictions or gaps
  3. a short uncertainty note if retrieval is insufficient

  Then return:
  [final artifact]
tags:
  - retrieval
  - grounding
  - evidence
  - prompt-primitive
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - research
  - coding
  - analysis
  - operations
model_targets:
  - generic
signals:
  - the prompt depends on retrieved context or search results
  - the answer should be grounded in evidence instead of memory
  - uncertainty should be tied to retrieval gaps
contraindications:
  - tasks where no retrieval layer or external evidence source exists
interaction_mode: tool_calling
output_mode: structured
grounding_mode: retrieval
evaluation_mode: rubric
capability_tags:
  - retrieval_grounding
  - tool_use
tactic_type: grounding
expected_effect: Lowers hallucination risk by tying the answer to retrieved evidence and making gaps visible instead of guessed through.
```

## Quote-First Evidence Extraction

```yaml
id: quote-first-evidence-extraction
title: Quote-First Evidence Extraction
record_type: technique
source_tier: manual_core
corpus_zone: technique
tool_fit:
  analyze: 3
  improve: 5
  build: 4
  target: 2
  search: 5
search_weight: 20
curation_status: core
curation_note: Included because quote-first prompting is a practical grounding move for evidence-sensitive summarization and synthesis.
summary: Extract exact evidence before summarizing, judging, or synthesizing.
description: Quote-First Evidence Extraction is the tactic of requiring the model to pull forward exact passages or specific evidence before it writes the synthesized answer. Prompt Compass uses it when trust, attribution, or factual discipline matters more than fast paraphrase. The technique is especially useful for source packs, transcripts, grading, and retrieval-backed prompts.
aliases:
  - quote first
  - evidence first extraction
  - extract then synthesize
related_entry_ids:
  - retrieval-grounding
  - context-injection-via-source-pack
  - source-pack-with-vague-ask
source_refs:
  - project://support/library/curated/techniques.md
  - https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices
template: |
  Step 1: extract the most relevant exact quotes or passages.
  Step 2: briefly explain what each quote shows.
  Step 3: synthesize the final answer using only that evidence.

  Source material:
  [text]
tags:
  - quotes
  - evidence
  - grounding
  - prompt-primitive
phase: 1
prompt_types:
  - reductive
  - transformative
subject_areas:
  - research
  - writing
  - analysis
  - education
model_targets:
  - generic
signals:
  - exact evidence matters before synthesis
  - the user wants quotes, citations, or passage discipline
  - the prompt should reduce unsupported paraphrase
contraindications:
  - open-ended ideation with no source material to quote from
interaction_mode: single_turn
output_mode: structured
grounding_mode: quote_first
evaluation_mode: rubric
capability_tags:
  - quote_first_evidence
  - retrieval_grounding
tactic_type: extraction
expected_effect: Forces the answer to anchor itself in visible evidence before interpretation, which improves traceability and reduces unsupported synthesis.
```

## Self-Refine Prompting

```yaml
id: self-refine-prompting
title: Self-Refine Prompting
record_type: technique
source_tier: house_curated
corpus_zone: technique
tool_fit:
  analyze: 2
  improve: 5
  build: 3
  target: 1
  search: 5
search_weight: 18
curation_status: supporting
curation_note: Curated support technique for iterative prompt revision once a draft exists, kept out of the deterministic core until the Phase 1.7 eval bar is met.
summary: Run one explicit critique-and-rewrite loop so a draft prompt gets materially better instead of only being restated.
description: Self-Refine Prompting is the tactic of drafting, critiquing, and revising a prompt in one bounded loop. In Prompt Compass it is narrower than a general self-critique move: it is specifically about using the first draft to expose missing blocks, weak framing, or loose output control, then tightening the prompt once before finalizing it.
aliases:
  - self refine prompting
  - critique revise prompting
  - refine once prompting
related_entry_ids:
  - self-critique-prompting
  - prompt-refinement-first
  - raccca
source_refs:
  - project://support/library/curated/techniques.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/reasoning-frameworks/self-improvement/self-refine-prompting.json
template: |
  Draft the prompt.
  Then critique the draft for:
  - missing context
  - vague instructions
  - weak output control
  - unnecessary scope
  Revise the prompt once and return only the improved version.
tags:
  - revision
  - refinement
  - prompt quality
  - house-curated
phase: 1
prompt_types:
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - coding
  - strategy
model_targets:
  - generic
signals:
  - user already has a draft prompt
  - first draft is close but under-specified
  - one critique-and-rewrite pass would improve the prompt materially
contraindications:
  - tasks where a full multi-pass evaluation loop would be overkill
  - prompts that still lack the basic objective or audience
interaction_mode: multi_turn
evaluation_mode: rubric
tactic_type: revision
expected_effect: Produces a tighter second-pass prompt with clearer task framing, fewer gaps, and stronger output control.
```

## Prompt-Based Evaluation

```yaml
id: prompt-based-evaluation
title: Prompt-Based Evaluation
record_type: technique
source_tier: house_curated
corpus_zone: technique
tool_fit:
  analyze: 3
  improve: 5
  build: 2
  target: 1
  search: 5
search_weight: 17
curation_status: core
curation_note: Graduated to the deterministic core in Phase 1.8 after clearing the promotion eval bar on rubric-led review and rewrite cases without regressions.
summary: Use an explicit rubric or scorecard to judge prompt quality before choosing or revising a draft.
description: Prompt-Based Evaluation is the tactic of treating prompts as artifacts that can be graded against explicit criteria such as clarity, completeness, grounding, or output control. In Prompt Compass it is used for prompt review, prompt comparison, and rewrite recommendation when intuition alone would be too vague.
aliases:
  - prompt evaluation
  - rubric-based prompt review
  - prompt grading
related_entry_ids:
  - raccca
  - missing-success-test
  - self-critique-prompting
  - eval-first-prompting
  - evaluator-optimizer-loop
  - llm-as-judge
source_refs:
  - project://support/library/curated/techniques.md
  - external-corpus://AIGlossary/data/critical-thinking/normalized/methodology-checks/audit/prompt-based-evaluation.json
template: |
  Evaluate the prompt against this rubric:
  - task clarity
  - context sufficiency
  - output control
  - grounding quality
  - likely failure modes
  Score each criterion, explain the weakest area, and recommend one revised prompt.
tags:
  - evaluation
  - rubric
  - prompt review
  - house-curated
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - writing
  - research
  - analysis
model_targets:
  - generic
signals:
  - user needs to compare prompt options
  - prompt quality needs explicit criteria rather than taste
  - a rewrite should be justified by a scorecard or rubric
contraindications:
  - cases where the user only needs a direct rewrite and not a formal evaluation pass
  - tasks with no stable criteria for comparison
evaluation_mode: rubric
tactic_type: evaluation
expected_effect: Makes prompt review more consistent and explainable by turning vague judgment into explicit criteria and revision advice.
```

## Compaction

```yaml
id: compaction
title: Compaction
record_type: technique
source_tier: house_curated
corpus_zone: technique
tool_fit:
  analyze: 2
  improve: 4
  build: 3
  target: 1
  search: 5
search_weight: 18
curation_status: supporting
curation_note: Included as support guidance because long-running prompt workflows need a way to compress stale context without losing decisions or evidence.
summary: Compress long history or source material into a smaller carry-forward note that preserves only what still matters.
description: Compaction is the tactic of reducing long conversation state, source material, or tool output into a smaller task-relevant working note. Prompt Compass uses it as support guidance for long-context and multi-turn workflows where everything technically fits, but not everything should keep competing for attention. Good compaction preserves decisions, unresolved questions, evidence anchors, and the next action while dropping noise.
aliases:
  - context compaction
  - carry-forward summary
  - context compression
related_entry_ids:
  - long-context-layout
  - context-engineering
  - prompt-caching
source_refs:
  - project://support/library/curated/techniques.md
  - project://docs/specs/deep_research_recommendations.md
  - import-source://deep-research-recommendations-b
template: |
  Compress the material below into a carry-forward note that preserves only:
  - locked decisions
  - key evidence or citations
  - unresolved questions
  - next action

  Omit repetitive background and stale context.
tags:
  - compaction
  - long-context
  - carry-forward
  - support-technique
phase: 1
prompt_types:
  - reductive
  - transformative
subject_areas:
  - general
  - research
  - coding
  - analysis
  - operations
model_targets:
  - generic
signals:
  - the prompt includes long history or many source blocks
  - stale context is crowding the live task
  - the next prompt needs a compact carry-forward state
contraindications:
  - tiny prompts where the source material is already minimal
interaction_mode: multi_turn
output_mode: structured
grounding_mode: source_pack
evaluation_mode: none
capability_tags:
  - context_compaction
  - long_context
tactic_type: compression
expected_effect: Reduces stale context so the next prompt can focus on the live task without losing key decisions or evidence.
```

## Parser-Aware Prompting

```yaml
id: parser-aware-prompting
title: Parser-Aware Prompting
record_type: technique
source_tier: house_curated
corpus_zone: technique
tool_fit:
  analyze: 2
  improve: 5
  build: 4
  target: 3
  search: 5
search_weight: 19
curation_status: supporting
curation_note: Included as support guidance because many prompt failures are really parser-contract failures rather than wording failures.
summary: Design the output for the downstream parser, workflow, or automation that will consume it.
description: Parser-Aware Prompting is the tactic of designing prompts around the system that will read the result next. In Prompt Compass it matters when JSON, YAML, CSV, XML, function arguments, or sectioned outputs feed another workflow. The tactic pushes the writer to specify required fields, empty-value behavior, escaping expectations, and what should happen when the model cannot satisfy the contract cleanly.
aliases:
  - parser aware prompting
  - parser-ready prompting
  - automation-aware prompting
related_entry_ids:
  - structured-output-steering
  - json-schema-outputs
  - schema-first-output-contract
source_refs:
  - project://support/library/curated/techniques.md
  - import-source://deep-research-recommendations-b
template: |
  Produce output for this downstream parser or workflow:
  - Required fields: [fields]
  - Allowed values or schema rules: [rules]
  - Empty or missing data behavior: [policy]
  - Refusal or error behavior: [policy]

  Return only the parser-ready output.
tags:
  - parser
  - automation
  - structured-output
  - support-technique
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - coding
  - operations
  - analysis
  - research
model_targets:
  - generic
signals:
  - the output will be parsed downstream
  - strict machine readability matters more than prose polish
  - failure handling must be part of the output contract
contraindications:
  - purely human-readable prompts where no parser or automation depends on exact structure
interaction_mode: single_turn
output_mode: schema_bound
grounding_mode: none
evaluation_mode: rubric
capability_tags:
  - parser_aware
  - structured_output
  - json_schema
tactic_type: contract_design
expected_effect: Makes automation-facing outputs more reliable by aligning the prompt with the downstream parser instead of only describing the topic.
```
