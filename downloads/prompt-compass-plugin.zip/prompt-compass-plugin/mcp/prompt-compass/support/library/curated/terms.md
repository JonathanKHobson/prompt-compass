# Prompt Compass Term Records

## Structured Outputs

```yaml
id: structured-outputs
title: Structured Outputs
record_type: term
source_tier: manual_core
corpus_zone: term
tool_fit:
  analyze: 2
  improve: 3
  build: 2
  target: 3
  search: 5
search_weight: 20
curation_status: core
curation_note: Included because structured outputs are now a first-class prompt-engineering concept and retrieval target.
summary: A prompting approach where the response shape is constrained to explicit sections, fields, keys, or schemas.
description: Structured Outputs is the general prompt-engineering concept of constraining model responses into a known shape instead of relying on freeform prose. In Prompt Compass this term anchors the family of tactics that use tables, labeled sections, JSON, XML, or schemas so output can be parsed, checked, or reused more reliably.
aliases:
  - structured output
  - output structuring
  - schema aware output
related_entry_ids:
  - structured-output-steering
  - json-schema-outputs
  - output-contract-first
source_refs:
  - project://support/library/curated/terms.md
  - https://ai.google.dev/gemini-api/docs/structured-output
template: ""
tags:
  - structured-output
  - output-control
  - term
  - prompt-primitive
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - analysis
  - operations
model_targets:
  - generic
signals:
  - the user needs predictable response shape
  - the output is reused downstream
  - formatting drift is causing problems
contraindications:
  - purely exploratory prompts where open prose is the desired artifact
interaction_mode: single_turn
output_mode: structured
grounding_mode: none
evaluation_mode: rubric
capability_tags:
  - structured_output
term_kind: prompt-primitive
```

## Function Calling

```yaml
id: function-calling
title: Function Calling
record_type: term
source_tier: manual_core
corpus_zone: term
tool_fit:
  analyze: 2
  improve: 3
  build: 2
  target: 4
  search: 5
search_weight: 20
curation_status: core
curation_note: Included because function calling is now a standard prompt surface for modern tool-capable models.
summary: A prompt/tool interface where the model returns or requests structured function arguments instead of only natural-language text.
description: Function Calling is the prompt-engineering concept of guiding a model to emit structured arguments for a named function or tool. In Prompt Compass it now sits inside a schema-first cluster with Structured Outputs, JSON Schema Outputs, and Tool-Use Prompting. The important distinction is that tool use is not just a formatting trick. The prompt should specify when a function should be called, what information it should supply, how tool failures should be handled, and what the final answer should look like after the call.
aliases:
  - function call
  - tool function calling
  - tool arguments prompting
related_entry_ids:
  - tool-use-prompting
  - json-schema-outputs
  - structured-outputs
  - schema-first-output-contract
source_refs:
  - project://support/library/curated/terms.md
  - https://ai.google.dev/gemini-api/docs/function-calling
template: ""
tags:
  - function-calling
  - tools
  - term
  - prompt-primitive
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - coding
  - operations
  - research
  - analysis
model_targets:
  - generic
signals:
  - the user wants the model to call a tool or API
  - the response needs structured function arguments
  - the model should switch between tools and final synthesis
contraindications:
  - plain text-only chat settings with no tool or function interface
interaction_mode: tool_calling
output_mode: schema_bound
grounding_mode: retrieval
evaluation_mode: none
capability_tags:
  - function_calling
  - tool_use
term_kind: prompt-primitive
```

## Prompt Caching

```yaml
id: prompt-caching
title: Prompt Caching
record_type: term
source_tier: manual_core
corpus_zone: term
tool_fit:
  analyze: 0
  improve: 1
  build: 1
  target: 2
  search: 5
search_weight: 16
curation_status: supporting
curation_note: Included as searchable support knowledge because prompt caching shapes prompt layout and cost/latency strategy, but should not steer the deterministic rewrite loop by default.
summary: A provider/runtime optimization where repeated prompt prefixes are reused to lower latency or cost.
description: Prompt Caching is the concept of structuring prompts so their stable prefix can be reused across repeated requests. In Prompt Compass it matters as support knowledge because it affects how large prompt templates, instructions, examples, and source packets should be ordered. It now sits closer to Long-Context Layout and Compaction because cache-aware layout is really a context-state design problem, not just a cost footnote. It is searchable and targetable, but it does not automatically drive diagnosis or rewriting unless the user is explicitly optimizing for cache reuse.
aliases:
  - cached prompts
  - cached prefix prompting
  - prompt prefix caching
related_entry_ids:
  - long-context-layout
  - prompt-template-engineering
  - structured-outputs
  - compaction
source_refs:
  - project://support/library/curated/terms.md
  - https://developers.openai.com/api/docs/guides/prompt-caching
template: ""
tags:
  - caching
  - latency
  - cost
  - support-term
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - operations
  - coding
  - general
model_targets:
  - gpt-5.4
  - gpt-4o
  - gpt-4-turbo
signals:
  - the user cares about repeated prompt reuse
  - stable instructions and examples should sit before variable content
  - cost or latency optimization matters
contraindications:
  - one-off prompts where cache reuse does not matter
interaction_mode: single_turn
output_mode: freeform
grounding_mode: none
evaluation_mode: none
capability_tags:
  - prompt_caching
term_kind: optimization
```

## Context Engineering

```yaml
id: context-engineering
title: Context Engineering
record_type: term
source_tier: manual_core
corpus_zone: term
tool_fit:
  analyze: 3
  improve: 4
  build: 3
  target: 2
  search: 5
search_weight: 24
curation_status: core
curation_note: Included because Prompt Compass now needs a first-class term for the layer above prompt wording: context selection, ordering, compression, and trust boundaries.
summary: The practice of deciding what context the model sees, in what order, with what boundaries, and for what immediate task.
description: Context Engineering is the broader discipline that surrounds prompt wording. In Prompt Compass it means selecting the smallest sufficient context for the current task, separating instructions from evidence, ordering sources so important constraints stay salient, compressing stale history, and carrying forward only what should persist. This record helps reframe Prompt Compass as a prompt-improvement system that also understands context delivery, not just sentence-level prompt polish.
aliases:
  - context design
  - working-state design
  - prompt plus context engineering
related_entry_ids:
  - context-injection-via-source-pack
  - long-context-layout
  - compaction
  - untrusted-context-boundary
source_refs:
  - project://support/library/curated/terms.md
  - project://docs/specs/deep_research_recommendations.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - context-engineering
  - runtime-layer
  - context-design
  - core-term
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - research
  - coding
  - analysis
  - operations
model_targets:
  - generic
signals:
  - the prompt depends on large context, retrieved material, or multi-turn state
  - the user is really struggling with context selection, not just wording
  - source ordering or trust boundaries matter
contraindications:
  - tiny one-shot prompts where context design adds no meaningful leverage
interaction_mode: multi_turn
output_mode: freeform
grounding_mode: retrieval
evaluation_mode: none
capability_tags:
  - context_engineering
  - long_context
  - retrieval_grounding
term_kind: system-part
```

## LLM as Judge

```yaml
id: llm-as-judge
title: LLM as Judge
record_type: term
source_tier: house_curated
corpus_zone: term
tool_fit:
  analyze: 2
  improve: 2
  build: 1
  target: 1
  search: 5
search_weight: 18
curation_status: supporting
curation_note: Included as support knowledge because judge-style evaluation is important for modern prompt workflows, but the term itself should not become an automatic recommendation without explicit eval need.
summary: An evaluation setup where a model grades, compares, or critiques candidate outputs against explicit criteria.
description: LLM as Judge is the idea of using a model in an evaluator role instead of only as a direct answer generator. In Prompt Compass this is support knowledge for rubric-driven review, critique loops, and prompt evaluation workflows. The important guardrail is that judge prompts still need explicit criteria, failure examples, and escalation rules. The term alone is not enough to guarantee reliable evaluation.
aliases:
  - llm judge
  - judge model
  - model as evaluator
related_entry_ids:
  - eval-first-prompting
  - evaluator-optimizer-loop
  - prompt-based-evaluation
source_refs:
  - project://support/library/curated/terms.md
  - project://docs/specs/deep_research_recommendations.md
  - import-source://deep-research-recommendations-b
template: ""
tags:
  - evaluation
  - judge
  - support-term
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - analysis
  - research
  - operations
model_targets:
  - generic
signals:
  - the user needs a grading pass, comparison, or explicit critique loop
  - rubric-driven prompt improvement matters
  - a rewrite should be justified by criteria instead of taste
contraindications:
  - low-stakes rewrites where a direct improvement is enough
interaction_mode: multi_turn
output_mode: structured
grounding_mode: none
evaluation_mode: grader
capability_tags:
  - judge_evaluation
term_kind: concept
```

## Context Window Selection

```yaml
id: context-window-selection
title: Context Window Selection
record_type: term
source_tier: supporting_term
corpus_zone: term
tool_fit:
  analyze: 1
  improve: 2
  build: 2
  target: 3
  search: 5
search_weight: 15
curation_status: supporting
curation_note: Added in Phase 2N as narrow Atlas-informed support for long-context and context-engineering prompts.
summary: Choosing what should enter the model context window for the current task instead of loading everything available.
description: Context Window Selection is the prompt-engineering decision of choosing the smallest useful context packet for a task. It asks what evidence, instructions, examples, history, and constraints should be visible now, what can be summarized, and what should stay out to avoid distraction or anchoring. In Prompt Compass this remains support knowledge for long-context, retrieval, and source-pack prompts.
aliases:
  - context selection
  - context window choice
  - context packet selection
related_entry_ids:
  - context-engineering
  - long-context-layout
  - compaction
  - source-priority-instructions
source_refs:
  - project://support/library/curated/terms.md
  - reference://compass-suite-atlas-enhancement-analysis/prompt-compass-enhancement-suggestions
template: ""
tags:
  - context
  - long-context
  - support-term
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - research
  - analysis
  - coding
model_targets:
  - generic
signals:
  - many sources or documents are available
  - the prompt risks loading irrelevant context
  - context ordering or exclusion matters
contraindications:
  - tiny one-shot prompts with no external context
interaction_mode: single_turn
output_mode: freeform
grounding_mode: source_pack
evaluation_mode: none
capability_tags:
  - context_engineering
  - long_context
term_kind: support-concept
```

## Prompt Brittleness Diagnosis

```yaml
id: prompt-brittleness-diagnosis
title: Prompt Brittleness Diagnosis
record_type: term
source_tier: supporting_term
corpus_zone: term
tool_fit:
  analyze: 2
  improve: 2
  build: 1
  target: 2
  search: 5
search_weight: 15
curation_status: supporting
curation_note: Added in Phase 2N to operationalize prompt brittleness diagnosis without colliding with the imported support term.
summary: Diagnose when a prompt works only under narrow hidden assumptions and breaks under realistic variants.
description: Prompt Brittleness Diagnosis names the review move for finding brittle prompts. It looks for hidden assumptions, fragile wording, vague source precedence, loose schema language, or model-specific behavior that is not stated. In Prompt Compass this term supports diagnosis and comparison when a prompt seems to work in one example but fails across realistic variants.
aliases:
  - prompt brittleness
  - brittle prompt
  - fragile prompt
  - prompt fragility
related_entry_ids:
  - output-contract-first
  - schema-first-output-contract
  - source-priority-instructions
  - trait-priority-conflict
source_refs:
  - project://support/library/curated/terms.md
  - reference://compass-suite-atlas-enhancement-analysis/prompt-compass-enhancement-suggestions
template: ""
tags:
  - reliability
  - prompt-quality
  - support-term
phase: 1
prompt_types:
  - reductive
  - transformative
  - generative
subject_areas:
  - general
  - coding
  - analysis
model_targets:
  - generic
signals:
  - the prompt works for one example but not another
  - small wording or model changes break the result
  - hidden assumptions are doing too much work
contraindications:
  - intentionally experimental prompts where variation is the goal
interaction_mode: single_turn
output_mode: freeform
grounding_mode: none
evaluation_mode: comparison
capability_tags:
  - judge_evaluation
term_kind: failure-mode
```
