# Prompt Compass Curation Manifest

_Generated: 2026-05-09T13:06:20-07:00_

_Compiled DB: `/Volumes/KyleSSD/prompt-compass/db/prompt-compass.sqlite`_

## Summary

- Total compiled records: `186`

### Compiled Counts By Record Type

- `technique`: `44`
- `pattern`: `27`
- `strategy`: `24`
- `anti_pattern`: `22`
- `term`: `22`
- `framework`: `20`
- `question`: `18`
- `model_profile`: `9`

### Compiled Counts By Curation Status

- `core`: `106`
- `supporting`: `80`

### Compiled Counts By Source Tier

- `manual_core`: `59`
- `aiglossary_curated`: `55`
- `house_curated`: `55`
- `supporting_term`: `17`

### Compiled Counts By Corpus Zone

- `technique`: `44`
- `pattern`: `27`
- `strategy`: `24`
- `anti_pattern`: `22`
- `term`: `22`
- `framework`: `20`
- `question`: `18`
- `model_profile`: `9`

## Import Decision Summary

- Approved imported records: `60`
- Excluded imported candidates: `208`

### Decisions

- `excluded`: `208`
- `support_only`: `52`
- `promote_to_core`: `7`
- `graduated_core`: `1`

### Approved Families

- `evaluation_reflection`: `13`
- `support_terms`: `13`
- `decomposition_sequencing`: `10`
- `role_goal_output_control`: `10`
- `context_grounding`: `7`
- `systems_architecture`: `4`
- `task_shape`: `3`

### Approved Origin Buckets

- `other_adjacent`: `22`
- `methodology_audit`: `13`
- `methodology_preflight`: `10`
- `reasoning_frameworks`: `8`
- `thinking_lenses`: `6`
- `biases_ai`: `1`

### Excluded Rule Counts

- `not_yet_curated`: `182`
- `security_and_adversarial`: `9`
- `vague_prompter_personas`: `8`
- `product_or_brand_specific`: `4`
- `image_and_multimodal`: `3`
- `auto_prompt_generation`: `1`
- `phase2_agentic_or_model_optimization`: `1`

## Compiled Records

| slug | name | record_type | curation_status | source_tier | corpus_zone | search_weight | decision | driver_eligible | capability_tags | curation_note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| scope-sprawl | Scope Sprawl | anti_pattern | core | manual_core | anti_pattern | 26 | curated | true |  | Scope Sprawl is a flagship Prompt Compass diagnostic because the product exists partly to turn sprawling asks into one usable prompt. |
| missing-success-test | Missing Success Test | anti_pattern | core | manual_core | anti_pattern | 25 | curated | true |  | Prompt Compass needs a distinct anti-pattern for prompts that name outputs but never say what would make them usable. |
| ghost-audience | Ghost Audience | anti_pattern | core | manual_core | anti_pattern | 24 | curated | true |  | One of the most common prompt failures is persuasive or tone-heavy instruction with no named reader. |
| hallucination-bait | Hallucination Bait | anti_pattern | core | manual_core | anti_pattern | 23 | curated | true |  | Prompt Compass needs a clear diagnostic for prompts that pressure certainty without grounding. |
| ineffective-negative-constraint | Ineffective Negative Constraint | anti_pattern | core | house_curated | anti_pattern | 22 | curated | true | source_priority | Added from Phase 2H/2J user testing because phrases like "do not hallucinate" read as safety instructions but do not define enforceable grounding behavior. |
| instruction-wall | Instruction Wall | anti_pattern | core | manual_core | anti_pattern | 22 | curated | true |  | This is the core diagnostic for overstuffed prompts that are long but still poorly structured. |
| missing-source-precedence | Missing Source Precedence | anti_pattern | core | house_curated | anti_pattern | 22 | curated | true | tool_use, retrieval_grounding, source_priority | Added from Phase 2H/2J user testing because retrieval plus tool fallback needs an explicit conflict rule. |
| source-pack-with-vague-ask | Source Pack with Vague Ask | anti_pattern | core | manual_core | anti_pattern | 22 | curated | true |  | This is the specific grounding anti-pattern for prompts that attach sources but never clarify the real job those sources should support. |
| unresolved-output-branch-conflict | Unresolved Output Branch Conflict | anti_pattern | core | house_curated | anti_pattern | 22 | curated | true | structured_output | Added from Phase 2H/2J user testing because mutually exclusive output shapes can pass structural preflight while still breaking runtime behavior. |
| context-hoarding | Context Hoarding | anti_pattern | core | house_curated | anti_pattern | 21 | curated | true | long_context | Included because long-context failures often come from dumping everything into the prompt instead of selecting the smallest sufficient context. |
| dual-model-targeting-conflict | Dual-Model Targeting Conflict | anti_pattern | core | house_curated | anti_pattern | 21 | curated | true |  | Added from Phase 2H/2J user testing because prompts targeting Claude and GPT-style models equally can produce contradictory optimization rules. |
| schema-theater | Schema Theater | anti_pattern | core | house_curated | anti_pattern | 21 | curated | true | structured_output, parser_aware | Included because many modern prompt failures say return JSON without defining a real parser contract. |
| stacked-adjectives | Stacked Adjectives | anti_pattern | core | manual_core | anti_pattern | 21 | curated | true |  | Prompt Compass needs a direct diagnosis for trait stacks without priority because this is one of the most common style failures. |
| tool-thrash | Tool Thrash | anti_pattern | core | house_curated | anti_pattern | 20 | curated | true | tool_use, agentic_tool_use, stop_conditions, function_calling | Included because tool-capable prompts fail when they encourage repeated low-value tool calls without boundaries or stopping rules. |
| trusted-source-collapse | Trusted-Source Collapse | anti_pattern | core | house_curated | anti_pattern | 20 | curated | true | retrieval_grounding | Included because retrieved or pasted content should usually be treated as evidence, not as a new instruction source. |
| vague-compression | Vague Compression | anti_pattern | core | manual_core | anti_pattern | 20 | curated | true |  | This anti-pattern catches the common rewrite request that asks for “better” without defining what “better” means. |
| middle-buried-requirement | Middle-Buried Requirement | anti_pattern | core | house_curated | anti_pattern | 19 | curated | true | long_context | Included because long prompts often hide the real constraint in the middle of a source pack where it loses salience. |
| role-collapse | Role Collapse | anti_pattern | core | manual_core | anti_pattern | 19 | curated | true |  | Prompt Compass needs a distinct anti-pattern for competing persona stacks because they regularly crowd out the deliverable. |
| vague-style-directive | Vague Style Directive | anti_pattern | core | house_curated | anti_pattern | 19 | curated | true | few_shot_examples | Added from Phase 2H/2J user testing because "be creative" was missed as an unmeasurable instruction. |
| agentic-overrun | Agentic Overrun | anti_pattern | core | house_curated | anti_pattern | 18 | curated | true | agentic_tool_use, stop_conditions | Included because agent-like prompts fail when they keep going past the user’s actual success condition. |
| premature-format-lock | Premature Format Lock | anti_pattern | core | manual_core | anti_pattern | 18 | curated | true | structured_output | This catches prompts that specify a format before the real job is stable enough to support it. |
| raccca | RACCCA | framework | core | manual_core | framework | 27 | curated | true | judge_evaluation | RACCCA is the primary diagnostic rubric for Prompt Compass and anchors the scoring layer. |
| costar | COSTAR | framework | core | manual_core | framework | 26 | curated | true |  | COSTAR is the most complete all-purpose prompt scaffold in Phase 1 and is especially strong for rewrite and build flows. |
| eval-first-prompting | Eval-First Prompting | framework | core | manual_core | framework | 25 | curated | true | judge_evaluation | Included because reusable prompt improvement now needs explicit success criteria and test cases before revision, not just better wording. |
| prompt-composition | Prompt Composition | framework | core | manual_core | framework | 25 | curated | true | few_shot_examples | Prompt Composition is the main framework for assembling layered prompt parts into a clean final prompt without instruction sprawl. |
| risen | RISEN | framework | core | manual_core | framework | 24 | curated | true |  | RISEN is the main scope-control scaffold for turning messy user intent into a single focused prompt. |
| prompt-architecture | Prompt Architecture | framework | core | manual_core | framework | 23 | curated | true |  | Prompt Architecture is the systems-level framework for arranging prompt layers, memory, tools, and checks without losing the core user job. |
| golden-circle | Golden Circle | framework | core | manual_core | framework | 21 | curated | true |  | Keeps Prompt Compass anchored to purpose-first prompt design when users start with outputs before intent. |
| clear | CLEAR | framework | core | manual_core | framework | 20 | curated | true |  | CLEAR is the Phase 1 framework for prompts that need explicit limits and execution expectations, not just more context. |
| rtf | RTF | framework | core | manual_core | framework | 19 | curated | true |  | RTF is the fastest lightweight cleanup scaffold when a prompt mostly works but lacks explicit framing. |
| self-discover | SELF-DISCOVER | framework | core | manual_core | framework | 18 | curated | true |  | SELF-DISCOVER is the Phase 1 framework for prompts where method selection itself is part of the problem. |
| chain-of-thought-deliberative-prompting | Chain-of-Thought / Deliberative Prompting | framework | core | manual_core | framework | 17 | curated | true |  | This is the main Phase 1 reasoning scaffold for tasks that genuinely require staged thinking before a final answer. |
| least-to-most-prompting | Least-to-Most Prompting | framework | core | manual_core | framework | 17 | curated | true |  | Least-to-Most is the staged decomposition scaffold for prompts that are too large to solve in one leap. |
| tree-of-thoughts | Tree of Thoughts | framework | core | manual_core | framework | 16 | curated | true |  | Tree of Thoughts is the comparison-heavy reasoning scaffold for prompts where alternatives need to be explored before committing. |
| gpt-5.5 | GPT-5.5 | model_profile | core | manual_core | model_profile | 28 | curated | true | tool_use | Current OpenAI frontier family profile for agentic coding, long-horizon tool use, and real-work knowledge tasks. |
| gpt-5.4 | GPT-5.4 | model_profile | core | manual_core | model_profile | 27 | curated | true | structured_output, long_context, multimodal | Current OpenAI flagship family profile for long-context, structured prompting, and schema-sensitive output work. |
| claude-sonnet-4 | Claude Sonnet 4 | model_profile | core | manual_core | model_profile | 26 | curated | true | xml_structure, structured_output, tool_use, long_context, multimodal | Current Anthropic Sonnet family profile for structured prompts, long context, and tool-capable workflows. |
| claude-opus-4 | Claude Opus 4 | model_profile | core | manual_core | model_profile | 25 | curated | true | structured_output, tool_use, long_context, multimodal | Current Anthropic Opus family profile for high-depth reasoning, long context, and tool-aware prompting. |
| claude-haiku-4 | Claude Haiku 4 | model_profile | core | manual_core | model_profile | 24 | curated | true |  | Current Anthropic Haiku family profile for fast, cost-aware prompting with near-frontier intelligence. |
| gemini-2.5-pro | Gemini 2.5 Pro | model_profile | core | manual_core | model_profile | 24 | curated | true | structured_output, json_schema, function_calling, long_context, multimodal, tool_use | Current Gemini high-capability profile for long-context reasoning, structured outputs, and function calling. |
| gemini-2.5-flash | Gemini 2.5 Flash | model_profile | core | manual_core | model_profile | 23 | curated | true | structured_output, function_calling, long_context, multimodal, tool_use | Current Gemini fast profile for tool use, structured outputs, and multimodal inputs with tighter prompt discipline. |
| gpt-4o | GPT-4o | model_profile | core | manual_core | model_profile | 21 | curated | true |  | Legacy compatibility OpenAI profile kept because many existing prompts and host UIs still target GPT-4o explicitly. |
| gpt-4-turbo | GPT-4 Turbo | model_profile | core | manual_core | model_profile | 19 | curated | true | structured_output | Legacy compatibility OpenAI profile retained for existing integrations that still name GPT-4 Turbo. |
| voice-memo-dictation-intake | Voice Memo / Dictation Intake | pattern | core | house_curated | pattern | 30 | curated | true | context_engineering | Added from Kyle's working style so Prompt Compass can retrieve the correct cleanup pattern for voice memo, dictation, and stream-of-consciousness prompt intake. |
| evaluator-optimizer-loop | Evaluator-Optimizer Loop | pattern | core | manual_core | pattern | 24 | curated | true | judge_evaluation | Included because modern prompt improvement often needs an explicit draft, judge, and revise loop instead of vague self-critique language. |
| intent-dump-constraint-sweep | Intent Dump + Constraint Sweep | pattern | core | house_curated | pattern | 24 | curated | true |  | This pattern is a primary bridge from messy raw user language into a usable prompt contract. |
| trait-stack-output-control | Trait-Stack Output Control | pattern | core | house_curated | pattern | 23 | curated | true |  | Converts vague style stacks into ranked output controls, which is a recurring Prompt Compass repair move. |
| context-injection-via-source-pack | Context Injection via Source Pack | pattern | core | house_curated | pattern | 22 | curated | true | quote_first_evidence, source_priority | This is the main pattern for grounding prompts with source material without letting the source pack become the task. |
| prompt-refinement-first | Prompt Refinement First | pattern | core | house_curated | pattern | 22 | curated | true |  | Preserves user intent while improving structure, which is a central Prompt Compass improvement behavior. |
| compression-after-expansion | Compression After Expansion | pattern | core | house_curated | pattern | 21 | curated | true |  | Captures the useful pattern of widening the thought space first, then compressing toward the final concise prompt or artifact. |
| iterative-clarification-through-follow-up | Iterative Clarification Through Follow-Up | pattern | core | house_curated | pattern | 21 | curated | true |  | Mirrors the bounded question-loop behavior Prompt Compass uses when a draft is close but under-specified. |
| specification-by-example | Specification by Example | pattern | core | house_curated | pattern | 20 | curated | true | few_shot_examples | Helps Prompt Compass turn vague stylistic or structural asks into concrete examples the model can emulate. |
| research-profile-deep-dive | Research / Profile Deep-Dive | pattern | core | house_curated | pattern | 19 | curated | true |  | Captures the broad-synthesis pattern that often needs strong narrowing to avoid sprawling prompt requests. |
| role-framing-as-shortcut | Role Framing as Shortcut | pattern | core | house_curated | pattern | 19 | curated | true |  | Keeps role framing useful and compressed instead of letting it become persona clutter. |
| multi-axis-organizing-prompt | Multi-Axis Organizing Prompt | pattern | core | house_curated | pattern | 18 | curated | true | structured_output | Helps Prompt Compass identify and repair prompts that need explicit sorting logic across more than one dimension. |
| reductive-prompting | Reductive Prompting | pattern | core | aiglossary_curated | pattern | 16 | curated | true | structured_output | Included from AIGlossary as the canonical pattern for extraction, summarization, and controlled reduction tasks. |
| generative-prompting | Generative Prompting | pattern | core | aiglossary_curated | pattern | 15 | curated | true |  | Included from AIGlossary as the canonical broad pattern for open-ended creation tasks in Prompt Compass. |
| output-format-and-length-limit | Output Format and Length Limit | question | core | manual_core | question | 24 | curated | true |  | This is one of the first output-contract questions because missing format guidance causes large quality swings. |
| single-most-important-thing | Single Most Important Thing | question | core | manual_core | question | 24 | curated | true |  | This is the highest-leverage narrowing question for prompts that are trying to do too much. |
| successful-response-look-like | What Does a Successful Response Look Like to You? | question | core | manual_core | question | 23 | curated | true |  | This is a top-priority question because it surfaces the success test that many weak prompts never state. |
| first-pass-usability-test | First-Pass Usability Test | question | core | manual_core | question | 22 | curated | true | judge_evaluation | This is the second success-test question so Prompt Compass does not stop at format and still miss practical usefulness. |
| one-thing-only | One Thing Only | question | core | manual_core | question | 22 | curated | true |  | Reinforces scope reduction by forcing the user to choose one artifact under pressure. |
| intended-reader | Intended Reader | question | core | manual_core | question | 21 | curated | true |  | Audience clarity is a high-leverage repair step for prompts that are persuasive, stylistic, or decision-facing. |
| parser-or-human-reader | Parser or Human Reader | question | core | house_curated | question | 21 | curated | true | structured_output, parser_aware | Included because machine-readable prompts need different output-contract repair than human-readable ones. |
| agent-stop-condition | Agent Stop Condition | question | core | house_curated | question | 20 | curated | true | agentic_tool_use, stop_conditions | Included because tool-using and agent-like prompts need a clear definition of done. |
| context-source-of-truth | Context Source of Truth | question | core | house_curated | question | 20 | curated | true | retrieval_grounding, context_engineering, source_priority | Included because source-grounded prompts need an explicit boundary between instructions and supporting evidence. |
| missing-context-needed | Missing Context Needed | question | core | manual_core | question | 20 | curated | true |  | This question fills high-leverage context gaps without encouraging the user to dump every possible detail. |
| runtime-layer | Runtime Layer | question | core | house_curated | question | 20 | curated | true | tool_use | Included because many prompt problems are really workflow-shape problems rather than wording-only problems. |
| what-not-to-cover | What Should the AI Explicitly Not Do or Cover? | question | core | manual_core | question | 20 | curated | true |  | This question is the clearest way to turn vague scope control into an explicit exclusion list. |
| belongs-in-follow-up | Belongs in a Follow-Up | question | core | manual_core | question | 19 | curated | true |  | This question helps split prompts into now versus later, which is central to Prompt Compass’s narrowing posture. |
| failure-examples | Failure Examples | question | core | house_curated | question | 19 | curated | true | few_shot_examples | Included because explicit failure cases improve evaluation quality more than vague quality adjectives. |
| source-priority | Source Priority | question | core | house_curated | question | 18 | curated | true | retrieval_grounding, source_priority | Included because grounded prompts need a visible rule for what source should win when documents conflict. |
| tool-confirmation-boundary | Tool Confirmation Boundary | question | core | house_curated | question | 18 | curated | true | tool_use, agentic_tool_use | Included because tool-using prompts often need a clear user-confirmation boundary before high-impact actions. |
| model-or-product | Which Model or Product? | question | core | manual_core | question | 18 | curated | true |  | This question supports the model-targeting pass without forcing it before the core contract is stable. |
| trait-priority | Trait Priority | question | core | manual_core | question | 17 | curated | true |  | This question operationalizes the house rule that adjective piles must be ranked, not merely collected. |
| schema-first-output-contract | Schema-First Output Contract | strategy | core | manual_core | strategy | 26 | curated | true | structured_output, json_schema, parser_aware | Included because parser-ready and automation-facing prompts need field-level contracts, not just loose formatting instructions. |
| output-contract-first | Output-Contract-First | strategy | core | house_curated | strategy | 25 | curated | true | structured_output | Encodes the house rule that the format, length, and success test should be visible before stylistic polishing. |
| diagnosis-before-rewrite | Diagnosis Before Rewrite | strategy | core | house_curated | strategy | 24 | curated | true | judge_evaluation | Added from Prompt Master principles so Prompt Compass can name the rule that diagnosis should precede substantive prompt rewrites. |
| one-primary-deliverable-narrowing | One-Primary-Deliverable Narrowing | strategy | core | house_curated | strategy | 24 | curated | true |  | Encodes the house rule that every prompt should drive one concrete deliverable instead of several parallel asks. |
| must-haves-nice-to-haves-exclusions | Must-Haves / Nice-to-Haves / Exclusions | strategy | core | house_curated | strategy | 23 | curated | true |  | Encodes the house rule to convert context dumps into priorities and boundaries instead of carrying every detail forward equally. |
| top-three-traits-ranking | Top-Three-Traits Ranking | strategy | core | house_curated | strategy | 22 | curated | true |  | Encodes the house rule to rank the top three traits instead of piling adjectives into the prompt. |
| short-functional-role-framing | Short Functional Role Framing | strategy | core | house_curated | strategy | 20 | curated | true |  | Encodes the house rule that role framing should be one short functional line, not a persona stack that crowds out the real job. |
| decomposed-sequential-prompting | Decomposed / Sequential Prompting | strategy | core | aiglossary_curated | strategy | 16 | curated | true |  | Included from AIGlossary because sequential decomposition is useful when a task needs staged prompt passes instead of one overloaded instruction block. |
| conditional-prompting | Conditional Prompting | strategy | core | aiglossary_curated | strategy | 15 | curated | true |  | Included from AIGlossary because conditional logic is useful when prompt behavior should change based on missing context, confidence, or user answers. |
| meta-prompting-self-discover-selection | Meta-Prompting / SELF-DISCOVER Selection | strategy | core | aiglossary_curated | strategy | 14 | curated | true |  | Included from AIGlossary because it helps prompts choose the right reasoning pattern instead of assuming one default approach. |
| json-schema-outputs | JSON Schema Outputs | technique | core | manual_core | technique | 22 | curated | true | structured_output, json_schema, parser_aware | Included because schema-bound outputs are a modern prompt primitive for reliable machine-readable results. |
| structured-output-steering | Structured Output Steering | technique | core | manual_core | technique | 22 | curated | true | structured_output | Included because structured outputs are now a core prompt primitive and a common repair target for weak drafts. |
| retrieval-grounding | Retrieval Grounding | technique | core | manual_core | technique | 21 | curated | true | retrieval_grounding, tool_use | Included because retrieval-backed prompts need explicit grounding instructions, not just access to a knowledge source. |
| tool-use-prompting | Tool-Use Prompting | technique | core | manual_core | technique | 21 | curated | true | function_calling, tool_use, retrieval_grounding | Included because tool-using models need explicit guidance on when to call tools and when to synthesize the final answer. |
| xml-or-delimiter-structuring | XML Or Delimiter Structuring | technique | core | manual_core | technique | 21 | curated | true | xml_structure, structured_output, few_shot_examples | Included because XML-style structure is a modern high-signal tactic for separating instructions, context, examples, and inputs. |
| few-shot-prompting | Few-Shot Prompting | technique | core | manual_core | technique | 20 | curated | true | few_shot_examples | Included because examples are now a first-class prompt primitive and often outperform extra prose instructions. |
| long-context-layout | Long-Context Layout | technique | core | manual_core | technique | 20 | curated | true | long_context, structured_output, context_engineering, context_compaction, source_priority | Included because modern models can take large context, but poor layout still causes drift, priority loss, and retrieval misses. |
| quote-first-evidence-extraction | Quote-First Evidence Extraction | technique | core | manual_core | technique | 20 | curated | true | quote_first_evidence, retrieval_grounding | Included because quote-first prompting is a practical grounding move for evidence-sensitive summarization and synthesis. |
| deliberative-pausing | Deliberative Prompting (Reflective Pausing) | technique | core | manual_core | technique | 19 | curated | true |  | Gives Prompt Compass a lightweight tactical version of deliberate reasoning without invoking a full reasoning framework every time. |
| role-playing-prompting | Role-Playing Prompting | technique | core | aiglossary_curated | technique | 18 | curated | true |  | Included because role-playing is a useful tactical move when a prompt needs a tighter judgment posture without a full framework swap. |
| self-critique-prompting | Self-Critique Prompting | technique | core | aiglossary_curated | technique | 18 | curated | true | few_shot_examples, judge_evaluation | Included because self-critique is a practical tactical move for tightening drafts before finalizing them. |
| calibrated-confidence-prompting | Calibrated Confidence Prompting (CCP) | technique | core | aiglossary_curated | technique | 17 | curated | true |  | Included because confidence labeling is a useful tactical move whenever a prompt risks false certainty. |
| goal-prompting | Goal Prompting | technique | core | aiglossary_curated | technique | 17 | curated | true |  | Included because it is a clean tactical move for centering a prompt on one outcome when intent is diffuse. |
| prompt-based-evaluation | Prompt-Based Evaluation | technique | core | house_curated | technique | 17 | curated | true | judge_evaluation | Graduated to the deterministic core in Phase 1.8 after clearing the promotion eval bar on rubric-led review and rewrite cases without regressions. |
| purposeful-contextual-absences | Contextual Absences | technique | core | house_curated | technique | 16 | curated | true |  | This is the intentional version of context removal: a tactical move for trimming irrelevant background so the prompt stays sharp. |
| prompt-template-engineering | Prompt Template Engineering | technique | core | aiglossary_curated | technique | 16 | curated | true | few_shot_examples | Included because template thinking is a reusable tactical move for repeatable prompt classes and scaffolds. |
| keyword-prompting | Keyword Prompting | technique | core | manual_core | technique | 15 | curated | true | retrieval_grounding | Included as a lightweight tactical move for anchoring prompts around a few high-signal terms when full prose instructions are not yet stable. |
| prompt-augmentation-demonstration-learning | Prompt Augmentation (Demonstration Learning) | technique | core | aiglossary_curated | technique | 15 | graduated_core | true | few_shot_examples, multimodal | Graduated in Phase 1.7 after improving few-shot eval coverage with zero regressions. |
| context-engineering | Context Engineering | term | core | manual_core | term | 24 | curated | true | context_engineering, long_context, retrieval_grounding | Included because Prompt Compass now needs a first-class term for the layer above prompt wording: context selection, ordering, compression, and trust boundaries. |
| function-calling | Function Calling | term | core | manual_core | term | 20 | curated | true | function_calling, tool_use, structured_output, json_schema | Included because function calling is now a standard prompt surface for modern tool-capable models. |
| structured-outputs | Structured Outputs | term | core | manual_core | term | 20 | curated | true | structured_output, xml_structure | Included because structured outputs are now a first-class prompt-engineering concept and retrieval target. |
| negative-avoidance-prompting | Negative Avoidance Prompting | anti_pattern | supporting | house_curated | anti_pattern | 21 | curated | false |  | Added from Prompt Master guidance for prompts that only tell the model what not to do without defining the desired replacement behavior. |
| clear-prompting-method | CLEAR Prompting Method — Clarity · Length · Empathy · Actionability · Relevance | framework | supporting | aiglossary_curated | framework | 16 | promote_to_core | false |  | Queue for later core review because it is operationally useful but overlaps the house CLEAR record. |
| ratio-framework | RATIO — Role · Audience · Task · Instructions · Output | framework | supporting | aiglossary_curated | framework | 16 | promote_to_core | false |  | Queue for later core review because it is operationally strong and prompt-native. |
| multi-objective-directional-prompting-modp | Multi-Objective Directional Prompting (MODP) | framework | supporting | aiglossary_curated | framework | 15 | promote_to_core | false |  | Queue for later core review because it may help advanced output-control use cases. |
| prompt-layered-architecture-pla | Prompt-Layered Architecture (PLA) | framework | supporting | aiglossary_curated | framework | 14 | support_only | false |  | Useful support framework for prompt-system architecture and layered scaffolds. |
| computational-thinking | Computational Thinking | framework | supporting | aiglossary_curated | framework | 10 | support_only | false |  | Useful support framework for decomposition-heavy prompt design. |
| strategic-reasoning | Strategic Reasoning | framework | supporting | aiglossary_curated | framework | 10 | support_only | false |  | Useful support framework for plan-first prompt design. |
| clear-path-forward-framework | CLEAR Path Forward — Concise · Logical · Explicit · Adaptive · Reflective | framework | supporting | aiglossary_curated | framework | 8 | support_only | false |  | Useful support framework for structured response direction and next-step prompts. |
| rag-grounding-faithfulness-check | RAG Grounding And Faithfulness Check | pattern | supporting | house_curated | pattern | 20 | curated | false | retrieval_grounding, quote_first_evidence, source_priority | Added in Phase 2N from Atlas RAG evaluator coverage to strengthen retrieval-grounded prompt examples. |
| tool-contract-prompting | Tool-Contract Prompting | pattern | supporting | house_curated | pattern | 20 | curated | false | agentic_tool_use, tool_use, stop_conditions, retrieval_grounding, function_calling | Included as support guidance because tool-capable prompts need explicit tool rules, but this pattern should stay outside the deterministic core until prompted by clear tool-use context. |
| untrusted-context-boundary | Untrusted-Context Boundary | pattern | supporting | house_curated | pattern | 20 | curated | false | untrusted_context, retrieval_grounding | Included as support guidance because modern prompts often mix trusted instructions with external content that should only count as evidence. |
| grader-loop-orchestrator | Grader-Loop Orchestrator | pattern | supporting | house_curated | pattern | 19 | curated | false | judge_evaluation | Added in Phase 2N from Atlas pattern coverage to support bounded judge loops without expanding Agent Mode. |
| stop-condition-contract | Stop-Condition Contract | pattern | supporting | house_curated | pattern | 19 | curated | false | stop_conditions, agentic_tool_use, tool_use | Included as support guidance because tool-using and agent-like prompts need a visible definition of done. |
| master-prompts | Master Prompts | pattern | supporting | aiglossary_curated | pattern | 15 | promote_to_core | false |  | Queue for later core review because it may become useful in later multi-layer prompt scaffolds. |
| extractive-prompting | Extractive Prompting | pattern | supporting | aiglossary_curated | pattern | 14 | support_only | false |  | Useful support pattern for field extraction and structured reduction work. |
| prompt-decomposition | Prompt Decomposition | pattern | supporting | aiglossary_curated | pattern | 14 | support_only | false |  | Useful support pattern for breaking prompts into subparts. |
| transformative-prompts | Transformative Prompts | pattern | supporting | aiglossary_curated | pattern | 14 | support_only | false |  | Useful support pattern for rewrite-heavy prompt tasks. |
| constraint-prompting | Constraint Prompting | pattern | supporting | aiglossary_curated | pattern | 13 | support_only | false |  | Useful support pattern for prompts that hinge on hard boundaries. |
| contextual-prompting | Contextual Prompting | pattern | supporting | aiglossary_curated | pattern | 13 | support_only | false |  | Useful support pattern for context-heavy prompt framing. |
| evaluation-prompting | Evaluation Prompting | pattern | supporting | aiglossary_curated | pattern | 13 | support_only | false |  | Useful support pattern for rubric-based review and QA loops. |
| expansion-prompting | Expansion Prompting | pattern | supporting | aiglossary_curated | pattern | 12 | support_only | false | few_shot_examples | Useful support pattern for widening idea space before narrowing. |
| terminology-lockdown | Terminology Lockdown | strategy | supporting | house_curated | strategy | 23 | curated | false | structured_output | Added from Prompt Master vocabulary-drift guidance for prompts where term consistency changes the quality or safety of the output. |
| source-priority-instructions | Source-Priority Instructions | strategy | supporting | house_curated | strategy | 21 | curated | false | source_priority, retrieval_grounding | Added in Phase 2N to support retrieval, source-pack, and tool-fallback prompts without making broad Atlas browsing a runtime dependency. |
| ask-vs-act-threshold | Ask-vs-Act Threshold | strategy | supporting | house_curated | strategy | 20 | curated | false | agentic_tool_use, stop_conditions, tool_use, function_calling | Included as support guidance because tool-using and agent-like prompts need an explicit rule for when to ask versus act. |
| long-context-salience-management | Long-Context Salience Management | strategy | supporting | house_curated | strategy | 19 | curated | false | long_context, source_priority, quote_first_evidence, context_compaction | Included as support guidance because large context windows still need explicit prioritization and salience control. |
| guardrail-configuration-prompting | Guardrail Configuration Prompting | strategy | supporting | house_curated | strategy | 18 | curated | false | tool_use, parser_aware, source_priority, retrieval_grounding, agentic_tool_use | Added in Phase 2N as narrow support for prompts that need boundaries, fallback behavior, and validation without expanding Prompt Compass into a safety framework. |
| sequential-linear-prompting | Sequential (Linear) Prompting | strategy | supporting | aiglossary_curated | strategy | 17 | promote_to_core | false | structured_output | Queue for later core review because it cleanly complements decomposed prompting. |
| parallel-prompting | Parallel Prompting | strategy | supporting | aiglossary_curated | strategy | 12 | support_only | false |  | Useful support strategy for exploration or comparison outside the main deterministic loop. |
| prompt-modification | Prompt Modification or Poly-Prompting | strategy | supporting | aiglossary_curated | strategy | 12 | support_only | false |  | Useful support strategy for deliberate prompt variant adjustments. |
| conversational-design | Conversational Design | strategy | supporting | aiglossary_curated | strategy | 11 | support_only | false |  | Useful support strategy for turn-by-turn prompt system design. |
| bias-impact-assessment | Bias Impact Assessment (AI/tech pre-launch) | strategy | supporting | aiglossary_curated | strategy | 10 | support_only | false |  | Useful support strategy for structured bias and risk review. |
| bias-mitigation | Bias Mitigation or Awareness | strategy | supporting | aiglossary_curated | strategy | 10 | support_only | false |  | Useful support strategy for mitigation-oriented prompt review. |
| cross-domain-reasoning | Cross-Domain Reasoning | strategy | supporting | aiglossary_curated | strategy | 8 | support_only | false |  | Useful support strategy for prompts that deliberately borrow from other domains. |
| holistic-reasoning | Holistic Reasoning | strategy | supporting | aiglossary_curated | strategy | 8 | support_only | false |  | Useful support strategy for broad-scope synthesis prompts. |
| strategic-thinking | Strategic Thinking | strategy | supporting | aiglossary_curated | strategy | 8 | support_only | false | few_shot_examples | Useful support strategy for strategic framing and option comparison. |
| divergent-intern | Divergent Intern | technique | supporting | house_curated | technique | 22 | curated | false |  | Added from Prompt Master style guidance as a safe ideation tactic for generating intentionally naive alternative framings without letting them become the final answer. |
| prompt-fingerprinting | Prompt Fingerprinting | technique | supporting | house_curated | technique | 22 | curated | false | judge_evaluation | Added from Prompt Master style guidance to help Prompt Compass notice prompt voice, habits, and recurring structure before rewriting. |
| continuation-instructions | Continuation Instructions | technique | supporting | house_curated | technique | 21 | curated | false | long_context, stop_conditions | Added from Prompt Master anti-silent-cap guidance for prompts where length limits or long outputs could cause silent truncation. |
| parser-aware-prompting | Parser-Aware Prompting | technique | supporting | house_curated | technique | 19 | curated | false | parser_aware, structured_output, json_schema, xml_structure | Included as support guidance because many prompt failures are really parser-contract failures rather than wording failures. |
| compaction | Compaction | technique | supporting | house_curated | technique | 18 | curated | false | context_compaction, long_context | Included as support guidance because long-running prompt workflows need a way to compress stale context without losing decisions or evidence. |
| self-refine-prompting | Self-Refine Prompting | technique | supporting | house_curated | technique | 18 | curated | false |  | Curated support technique for iterative prompt revision once a draft exists, kept out of the deterministic core until the Phase 1.7 eval bar is met. |
| contextual-understanding | Contextual understanding | technique | supporting | aiglossary_curated | technique | 15 | promote_to_core | false | retrieval_grounding | Queue for later core review because it directly improves grounding quality. |
| rubric-approach | Rubric Approach | technique | supporting | aiglossary_curated | technique | 13 | support_only | false | few_shot_examples, judge_evaluation | Useful support technique for rubric-guided prompting and evaluation. |
| transparent-sourcing | Transparent sourcing | technique | supporting | aiglossary_curated | technique | 13 | support_only | false |  | Useful support technique for prompts that should expose source provenance. |
| bias-reflection-prompts | Bias reflection prompts | technique | supporting | aiglossary_curated | technique | 12 | support_only | false |  | Useful support technique for reflective prompt review and fairness checks. |
| scratchpad-reasoning | Scratchpad Reasoning | technique | supporting | aiglossary_curated | technique | 12 | support_only | false |  | Useful support technique for scratchpad-style prompt design. |
| user-centric-design | User-centric design | technique | supporting | aiglossary_curated | technique | 12 | support_only | false |  | Useful support technique for audience-aware prompt design. |
| historical-contextualization | Historical contextualization | technique | supporting | aiglossary_curated | technique | 11 | support_only | false |  | Useful support technique for grounding prompts in historical or situational context. |
| multimodal-prompting | Multimodal Prompting | technique | supporting | aiglossary_curated | technique | 11 | support_only | false | multimodal | Useful support technique for multimodal prompt lookup while keeping the deterministic workflow text-first. |
| prompt-augmentation | Prompt Augmentation | technique | supporting | aiglossary_curated | technique | 11 | support_only | false | few_shot_examples | Useful support technique for enriching a prompt with extra signal. |
| prompt-ensembling | Prompt Ensembling | technique | supporting | aiglossary_curated | technique | 11 | support_only | false | judge_evaluation | Useful support technique for comparing prompt outputs across variants. |
| cross-cultural-validation | Cross-cultural validation | technique | supporting | aiglossary_curated | technique | 10 | support_only | false |  | Useful support technique for cross-context validation. |
| cultural-context-sensitivity-training | Cultural & contextual sensitivity training | technique | supporting | aiglossary_curated | technique | 10 | support_only | false |  | Useful support technique for prompts that need cross-context sensitivity. |
| prompt-fine-tuning | Prompt Fine-Tuning | technique | supporting | aiglossary_curated | technique | 10 | support_only | false | few_shot_examples | Useful support technique for smaller tactical prompt adjustments. |
| real-time-adaptive-prompting | Real-Time Adaptive Prompting | technique | supporting | aiglossary_curated | technique | 10 | support_only | false |  | Useful support technique for adaptive behavior under changing context. |
| regular-updating-reevaluation | Regular updating & reevaluation | technique | supporting | aiglossary_curated | technique | 10 | support_only | false |  | Useful support technique for iterative prompt review and maintenance. |
| recursive-self-improvement-prompting-rsip | Recursive Self-Improvement Prompting (RSIP) | technique | supporting | aiglossary_curated | technique | 9 | support_only | false |  | Useful support technique for advanced self-improvement prompting lookup. |
| analogical-reasoning | Analogical Reasoning | technique | supporting | aiglossary_curated | technique | 8 | support_only | false |  | Useful support technique for analogy-guided prompting. |
| counterbalancing | Counterbalancing | technique | supporting | aiglossary_curated | technique | 8 | support_only | false |  | Useful support technique for contrastive or counterbalanced prompt setups. |
| fairness-metrics-evaluation | Fairness metrics evaluation | technique | supporting | aiglossary_curated | technique | 8 | support_only | false |  | Useful support technique for fairness metric lookup in evaluation-heavy work. |
| scenario-based-testing-bias | Scenario-Based Testing | technique | supporting | aiglossary_curated | technique | 8 | support_only | false |  | Useful support technique for scenario-based prompt review. |
| llm-as-judge | LLM as Judge | term | supporting | house_curated | term | 18 | curated | false | judge_evaluation, few_shot_examples | Included as support knowledge because judge-style evaluation is important for modern prompt workflows, but the term itself should not become an automatic recommendation without explicit eval need. |
| prompt-caching | Prompt Caching | term | supporting | manual_core | term | 16 | curated | false | prompt_caching, few_shot_examples, long_context, context_compaction | Included as searchable support knowledge because prompt caching shapes prompt layout and cost/latency strategy, but should not steer the deterministic rewrite loop by default. |
| context-window-selection | Context Window Selection | term | supporting | supporting_term | term | 15 | curated | false | context_engineering, long_context, few_shot_examples, retrieval_grounding | Added in Phase 2N as narrow Atlas-informed support for long-context and context-engineering prompts. |
| prompt-cognitive-overload | Prompt (Cognitive) Overload | term | supporting | supporting_term | term | 15 | promote_to_core | false |  | Queue for later core review because it maps cleanly to instruction-wall and scope-sprawl repair. |
| prompt-brittleness-diagnosis | Prompt Brittleness Diagnosis | term | supporting | supporting_term | term | 15 | curated | false | judge_evaluation | Added in Phase 2N to operationalize prompt brittleness diagnosis without colliding with the imported support term. |
| prompting-evaluation | Prompting (as evaluation dimension) | term | supporting | supporting_term | term | 12 | support_only | false | few_shot_examples | Useful support term for evaluation discussions about prompt sensitivity. |
| reasoning-models-or-structures | Reasoning Models or Structures | term | supporting | supporting_term | term | 11 | support_only | false |  | Useful support term for reasoning-structure lookup and navigation. |
| prompt-distillation | Prompt Distillation | term | supporting | supporting_term | term | 10 | support_only | false | retrieval_grounding | Useful support term for prompt distillation and compression discussions. |
| mega-prompt | Mega-Prompt | term | supporting | supporting_term | term | 9 | support_only | false |  | Useful support term for large monolithic prompt styles and their tradeoffs. |
| reasoning-tokens-o1-style | Reasoning Tokens (o1-style) | term | supporting | supporting_term | term | 9 | support_only | false |  | Useful support term for reasoning-model prompt discussions. |
| system-prompt | System Prompt | term | supporting | supporting_term | term | 9 | support_only | false |  | Useful support term for understanding layered prompt systems. |
| ai-human-research-and-analysis | AI-Human Research and Analysis | term | supporting | supporting_term | term | 8 | support_only | false |  | Useful support term for human-in-the-loop research and analysis discussions. |
| bias-awareness-techniques | Bias Awareness Techniques | term | supporting | supporting_term | term | 8 | support_only | false |  | Useful support term for bias-awareness lookup and orientation. |
| prompt-brittleness | Prompt Brittleness | term | supporting | supporting_term | term | 8 | support_only | false |  | Useful support term for diagnosing fragile prompt behavior. |
| prompt-engineering-and-development | Prompt Engineering and Development | term | supporting | supporting_term | term | 8 | support_only | false | few_shot_examples | Useful support term for general search and orientation. |
| waves-of-ai-prompting-evolutions | Waves of AI Prompting Evolutions | term | supporting | supporting_term | term | 8 | support_only | false | tool_use | Useful support term for high-level prompting evolution narratives. |
| discrete-prompts | Discrete Prompts | term | supporting | supporting_term | term | 7 | support_only | false |  | Useful support term for distinguishing isolated prompt units. |
| prompt-architect | Prompt Architect | term | supporting | supporting_term | term | 7 | support_only | false |  | Useful support term for role and practice discussions. |
| continuous-prompts | Continuous Prompts | term | supporting | supporting_term | term | 6 | support_only | false |  | Useful support term for longer conversational prompt flow concepts. |
