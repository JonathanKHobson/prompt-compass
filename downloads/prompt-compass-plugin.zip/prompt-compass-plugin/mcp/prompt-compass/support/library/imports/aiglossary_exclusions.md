# AIGlossary Exclusion Ledger

This file records Phase 1.5 exclusions for AIGlossary-derived Prompt Compass
imports.

Use it together with the support catalog:

- named exclusions document intentional keep-out decisions
- bucket rules document reusable exclusion heuristics
- any scanned candidate not approved in the support catalog and not matched by a
  named or bucket rule is treated as `excluded` with the default reason
  `not_yet_curated`

## Named Exclusions

| slug | rule_id | reason |
| --- | --- | --- |
| prompt-injection | security_and_adversarial | Security and injection content is out of Phase 1.5 scope. |
| indirect-prompt-injection | security_and_adversarial | Security and injection content is out of Phase 1.5 scope. |
| zero-width-prompt-injection | security_and_adversarial | Security and injection content is out of Phase 1.5 scope. |
| adversarial-prompts | security_and_adversarial | Red-team prompt attacks are out of scope for Prompt Compass Phase 1.5. |
| artprompt | security_and_adversarial | Jailbreak-adjacent attack content is out of scope for Prompt Compass Phase 1.5. |
| cloaked-prompt | security_and_adversarial | Cloaked or attack-style prompting is out of scope for Prompt Compass Phase 1.5. |
| masked-prompt-word-masking | security_and_adversarial | Attack-evasion prompting is out of scope for Prompt Compass Phase 1.5. |
| promptbench | security_and_adversarial | Attack-eval benchmarking is outside the Phase 1.5 guidance loop. |
| promptperfect | product_or_brand_specific | Product-specific prompt systems are excluded from the neutral Prompt Compass KB. |
| promptomatix | product_or_brand_specific | Product-specific prompt systems are excluded from the neutral Prompt Compass KB. |
| automatic-prompt-engineer-ape | auto_prompt_generation | Auto-generated prompt optimization systems are outside the Phase 1.5 assistant scope. |
| langgpt-dual-layer-framework | product_or_brand_specific | Stack-specific prompt frameworks stay out until the base corpus is stable. |
| mixture-of-prompt-experts-mope | image_and_multimodal | Multi-expert multimodal prompt orchestration is deferred beyond Phase 1.5. |
| contextual-prompter | vague_prompter_personas | Vague prompter persona labels are excluded unless recast into an operational record. |
| detailed-prompter | vague_prompter_personas | Vague prompter persona labels are excluded unless recast into an operational record. |
| explorative-prompter | vague_prompter_personas | Vague prompter persona labels are excluded unless recast into an operational record. |
| iterative-prompter | vague_prompter_personas | Vague prompter persona labels are excluded unless recast into an operational record. |
| minimalist-prompter | vague_prompter_personas | Vague prompter persona labels are excluded unless recast into an operational record. |
| pragmatic-prompter | vague_prompter_personas | Vague prompter persona labels are excluded unless recast into an operational record. |
| utility-driven-prompter | vague_prompter_personas | Vague prompter persona labels are excluded unless recast into an operational record. |
| enthusiast-prompter | vague_prompter_personas | Vague prompter persona labels are excluded unless recast into an operational record. |
| personalized-prompt-distillation-peapod | product_or_brand_specific | Product-specific prompt distillation systems are excluded from the neutral KB. |
| recursive-self-improvement-prompting-rsip-2 | phase2_agentic_or_model_optimization | Advanced recursive self-improvement variants are deferred beyond Phase 1.5. |

## Bucket Rules

| rule_id | description | reason |
| --- | --- | --- |
| security_and_adversarial | Exclude records whose slug, title, summary, or path indicates injection, adversarial, jailbreak, cloaking, or red-team prompt attacks. | Prompt Compass Phase 1.5 is a prompt engineering assistant, not a prompt-security or red-team product. |
| image_and_multimodal | Exclude records whose slug, title, summary, or path indicates multimodal, image, OCR-routing, or visual prompt orchestration. | Image and multimodal prompt grammars need a separate Phase 2 treatment. |
| product_or_brand_specific | Exclude productized, branded, or stack-specific prompt systems that would distort the neutral Prompt Compass corpus. | Prompt Compass should stay vendor-neutral and technique-first in Phase 1.5. |
| vague_prompter_personas | Exclude named prompter personas unless they are manually recast into a concrete pattern, technique, term, or strategy. | Persona labels create noisy search results without adding enough operational guidance. |
| auto_prompt_generation | Exclude automated prompt generation or prompt optimizer systems that shift the tool from guidance toward autonomous prompt synthesis infrastructure. | Auto-prompt-generation systems are outside the current local-first assistant scope. |
| phase2_agentic_or_model_optimization | Exclude agentic orchestration, autonomous optimization loops, or model-training optimization records that belong to a later phase. | Agent-aware and optimization-heavy prompting stays deferred until the Phase 1 chat guidance loop is stable. |
