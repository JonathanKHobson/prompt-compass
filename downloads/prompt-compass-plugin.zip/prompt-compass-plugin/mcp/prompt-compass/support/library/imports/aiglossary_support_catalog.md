# AIGlossary Support Import Catalog

This file is the Phase 1.7 approval layer for AIGlossary-derived Prompt Compass
support records.

Rules:

- `decision: support_only` means compile into the searchable support ring.
- `decision: promote_to_core` means keep the record in the searchable support
  ring for Phase 1.7, but mark it as promotion-queue material for a later core
  graduation pass.
- `decision: graduated_core` means the imported record has passed the promotion
  bar and may compile as workflow-driving core.
- Imported records stay `curation_status: supporting` unless they are explicitly
  marked `graduated_core`.
- `driver_eligible` stays `false` for imported support records and flips to
  `true` only for `graduated_core` entries.

## Carry-Forward Support Imports

| slug | title | source_kind | normalized_record_type | decision | family | origin_bucket | search_weight | ambiguity_status | driver_eligible | weight_reason | curation_note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| evaluation-prompting | Evaluation Prompting | pattern | pattern | support_only | evaluation_reflection | methodology_audit | 13 | clear | false | Prompt-native evaluation pattern with direct QA utility. | Useful support pattern for rubric-based review and QA loops. |
| extractive-prompting | Extractive Prompting | pattern | pattern | support_only | task_shape | methodology_audit | 14 | clear | false | High-signal reduction pattern for structured extraction work. | Useful support pattern for field extraction and structured reduction work. |
| transformative-prompts | Transformative Prompts | pattern | pattern | support_only | task_shape | other_adjacent | 14 | clear | false | Direct rewrite pattern for audience, tone, and format shifts. | Useful support pattern for rewrite-heavy prompt tasks. |
| prompt-decomposition | Prompt Decomposition | pattern | pattern | support_only | decomposition_sequencing | other_adjacent | 14 | clear | false | Clear decomposition pattern that strengthens stepwise prompting. | Useful support pattern for breaking prompts into subparts. |
| constraint-prompting | Constraint Prompting | pattern | pattern | support_only | role_goal_output_control | other_adjacent | 13 | clear | false | Useful when hard boundaries shape output quality. | Useful support pattern for prompts that hinge on hard boundaries. |
| contextual-prompting | Contextual Prompting | pattern | pattern | support_only | context_grounding | other_adjacent | 13 | clear | false | Strong support for prompts that depend on deliberate context loading. | Useful support pattern for context-heavy prompt framing. |
| expansion-prompting | Expansion Prompting | pattern | pattern | support_only | task_shape | other_adjacent | 12 | clear | false | Supports widen-then-narrow ideation flows. | Useful support pattern for widening idea space before narrowing. |
| prompt-modification | Prompt Modification or Poly-Prompting | strategy | strategy | support_only | role_goal_output_control | biases_ai | 12 | overlap_guarded | false | Practical support strategy for deliberate prompt variant edits. | Useful support strategy for deliberate prompt variant adjustments. |
| parallel-prompting | Parallel Prompting | strategy | strategy | support_only | decomposition_sequencing | other_adjacent | 12 | clear | false | Useful for search and comparison outside the deterministic loop. | Useful support strategy for exploration or comparison outside the main deterministic loop. |
| prompt-augmentation | Prompt Augmentation | technique | technique | support_only | role_goal_output_control | other_adjacent | 11 | clear | false | Supports targeted enrichment of under-specified prompts. | Useful support technique for enriching a prompt with extra signal. |
| prompt-fine-tuning | Prompt Fine-Tuning | technique | technique | support_only | role_goal_output_control | other_adjacent | 10 | clear | false | Supports tactical prompt adjustments without becoming a core driver. | Useful support technique for smaller tactical prompt adjustments. |
| real-time-adaptive-prompting | Real-Time Adaptive Prompting | technique | technique | support_only | role_goal_output_control | other_adjacent | 10 | clear | false | Useful adaptive tactic, but too situational to steer the core workflow. | Useful support technique for adaptive behavior under changing context. |
| prompt-ensembling | Prompt Ensembling | technique | technique | support_only | decomposition_sequencing | methodology_audit | 11 | clear | false | Useful support for comparing prompt variants and outputs. | Useful support technique for comparing prompt outputs across variants. |
| system-prompt | System Prompt | term | term | support_only | support_terms | other_adjacent | 9 | clear | false | Common support term that helps explain layered prompt systems. | Useful support term for understanding layered prompt systems. |
| prompt-brittleness | Prompt Brittleness | term | term | support_only | support_terms | other_adjacent | 8 | clear | false | Useful diagnostic term for fragile prompt behavior. | Useful support term for diagnosing fragile prompt behavior. |
| prompt-architect | Prompt Architect | term | term | support_only | support_terms | other_adjacent | 7 | clear | false | Useful support term for role and practice discussions. | Useful support term for role and practice discussions. |
| prompt-engineering-and-development | Prompt Engineering and Development | term | term | support_only | support_terms | other_adjacent | 8 | clear | false | Broad orientation term that helps general lookup. | Useful support term for general search and orientation. |
| discrete-prompts | Discrete Prompts | term | term | support_only | support_terms | methodology_audit | 7 | clear | false | Useful terminology for isolated prompt units. | Useful support term for distinguishing isolated prompt units. |
| continuous-prompts | Continuous Prompts | term | term | support_only | support_terms | other_adjacent | 6 | clear | false | Useful terminology for conversational prompt flow concepts. | Useful support term for longer conversational prompt flow concepts. |

## Promotion Queue

| slug | title | source_kind | normalized_record_type | decision | family | origin_bucket | search_weight | ambiguity_status | driver_eligible | weight_reason | curation_note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| sequential-linear-prompting | Sequential (Linear) Prompting | strategy | strategy | promote_to_core | decomposition_sequencing | other_adjacent | 17 | clear | false | Direct staged prompting strategy with strong workflow relevance. | Queue for later core review because it cleanly complements decomposed prompting. |
| clear-prompting-method | CLEAR Prompting Method — Clarity · Length · Empathy · Actionability · Relevance | framework | framework | promote_to_core | role_goal_output_control | methodology_audit | 16 | alias_guarded | false | Strong overlap-adjacent scaffold that may deserve later graduation after alias review. | Queue for later core review because it is operationally useful but overlaps the house CLEAR record. |
| ratio-framework | RATIO — Role · Audience · Task · Instructions · Output | framework | framework | promote_to_core | role_goal_output_control | other_adjacent | 16 | clear | false | Audience-centered prompt scaffold with direct contract utility. | Queue for later core review because it is operationally strong and prompt-native. |
| contextual-understanding | Contextual understanding | technique | technique | promote_to_core | context_grounding | methodology_preflight | 15 | clear | false | High-signal context tactic that complements audience and source-pack repair. | Queue for later core review because it directly improves grounding quality. |
| prompt-cognitive-overload | Prompt (Cognitive) Overload | unknown | term | promote_to_core | support_terms | other_adjacent | 15 | normalized_unknown | false | Useful failure-mode concept for overstuffed prompts and architectures. | Queue for later core review because it maps cleanly to instruction-wall and scope-sprawl repair. |
| master-prompts | Master Prompts | pattern | pattern | promote_to_core | systems_architecture | other_adjacent | 15 | overlap_guarded | false | Strong umbrella pattern for system-level prompting and sub-prompt inheritance. | Queue for later core review because it may become useful in later multi-layer prompt scaffolds. |
| multi-objective-directional-prompting-modp | Multi-Objective Directional Prompting (MODP) | framework | framework | promote_to_core | role_goal_output_control | methodology_audit | 15 | clear | false | Useful structure for prompts balancing several explicit objectives. | Queue for later core review because it may help advanced output-control use cases. |

## Graduated Core Imports

| slug | title | source_kind | normalized_record_type | decision | family | origin_bucket | search_weight | ambiguity_status | driver_eligible | weight_reason | curation_note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| prompt-augmentation-demonstration-learning | Prompt Augmentation (Demonstration Learning) | technique | technique | graduated_core | role_goal_output_control | other_adjacent | 15 | clear | true | Strong example-driven tactic with clear practical value. | Graduated in Phase 1.7 after improving few-shot eval coverage with zero regressions. |

## Direct Prompt-Native Additions

| slug | title | source_kind | normalized_record_type | decision | family | origin_bucket | search_weight | ambiguity_status | driver_eligible | weight_reason | curation_note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| prompting-evaluation | Prompting (as evaluation dimension) | unknown | term | support_only | evaluation_reflection | methodology_audit | 12 | normalized_unknown | false | Useful support concept for prompt sensitivity as an evaluation dimension. | Useful support term for evaluation discussions about prompt sensitivity. |
| prompt-layered-architecture-pla | Prompt-Layered Architecture (PLA) | framework | framework | support_only | systems_architecture | thinking_lenses | 14 | clear | false | Systems-level support framework for prompt layers, reuse, and testing. | Useful support framework for prompt-system architecture and layered scaffolds. |
| transparent-sourcing | Transparent sourcing | technique | technique | support_only | context_grounding | methodology_preflight | 13 | clear | false | Context-grounding tactic that improves provenance and trust. | Useful support technique for prompts that should expose source provenance. |
| user-centric-design | User-centric design | technique | technique | support_only | context_grounding | methodology_preflight | 12 | clear | false | Strong audience-fit tactic for prompts shaped around user constraints. | Useful support technique for audience-aware prompt design. |
| historical-contextualization | Historical contextualization | technique | technique | support_only | context_grounding | methodology_preflight | 11 | clear | false | Useful support tactic for time- and place-aware prompts. | Useful support technique for grounding prompts in historical or situational context. |
| cultural-context-sensitivity-training | Cultural & contextual sensitivity training | technique | technique | support_only | context_grounding | methodology_preflight | 10 | clear | false | Useful support tactic for culturally aware prompt design. | Useful support technique for prompts that need cross-context sensitivity. |
| prompt-distillation | Prompt Distillation | unknown | term | support_only | support_terms | other_adjacent | 10 | normalized_unknown | false | Useful support concept for prompt-to-model knowledge transfer discussions. | Useful support term for prompt distillation and compression discussions. |
| mega-prompt | Mega-Prompt | technique | term | support_only | support_terms | other_adjacent | 9 | normalized_unknown | false | Useful support concept for overgrown all-in-one prompt styles. | Useful support term for large monolithic prompt styles and their tradeoffs. |
| reasoning-tokens-o1-style | Reasoning Tokens (o1 style) | term | term | support_only | support_terms | reasoning_frameworks | 9 | clear | false | Useful support term for reasoning-model prompt expectations and token budgeting. | Useful support term for reasoning-model prompt discussions. |
| recursive-self-improvement-prompting-rsip | Recursive Self-Improvement Prompting (RSIP) | technique | technique | support_only | evaluation_reflection | thinking_lenses | 9 | clear | false | Useful support tactic for iterative self-improvement search. | Useful support technique for advanced self-improvement prompting lookup. |
| multimodal-prompting | Multimodal Prompting | technique | technique | support_only | context_grounding | other_adjacent | 11 | clear | false | Searchable multimodal prompt concept for Phase 1.6 broad KB coverage without making it a deterministic driver. | Useful support technique for multimodal prompt lookup while keeping the deterministic workflow text-first. |

## Context And Evaluation Support

| slug | title | source_kind | normalized_record_type | decision | family | origin_bucket | search_weight | ambiguity_status | driver_eligible | weight_reason | curation_note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| bias-reflection-prompts | Bias reflection prompts | technique | technique | support_only | evaluation_reflection | methodology_audit | 12 | clear | false | Useful support tactic for bias-aware prompt review. | Useful support technique for reflective prompt review and fairness checks. |
| rubric-approach | Rubric Approach | technique | technique | support_only | evaluation_reflection | methodology_audit | 13 | clear | false | Strong evaluation technique for explicit criteria and consistent review. | Useful support technique for rubric-guided prompting and evaluation. |
| regular-updating-reevaluation | Regular updating & reevaluation | technique | technique | support_only | evaluation_reflection | methodology_audit | 10 | clear | false | Useful support tactic for refresh-and-retest evaluation loops. | Useful support technique for iterative prompt review and maintenance. |
| cross-cultural-validation | Cross-cultural validation | technique | technique | support_only | evaluation_reflection | methodology_audit | 10 | clear | false | Useful support tactic for checking prompts across audiences and contexts. | Useful support technique for cross-context validation. |
| bias-impact-assessment | Bias Impact Assessment (AI/tech pre-launch) | strategy | strategy | support_only | evaluation_reflection | methodology_preflight | 10 | clear | false | Broad but useful support strategy for preflight bias review. | Useful support strategy for structured bias and risk review. |
| bias-mitigation | Bias Mitigation or Awareness | strategy | strategy | support_only | evaluation_reflection | methodology_preflight | 10 | clear | false | Useful support strategy for fairness-aware prompt design. | Useful support strategy for mitigation-oriented prompt review. |
| conversational-design | Conversational Design | strategy | strategy | support_only | systems_architecture | thinking_lenses | 11 | clear | false | Useful support strategy for longer conversational flows and turn design. | Useful support strategy for turn-by-turn prompt system design. |
| bias-awareness-techniques | Bias Awareness Techniques | unknown | term | support_only | evaluation_reflection | methodology_preflight | 8 | normalized_unknown | false | Useful support term for bias-checking prompt workflows. | Useful support term for bias-awareness lookup and orientation. |
| scenario-based-testing-bias | Scenario-Based Testing | unknown | technique | support_only | evaluation_reflection | methodology_preflight | 8 | normalized_unknown | false | Useful support evaluation tactic for scenario-based prompt testing. | Useful support technique for scenario-based prompt review. |
| counterbalancing | Counterbalancing | technique | technique | support_only | evaluation_reflection | methodology_preflight | 8 | clear | false | Useful support tactic for balancing examples and viewpoints. | Useful support technique for contrastive or counterbalanced prompt setups. |
| fairness-metrics-evaluation | Fairness Metrics Evaluation | technique | technique | support_only | evaluation_reflection | methodology_audit | 8 | clear | false | Useful support evaluation concept for fairness-sensitive prompt review. | Useful support technique for fairness metric lookup in evaluation-heavy work. |
| ai-human-research-and-analysis | AI-Human Research and Analysis | term | term | support_only | support_terms | thinking_lenses | 8 | clear | false | Broad support term for human-centered AI collaboration work. | Useful support term for human-in-the-loop research and analysis discussions. |

## Reasoning Structure Support

| slug | title | source_kind | normalized_record_type | decision | family | origin_bucket | search_weight | ambiguity_status | driver_eligible | weight_reason | curation_note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| waves-of-ai-prompting-evolutions | Waves of AI Prompting Evolutions | term | term | support_only | support_terms | thinking_lenses | 8 | clear | false | Useful support term for prompting-era framing and education. | Useful support term for high-level prompting evolution narratives. |
| reasoning-models-or-structures | Reasoning Models or Structures | term | term | support_only | support_terms | reasoning_frameworks | 11 | clear | false | Useful umbrella term for structured reasoning patterns used in prompts. | Useful support term for reasoning-structure lookup and navigation. |
| scratchpad-reasoning | Scratchpad Reasoning | technique | technique | support_only | decomposition_sequencing | reasoning_frameworks | 12 | clear | false | Useful reasoning tactic for intermediate notes and structured thinking. | Useful support technique for scratchpad-style prompt design. |
| computational-thinking | Computational Thinking | framework | framework | support_only | decomposition_sequencing | thinking_lenses | 10 | clear | false | Useful support framework for decomposition and stepwise problem shaping. | Useful support framework for decomposition-heavy prompt design. |
| strategic-reasoning | Strategic Reasoning | framework | framework | support_only | decomposition_sequencing | reasoning_frameworks | 10 | clear | false | Useful support framework for planning-oriented prompt scaffolds. | Useful support framework for plan-first prompt design. |
| cross-domain-reasoning | Cross-Domain Reasoning | strategy | strategy | support_only | decomposition_sequencing | reasoning_frameworks | 8 | clear | false | Useful support strategy for analogy and transfer across domains. | Useful support strategy for prompts that deliberately borrow from other domains. |
| analogical-reasoning | Analogical Reasoning | technique | technique | support_only | decomposition_sequencing | reasoning_frameworks | 8 | clear | false | Useful support technique for example transfer and analogy-based prompting. | Useful support technique for analogy-guided prompting. |
| strategic-thinking | Strategic Thinking | strategy | strategy | support_only | systems_architecture | methodology_audit | 8 | clear | false | Broad support strategy for prompts that frame decisions or tradeoffs. | Useful support strategy for strategic framing and option comparison. |
| clear-path-forward-framework | CLEAR Path Forward — Concise · Logical · Explicit · Adaptive · Reflective | framework | framework | support_only | role_goal_output_control | reasoning_frameworks | 8 | alias_guarded | false | Useful support scaffold, but too overlapping and broad for core guidance. | Useful support framework for structured response direction and next-step prompts. |
| holistic-reasoning | Holistic Reasoning | strategy | strategy | support_only | decomposition_sequencing | reasoning_frameworks | 8 | clear | false | Useful support strategy for prompts that need whole-system framing. | Useful support strategy for broad-scope synthesis prompts. |
