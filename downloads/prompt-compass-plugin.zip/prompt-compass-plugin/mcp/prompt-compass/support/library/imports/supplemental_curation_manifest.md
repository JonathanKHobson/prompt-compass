# Prompt Compass Supplemental Curation Manifest

_Prepared: 2026-04-21_

_Source basis: imported deep-research report material and current Phase 1.6 Prompt Compass coverage._

This manifest is a handoff backlog for the Prompt Compass dev. It is not a
compiled runtime source yet. The intent is to make the next curation pass
decision-complete without forcing a broad, unfocused expansion.

## Add Now - Curated Core

| slug | title | record_type | target_file | proposed_status | interaction_mode | output_mode | grounding_mode | evaluation_mode | capability_tags | why now |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `context-engineering` | Context Engineering | `term` | `support/library/curated/terms.md` | `core` | `multi_turn` | `freeform` | `retrieval` | `none` | `context_engineering`, `memory_management`, `long_context`, `retrieval_grounding` | New umbrella concept that reframes prompt engineering as one slice of total working-state design. |
| `evaluator-optimizer-loop` | Evaluator-Optimizer Loop | `pattern` | `support/library/curated/patterns.md` | `core` | `multi_turn` | `structured` | `none` | `grader` | `judge_evaluation`, `rubric_eval`, `iterative_refinement` | High-value modern pattern for explicit draft -> judge -> revise workflows. |

## Add Now - Curated Support

| slug | title | record_type | target_file | proposed_status | interaction_mode | output_mode | grounding_mode | evaluation_mode | capability_tags | why support-only now |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `compaction` | Compaction | `technique` | `support/library/curated/techniques.md` | `supporting` | `multi_turn` | `freeform` | `source_pack` | `none` | `context_compaction`, `memory_management`, `long_context` | Important for long-running workflows, but not yet a deterministic default driver. |
| `llm-as-judge` | LLM as Judge | `term` | `support/library/curated/terms.md` | `supporting` | `single_turn` | `freeform` | `none` | `grader` | `judge_evaluation`, `rubric_eval` | Useful as a retrieval concept and caution term; should not become an automatic recommendation by itself. |
| `routing-workflow` | Routing Workflow | `pattern` | `support/library/curated/patterns.md` | `supporting` | `agentic` | `structured` | `retrieval` | `none` | `workflow_routing`, `cost_routing` | Real production pattern, but broader than the current prompt rewrite loop. |
| `model-context-protocol` | Model Context Protocol | `term` | `support/library/curated/terms.md` | `supporting` | `tool_calling` | `schema_bound` | `retrieval` | `none` | `protocol_tools`, `tool_use` | Useful support terminology for tool/data context design. |
| `skills` | Skills | `term` | `support/library/curated/terms.md` | `supporting` | `agentic` | `freeform` | `retrieval` | `none` | `reusable_instructions`, `workflow_modularity` | Good searchable concept for reusable instruction bundles, but not a prompt-default driver. |
| `agents-md` | AGENTS.md | `term` | `support/library/curated/terms.md` | `supporting` | `agentic` | `freeform` | `source_pack` | `none` | `durable_repo_instructions`, `reusable_instructions` | Valuable for agent workflows and coding contexts; keep searchable first. |
| `agent2agent` | Agent2Agent | `term` | `support/library/curated/terms.md` | `supporting` | `agentic` | `structured` | `retrieval` | `none` | `protocol_agents`, `multi_agent` | Relevant to agent-to-agent systems, but outside the deterministic Phase 1 loop. |
| `orchestrator-workers` | Orchestrator-Workers | `pattern` | `support/library/curated/patterns.md` | `supporting` | `agentic` | `structured` | `retrieval` | `none` | `multi_agent`, `workflow_routing` | High-signal workflow pattern that should stay support-only until evals prove fit. |
| `parallelization-and-voting` | Parallelization and Voting | `pattern` | `support/library/curated/patterns.md` | `supporting` | `agentic` | `structured` | `none` | `comparison` | `multi_agent`, `reasoning_budget`, `ensemble_selection` | Useful for robustness and test-time scaling, but not a universal prompt recommendation. |
| `interleaved-thinking` | Interleaved Thinking | `technique` | `support/library/curated/techniques.md` | `supporting` | `tool_calling` | `structured` | `retrieval` | `none` | `interleaved_thinking`, `tool_use` | Valuable for tool-call workflows; keep it searchable before it steers defaults. |
| `tool-preambles-and-explicit-stop-conditions` | Tool Preambles and Explicit Stop Conditions | `pattern` | `support/library/curated/patterns.md` | `supporting` | `agentic` | `structured` | `none` | `none` | `agent_legibility`, `stop_conditions` | Strong user-facing agent pattern, but one layer above ordinary prompt cleanup. |
| `test-time-compute` | Test-Time Compute | `term` | `support/library/curated/terms.md` | `supporting` | `single_turn` | `freeform` | `none` | `comparison` | `reasoning_budget`, `ensemble_selection` | Important concept for modern prompting limits and tradeoffs; best treated as support knowledge first. |
| `chain-of-draft` | Chain of Draft | `technique` | `support/library/curated/techniques.md` | `supporting` | `single_turn` | `structured` | `none` | `none` | `concise_reasoning`, `reasoning_budget` | Promising concise-reasoning tactic, but still earlier-stage than the mainstream production patterns. |

## Update Now - Existing Records

| existing_slug | target_file | change_request |
| --- | --- | --- |
| `chain-of-thought-deliberative-prompting` | `support/library/curated/frameworks.md` | Reframe as conditional. Add contraindications for reasoning-oriented models, latency-sensitive flows, and cases where visible reasoning adds no value. Link to `chain-of-draft`, `test-time-compute`, and `evaluator-optimizer-loop`. |
| `few-shot-prompting` | `support/library/curated/techniques.md` | Add "minimum canonical examples" guidance. Recommend zero-shot first when the task and model can support it. Warn against overloading with many edge-case examples. |
| `role-playing-prompting` | `support/library/curated/techniques.md` | Clarify that roles shape tone, posture, and boundaries, but do not substitute for grounding or factual evidence. Add a contraindication for domain-mismatched personas. |
| `structured-output-steering` | `support/library/curated/techniques.md` | Reframe around sectioned information architecture rather than delimiter tricks alone. Link tightly to `json-schema-outputs` and `function-calling`. |
| `json-schema-outputs` | `support/library/curated/techniques.md` | Add a stronger note that schema-bound outputs are preferable to prompt-only formatting when downstream code depends on exact structure. |
| `function-calling` | `support/library/curated/terms.md` | Cluster with `json-schema-outputs`, `structured-outputs`, and `tool-use-prompting` as a schema-first tool surface instead of a formatting footnote. |
| `self-critique-prompting` | `support/library/curated/techniques.md` | Reframe as a lightweight single-model tactic. Point to `evaluator-optimizer-loop`, `prompt-based-evaluation`, and `llm-as-judge` for stronger evaluation workflows. |
| `prompt-caching` | `support/library/curated/terms.md` | Link to `long-context-layout` and proposed `compaction` so cache-aware layout is treated as part of context-state design, not a standalone optimization footnote. |
| `long-context-layout` | `support/library/curated/techniques.md` | Add carry-forward and trimming guidance. Cross-link to proposed `compaction`. |
| `prompt-engineering-and-development` | imported support record | Recast as a subset of `context-engineering`. Add prompt versioning, authority layers, eval linkage, and failure-case tracking. Consider graduating it into curated `terms.md` once the new umbrella term exists. |

## Optional Tag Additions

Add these capability tags when the new records land:

- `context_engineering`
- `memory_management`
- `context_compaction`
- `judge_evaluation`
- `workflow_routing`
- `protocol_tools`
- `protocol_agents`
- `reusable_instructions`
- `durable_repo_instructions`
- `multi_agent`
- `reasoning_budget`
- `interleaved_thinking`
- `agent_legibility`
- `stop_conditions`

## Keep Deferred

These should stay out of the deterministic driver layer for now:

- tree-search agents
- full multi-agent "teams" as default recommendations
- broad prompt-security or red-team content
- standards-landscape winner claims

## Eval Notes For The Dev

Before promoting any new support records into core, add eval cases for:

- context compaction and carry-forward summaries
- judge-with-rubric evaluation flows
- routing and branch selection
- tool preambles and explicit stop conditions
- MCP/tool-context terminology retrieval
- cache-aware prompt layout

The desired outcome is not a bigger KB. The desired outcome is a Prompt Compass
that stays current while remaining selective about what actually drives its
prompt advice.
