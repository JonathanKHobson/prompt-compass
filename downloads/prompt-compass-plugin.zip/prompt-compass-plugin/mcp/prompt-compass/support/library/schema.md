# Prompt Compass KB Authoring Schema

This file defines the human-authored source schema for Prompt Compass Phase 1
knowledge-base records.

It is the source-of-truth schema for records authored in:

- `support/library/curated/frameworks.md`
- `support/library/curated/strategies.md`
- `support/library/curated/patterns.md`
- `support/library/curated/anti_patterns.md`
- `support/library/curated/techniques.md`
- `support/library/curated/terms.md`
- `support/library/curated/questions.md`
- `support/library/curated/model_profiles.md`

The authoring schema is intentionally stricter and more human-readable than the
current compiled runtime JSON. The compiler will map these authoring fields into
the runtime record format used by the SQLite KB and tool layer.

## Record Block Format

Each record is authored as:

````md
## Display Title

```yaml
id: example-slug
title: Example Title
record_type: framework
...
```
````

Rules:

- One `##` heading per record.
- One fenced YAML block immediately under the heading.
- Every required field for that record type must be present.
- No placeholder values such as `TODO`, `TBD`, `later`, or empty required keys.
- `id` is the canonical lookup slug in authoring files.

## Runtime Mapping

The compiler maps authoring fields to runtime fields as follows:

| Authoring field | Runtime field | Rule |
| --- | --- | --- |
| `id` | `entry_id` + `slug` | `entry_id` becomes `pc:{record_type}:{id}` and `slug` becomes `id` |
| `title` | `name` | copied directly |
| `summary` | `summary` | copied if present; otherwise derived from `description` |
| `description` | `definition` | copied directly |
| `template` | `template` | copied directly |
| `source_refs[]` | `source_refs[]` | compiler wraps string refs into runtime source objects |
| all other authored keys | runtime extras | preserved for ranking, matching, and tool payloads |

## Shared Enums And Formats

### `record_type` and `corpus_zone`

Allowed values:

- `framework`
- `strategy`
- `pattern`
- `anti_pattern`
- `technique`
- `term`
- `question`
- `model_profile`

Rule:

- `corpus_zone` must mirror `record_type` exactly.

### `source_tier`

Allowed values:

- `manual_core`
- `house_curated`
- `aiglossary_curated`
- `supporting_term`

### `curation_status`

Allowed values:

- `core`
- `supporting`
- `excluded`

### `phase`

Allowed values:

- `1`
- `2`

### `prompt_types[]`

Allowed values:

- `reductive`
- `transformative`
- `generative`

### `interaction_mode`

Allowed values:

- `single_turn`
- `multi_turn`
- `tool_calling`
- `agentic`
- `multimodal`

### `output_mode`

Allowed values:

- `freeform`
- `structured`
- `schema_bound`

### `grounding_mode`

Allowed values:

- `none`
- `source_pack`
- `retrieval`
- `quote_first`

### `evaluation_mode`

Allowed values:

- `none`
- `rubric`
- `grader`
- `comparison`

### `question_category`

Allowed values:

- `audience`
- `output_contract`
- `scope`
- `deliverable`
- `model_target`
- `context_depth`
- `trait_ranking`
- `success_test`
- `runtime_layer`
- `grounding`
- `parser_contract`
- `evaluation`
- `agent_control`
- `tool_use`
- `source_priority`

### `answer_type`

Allowed values:

- `short_text`
- `long_text`
- `single_select`
- `multi_select`
- `json`

### `verbosity_default`

Allowed values:

- `low`
- `medium`
- `medium_high`
- `high`

### `context_reading`

Allowed values:

- `literal`
- `moderate`
- `strong`

### `instruction_tolerance`

Allowed values:

- `low`
- `medium`
- `high`

### `tool_fit`

Required object shape:

```yaml
tool_fit:
  analyze: 0
  improve: 0
  build: 0
  target: 0
  search: 0
```

Rules:

- All five keys are required on every record.
- Each value must be an integer from `0` to `5`.
- `0` means irrelevant to that tool.
- `5` means highly influential for that tool.

### `id`

Format:

- lowercase kebab-case slug
- letters, numbers, and hyphens only
- unique within the full Prompt Compass corpus

Examples:

- `golden-circle`
- `one-primary-deliverable-narrowing`
- `missing-success-test`

### `related_entry_ids[]`

Format:

- list of canonical record `id` slugs
- each referenced slug must exist in the curated corpus or imported support corpus

### `source_refs[]`

Format:

- list of strings
- each string must be either:
  - an absolute local file path, or
  - a stable URL

### `triggers_when[]`

Format:

- list of machine-readable trigger strings
- allowed trigger prefixes:
  - `missing:`
  - `anti_pattern:`
  - `prompt_type:`
  - `subject_area:`
  - `model_target:`
  - `raccca:`
  - `output_contract:`
  - `trait_stack:`

Examples:

- `missing:output_contract`
- `anti_pattern:stacked-adjectives`
- `prompt_type:generative`
- `raccca:clarity<=2`

### `capability_tags[]`

Format:

- list of lowercase capability slugs
- every tag must exist in `support/taxonomy/capability-tags.json`
- authored records may list only the tags they explicitly support; the compiler
  may add inferred tags from text during runtime normalization

Examples:

- `structured_output`
- `json_schema`
- `context_engineering`
- `untrusted_context`

## Shared Fields

These fields apply to every authored record unless otherwise noted.

| Field | Data type | Allowed values / format | Required | Purpose |
| --- | --- | --- | --- | --- |
| `id` | `string` | unique kebab-case slug | required | Canonical authoring slug and lookup key. |
| `title` | `string` | human-readable display title | required | Primary display name for the record. |
| `record_type` | `string` | one of the 8 allowed record types | required | Declares the semantic type of the record. |
| `source_tier` | `string` | `manual_core`, `house_curated`, `aiglossary_curated`, `supporting_term` | required | Sets trust and base ranking weight. |
| `corpus_zone` | `string` | must exactly match `record_type` | required | Controls search routing and corpus partitioning. |
| `tool_fit` | `object` | integers `0-5` for `analyze`, `improve`, `build`, `target`, `search` | required | Encodes how strongly the record should influence each tool. |
| `search_weight` | `integer` | `0-30` | required | Fine-grained rerank weight inside the source tier. |
| `curation_status` | `string` | `core`, `supporting`, `excluded` | required | Marks whether the record drives workflows, supports lookup, or is excluded. |
| `curation_note` | `string` | one concise sentence | required | States why the record belongs in Prompt Compass. |
| `summary` | `string` | 1-2 sentence card summary | optional | Provides a short preview for search cards and exact lookups. |
| `description` | `string` | full prose definition | required | Explains the record in usable detail. |
| `aliases` | `string[]` | alternate names, user phrasings, or legacy slugs | required | Supports exact and fuzzy lookup resolution. |
| `related_entry_ids` | `string[]` | canonical slugs | required | Links the record to nearby concepts for reranking and explanation. |
| `source_refs` | `string[]` | absolute file paths or stable URLs | required | Preserves provenance for every authored record. |
| `template` | `string` | copy-paste prompt scaffold or prompt pattern | optional | Gives the user a ready-to-use implementation form. |
| `tags` | `string[]` | lowercase keyword tags | required | Improves search, grouping, and filtering. |
| `phase` | `integer` | `1` or `2` | required | Declares which product phase ships the record. |
| `prompt_types` | `string[]` | `reductive`, `transformative`, `generative` | required | States which prompt task types the record best supports. |
| `subject_areas` | `string[]` | lowercase slugs such as `general`, `writing`, `coding`, `research`, `strategy` | required | Helps rank records by domain fit. |
| `model_targets` | `string[]` | `generic` or supported model ids | required | Declares whether the record is generic or model-specific. |
| `signals` | `string[]` | short retrieval or matching cues | required | Lists cues that suggest the record should match. |
| `contraindications` | `string[]` | short "do not use when..." statements | required | Prevents inappropriate matching or overuse. |
| `interaction_mode` | `string` | `single_turn`, `multi_turn`, `tool_calling`, `agentic`, `multimodal` | optional | Adds the primary interaction pattern for search and matching. |
| `output_mode` | `string` | `freeform`, `structured`, `schema_bound` | optional | Adds the dominant response-shape mode for search and matching. |
| `grounding_mode` | `string` | `none`, `source_pack`, `retrieval`, `quote_first` | optional | Adds the primary grounding pattern for search and matching. |
| `evaluation_mode` | `string` | `none`, `rubric`, `grader`, `comparison` | optional | Adds the evaluation posture for search and matching. |
| `capability_tags` | `string[]` | lowercase capability slugs defined in `support/taxonomy/capability-tags.json` | optional | Adds prompt-primitive and runtime-control tags used for broad KB lookup and ranking. |

## Optional Shared Enrichment Fields

These fields are optional across record types but may be present when useful.

| Field | Data type | Allowed values / format | Required | Purpose |
| --- | --- | --- | --- | --- |
| `examples` | `object[]` | objects with `before`, `after`, and optional `notes` | optional | Provides worked examples for search cards and rewrites. |
| `notes` | `string` | short implementation or usage note | optional | Captures a narrow caveat that does not belong in `description`. |

## Type-Specific Fields

### Framework Records

Required when `record_type: framework`.

| Field | Data type | Allowed values / format | Required | Purpose |
| --- | --- | --- | --- | --- |
| `framework_components` | `string[]` | ordered component names or abbreviations | required | Lists the named parts of the framework. |
| `when_to_use` | `string[]` | short usage conditions | required | States when the framework is a strong fit. |
| `required_slots` | `string[]` | prompt-contract slot names such as `objective`, `audience`, `output_contract` | required | Tells the runtime which prompt slots the framework depends on. |
| `output_shapes` | `string[]` | artifact types such as `memo`, `table`, `plan`, `brief` | required | Indicates the response shapes the framework helps structure. |

### Strategy Records

Required when `record_type: strategy`.

| Field | Data type | Allowed values / format | Required | Purpose |
| --- | --- | --- | --- | --- |
| `goal_fit` | `string[]` | short job labels such as `diagnose`, `improve`, `build`, `target` | required | States which user goals the strategy best serves. |
| `works_best_for` | `string[]` | short fit conditions | required | Describes the situations where the strategy is strongest. |
| `apply_order` | `integer` | positive integer, lower means earlier | required | Controls recommended application order in multi-strategy flows. |

### Pattern Records

Required when `record_type: pattern`.

| Field | Data type | Allowed values / format | Required | Purpose |
| --- | --- | --- | --- | --- |
| `failure_mode` | `string` | one concise paragraph | required | Explains what goes wrong when the pattern is applied badly. |
| `better_version` | `string` | corrected behavior description | required | States the improved version of the pattern behavior. |

### Anti-Pattern Records

Required when `record_type: anti_pattern`.

| Field | Data type | Allowed values / format | Required | Purpose |
| --- | --- | --- | --- | --- |
| `what_it_looks_like` | `string` | concrete example sentence or behavior | required | Makes the anti-pattern recognizable in user drafts. |
| `fix` | `string` | one or two sentences | required | Gives the corrective move to resolve the anti-pattern. |
| `detection_signal` | `string` | short machine-usable or human-readable trigger description | required | States what prompt evidence should cause the anti-pattern to flag. |
| `severity_default` | `string` | `low`, `medium`, or `high` | required | Sets the default diagnostic severity. |

### Technique Records

Required when `record_type: technique`.

| Field | Data type | Allowed values / format | Required | Purpose |
| --- | --- | --- | --- | --- |
| `tactic_type` | `string` | short single-move label such as `framing`, `calibration`, `compression`, `grounding` | required | Confirms the record is a tactic, not a full strategy. |
| `expected_effect` | `string` | one concise sentence | required | States the immediate outcome the technique should produce. |

### Term Records

Required when `record_type: term`.

| Field | Data type | Allowed values / format | Required | Purpose |
| --- | --- | --- | --- | --- |
| `term_kind` | `string` | short label such as `concept`, `artifact`, `failure-mode`, `system-part` | required | Distinguishes glossary support terms from actionable records. |

### Question Records

Required when `record_type: question`.

| Field | Data type | Allowed values / format | Required | Purpose |
| --- | --- | --- | --- | --- |
| `slot` | `string` | canonical prompt-contract slot such as `objective`, `audience`, `output_contract`, `constraints` | required | Maps the answer back into the prompt contract. |
| `question_text` | `string` | exact user-facing wording | required | Stores the exact question the host AI should ask. |
| `triggers_when` | `string[]` | machine-readable trigger strings | required | Declares when this question should surface. |
| `question_category` | `string` | one of the 15 allowed categories | required | Groups the question by what gap it addresses. |
| `sequence_priority` | `integer` | `1-5`, lower means earlier | required | Orders the question inside the bounded question loop. |
| `answer_type` | `string` | `short_text`, `long_text`, `single_select`, `multi_select`, `json` | required | Declares the expected answer shape. |
| `choices` | `string[]` | explicit options for select-style questions | optional | Provides selectable values when the question is not free-text. |
| `on_skip` | `string` | short fallback behavior | optional | States what the runtime should assume if the user skips the question. |

### Model Profile Records

Required when `record_type: model_profile`.

| Field | Data type | Allowed values / format | Required | Purpose |
| --- | --- | --- | --- | --- |
| `model_id` | `string` | canonical model slug such as `claude-sonnet` or `gpt-4o` | required | Stores the exact model identifier for targeting and lookup. |
| `verbosity_default` | `string` | `low`, `medium`, `medium_high`, `high` | required | States the model's typical response verbosity. |
| `context_reading` | `string` | `literal`, `moderate`, `strong` | required | Rates how well the model infers unstated intent from context. |
| `instruction_tolerance` | `string` | `low`, `medium`, `high` | required | Rates how much instruction density the model handles reliably. |
| `tool_agent_support` | `boolean` | `true` or `false` | required | States whether the model supports tool use or agent workflows. |
| `prompting_style_preference` | `string` | 2-3 sentences | required | Explains what prompt style works well for this model specifically. |
| `known_failure_modes` | `string[]` | 2 or more short bullets | required | Lists model-specific prompting pitfalls to avoid. |
| `recommended_strategies` | `string[]` | canonical slugs from frameworks, strategies, or patterns | required | Recommends the records that pair especially well with this model. |

## Required Field Matrix By Record Type

This matrix is the validation rule for later files.

| Record type | Required shared fields | Required type-specific fields |
| --- | --- | --- |
| `framework` | all shared fields except `summary` and `template` optionality rule; in Phase 1 frameworks will populate `template` | `framework_components`, `when_to_use`, `required_slots`, `output_shapes` |
| `strategy` | all shared fields; in Phase 1 strategies will populate `template` | `goal_fit`, `works_best_for`, `apply_order` |
| `pattern` | all shared fields; in Phase 1 patterns will populate `template` | `failure_mode`, `better_version` |
| `anti_pattern` | all shared fields | `what_it_looks_like`, `fix`, `detection_signal`, `severity_default` |
| `technique` | all shared fields; in Phase 1 techniques will populate `template` | `tactic_type`, `expected_effect` |
| `term` | all shared fields | `term_kind` |
| `question` | all shared fields except `template` optional | `slot`, `question_text`, `triggers_when`, `question_category`, `sequence_priority`, `answer_type` |
| `model_profile` | all shared fields except `template` optional | `model_id`, `verbosity_default`, `context_reading`, `instruction_tolerance`, `tool_agent_support`, `prompting_style_preference`, `known_failure_modes`, `recommended_strategies` |

## Validation Rules

- `id` must be globally unique across all curated files.
- `aliases[]` must not contain duplicates or the same value as `id`.
- `search_weight` must be intentionally differentiated; do not use the same value
  for every record in a file.
- `tool_fit` values must reflect actual use; avoid blanket `5` values.
- `phase: 1` is required for every Phase 1 curated record in Steps 2-8.
- `source_tier` and `curation_status` must agree with the record's role in the
  corpus.
- Records marked `excluded` may appear only in the manifest or imported-support
  appendix, not in the curated core record files.
- `recommended_strategies[]` and `related_entry_ids[]` must reference real
  canonical slugs.
- `question` records must use `sequence_priority` so output-contract and
  deliverable questions can be asked first.
- `model_profile` records must not reference Phase 2 models in Phase 1 files.

## Imported Support Metadata

Phase 1.5 adds a second authoring surface for AIGlossary-derived support
records:

- `support/library/imports/aiglossary_support_catalog.md`
- `support/library/imports/aiglossary_exclusions.md`

These imported support records do not use the curated YAML-per-record format.
They are compiled from AIGlossary source JSON plus manual decision metadata.

Imported support records carry these extra runtime fields:

| Field | Data type | Purpose |
| --- | --- | --- |
| `decision` | `string` | `support_only`, `promote_to_core`, or `graduated_core` from the import catalog. |
| `family` | `string` | Search/ranking family such as `evaluation_reflection` or `context_grounding`. |
| `origin_bucket` | `string` | Path-derived source bucket such as `methodology_audit` or `other_adjacent`. |
| `driver_eligible` | `boolean` | Whether the record may steer deterministic workflows. In Phase 1.7 this stays `false` unless the import decision is `graduated_core`. |
| `ambiguity_status` | `string` | Notes whether the record is clear, alias-guarded, overlap-guarded, or normalized from an unknown source kind. |
| `weight_reason` | `string` | Human-authored reason for the record’s search weight and placement. |
| `promotion_queue` | `boolean` | Marks records tagged `promote_to_core` that still remain runtime-supporting in Phase 1.7. |
| `source_kind` | `string` | The original AIGlossary `kind` before Prompt Compass normalization. |
| `relative_source_path` | `string` | The source JSON path inside the AIGlossary normalized corpus. |

## Authoring Guidance

- Prefer short, functional aliases over exhaustive alias dumps.
- Keep `curation_note` concrete: say why the record helps Prompt Compass.
- Write `description` for action, not glossary ornament.
- Use `template` whenever a user should be able to paste and use the record
  immediately.
- Use `contraindications` to stop overly broad matching.
