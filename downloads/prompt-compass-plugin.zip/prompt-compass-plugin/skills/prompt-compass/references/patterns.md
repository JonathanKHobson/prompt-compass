# Prompt Compass Pattern Reference

Use this file only when the MCP is unavailable or when explaining why a Prompt
Compass diagnosis makes sense.

## 1. Prompt Refinement First

Use when there is already a draft prompt and the user wants it improved.

- Signal: "improve this prompt," "make this better," "keep the intent."
- Failure mode: the wrapper request competes with the draft.
- Repair: name one returned artifact, state how much wording to preserve, add an
  output contract.

## 2. Intent Dump + Constraint Sweep

Use when the input is a voice memo, dictation, or stream-of-consciousness brief.

- Signal: pivots, "also," "I think," multiple goals, weak ending ask.
- Failure mode: every idea is treated as equally important.
- Repair: extract objective, must-haves, nice-to-haves, exclusions, and one
  primary deliverable before writing the prompt.

## 3. Role Framing as Shortcut

Use when a role or persona is meant to import expertise.

- Signal: "act as," "you are a," long expert persona paragraphs.
- Failure mode: the role becomes performance theater and crowds out the task.
- Repair: role in one line, deliverable immediately after.

## 4. Trait-Stack Output Control

Use when the user lists many desired qualities.

- Signal: "clear, deep, concise, comprehensive, polished..."
- Failure mode: conflicting traits create bland compromise.
- Repair: rank the top three traits and state what can be sacrificed.

## 5. Multi-Axis Organizing Prompt

Use when content must be sorted, grouped, or prioritized across multiple axes.

- Signal: "sort by X and Y," "group by category and priority."
- Failure mode: missing tie-breaks make order drift across runs.
- Repair: primary axis, secondary axis, tie-break rule, and display shape.

## 6. Research/Profile Deep-Dive

Use when the prompt asks for synthesis across a body of material.

- Signal: "synthesize," "analyze patterns," "what do you see?"
- Failure mode: profile, diagnosis, and plan blur into a sprawling essay.
- Repair: choose one artifact: profile, diagnosis, or next-step plan.

## 7. Iterative Clarification

Use when a previous answer is being refined.

- Signal: "keep this but change that," "same thing but tighter."
- Failure mode: follow-ups add constraints without protecting what worked.
- Repair: state the delta and list non-negotiables.

## 8. Context Injection via Source Pack

Use when source material is pasted before or after the task.

- Signal: long documents, transcripts, notes, or datasets.
- Failure mode: the source is rich but the transformation request is vague.
- Repair: name exactly what to extract, transform, preserve, and ignore.

## 9. Specification by Example

Use when a reference output should guide a new output.

- Signal: "make one like this," "same format," "match this style."
- Failure mode: the model copies the wrong things or ignores the example.
- Repair: state whether the example governs structure, tone, depth, or all
  three, then list what to preserve and what to change.

## 10. Compression After Expansion

Use when the user wants broad exploration and practical convergence.

- Signal: "brainstorm widely, then pick," "explore all angles."
- Failure mode: expansion happens but compression never arrives.
- Repair: request expansion and compression in the same turn.

## Cross-Pattern Repairs

- Intent dump + trait stack: extract one deliverable, rank traits, add output
  contract.
- Role framing + instruction wall: cut role to one line, keep top constraints.
- Source pack + vague transformation: name exact extraction targets.
- Iterative follow-up + drift: preserve non-negotiables and change only the
  requested delta.

## Universal Anti-Patterns

| Anti-pattern | Symptom | Repair |
|---|---|---|
| Ghost audience | no reader is named | define the audience |
| Hallucination bait | factual work without grounding | add sources or citation rules |
| Instruction wall | too many unranked constraints | rank and cut |
| Premature format lock | format before goal | goal first, format second |
| Role collapse | persona contradicts work | role short, deliverable drives |
| Stacked adjectives | unranked quality traits | rank top three |
| Missing output contract | no format, length, success test | add all three |
