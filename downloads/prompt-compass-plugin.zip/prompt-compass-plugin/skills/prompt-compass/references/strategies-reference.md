# Prompt Compass Strategies Reference

This file supports manual fallback and explanation. It should not replace the
Prompt Compass MCP workflow when the MCP is available.

## Context Delivery

| Strategy | Use when | Key move |
|---|---|---|
| Goal prompting | almost always | state what done looks like |
| WHY prompting | purpose matters | explain situation and motivation |
| Persona prompting | expertise matters | one-line role, then task |
| Keyword prompting | domain precision matters | include domain terms and definitions |
| Contextual absences | anchoring is risky | withhold the user's hypothesis |
| Source grounding | factual accuracy matters | provide sources and citation rules |

## Structure

| Strategy | Use when | Key move |
|---|---|---|
| Template prompting | recurring deliverables | provide fields and order |
| Delimiters | long inputs | separate instructions from source material |
| XML tags | Claude prompts | isolate sections such as `<source>` and `<task>` |
| Example prompting | format fidelity matters | provide 1-3 examples and say what they govern |
| Constraint-based prompting | scope can sprawl | state length, audience, exclusions, and success test |

## Quality And Reasoning

| Strategy | Use when | Key move |
|---|---|---|
| Reflection | validation matters | ask for checks before final answer |
| Deliberative prompting | complex reasoning | ask for a careful process without demanding hidden chain-of-thought |
| Negative avoidance | steering away from bad style | describe the positive target instead of only saying "do not" |
| Trait ranking | multiple qualities matter | rank top traits and define sacrifice order |
| Skeptical review | blind spots matter | ask what a rigorous reviewer would challenge |

## RACCCA

Use RACCCA to evaluate output quality:

- Relevance: directly addresses the question or task.
- Accuracy: grounded, factual, and contradiction-aware.
- Completeness: covers essential context and constraints.
- Clarity: easy to understand on first read.
- Coherence: logically organized and internally consistent.
- Appropriateness: fits audience, tone, stakes, and surface.

For high-stakes factual work, weight Accuracy higher. For public copy, weight
Appropriateness and Clarity higher.

## Iteration Tactics

- Accordion editing: specify what can shrink, expand, or stay fixed.
- Apple picking: preserve the strongest pieces from a previous answer.
- Delta-only revision: name the exact change instead of reopening the full brief.
- Compression after expansion: ask for broad exploration and a compact artifact
  in the same turn.
- Counterexample repair: provide what not to do, then translate it into a
  positive target.

## Debugging Questions

Use one question at a time:

- What did the model assume that the prompt never said?
- What is the one primary deliverable?
- Who is the audience?
- What must the answer preserve?
- What can be sacrificed if traits conflict?
- What exact format and success test should close the prompt?

## Sayings Worth Keeping

- Put smart, get smart.
- Easy for you, easy for it.
- The model is a divergent intern.
- Context before compression.
- Format should serve the task, not precede it.
