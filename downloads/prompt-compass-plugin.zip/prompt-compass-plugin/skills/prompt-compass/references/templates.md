# Prompt Compass Template Reference

These are manual fallback templates. When the MCP is available, use
`route_prompt_request` and the routed workflow first.

## Prompt Refinement First

```text
Refine the prompt below without changing its core intent. Preserve wording that
carries important tone or meaning. Improve structure, sequencing, constraints,
and output instructions.

Return:
1. The tightened prompt
2. The main ambiguities removed
3. Any assumptions that remain

Output contract: Format = code block + brief notes | Length = tightened prompt
no longer than the original unless needed | Success test = intent preserved and
instructions clearer

Prompt:
[paste draft]
```

## Voice Memo / Intent Dump Cleanup

```text
Turn the raw brief below into a clean working prompt.

First extract:
- Core objective in one sentence
- Must-haves, ranked
- Nice-to-haves
- Exclusions / out-of-scope
- One primary deliverable
- Audience
- Success test

Then write the prompt using WHY -> WHAT -> HOW and end with an output contract.

Output contract: Format = extraction table + improved prompt | Length =
extraction <= 1 page | Success test = one primary deliverable named and tradeoffs
made explicit

Raw brief:
[paste brief]
```

## Role Framing

```text
Act as a [role] with strong judgment in [domain]. Help produce one concrete
deliverable: [deliverable].

Context:
[3-5 lines max]

Return:
1. [deliverable]
2. Key reasoning
3. Biggest risk or blind spot

Output contract: Format = [format] | Length = [limit] | Success test = [what
good looks like from this expert perspective]
```

## Trait-Stack Control

```text
Complete the task for [audience].

Optimize for these traits in priority order:
1. [most important trait]
2. [second trait]
3. [third trait]

Avoid:
- [anti-trait]
- [anti-trait]

If traits conflict, sacrifice #3 before #2 and #2 before #1.

Task: [task]

Output contract: Format = [format] | Length = [limit] | Success test = trait #1
is clearly dominant
```

## Source-Pack Synthesis

```text
Use the source material below as the primary basis for your answer. Do not
generalize beyond the evidence unless you label it as an inference.

Task: [specific extraction or transformation]

Extract or transform:
- [target 1]
- [target 2]
- [target 3]

Rules:
- Ground claims in the source
- Flag gaps instead of filling them
- Surface contradictions if the source conflicts with itself

Output contract: Format = [format] | Length = [limit] | Success test = every
claim is traceable to the source or labeled as inference

Source pack:
[source material]
```

## Specification by Example

```text
Use the example below as a reference for [structure / tone / depth / all three].
Do not copy its content directly.

Preserve:
- [element]
- [element]

Change:
- [element]
- [element]

Task: [new task]

Output contract: Format = match the intended example dimension | Length =
similar to the example | Success test = new output feels like the example's
sibling, not its clone

Example:
[example]
```

## Universal Output Contract

```text
Output contract:
- Format: [exact structure]
- Length: [word count, bullet count, page limit, or time limit]
- Success test: [observable criterion that separates done from not done]
```
