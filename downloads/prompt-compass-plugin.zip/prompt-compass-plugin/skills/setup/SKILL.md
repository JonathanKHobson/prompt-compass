---
name: setup
description: Diagnose Prompt Compass plugin or MCP setup issues after install.
---

# Prompt Compass Setup Helper

Use this only when Prompt Compass was installed as a plugin, MCPB/Desktop
extension, or local MCP source and the host cannot see or call the expected
tools.

Work conservatively:

1. Identify the client: Claude Desktop, Claude Code, Claude Cowork, Codex, or
   another host.
2. Ask whether the user installed the plugin zip, MCPB/Desktop extension, skill,
   or raw source zip.
3. Confirm the expected tool surface includes `prompt_compass_overview`,
   `get_started`, `route_prompt_request`, `improve_prompt`, and `build_prompt`.
4. If MCP tools are unavailable but this skill is active, explain that the skill
   can provide guidance but cannot call the local MCP by itself.
5. Do not delete or rewrite unrelated host config.
6. Recommend one recovery step at a time: restart host, verify plugin enabled,
   inspect `.mcp.json`, or reinstall the package.

Expected first smoke prompt:

```text
Use Prompt Compass and call get_started.
```

If the user is using only the skill, use the manual fallback in the Prompt
Compass skill and state that MCP-backed tools are not active.
